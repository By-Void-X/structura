// Host tests (g++, no game): shared transform pipeline, raw state preservation, progress model, layers.
// Oracle = GEOMETRY: an expected transformed direction is derived from localToWorld (the position mapping the
// hologram and Easy Place use), never from the transform tables under test.
//   (after scripts/build.sh generated build/block_pack.zip and build/java_map.bin)
//   gcc -c -Wa,-Ibuild src/BlockPack.S -o /tmp/bp.o
//   g++ -std=c++20 -O1 -Isrc tests/host_test.cpp src/BlockStates.cpp src/Structure.cpp src/Nbt.cpp src/JavaFormats.cpp
//       src/Transformed.cpp src/Progress.cpp /tmp/bp.o -lz -o /tmp/host_test && /tmp/host_test
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <set>
#include <string>
#include <vector>

#include "BlockStates.hpp"
#include "JavaFormats.hpp"
#include "Nbt.hpp"
#include "Progress.hpp"
#include "State.hpp"
#include "Structure.hpp"
#include "Transformed.hpp"

namespace lm {
Settings &settings() { static Settings s; return s; }
Model &model() { static Model m; return m; }
}  // namespace lm

using namespace lm;
namespace st = lm::states;

static int gPass = 0, gFail = 0;
#define CHECK(c, ...)                                         \
  do {                                                        \
    if (c) ++gPass;                                           \
    else {                                                    \
      ++gFail;                                                \
      if (gFail <= 60) {                                      \
        std::printf("FAIL %s:%d: %s | ", __FILE__, __LINE__, #c); \
        std::printf(__VA_ARGS__);                             \
        std::printf("\n");                                    \
      }                                                       \
    }                                                         \
  } while (0)

// ---------------------------------------------------------------- geometry oracle
// cardinal: 0 N(-z) 1 E(+x) 2 S(+z) 3 W(-x)
static const int kVx[4] = {0, 1, 0, -1}, kVz[4] = {-1, 0, 1, 0};
static const char *kCardName[4] = {"north", "east", "south", "west"};

static Structure box(int sx, int sy, int sz) {
  Structure s;
  s.sx = sx; s.sy = sy; s.sz = sz;
  return s;
}
// world cardinal of a local cardinal under (rot, mirror), measured with localToWorld on a non-square box
static int worldCard(int c, int rot, bool mirror) {
  Structure s = box(5, 2, 7);
  Placement p;
  p.ox = 100; p.oy = -64; p.oz = -50; p.rot = rot; p.mirror = mirror;
  int ax, ay, az, bx, by, bz;
  localToWorld(s, p, 2, 0, 3, ax, ay, az);
  localToWorld(s, p, 2 + kVx[c], 0, 3 + kVz[c], bx, by, bz);
  for (int k = 0; k < 4; ++k)
    if (bx - ax == kVx[k] && bz - az == kVz[k]) return k;
  return -1;
}
// world vector of a local (float) vector: linear part of localToWorld, measured from two points
static void worldVec(float vx, float vz, int rot, bool mirror, float &wx, float &wz) {
  const int ex = worldCard(1, rot, mirror), sz = worldCard(2, rot, mirror);  // images of +x and +z
  wx = vx * kVx[ex] + vz * kVx[sz];
  wz = vx * kVz[ex] + vz * kVz[sz];
}

static BlockStateValue I(const char *k, int v) { BlockStateValue s; s.key = k; s.type = 3; s.i = v; return s; }
static BlockStateValue B(const char *k, int v) { BlockStateValue s; s.key = k; s.type = 1; s.i = v; return s; }
static BlockStateValue S(const char *k, const char *v) { BlockStateValue s; s.key = k; s.type = 8; s.s = v; return s; }
static const BlockStateValue *find(const std::vector<BlockStateValue> &v, const char *k) {
  for (auto &s : v)
    if (s.key == k) return &s;
  return nullptr;
}

// int-encoded direction tables (value -> cardinal), the in-game verified ones
struct Enc { const char *name; int n; int toC[6]; };
static const Enc kDoor{"door", 4, {1, 2, 3, 0}};          // 0 E 1 S 2 W 3 N
static const Enc kTrap{"trapdoor", 4, {1, 3, 2, 0}};      // 0 E 1 W 2 S 3 N
static const Enc kGeneric{"direction", 4, {2, 3, 0, 1}};  // 0 S 1 W 2 N 3 E
static const Enc kStair{"weirdo", 4, {1, 3, 2, 0}};       // 0 E 1 W 2 S 3 N
static const Enc kCoral{"coral", 4, {3, 1, 0, 2}};        // 0 W 1 E 2 N 3 S
static int dec(const Enc &e, int v) { return e.toC[v]; }
static int enc(const Enc &e, int c) {
  for (int i = 0; i < e.n; ++i)
    if (e.toC[i] == c) return i;
  return -1;
}
// facing_direction int: 0 down 1 up 2 N 3 S 4 W 5 E
static int f6ToC(int v) { return v == 2 ? 0 : v == 5 ? 1 : v == 3 ? 2 : v == 4 ? 3 : -1; }
static int cToF6(int c) { static const int k[4] = {2, 5, 3, 4}; return k[c]; }

// ---------------------------------------------------------------- 1. primitive transforms
static void testPrimitives() {
  for (int rot = 0; rot < 4; ++rot)
    for (int m = 0; m < 2; ++m) {
      const bool mir = m;
      for (int c = 0; c < 4; ++c) {
        const int w = worldCard(c, rot, mir);
        CHECK(st::transformFacing(c, rot, mir) == w, "card %d rot %d mir %d", c, rot, m);
        const char *nm = st::transformFacingName(kCardName[c], rot, mir);
        CHECK(nm && std::string(nm) == kCardName[w], "name %s rot %d mir %d -> %s", kCardName[c], rot, m, nm ? nm : "-");
        CHECK(st::transformFacing6(cToF6(c), rot, mir) == cToF6(w), "f6 %d rot %d mir %d", c, rot, m);
        for (const Enc *e : {&kDoor, &kTrap, &kGeneric, &kStair, &kCoral}) {
          const int v = enc(*e, c), want = enc(*e, w);
          int got = -9;
          if (e == &kStair) got = st::transformStairDirection(v, rot, mir);
          else if (e == &kCoral) got = st::transformCoralDirection(v, rot, mir);
          else if (e == &kDoor) got = st::transformDirection("oak_door", v, rot, mir);
          else if (e == &kTrap) got = st::transformDirection("spruce_trapdoor", v, rot, mir);
          else got = st::transformDirection("bed", v, rot, mir);
          CHECK(got == want, "%s v %d rot %d mir %d got %d want %d", e->name, v, rot, m, got, want);
        }
      }
      CHECK(st::transformFacing6(0, rot, mir) == 0 && st::transformFacing6(1, rot, mir) == 1, "f6 up/down");
      // bit sets: vine S1 W2 N4 E8, multi_face N4 S8 W16 E32 (+ D1 U2 kept)
      static const int vineBit[4] = {4, 8, 1, 2}, faceBit[4] = {4, 32, 8, 16};
      for (int mask = 0; mask < 16; ++mask) {
        int vin = 0, vw = 0, fin = 3, fw = 3;
        for (int c = 0; c < 4; ++c)
          if (mask & (1 << c)) {
            vin |= vineBit[c]; vw |= vineBit[worldCard(c, rot, mir)];
            fin |= faceBit[c]; fw |= faceBit[worldCard(c, rot, mir)];
          }
        CHECK(st::transformVineBits(vin, rot, mir) == vw, "vine %d rot %d mir %d", vin, rot, m);
        CHECK(st::transformFaceBits(fin, rot, mir) == fw, "face %d rot %d mir %d", fin, rot, m);
      }
      // sign rotation: r * 22.5 deg from south toward west: v = (-sin, cos)
      for (int r = 0; r < 16; ++r) {
        const double a = r * M_PI / 8;
        float wx, wz;
        worldVec(float(-std::sin(a)), float(std::cos(a)), rot, mir, wx, wz);
        int want = -1;
        for (int q = 0; q < 16; ++q) {
          const double b = q * M_PI / 8;
          if (std::fabs(-std::sin(b) - wx) < 1e-4 && std::fabs(std::cos(b) - wz) < 1e-4) want = q;
        }
        CHECK(st::transformSignRotation(r, rot, mir) == want, "sign %d rot %d mir %d", r, rot, m);
      }
      // rails: 0 NS, 1 EW, 2..5 ascending E W N S, 6..9 curves SE SW NW NE
      auto railCards = [](int v) -> std::set<int> {
        switch (v) {
          case 0: return {0, 2}; case 1: return {1, 3};
          case 2: return {1, 100}; case 3: return {3, 100}; case 4: return {0, 100}; case 5: return {2, 100};
          case 6: return {2, 1}; case 7: return {2, 3}; case 8: return {0, 3}; default: return {0, 1};
        }
      };
      for (int v = 0; v < 10; ++v) {
        std::set<int> want;
        for (int c : railCards(v)) want.insert(c == 100 ? 100 : worldCard(c, rot, mir));
        const int got = st::transformRailShape(v, rot, mir);
        CHECK(railCards(got) == want, "rail %d rot %d mir %d got %d", v, rot, m, got);
      }
      // axis
      CHECK(st::transformAxis("y", rot, mir) == "y", "axis y");
      CHECK(st::transformAxis("x", rot, mir) == ((rot & 1) ? "z" : "x"), "axis x rot %d", rot);
      CHECK(st::transformAxis("z", rot, mir) == ((rot & 1) ? "x" : "z"), "axis z rot %d", rot);
      // hinge flips with the mirror only; stair shape (Java style) left/right swap with the mirror only
      CHECK(st::transformHinge(0, rot, mir) == (mir ? 1 : 0), "hinge");
      CHECK(st::transformStairShape("inner_left", rot, mir) == (mir ? "inner_right" : "inner_left"), "shape");
      CHECK(st::transformStairShape("outer_right", rot, mir) == (mir ? "outer_left" : "outer_right"), "shape");
      CHECK(st::transformStairShape("straight", rot, mir) == "straight", "shape straight");
      // attachment faces follow the cardinal transform; floor/ceiling stay
      for (int c = 0; c < 4; ++c)
        CHECK(st::transformAttachment(kCardName[c], rot, mir) == kCardName[worldCard(c, rot, mir)], "attach %d", c);
      CHECK(st::transformAttachment(std::string("up"), rot, mir) == "up", "attach up");
      // connections (walls): the value of side c moves to worldCard(c)
      std::vector<BlockStateValue> w = {S("wall_connection_type_north", "tall"), S("wall_connection_type_east", "short"),
                                        S("wall_connection_type_south", "none"), S("wall_connection_type_west", "none"),
                                        B("wall_post_bit", 1)};
      const char *orig[4] = {"tall", "short", "none", "none"};
      st::transformConnections(w, rot, mir);
      for (int c = 0; c < 4; ++c) {
        const std::string k = std::string("wall_connection_type_") + kCardName[worldCard(c, rot, mir)];
        const auto *sv = find(w, k.c_str());
        CHECK(sv && sv->s == orig[c], "wall side %d rot %d mir %d", c, rot, m);
      }
      // a full turn and a double mirror are identities
      for (int c = 0; c < 4; ++c) {
        int x = c;
        for (int k = 0; k < 4; ++k) x = st::transformFacing(x, 1, false);
        CHECK(x == c, "4 turns");
        CHECK(st::transformFacing(st::transformFacing(c, 0, true), 0, true) == c, "2 mirrors");
      }
    }
}

// ---------------------------------------------------------------- 2. block families (full state lists)
struct Case {
  const char *name;
  std::vector<BlockStateValue> states;
  // checks run on the transformed list
};
static void expectCard(const std::vector<BlockStateValue> &t, const char *key, const Enc *e, int localCard, int rot,
                       bool mir, const char *blk) {
  const auto *sv = find(t, key);
  const int w = worldCard(localCard, rot, mir);
  if (!e) CHECK(sv && sv->s == kCardName[w], "%s %s rot %d mir %d got %s", blk, key, rot, int(mir), sv ? sv->s.c_str() : "-");
  else CHECK(sv && sv->i == enc(*e, w), "%s %s rot %d mir %d got %d want %d", blk, key, rot, int(mir), sv ? sv->i : -1,
             enc(*e, w));
}
static void expectF6(const std::vector<BlockStateValue> &t, const char *key, int localCard, int rot, bool mir,
                     const char *blk) {
  const auto *sv = find(t, key);
  CHECK(sv && sv->i == cToF6(worldCard(localCard, rot, mir)), "%s %s rot %d mir %d", blk, key, rot, int(mir));
}
static void expectSame(const std::vector<BlockStateValue> &orig, const std::vector<BlockStateValue> &t, const char *key,
                       const char *blk) {
  const auto *a = find(orig, key), *b = find(t, key);
  CHECK(a && b && a->i == b->i && a->s == b->s && a->type == b->type, "%s %s must be kept", blk, key);
}

static void testFamilies() {
  int families = 0;
  for (int rot = 0; rot < 4; ++rot)
    for (int m = 0; m < 2; ++m) {
      const bool mir = m;
      families = 0;
      auto run = [&](const char *name, std::vector<BlockStateValue> s, auto &&check) {
        ++families;
        const auto orig = s;
        const auto out = st::transformBlockState(s, rot, mir, name);
        CHECK(out.unknownDirectional.empty(), "%s: unknown directional %s", name,
              out.unknownDirectional.empty() ? "" : out.unknownDirectional[0].c_str());
        CHECK(s.size() == orig.size(), "%s: state count changed", name);
        for (auto &sv : orig) {
          bool known = false;
          st::ruleFor(sv.key, name, &known);
          CHECK(known, "%s: key %s has no rule", name, sv.key.c_str());
        }
        check(orig, s);
      };
      // stairs: weirdo_direction (local east), upside_down_bit kept
      run("oak_stairs", {I("weirdo_direction", 0), B("upside_down_bit", 1)}, [&](auto &o, auto &t) {
        expectCard(t, "weirdo_direction", &kStair, 1, rot, mir, "stairs");
        expectSame(o, t, "upside_down_bit", "stairs");
      });
      run("stone_brick_stairs", {I("weirdo_direction", 3), B("upside_down_bit", 0)}, [&](auto &, auto &t) {
        expectCard(t, "weirdo_direction", &kStair, 0, rot, mir, "stairs N");
      });
      // slabs: half kept
      run("oak_slab", {S("minecraft:vertical_half", "top")}, [&](auto &o, auto &t) {
        expectSame(o, t, "minecraft:vertical_half", "slab");
      });
      // doors (legacy int direction and the newer cardinal string), hinge flips with the mirror, part kept
      run("oak_door", {I("direction", 1), B("door_hinge_bit", 0), B("open_bit", 1), B("upper_block_bit", 0)},
          [&](auto &o, auto &t) {
            expectCard(t, "direction", &kDoor, 2, rot, mir, "door");
            CHECK(find(t, "door_hinge_bit")->i == (mir ? 1 : 0), "door hinge");
            expectSame(o, t, "open_bit", "door");
            expectSame(o, t, "upper_block_bit", "door");
          });
      run("iron_door", {S("minecraft:cardinal_direction", "west"), B("door_hinge_bit", 1), B("open_bit", 0),
                        B("upper_block_bit", 1)},
          [&](auto &, auto &t) {
            expectCard(t, "minecraft:cardinal_direction", nullptr, 3, rot, mir, "door str");
            CHECK(find(t, "door_hinge_bit")->i == (mir ? 0 : 1), "door hinge 1");
          });
      run("spruce_trapdoor", {I("direction", 2), B("open_bit", 0), B("upside_down_bit", 1)}, [&](auto &o, auto &t) {
        expectCard(t, "direction", &kTrap, 2, rot, mir, "trapdoor");
        expectSame(o, t, "upside_down_bit", "trapdoor");
      });
      run("stone_button", {I("facing_direction", 4), B("button_pressed_bit", 0)}, [&](auto &, auto &t) {
        expectF6(t, "facing_direction", 3, rot, mir, "button");
      });
      run("stone_button", {I("facing_direction", 1), B("button_pressed_bit", 0)}, [&](auto &, auto &t) {
        CHECK(find(t, "facing_direction")->i == 1, "button up kept");
      });
      run("lever", {S("lever_direction", "north"), B("open_bit", 0)}, [&](auto &, auto &t) {
        CHECK(find(t, "lever_direction")->s == kCardName[worldCard(0, rot, mir)], "lever wall rot %d", rot);
      });
      run("lever", {S("lever_direction", "up_north_south"), B("open_bit", 0)}, [&](auto &, auto &t) {
        CHECK(find(t, "lever_direction")->s == ((rot & 1) ? "up_east_west" : "up_north_south"), "lever floor rot %d", rot);
      });
      run("lever", {S("lever_direction", "down_east_west"), B("open_bit", 1)}, [&](auto &, auto &t) {
        CHECK(find(t, "lever_direction")->s == ((rot & 1) ? "down_north_south" : "down_east_west"), "lever ceil rot %d", rot);
      });
      run("standing_sign", {I("ground_sign_direction", 3)}, [&](auto &, auto &t) {
        CHECK(find(t, "ground_sign_direction")->i == st::transformSignRotation(3, rot, mir), "sign");
      });
      run("wall_sign", {I("facing_direction", 2)}, [&](auto &, auto &t) { expectF6(t, "facing_direction", 0, rot, mir, "wall sign"); });
      run("oak_hanging_sign", {I("facing_direction", 5), I("ground_sign_direction", 6), B("attached_bit", 0), B("hanging", 1)},
          [&](auto &o, auto &t) {
            expectF6(t, "facing_direction", 1, rot, mir, "hanging sign");
            CHECK(find(t, "ground_sign_direction")->i == st::transformSignRotation(6, rot, mir), "hanging sign rot");
            expectSame(o, t, "hanging", "hanging sign");
          });
      run("oak_log", {S("pillar_axis", "x")}, [&](auto &, auto &t) {
        CHECK(find(t, "pillar_axis")->s == ((rot & 1) ? "z" : "x"), "log");
      });
      run("rail", {I("rail_direction", 6)}, [&](auto &, auto &t) {
        CHECK(find(t, "rail_direction")->i == st::transformRailShape(6, rot, mir), "rail");
      });
      run("golden_rail", {I("rail_direction", 2), B("rail_data_bit", 0)}, [&](auto &, auto &t) {
        CHECK(find(t, "rail_direction")->i == st::transformRailShape(2, rot, mir), "golden rail");
      });
      run("unpowered_repeater", {S("minecraft:cardinal_direction", "north"), I("repeater_delay", 2)}, [&](auto &o, auto &t) {
        expectCard(t, "minecraft:cardinal_direction", nullptr, 0, rot, mir, "repeater");
        expectSame(o, t, "repeater_delay", "repeater");
      });
      run("unpowered_comparator", {S("minecraft:cardinal_direction", "east"), B("output_subtract_bit", 1), B("output_lit_bit", 0)},
          [&](auto &o, auto &t) {
            expectCard(t, "minecraft:cardinal_direction", nullptr, 1, rot, mir, "comparator");
            expectSame(o, t, "output_subtract_bit", "comparator");
          });
      for (const char *n : {"chest", "trapped_chest", "furnace", "blast_furnace", "smoker", "anvil"})
        run(n, {S("minecraft:cardinal_direction", "south")}, [&](auto &, auto &t) {
          expectCard(t, "minecraft:cardinal_direction", nullptr, 2, rot, mir, n);
        });
      run("hopper", {I("facing_direction", 3), B("toggle_bit", 0)}, [&](auto &, auto &t) { expectF6(t, "facing_direction", 2, rot, mir, "hopper"); });
      run("hopper", {I("facing_direction", 0), B("toggle_bit", 0)}, [&](auto &, auto &t) {
        CHECK(find(t, "facing_direction")->i == 0, "hopper down kept");
      });
      for (const char *n : {"dispenser", "dropper"})
        run(n, {I("facing_direction", 5), B("triggered_bit", 0)}, [&](auto &, auto &t) { expectF6(t, "facing_direction", 1, rot, mir, n); });
      run("observer", {S("minecraft:facing_direction", "west"), B("powered_bit", 0)}, [&](auto &, auto &t) {
        expectCard(t, "minecraft:facing_direction", nullptr, 3, rot, mir, "observer");
      });
      for (const char *n : {"piston", "sticky_piston"})
        run(n, {I("facing_direction", 2)}, [&](auto &, auto &t) { expectF6(t, "facing_direction", 0, rot, mir, n); });
      run("bed", {I("direction", 0), B("head_piece_bit", 0), B("occupied_bit", 0)}, [&](auto &o, auto &t) {
        expectCard(t, "direction", &kGeneric, 2, rot, mir, "bed");
        expectSame(o, t, "head_piece_bit", "bed");
      });
      run("standing_banner", {I("ground_sign_direction", 9)}, [&](auto &, auto &t) {
        CHECK(find(t, "ground_sign_direction")->i == st::transformSignRotation(9, rot, mir), "banner");
      });
      run("wall_banner", {I("facing_direction", 4)}, [&](auto &, auto &t) { expectF6(t, "facing_direction", 3, rot, mir, "wall banner"); });
      run("white_glazed_terracotta", {I("facing_direction", 3)}, [&](auto &, auto &t) {
        expectF6(t, "facing_direction", 2, rot, mir, "glazed terracotta");
      });
      run("pointed_dripstone", {S("dripstone_thickness", "tip"), B("hanging", 1)}, [&](auto &o, auto &t) {
        expectSame(o, t, "dripstone_thickness", "dripstone");
        expectSame(o, t, "hanging", "dripstone");
      });
      run("candle", {I("candles", 2), B("lit", 0)}, [&](auto &o, auto &t) { expectSame(o, t, "candles", "candle"); });
      run("lantern", {B("hanging", 1)}, [&](auto &o, auto &t) { expectSame(o, t, "hanging", "lantern"); });
      run("end_rod", {I("facing_direction", 5)}, [&](auto &, auto &t) { expectF6(t, "facing_direction", 1, rot, mir, "end rod"); });
      run("bell", {S("attachment", "side"), I("direction", 3), B("toggle_bit", 0)}, [&](auto &o, auto &t) {
        expectCard(t, "direction", &kGeneric, 1, rot, mir, "bell");
        expectSame(o, t, "attachment", "bell");
      });
      run("torch", {S("torch_facing_direction", "west")}, [&](auto &, auto &t) {
        CHECK(find(t, "torch_facing_direction")->s == kCardName[worldCard(3, rot, mir)], "wall torch");
      });
      run("torch", {S("torch_facing_direction", "top")}, [&](auto &, auto &t) {
        CHECK(find(t, "torch_facing_direction")->s == "top", "floor torch");
      });
      run("ladder", {I("facing_direction", 3)}, [&](auto &, auto &t) { expectF6(t, "facing_direction", 2, rot, mir, "ladder"); });
      run("tall_grass", {B("upper_block_bit", 1)}, [&](auto &o, auto &t) { expectSame(o, t, "upper_block_bit", "tall plant"); });
      run("cobblestone_wall", {S("wall_connection_type_north", "short"), S("wall_connection_type_east", "none"),
                               S("wall_connection_type_south", "none"), S("wall_connection_type_west", "tall"),
                               B("wall_post_bit", 1)},
          [&](auto &, auto &t) {
            const std::string k = std::string("wall_connection_type_") + kCardName[worldCard(3, rot, mir)];
            CHECK(find(t, k.c_str())->s == "tall", "wall west side");
          });
    }
  std::printf("block families: %d per transform x 8 transforms\n", families);
}

// ---------------------------------------------------------------- 3. raw states (parser) + shared table
static std::string writeStructure(const char *path) {
  nbt::Writer w;
  w.beginCompound("");
  w.putInt("format_version", 1);
  w.beginList("size", nbt::Int, 3);
  w.listInt(2); w.listInt(1); w.listInt(1);
  w.beginCompound("structure");
  w.beginList("block_indices", nbt::List, 2);
  w.listListBegin(nbt::Int, 2);
  w.listInt(0); w.listInt(1);
  w.listListBegin(nbt::Int, 2);
  w.listInt(-1); w.listInt(-1);
  w.beginList("entities", nbt::Compound, 0);
  w.beginCompound("palette");
  w.beginCompound("default");
  w.beginList("block_palette", nbt::Compound, 2);
  // 0: stairs with a raw (list typed) extra state
  w.putString("name", "minecraft:oak_stairs");
  w.beginCompound("states");
  w.putInt("weirdo_direction", 2);
  w.putByte("upside_down_bit", 1);
  w.beginList("mystery_list", nbt::Int, 2);
  w.listInt(7); w.listInt(8);
  w.endCompound();
  w.putInt("version", 18168865);
  w.listCompoundEnd();
  // 1: chest (plain states only)
  w.putString("name", "minecraft:chest");
  w.beginCompound("states");
  w.putString("minecraft:cardinal_direction", "north");
  w.endCompound();
  w.putInt("version", 18168865);
  w.listCompoundEnd();
  w.beginCompound("block_position_data");
  w.endCompound();
  w.endCompound();
  w.endCompound();
  w.endCompound();
  w.beginList("structure_world_origin", nbt::Int, 3);
  w.listInt(0); w.listInt(0); w.listInt(0);
  w.endCompound();
  std::ofstream f(path, std::ios::binary | std::ios::trunc);
  f.write(reinterpret_cast<const char *>(w.out.data()), std::streamsize(w.out.size()));
  return path;
}

static void testRawStates() {
  const std::string p = writeStructure("/tmp/structura_raw_test.mcstructure");
  auto s = std::make_shared<Structure>();
  std::string err;
  LoadInfo info;
  const bool ok = loadStructure(p, *s, err, &info);
  CHECK(ok, "load: %s", err.c_str());
  if (!ok) return;
  CHECK(info.discardedStates == 0, "discarded %zu", info.discardedStates);
  CHECK(info.preservedStates == 4, "preserved %zu", info.preservedStates);
  CHECK(info.rawStates == 1, "raw %zu", info.rawStates);
  CHECK(info.rawKeys.find("mystery_list") != std::string::npos, "raw keys '%s'", info.rawKeys.c_str());
  const BlockVariant *stairs = nullptr;
  for (auto &v : s->variants)
    if (v.fullName.find("oak_stairs") != std::string::npos) stairs = &v;
  CHECK(stairs != nullptr, "stairs variant");
  if (stairs) {
    CHECK(stairs->states.size() == 3, "stairs states %zu", stairs->states.size());
    const auto *raw = find(stairs->states, "mystery_list");
    CHECK(raw && raw->type == nbt::List && !st::plainType(*raw), "raw kept with its NBT type");
  }
  std::printf("parser: %s\n", info.statesLine().c_str());
  // shared table: stairs flagged unsupported (raw data can't be reproduced), chest transformed
  for (int rot = 0; rot < 4; ++rot)
    for (int m = 0; m < 2; ++m) {
      const auto X = xf::get(s, rot, m);
      CHECK(X && X->states.size() == s->variants.size(), "table size");
      if (!X) continue;
      for (size_t v = 0; v < s->variants.size(); ++v) {
        const bool isStairs = s->variants[v].fullName.find("oak_stairs") != std::string::npos;
        if (isStairs) {
          CHECK(X->unsupported[v].find("raw") != std::string::npos, "stairs unsupported reason '%s'", X->unsupported[v].c_str());
          const auto *wd = find(X->states[v], "weirdo_direction");
          CHECK(wd && wd->i == enc(kStair, worldCard(2, rot, m)), "stairs transformed in table");
        } else if (s->variants[v].fullName.find("chest") != std::string::npos) {
          CHECK(X->unsupported[v].empty(), "chest supported");
          const auto *cd = find(X->states[v], "minecraft:cardinal_direction");
          CHECK(cd && cd->s == kCardName[worldCard(0, rot, m)], "chest transformed in table");
        }
      }
      // cache: the same table comes back; peek never builds
      CHECK(xf::get(s, rot, m).get() == X.get(), "cached");
      CHECK(xf::peek(s.get(), rot, m).get() == X.get(), "peek");
    }
  xf::clear();
  CHECK(xf::peek(s.get(), 0, false) == nullptr, "cleared");
  // progress: the stairs start as Unsupported, the chest as Not checked
  const auto X = xf::get(s, 0, false);
  auto C = progress::create(1, 1, s, X.get());
  const auto c = progress::overall(*C);
  CHECK(c.total == 2 && c.s[PUnsupported] == 1 && c.s[PNotChecked] == 1, "initial counts %u %u %u", c.total,
        c.s[PUnsupported], c.s[PNotChecked]);
  xf::clear();
}

// ---------------------------------------------------------------- 4. progress model + layers
static std::shared_ptr<Structure> randomStructure(int sx, int sy, int sz, unsigned seed) {
  auto s = std::make_shared<Structure>();
  s->sx = sx; s->sy = sy; s->sz = sz;
  s->palette.resize(3);
  s->palette[0].name = "air"; s->palette[0].air = true;
  s->palette[1].name = "stone";
  s->palette[2].name = "oak_planks";
  s->variants.resize(3);
  for (int i = 0; i < 3; ++i) s->variants[size_t(i)].palette = uint16_t(i);
  const size_t n = s->volume();
  s->idx.resize(n);
  s->vidx.resize(n);
  unsigned r = seed;
  for (size_t i = 0; i < n; ++i) {
    r = r * 1103515245u + 12345u;
    const uint16_t p = uint16_t((r >> 16) % 3);
    s->idx[i] = p;
    s->vidx[i] = p;
  }
  // one fully empty layer (y = 1) to test empty layers
  for (int x = 0; x < sx; ++x)
    for (int z = 0; z < sz; ++z) { s->idx[s->index(x, 1, z)] = 0; s->vidx[s->index(x, 1, z)] = 0; }
  return s;
}

static void testProgress() {
  auto s = randomStructure(4, 5, 6, 7);
  auto C = progress::create(3, 1, s, nullptr);
  uint32_t solid = 0;
  for (size_t i = 0; i < s->volume(); ++i) solid += s->palette[s->idx[i]].air ? 0 : 1;
  auto c = progress::overall(*C);
  CHECK(c.total == solid && c.s[PNotChecked] == solid, "fresh model total %u solid %u", c.total, solid);
  // drive every block through states; counters must always match a brute-force recount
  unsigned r = 99;
  std::vector<uint8_t> shadow(s->volume(), 0);
  for (int step = 0; step < 4000; ++step) {
    r = r * 1103515245u + 12345u;
    const size_t li = (r >> 8) % s->volume();
    const int op = int((r >> 4) % 6);
    if (op < 3) {
      static const uint8_t cmps[] = {CmpCorrect, CmpMissing, CmpWrongState, CmpWrong, CmpUnknown};
      progress::setCmp(*C, li, cmps[(r >> 20) % 5]);
    } else {
      static const EpFlag fl[] = {EpNone, EpPlacing, EpSkipped, EpFailed, EpUnsupported};
      progress::setEp(*C, li, fl[(r >> 20) % 5], ErrNone, true);
    }
    if (step % 250 == 0 || step == 3999) {
      uint32_t want[PCount] = {};
      uint32_t extra = 0;
      for (size_t i = 0; i < s->volume(); ++i) {
        const bool air = s->palette[s->idx[i]].air;
        const uint8_t rec = C->st[i].load();
        if (air) { if ((rec & 7) == CmpExtra) ++extra; continue; }
        ++want[progress::stateOf(rec, false)];
      }
      c = progress::overall(*C);
      bool same = true;
      for (int k = 0; k < PCount; ++k) same &= c.s[k] == want[k];
      CHECK(same, "counters drift at step %d", step);
      // per-layer slices for every transform and axis = brute force over world layers
      for (int rot = 0; rot < 4; ++rot)
        for (int m = 0; m < 2; ++m)
          for (int axis = 0; axis < 3; ++axis) {
            Placement P;
            P.ox = -7; P.oy = -64; P.oz = 13; P.rot = rot; P.mirror = m;
            const int L = progress::layerCount(*s, P, axis);
            int dx, dz;
            rotatedSize(*s, rot, dx, dz);
            CHECK(L == (axis == 0 ? dx : axis == 1 ? s->sy : dz), "layer count");
            for (int li2 = 0; li2 < L; ++li2) {
              const int wc = progress::layerWorld(*s, P, axis, li2);
              CHECK(wc == (axis == 0 ? P.ox : axis == 1 ? P.oy : P.oz) + li2, "layer world");
              uint32_t bw[PCount] = {};
              for (int x = 0; x < s->sx; ++x)
                for (int y = 0; y < s->sy; ++y)
                  for (int z = 0; z < s->sz; ++z) {
                    int wx, wy, wz;
                    localToWorld(*s, P, x, y, z, wx, wy, wz);
                    const int w = axis == 0 ? wx : axis == 1 ? wy : wz;
                    if (w != wc) continue;
                    const size_t i = s->index(x, y, z);
                    if (s->palette[s->idx[i]].air) continue;
                    ++bw[progress::stateOf(C->st[i].load(), false)];
                  }
              progress::Counts lc;
              const bool ok = progress::layerCounts(*C, *s, P, axis, li2, lc);
              bool eq = ok;
              for (int k = 0; k < PCount; ++k) eq &= lc.s[k] == bw[k];
              CHECK(eq, "layer counts rot %d mir %d axis %d layer %d", rot, m, axis, li2);
              if (axis == 1 && li2 == 1) CHECK(ok && lc.total == 0, "empty layer");
            }
          }
    }
  }
  // priorities
  CHECK(progress::stateOf(CmpCorrect | (EpPlacing << 4), false) == PPlacing, "placing first");
  CHECK(progress::stateOf(CmpCorrect | (EpFailed << 4), false) == PCorrect, "verified correct beats failed");
  CHECK(progress::stateOf(CmpWrongState, false) == PIncorrect, "wrong state is incorrect");
  CHECK(progress::stateOf(CmpMissing | (EpUnsupported << 4), false) == PUnsupported, "unsupported");
  CHECK(progress::stateOf(CmpMissing | (EpSkipped << 4), false) == PSkipped, "skipped");
  CHECK(progress::stateOf(CmpUnknown, true) == PNone, "air");
  // Unsupported survives a new comparison, other Easy Place outcomes are cleared by it
  progress::setEp(*C, 0, EpUnsupported);
  progress::setCmp(*C, 0, CmpMissing);
  CHECK(((C->st[0].load() >> 4) & 7) == EpUnsupported, "unsupported sticky");
  progress::setEp(*C, 0, EpSkipped);
  CHECK(((C->st[0].load() >> 4) & 7) == EpUnsupported, "skipped can't override unsupported");
  // world helpers through the shared model (negative Y origin)
  {
    auto &m = model();
    std::lock_guard<std::mutex> lk(m.mu);
    m.structure = s;
    m.placed = true;
    m.placement = Placement{};
    m.placement.ox = 10; m.placement.oy = -60; m.placement.oz = -3; m.placement.rot = 1; m.placement.mirror = true;
    m.compare = C;
    m.gen = C->gen;
  }
  int wx, wy, wz;
  // pick a solid local cell
  int sxl = -1, syl = -1, szl = -1;
  for (int x = 0; x < s->sx && sxl < 0; ++x)
    for (int z = 0; z < s->sz && sxl < 0; ++z)
      if (!s->palette[s->idx[s->index(x, 0, z)]].air) { sxl = x; syl = 0; szl = z; }
  localToWorld(*s, model().placement, sxl, syl, szl, wx, wy, wz);
  const size_t li = s->index(sxl, syl, szl);
  CHECK(progress::verifiedWorld(wx, wy, wz, CmpCorrect), "verifiedWorld");
  CHECK((C->st[li].load() & 7) == CmpCorrect, "verifiedWorld hit the right block");
  CHECK(progress::noteWorld(wx, wy, wz, EpPlacing, ErrNone, true), "noteWorld");
  CHECK(progress::stateOf(C->st[li].load(), false) == PPlacing, "placing");
  CHECK(C->tries[li].load() >= 1, "attempt counted");
  CHECK(!progress::noteWorld(wx + 1000, wy, wz, EpPlacing), "outside");
  {  // a stale model (structure changed: gen bumped) is never written
    auto &m = model();
    std::lock_guard<std::mutex> lk(m.mu);
    ++m.gen;
  }
  CHECK(!progress::verifiedWorld(wx, wy, wz, CmpMissing), "stale generation rejected");
  CHECK((C->st[li].load() & 7) == CmpCorrect, "stale write did not land");
  {
    auto &m = model();
    std::lock_guard<std::mutex> lk(m.mu);
    m.structure.reset();
    m.compare.reset();
    m.placed = false;
  }
}

// ---------------------------------------------------------------------------------------------------------------
// Java formats: big-endian NBT written here byte by byte (independent of the reader under test)
struct BeW {
  std::vector<uint8_t> o;
  void u8(int v) { o.push_back(uint8_t(v)); }
  void u16(int v) { u8(v >> 8); u8(v); }
  void u32(int64_t v) { for (int k = 3; k >= 0; --k) u8(int(uint32_t(v) >> (8 * k))); }
  void u64(uint64_t v) { for (int k = 7; k >= 0; --k) u8(int(v >> (8 * k))); }
  void str(const std::string &s) { u16(int(s.size())); o.insert(o.end(), s.begin(), s.end()); }
  void head(int t, const std::string &n) { u8(t); str(n); }
  void comp(const std::string &n) { head(10, n); }
  void end() { u8(0); }
  void i32(const std::string &n, int v) { head(3, n); u32(v); }
  void i16(const std::string &n, int v) { head(2, n); u16(v); }
  void s(const std::string &n, const std::string &v) { head(8, n); str(v); }
  void intList(const std::string &n, std::vector<int> v) { head(9, n); u8(3); u32(int64_t(v.size())); for (int x : v) u32(x); }
  void bytes(const std::string &n, const std::vector<int> &v) { head(7, n); u32(int64_t(v.size())); for (int x : v) u8(x); }
  void longs(const std::string &n, const std::vector<uint64_t> &v) { head(12, n); u32(int64_t(v.size())); for (auto x : v) u64(x); }
  void listComp(const std::string &n, int count) { head(9, n); u8(10); u32(count); }
  bool save(const std::string &path) { std::ofstream f(path, std::ios::binary); f.write((const char *)o.data(), o.size()); return bool(f); }
};
// Java palette entry inside a List<Compound>
static void jEntry(BeW &w, const std::string &name, std::vector<std::pair<std::string, std::string>> props) {
  w.s("Name", name);
  if (!props.empty()) {
    w.comp("Properties");
    for (auto &p : props) w.s(p.first, p.second);
    w.end();
  }
  w.end();
}
static const BlockVariant *varAt(const Structure &s, int x, int y, int z) {
  if (!s.inside(x, y, z)) return nullptr;
  const uint16_t v = s.vidx[s.index(x, y, z)];
  return v == kVoid ? nullptr : &s.variants[v];
}
static std::string stateOf(const BlockVariant *v, const char *key) {
  if (!v) return "<void>";
  for (auto &k : v->states)
    if (k.key == key) return k.type == nbt::String ? k.s : std::to_string(k.i);
  return "<none>";
}

static void testJavaFormats() {
  const std::string dir = "/tmp/structura_java_test";
  std::system(("mkdir -p " + dir).c_str());
  // 1) structure-block .nbt: east stairs (waterlogged), stone, explicit air, one void position
  {
    BeW w;
    w.comp("");
    w.i32("DataVersion", 3953);
    w.intList("size", {2, 2, 1});
    w.listComp("palette", 3);
    jEntry(w, "minecraft:oak_stairs", {{"facing", "east"}, {"half", "bottom"}, {"shape", "straight"}, {"waterlogged", "true"}});
    jEntry(w, "minecraft:stone", {});
    jEntry(w, "minecraft:air", {});
    w.listComp("blocks", 3);
    w.intList("pos", {0, 0, 0}); w.i32("state", 0); w.end();
    w.intList("pos", {1, 0, 0}); w.i32("state", 1); w.end();
    w.intList("pos", {0, 1, 0}); w.i32("state", 2); w.end();
    w.end();
    CHECK(w.save(dir + "/a.nbt"), "write");
    // the same bytes under a wrong extension must load too (content decides, extension only orders the tries)
    CHECK(w.save(dir + "/a_wrong_ext.mcstructure"), "write");
    for (const char *f : {"/a.nbt", "/a_wrong_ext.mcstructure"}) {
      Structure s; std::string err; LoadInfo li;
      const bool ok = loadStructure(dir + f, s, err, &li);
      CHECK(ok, "%s: %s", f, err.c_str());
      if (!ok) continue;
      CHECK(li.format == "java-nbt", "format %s", li.format.c_str());
      CHECK(s.sx == 2 && s.sy == 2 && s.sz == 1, "size");
      const BlockVariant *st0 = varAt(s, 0, 0, 0);
      CHECK(st0 && st0->fullName == "minecraft:oak_stairs", "stairs name");
      CHECK(stateOf(st0, "weirdo_direction") == "0" && stateOf(st0, "upside_down_bit") == "0", "east bottom stairs");
      CHECK(s.waterAt(s.index(0, 0, 0)), "waterlogged -> layer 2 water");
      CHECK(varAt(s, 1, 0, 0) && varAt(s, 1, 0, 0)->fullName == "minecraft:stone", "stone");
      CHECK(s.idx[s.index(0, 1, 0)] != kVoid && s.palette[s.idx[s.index(0, 1, 0)]].air, "explicit air kept");
      CHECK(s.idx[s.index(1, 1, 0)] == kVoid, "missing position is structure void");
      CHECK(li.javaUnmapped == 0 && li.javaApprox == 0, "all mapped");
    }
  }
  // 2) litematic: negative region size, 17-entry palette (5 bits: values straddle long boundaries)
  {
    const char *names[17] = {"air", "stone", "granite", "diorite", "andesite", "dirt", "cobblestone", "oak_planks",
                             "spruce_planks", "birch_planks", "sand", "gravel", "gold_ore", "iron_ore", "coal_ore",
                             "glass", "red_wool"};
    const int ax = 5, ay = 3, az = 4, vol = ax * ay * az;
    std::vector<int> vals(vol);
    for (int i = 0; i < vol; ++i) vals[i] = (i * 7 + 3) % 17;
    const int bits = 5;
    std::vector<uint64_t> longs((vol * bits + 63) / 64, 0);
    for (int i = 0; i < vol; ++i) {
      const uint64_t b0 = uint64_t(i) * bits;
      longs[b0 >> 6] |= uint64_t(vals[i]) << (b0 & 63);
      if (((b0 + bits - 1) >> 6) != (b0 >> 6)) longs[(b0 >> 6) + 1] |= uint64_t(vals[i]) >> (64 - (b0 & 63));
    }
    BeW w;
    w.comp("");
    w.i32("MinecraftDataVersion", 3955);
    w.i32("Version", 6);
    w.comp("Regions");
    w.comp("main");
    w.comp("Position"); w.i32("x", 100); w.i32("y", 70); w.i32("z", -20); w.end();
    w.comp("Size"); w.i32("x", -ax); w.i32("y", ay); w.i32("z", -az); w.end();
    w.listComp("BlockStatePalette", 17);
    for (auto *n : names) jEntry(w, std::string("minecraft:") + n, {});
    w.longs("BlockStates", longs);
    w.end();  // main
    w.end();  // Regions
    w.end();
    CHECK(w.save(dir + "/b.litematic"), "write");
    Structure s; std::string err; LoadInfo li;
    const bool ok = loadStructure(dir + "/b.litematic", s, err, &li);
    CHECK(ok, "litematic: %s", err.c_str());
    if (ok) {
      CHECK(li.format == "litematic", "format");
      CHECK(s.sx == ax && s.sy == ay && s.sz == az, "size %d %d %d", s.sx, s.sy, s.sz);
      int bad = 0;
      for (int i = 0; i < vol; ++i) {
        const int x = i % ax, z = (i / ax) % az, y = i / (ax * az);
        const uint16_t p = s.idx[s.index(x, y, z)];
        const std::string want = names[vals[i]];
        const std::string got = p == kVoid ? "<void>" : s.palette[p].name;
        if (got != want) ++bad;
      }
      CHECK(bad == 0, "%d litematic voxels differ", bad);
    }
  }
  // 3) Sponge v2 (root fields) and v3 (Schematic.Blocks): varint ids above 127, index x + z*W + y*W*L
  for (int version : {2, 3}) {
    BeW w;
    w.comp("");
    if (version == 3) w.comp("Schematic");
    w.i32("Version", version);
    w.i32("DataVersion", 3955);
    w.i16("Width", 2); w.i16("Height", 1); w.i16("Length", 2);
    std::vector<int> data = {1, 0xC8, 0x01, 0, 1};  // 1, 200 (varint), 0, 1
    if (version == 3) w.comp("Blocks");
    w.comp("Palette");
    w.i32("minecraft:air", 0);
    w.i32("minecraft:oak_stairs[waterlogged=false,shape=straight,half=top,facing=north]", 1);  // unsorted props
    w.i32("minecraft:stone", 200);
    w.end();
    w.bytes(version == 3 ? "Data" : "BlockData", data);
    if (version == 3) { w.end(); w.end(); }
    w.end();
    const std::string f = dir + "/c" + std::to_string(version) + ".schem";
    CHECK(w.save(f), "write");
    Structure s; std::string err; LoadInfo li;
    const bool ok = loadStructure(f, s, err, &li);
    CHECK(ok, "sponge v%d: %s", version, err.c_str());
    if (!ok) continue;
    CHECK(li.format == "sponge-v" + std::to_string(version), "format %s", li.format.c_str());
    const BlockVariant *a = varAt(s, 0, 0, 0), *b = varAt(s, 1, 0, 0), *d = varAt(s, 1, 0, 1);
    CHECK(a && a->fullName == "minecraft:oak_stairs" && stateOf(a, "weirdo_direction") == "3" &&
          stateOf(a, "upside_down_bit") == "1", "north top stairs (%s)", a ? a->fullName.c_str() : "-");
    CHECK(b && b->fullName == "minecraft:stone", "varint 200 -> stone");
    CHECK(d && d->fullName == "minecraft:oak_stairs", "last voxel");
    CHECK(s.palette[s.idx[s.index(0, 0, 1)]].air, "air");
  }
  // 4) MCEdit legacy ids: stairs 53:0, red wool 35:14, unknown id 253 (-> void, reported)
  {
    BeW w;
    w.comp("");
    w.i16("Width", 3); w.i16("Height", 1); w.i16("Length", 1);
    w.s("Materials", "Alpha");
    w.bytes("Blocks", {53, 35, 253});
    w.bytes("Data", {0, 14, 0});
    w.end();
    CHECK(w.save(dir + "/e.schematic"), "write");
    Structure s; std::string err; LoadInfo li;
    const bool ok = loadStructure(dir + "/e.schematic", s, err, &li);
    CHECK(ok, "mcedit: %s", err.c_str());
    if (ok) {
      CHECK(li.format == "mcedit", "format");
      const BlockVariant *a = varAt(s, 0, 0, 0), *b = varAt(s, 1, 0, 0);
      CHECK(a && a->fullName == "minecraft:oak_stairs" && stateOf(a, "weirdo_direction") == "0", "53:0 east stairs");
      CHECK(b && b->fullName == "minecraft:red_wool", "35:14 red wool");
      CHECK(!varAt(s, 2, 0, 0) && li.javaUnmapped == 1, "unknown legacy id -> void + reported");
    }
  }
  // 5) state mapping
  {
    nbt::Tag e; bool exact = false;
    CHECK(java::mapStateString("minecraft:oak_door[facing=north,half=upper,hinge=left,open=true,powered=false]", e, exact) &&
          exact && e.get("name") && e.get("name")->s == "minecraft:wooden_door", "door");
    CHECK(java::mapStateString("minecraft:grass", e, exact) && e.get("name") && e.get("name")->s != "minecraft:grass_block",
          "old 'grass' plant alias (%s)", e.get("name") ? e.get("name")->s.c_str() : "-");
    CHECK(!java::mapStateString("create:shaft[axis=y]", e, exact), "modded block is not guessed");
    CHECK(java::mapStateString("minecraft:oak_stairs[facing=up]", e, exact) && !exact, "bad value -> closest, flagged");
    CHECK(java::legacyState(1, 1) == "minecraft:granite", "legacy 1:1");
  }
  // 6) garbage: both byte orders fail cleanly (no huge allocations, no crash)
  {
    uint32_t seed = 12345;
    int okCount = 0;
    for (int round = 0; round < 300; ++round) {
      std::vector<uint8_t> g(64 + round * 13);
      for (auto &b : g) { seed = seed * 1103515245u + 12345u; b = uint8_t(seed >> 16); }
      g[0] = 0x0A;
      for (bool be : {false, true}) {
        nbt::Tag t; std::string err;
        if (nbt::parse(g.data(), g.size(), t, err, be)) ++okCount;
      }
    }
    CHECK(true, "garbage survived (%d parsed)", okCount);
  }
}

int main() {
  testPrimitives();
  testFamilies();
  testRawStates();
  testProgress();
  testJavaFormats();
  std::printf("host tests: %d passed, %d failed\n", gPass, gFail);
  return gFail ? 1 : 0;
}
