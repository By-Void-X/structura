#!/usr/bin/env python3
"""Builds the compact Java Edition -> Bedrock block table used to load .nbt/.litematic/.schem/.schematic.

Inputs (downloaded by scripts/build.sh, never committed):
  blocksJ2B.json   PrismarineJS/minecraft-data  data/bedrock/<ver>/blocksJ2B.json  (Java state -> Bedrock state)
  legacy.json      PrismarineJS/minecraft-data  data/pc/common/legacy.json        (MCEdit id:meta -> Java state)
  mojang-blocks    Mojang bedrock-samples       metadata/vanilladata_modules/mojang-blocks.json (state value types)

Output: zlib stream of a little-endian table (see JavaFormats.cpp, struct Table, for the reader):
  "SJM1" u32 nStr u32 nBed u32 nBlk u32 nSt u32 nLeg u32 nAlias
  strings      : u8 len + bytes                         (block names stored without "minecraft:")
  bedrock[nBed]: u16 name, u8 n, n * (u16 key, u8 type(1 byte|3 int|8 string), i32 value | u16 str)
  blocks[nBlk] : u16 name, u32 firstState, u16 count     (sorted by name)
  states[nSt]  : u8 n, n * (u16 key, u16 value), u32 bedrock   (props sorted by key)
  legacy[nLeg] : u16 id, u8 meta, u16 javaStateString
  alias[nAlias]: u16 from, u16 to
"""
import json
import struct
import sys
import zipfile
import zlib


def strip(n):
    return n[10:] if n.startswith("minecraft:") else n


def split_state(s):
    name, _, rest = s.partition("[")
    rest = rest.rstrip("]")
    props = []
    for kv in filter(None, rest.split(",")):
        k, _, v = kv.partition("=")
        props.append((k, v))
    return name, props


def main():
    if len(sys.argv) != 5:
        sys.exit("usage: gen_java_map.py blocksJ2B.json legacy.json bedrock-samples.zip out.bin")
    j2b = json.load(open(sys.argv[1]))
    legacy = json.load(open(sys.argv[2]))["blocks"]
    with zipfile.ZipFile(sys.argv[3]) as z:
        member = next(n for n in z.namelist() if n.endswith("metadata/vanilladata_modules/mojang-blocks.json"))
        mb = json.loads(z.read(member))
    ptype = {p["name"]: p["type"] for p in mb["block_properties"]}

    strings, sidx = [], {}

    def S(x):
        if x not in sidx:
            b = x.encode()
            assert len(b) < 256, x
            sidx[x] = len(strings)
            strings.append(b)
        return sidx[x]

    bed, bidx = [], {}

    def B(state):
        if state in bidx:
            return bidx[state]
        name, props = split_state(state)
        rec = [S(strip(name)), []]
        for k, v in sorted(props):
            t = ptype.get(k)
            if t == "bool" or (t is None and v in ("true", "false")):
                rec[1].append((S(k), 1, 1 if v == "true" else 0))
            elif t == "int" or (t is None and v.lstrip("-").isdigit()):
                rec[1].append((S(k), 3, int(v)))
            else:
                rec[1].append((S(k), 8, S(v)))
        bidx[state] = len(bed)
        bed.append(rec)
        return bidx[state]

    blocks = {}
    for js, bs in j2b.items():
        name, props = split_state(js)
        blocks.setdefault(strip(name), []).append((sorted(props), B(bs)))

    aliases = []
    for a, b in (("grass", "short_grass"), ("grass_path", "dirt_path"), ("sign", "oak_sign"),
                 ("wall_sign", "oak_wall_sign"), ("chain", "iron_chain"), ("cave_air", "air"),
                 ("void_air", "air")):
        if a not in blocks and b in blocks:
            aliases.append((S(a), S(b)))

    names = sorted(blocks)
    for n in names:
        S(n)
    out = bytearray()
    blk, st = bytearray(), bytearray()
    nst = 0
    for n in names:
        lst = blocks[n]
        blk += struct.pack("<HIH", S(n), nst, len(lst))
        for props, b in lst:
            st += struct.pack("<B", len(props))
            for k, v in props:
                st += struct.pack("<HH", S(k), S(v))
            st += struct.pack("<I", b)
            nst += 1
    leg = bytearray()
    nleg = 0
    for key, val in legacy.items():
        i, _, m = key.partition(":")
        leg += struct.pack("<HBH", int(i), int(m), S(val))
        nleg += 1
    bd = bytearray()
    for name, props in bed:
        bd += struct.pack("<HB", name, len(props))
        for k, t, v in props:
            bd += struct.pack("<HB", k, t)
            bd += struct.pack("<H", v) if t == 8 else struct.pack("<i", v)
    assert len(strings) < 65536
    out += b"SJM1" + struct.pack("<6I", len(strings), len(bed), len(names), nst, nleg, len(aliases))
    for s in strings:
        out += bytes([len(s)]) + s
    out += bd + blk + st + leg
    for a, b in aliases:
        out += struct.pack("<HH", a, b)
    z = zlib.compress(bytes(out), 9)
    open(sys.argv[4], "wb").write(z)
    print(f"java map: {len(names)} blocks, {nst} states, {len(bed)} bedrock states, {nleg} legacy, "
          f"{len(aliases)} aliases, {len(out)} -> {len(z)} bytes")


if __name__ == "__main__":
    main()
