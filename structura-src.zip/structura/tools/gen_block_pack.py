"""Builds the block texture pack embedded in Structura (Items tab icons).

usage: gen_block_pack.py <bedrock-samples .zip or folder> <out.zip>

Input: Mojang's bedrock-samples (github.com/Mojang/bedrock-samples, same version as the game).
Output: a small zip with the layout the game APK uses (assets/resource_packs/vanilla/...):
  blocks.json + textures/terrain_texture.json (only the fields the icon renderer reads)
  textures/{blocks,items}/**.png : every texture those files can reach, first animation frame,
                                   at most 16x16, re-encoded as PNG (textures/items: the inventory
                                   sprites some blocks use as icon, e.g. lantern_carried).
The textures are Mojang's; they are not stored in the source repo, only generated at build time.
"""
import io, json, re, sys, zipfile
from pathlib import PurePosixPath
from PIL import Image

src, out = sys.argv[1], sys.argv[2]
MAX = 16


class Src:
    def __init__(self, p):
        self.zip = zipfile.ZipFile(p) if p.endswith(".zip") else None
        self.root = p
        names = self.zip.namelist() if self.zip else None
        if self.zip:
            hit = [n for n in names if n.endswith("resource_pack/blocks.json")]
            assert hit, "resource_pack/blocks.json not found"
            self.base = hit[0][: -len("blocks.json")]
            self.names = set(names)
        else:
            import os
            self.base = os.path.join(p, "resource_pack") + "/"
            self.names = None

    def read(self, rel):
        if self.zip:
            n = self.base + rel
            return self.zip.read(n) if n in self.names else None
        try:
            return open(self.base + rel, "rb").read()
        except OSError:
            return None


def loadj(b):
    s = b.decode("utf-8-sig")
    s = re.sub(r"^\s*//[^\n]*", "", s, flags=re.M)  # the vanilla files have a few // comments
    return json.loads(s)


S = Src(src)
blocks = loadj(S.read("blocks.json"))
terrain = loadj(S.read("textures/terrain_texture.json"))["texture_data"]

FACE_KEYS = ("up", "down", "side", "north", "south", "east", "west")
mb = {}
for k, v in blocks.items():
    if not isinstance(v, dict):
        continue
    o = {}
    for key in ("carried_textures", "textures"):
        t = v.get(key)
        if isinstance(t, str):
            o[key] = t
        elif isinstance(t, dict):
            o[key] = {f: t[f] for f in FACE_KEYS if isinstance(t.get(f), str)}
    if o:
        mb[k] = o

paths = set()


def slim(atlas, keys=None):
    out = {}
    for k, v in atlas.items():
        if keys is not None and k not in keys:
            continue
        r = slim1(v)
        if r:
            out[k] = r
    return out


def slim1(v):
    t = v.get("textures") if isinstance(v, dict) else None
    if t is None:
        return None
    keep = []
    for it in (t if isinstance(t, list) else [t]):
        if isinstance(it, str):
            keep.append(it)
            paths.add(it)
        elif isinstance(it, dict) and isinstance(it.get("path"), str):
            d = {"path": it["path"]}
            for c in ("tint_color", "overlay_color"):
                if isinstance(it.get(c), str):
                    d[c] = it[c]
            keep.append(d)
            paths.add(it["path"])
    return {"textures": keep if isinstance(t, list) else keep[0]} if keep else None


mt = slim(terrain)

fallback = {"textures/blocks/" + k for k in blocks} - paths
paths |= fallback


def first_frame(im):
    im = im.convert("RGBA")
    w, h = im.size
    if h > w and h % w == 0:
        im = im.crop((0, 0, w, w))
    if max(im.size) > MAX:
        s = MAX / max(im.size)
        im = im.resize((max(1, round(im.size[0] * s)), max(1, round(im.size[1] * s))), Image.BOX)
    return im


n = 0
missing = 0
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    base = "assets/resource_packs/vanilla/"
    def entry(name):  # fixed date: the same input always gives the same bytes
        return zipfile.ZipInfo(base + name, (2026, 1, 1, 0, 0, 0))
    z.writestr(entry("blocks.json"), json.dumps(mb, separators=(",", ":")), zipfile.ZIP_DEFLATED)
    z.writestr(entry("textures/terrain_texture.json"),
               json.dumps({"texture_data": mt}, separators=(",", ":")), zipfile.ZIP_DEFLATED)

    for p in sorted(paths):
        if not p.startswith(("textures/blocks/", "textures/items/")):
            continue
        data = None
        for ext in (".png", ".tga"):
            data = S.read(p + ext)
            if data:
                break
        if not data:
            missing += p not in fallback
            continue
        try:
            im = first_frame(Image.open(io.BytesIO(data)))
        except Exception:
            missing += 1
            continue
        b = io.BytesIO()
        im.save(b, "PNG", optimize=True)
        z.writestr(entry(p + ".png"), b.getvalue(), zipfile.ZIP_STORED)
        n += 1
print(f"{out}: {len(mb)} blocks, {len(mt)} terrain entries, {n} textures, {missing} referenced but missing")
