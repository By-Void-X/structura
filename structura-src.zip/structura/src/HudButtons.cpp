#include "HudButtons.hpp"

#include <dlfcn.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstring>
#include <mutex>

#include "Perf.hpp"
#include "State.hpp"
#include "Theme.hpp"

namespace lm::hudbtn {
namespace {

using ui::kit::Canvas;
using ui::kit::Metrics;
using ui::kit::Rect;
namespace col = theme::color;
namespace sty = theme::style;


constexpr float kSideDp[2] = {40.f, 38.f};  
constexpr float kEdgeDp = 16.f;             
constexpr float kGapDp = 10.f;              
constexpr float kSlopDp = 10.f;             
constexpr const char *kLabel[2] = {"ST", "EP"};



using JniBoolFn = unsigned char (*)(void *, void *);
JniBoolFn gHudFn = nullptr, gMenuFn = nullptr, gPauseFn = nullptr;
bool (*gTestHud)() = nullptr;
bool (*gTestMenu)() = nullptr;
bool (*gTestPause)() = nullptr;

std::atomic_bool gActive{false}, gModuleOn{true};
std::atomic<void (*)()> gPanelAct{nullptr}, gEpAct{nullptr}, gWake{nullptr};
std::atomic<bool (*)()> gEpOn{nullptr};

std::mutex gMu;  
struct Geo {
  float W = 0, H = 0, dev = 1;
  Rect r[2];
  bool valid = false;
} gGeo;
int gPtr = -1, gWhich = -1;
bool gDrag = false;
float gDownX = 0, gDownY = 0, gStartX = 0, gStartY = 0;
std::atomic<int> gPressed{-1};
std::atomic<uint32_t> gMoveRev{0};  


struct Key {
  float W, H, fx[4];
  int pressed, epOn, opMode, pct[sty::InkCount];
  uint32_t accent, moveRev;
  bool operator==(const Key &o) const { return std::memcmp(this, &o, sizeof(Key)) == 0; }
};
Key gLast{};
bool gHaveLast = false;

std::atomic<float> &posAtom(int which, int axis) {
  auto &s = settings();
  return which == 0 ? (axis == 0 ? s.stX : s.stY) : (axis == 0 ? s.epX : s.epY);
}

float side(int i, float dev) { return std::round(std::max(kSideDp[i], sty::TouchMin) * dev); }  


void layoutLocked(float W, float H, float dev) {
  gGeo.W = W;
  gGeo.H = H;
  gGeo.dev = dev;
  const float s0 = side(0, dev), s1 = side(1, dev);
  const float defX0 = W - s0 - kEdgeDp * dev, defY0 = H * 0.28f;
  const float defX1 = defX0 + s0 - s1, defY1 = defY0 + s0 + kGapDp * dev;
  const float def[2][2] = {{defX0, defY0}, {defX1, defY1}};
  for (int i = 0; i < 2; ++i) {
    const float sd = side(i, dev);
    const float freeW = std::max(0.f, W - sd), freeH = std::max(0.f, H - sd);
    const float fx = posAtom(i, 0).load(), fy = posAtom(i, 1).load();
    const float x = fx >= 0.f ? fx * freeW : def[i][0];
    const float y = fy >= 0.f ? fy * freeH : def[i][1];
    gGeo.r[i] = {std::round(std::clamp(x, 0.f, freeW)), std::round(std::clamp(y, 0.f, freeH)), sd, sd};
  }
  gGeo.valid = W > 0 && H > 0;
}

void resetGestureLocked() {
  gPtr = -1;
  gWhich = -1;
  gDrag = false;
  gPressed.store(-1);
}

void wake() {
  if (auto w = gWake.load()) w();
}

}  

bool probe() {
  static const bool ok = [] {
    auto find = [](const char *name) -> void * {
      if (void *p = dlsym(RTLD_DEFAULT, name)) return p;
      if (void *h = dlopen("libpreloader.so", RTLD_NOW | RTLD_NOLOAD)) return dlsym(h, name);
      return nullptr;
    };
    gHudFn = reinterpret_cast<JniBoolFn>(find("Java_org_levimc_launcher_preloader_PreloaderInput_nativeIsHudScreenOpen"));
    gMenuFn = reinterpret_cast<JniBoolFn>(find("Java_org_levimc_launcher_preloader_PreloaderInput_nativeIsShowingMenu"));
    gPauseFn =
        reinterpret_cast<JniBoolFn>(find("Java_org_levimc_launcher_preloader_PreloaderInput_nativeIsPauseMenuOpen"));
    return gHudFn && gMenuFn && gPauseFn;
  }();
  return ok || (gTestHud && gTestMenu && gTestPause);
}

void setActive(bool on) {
  gActive.store(on);
  std::lock_guard<std::mutex> lk(gMu);
  resetGestureLocked();
  gHaveLast = false;
}
bool active() { return gActive.load(std::memory_order_relaxed); }
void setModuleOn(bool on) {
  gModuleOn.store(on);
  if (!on) {
    std::lock_guard<std::mutex> lk(gMu);
    resetGestureLocked();
  }
}

bool gameHudVisible() {
  if (gTestHud && gTestMenu && gTestPause) return gTestHud() && !gTestMenu() && !gTestPause();
  if (!gHudFn || !gMenuFn || !gPauseFn) return true;
  return gHudFn(nullptr, nullptr) && !gMenuFn(nullptr, nullptr) && !gPauseFn(nullptr, nullptr);
}

void setActions(void (*panel)(), void (*easyPlace)(), bool (*easyPlaceOn)()) {
  gPanelAct.store(panel);
  gEpAct.store(easyPlace);
  gEpOn.store(easyPlaceOn);
}
void setWake(void (*w)()) { gWake.store(w); }

bool onTouch(const pl::input::TouchEvent &ev) {
  if (!gActive.load(std::memory_order_relaxed)) return false;
  int fire = -1;
  bool consumed = false, changedLook = false;
  {
    std::lock_guard<std::mutex> lk(gMu);
    if (!gModuleOn.load(std::memory_order_relaxed) || !gGeo.valid) {
      if (gPtr >= 0) resetGestureLocked();
      return false;
    }
    switch (ev.action) {
      case 0:
      case 5:
        if (ev.action == 0 && gPtr >= 0) {  
          resetGestureLocked();
          changedLook = true;
        }
        if (gPtr >= 0 || !gameHudVisible()) break;
        for (int i = 0; i < 2; ++i)  
          if (gGeo.r[i].contains(ev.x, ev.y)) {
            gPtr = ev.pointerId;
            gWhich = i;
            gDrag = false;
            gDownX = ev.x;
            gDownY = ev.y;
            gStartX = gGeo.r[i].x;
            gStartY = gGeo.r[i].y;
            gPressed.store(i);
            consumed = changedLook = true;
            break;
          }
        break;
      case 2: {
        if (gPtr < 0 || ev.pointerId != gPtr) break;
        consumed = true;
        const float dx = ev.x - gDownX, dy = ev.y - gDownY;
        if (!gDrag && std::hypot(dx, dy) > kSlopDp * gGeo.dev) {
          gDrag = true;
          gPressed.store(-1);
          changedLook = true;
        }
        if (gDrag) {
          Rect &r = gGeo.r[gWhich];
          const float freeW = std::max(0.f, gGeo.W - r.w), freeH = std::max(0.f, gGeo.H - r.h);
          r.x = std::round(std::clamp(gStartX + dx, 0.f, freeW));
          r.y = std::round(std::clamp(gStartY + dy, 0.f, freeH));
          posAtom(gWhich, 0).store(freeW > 0 ? r.x / freeW : 0.f);
          posAtom(gWhich, 1).store(freeH > 0 ? r.y / freeH : 0.f);
          gMoveRev.fetch_add(1);
          changedLook = true;
        }
        break;
      }
      case 1:
      case 6:
        if (gPtr < 0 || ev.pointerId != gPtr) break;
        consumed = true;
        if (!gDrag && gWhich >= 0 && gGeo.r[gWhich].contains(ev.x, ev.y)) fire = gWhich;
        resetGestureLocked();
        changedLook = true;
        break;
      case 3:
        if (gPtr < 0) break;
        consumed = true;
        resetGestureLocked();
        changedLook = true;
        break;
      default: break;
    }
  }
  
  if (fire == 0) {
    if (auto f = gPanelAct.load()) f();
  } else if (fire == 1) {
    if (auto f = gEpAct.load()) f();
  }
  if (changedLook || fire >= 0) wake();
  return consumed;
}

bool changed(float W, float H) {
  auto &s = settings();
  Key k{};
  k.W = W;
  k.H = H;
  for (int i = 0; i < 4; ++i) k.fx[i] = posAtom(i / 2, i % 2).load();
  k.pressed = gPressed.load();
  const auto epOn = gEpOn.load();
  k.epOn = epOn && epOn() ? 1 : 0;
  k.opMode = s.opacityMode.load();
  for (int i = 0; i < sty::InkCount; ++i) k.pct[i] = s.opacityPct[i].load();
  k.accent = col::Accent;
  k.moveRev = gMoveRev.load();
  if (gHaveLast && k == gLast) return false;
  gLast = k;
  gHaveLast = true;
  return true;
}

void draw(Canvas &cv, float W, float H) {
  const float dev = ui::kit::deviceDensity(W, H);
  Rect r[2];
  {
    std::lock_guard<std::mutex> lk(gMu);
    
    if (gPtr < 0 || !gDrag || gGeo.W != W || gGeo.H != H || gGeo.dev != dev) layoutLocked(W, H, dev);
    r[0] = gGeo.r[0];
    r[1] = gGeo.r[1];
  }
  perf::count(perf::LayoutRebuild);
  
  auto &s = settings();
  theme::UiStyle style;
  style.scale = 1.f;
  style.spacing = 1.f;
  int pct[sty::InkCount];
  for (int i = 0; i < sty::InkCount; ++i) pct[i] = s.opacityPct[i].load();
  theme::resolveOpacity(std::clamp(s.opacityMode.load(), 0, sty::OpacityModeCount - 1), pct, style.op);
  const Metrics saved = cv.m;
  const Rect savedClip = cv.clip, savedPressed = cv.pressed;
  const float savedAlpha = cv.alpha;
  cv.m = ui::kit::makeMetrics(dev, false, &style, dev);
  cv.noClip();
  cv.pressed = {};
  cv.alpha = 1.f;
  const auto epOnFn = gEpOn.load();
  const bool epOn = epOnFn && epOnFn();
  const int pressed = gPressed.load();
  for (int i = 1; i >= 0; --i) {  
    const bool on = i == 0 || epOn;
    const bool down = pressed == i;
    
    const uint32_t fill = on ? (down ? col::AccentPressed : col::Accent) : (down ? col::ControlPressed : col::Control);
    cv.fill(r[i], fill, 10.f * dev);
    cv.text(r[i], kLabel[i], on ? col::TextOnAccent : col::AccentText, r[i].h * 0.36f, ui::kit::Align::Center, false);
  }
  cv.m = saved;
  cv.clip = savedClip;
  cv.pressed = savedPressed;
  cv.alpha = savedAlpha;
}

Rect rectOf(int which) {
  std::lock_guard<std::mutex> lk(gMu);
  return gGeo.r[std::clamp(which, 0, 1)];
}

void setStateFnsForTest(bool (*hud)(), bool (*menu)(), bool (*pause)()) {
  gTestHud = hud;
  gTestMenu = menu;
  gTestPause = pause;
}

}  
