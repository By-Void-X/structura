




#include "Ui.hpp"

#include <algorithm>
#include <atomic>
#include <pthread.h>
#include <time.h>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <chrono>
#include <cstring>
#include <functional>
#include <mutex>
#include <set>
#include <span>
#include <string>
#include <unordered_map>
#include <vector>

#include <pl/ModMenu.hpp>

#include "App.hpp"
#include "Catalog.hpp"
#include "Compat.hpp"
#include "Diag.hpp"
#include "HoloState.hpp"
#include "EasyPlace.hpp"
#include "GameVersion.hpp"
#include "Hologram.hpp"
#include "I18n.hpp"
#include "Icons.hpp"
#include "State.hpp"
#include "Theme.hpp"
#include "UiKit.hpp"
#include "HudButtons.hpp"
#include "Overlay.hpp"
#include "Perf.hpp"

namespace lm::ui {
namespace {

using pl::modmenu::DrawCommand;
using pl::modmenu::DrawCommandType;
using kit::Align;
using kit::Canvas;
using kit::Rect;
using KTone = kit::Tone;
using i18n::fmt;
using i18n::tr;
namespace col = theme::color;
namespace sz = theme::size;
namespace sty = theme::style;

const char *gModuleId = "structura.main";
std::string gVersion;
std::atomic_bool gOpen{false};



enum Sec { SecBuilds = 0, SecGuide, SecCreate, SecFavorites, SecRecent, SecSettings, SecCount };
const char *const kNavKeys[SecCount] = {"ui.nav_builds", "ui.nav_guide",  "ui.nav_create",
                                        "ui.nav_favorites", "ui.nav_recent", "ui.nav_settings"};

enum Sub { SubNone = 0, SubDetail, SubLanguage, SubColor, SubSettings };

enum Tool { ToolOverview = 0, ToolMove, ToolLayers, ToolItems, ToolVerify, ToolCount };
const char *const kToolKeys[ToolCount] = {"ui.overview", "ui.move", "ui.layers", "ui.items", "ui.verify"};
bool toolNeedsGame(int t) { return t == ToolMove || t == ToolLayers || t == ToolVerify; }

struct Nav {
  int sec = SecBuilds;
  int sub = SubNone;
  std::string detail;  
  int tool = ToolOverview;
  int color = 0;       
  int page = 0;        // SubSettings: settings category
};

enum PopKind { PopNone = 0, PopType, PopSort, PopCard };
struct Popup {
  int kind = PopNone;
  Rect anchor;
  std::string path;  
  int64_t armedAt = 0;  
};

std::mutex gNavMu;  
Nav gNav;
Popup gPopup;
struct Rename {
  bool open = false;
  std::string path;
} gRename;
std::atomic_bool gDrawer{false};
std::atomic<int64_t> gViewChangedAt{0};

constexpr int kViewKeys = SecCount * 32;
int viewKey(const Nav &n) {
  int k = n.sec * 32;
  if (n.sub == SubDetail) k += 1 + std::clamp(n.tool, 0, ToolCount - 1);
  else if (n.sub == SubLanguage) k += 8;
  else if (n.sub == SubColor) k += 9 + std::clamp(n.color, 0, ColCount - 1);
  else if (n.sub == SubSettings) k += 16 + std::clamp(n.page, 0, 15);
  return k;
}

enum Area { AreaNone = 0, AreaPreview, AreaMats, AreaHandle, AreaContent };


std::mutex gMu;
std::vector<kit::Hit> gHits;
Rect gPanel, gHead, gPrev, gMats, gContent, gSearchRect;
int gContentKey = 0;
float gSurfW = 0, gSurfH = 0, gMargin = 8, gSlop = 12;
float gMatsScroll = 0;
float gScroll[kViewKeys] = {};
float gScrollMax[kViewKeys] = {};  
float gMatsMax = 0.f;


struct ScrollAnchor {
  int key = -1;
  float yDp = 0, viewFrac = 0;
  int64_t at = 0;
} gAnchor;
float gDpNow = 1.f;
float gYaw = 35.f, gPitch = 30.f;
Rect gPressed;  
bool gRailNow = false, gOverlayNow = false;
Rect gNavRect[SecCount], gToolRect[ToolCount];  

std::atomic<int> gStep{1};
std::atomic_bool gHideDone{false};


enum TypeFilter { TypeAll = 0, TypeMine, TypeDownloads, TypeWorlds, TypePacks, TypeGame, TypeCount };
const char *const kTypeKeys[TypeCount] = {"ui.filter_all", "ui.src_mine",  "ui.src_downloads",
                                          "ui.src_worlds", "ui.src_packs", "ui.src_game"};
enum SortBy { SortNewest = 0, SortName, SortSize, SortCount };
const char *const kSortKeys[SortCount] = {"ui.sort_newest", "ui.sort_name", "ui.sort_size"};
std::atomic<int> gType{TypeAll}, gSort{SortNewest};
std::atomic_bool gFiltersOpen{false};


enum Field { FieldNone = 0, FieldSearch, FieldRename };
std::mutex gFieldMu;
int gField = FieldNone;
std::string gSearch, gRenameText;
std::atomic<void (*)()> gKbShow{nullptr}, gKbHide{nullptr};
std::atomic<void (*)(bool)> gEpHandler{nullptr};
std::atomic<int (*)()> gDiagHandler{nullptr};  


constexpr float kScaleMin = 0.6f, kScaleMax = 1.6f;
constexpr float kSizeMin = 0.5f, kSizeMax = 1.0f;
std::atomic<float> gEffScale{0.9f};


int gPtr = -1;
float gDownX = 0, gDownY = 0, gLastX = 0, gLastY = 0;
bool gDragging = false;
Area gDragArea = AreaNone;
int gDownHit = -1;
int64_t gDownAt = 0, gLastRepeat = 0, gLastEvAt = 0;


std::set<std::string> gRegisteredImages;
std::set<uint64_t> gThumbReady;
const Structure *gPrevStruct = nullptr;
uint64_t gPrevSerial = 0;

Canvas gCv;  

bool animationsOn() { return settings().animations.load(); }
bool gameFailed() { return status().phase.load() == Phase::Failed; }

Nav nav() {
  std::lock_guard<std::mutex> lk(gNavMu);
  return gNav;
}
int popupKind() {
  std::lock_guard<std::mutex> lk(gNavMu);
  return gPopup.kind;
}
bool renameOpen() {
  std::lock_guard<std::mutex> lk(gNavMu);
  return gRename.open;
}

void resetScrollFor(const Nav &n) {
  std::lock_guard<std::mutex> lk(gMu);
  gScroll[viewKey(n)] = 0;
  if (n.sub == SubDetail) gMatsScroll = 0;
}


void hideKeyboard() {
  if (auto f = gKbHide.load()) f();
}
void blurField() {
  bool was;
  {
    std::lock_guard<std::mutex> lk(gFieldMu);
    was = gField != FieldNone;
    gField = FieldNone;
  }
  if (was) hideKeyboard();
}
bool focusField(int which) {
  auto show = gKbShow.load();
  if (!show) {
    notify("msg.no_keyboard", Tone::Warning, 3000);
    return false;
  }
  {
    std::lock_guard<std::mutex> lk(gFieldMu);
    gField = which;
  }
  show();
  return true;
}
int focusedField() {
  std::lock_guard<std::mutex> lk(gFieldMu);
  return gField;
}
std::string searchText() {
  std::lock_guard<std::mutex> lk(gFieldMu);
  return gSearch;
}

void closeOverlays() {
  gDrawer.store(false);
  {
    std::lock_guard<std::mutex> lk(gNavMu);
    gPopup = Popup{};
  }
}


void setView(const Nav &n) {
  {
    std::lock_guard<std::mutex> lk(gNavMu);
    gNav = n;
    gPopup = Popup{};
  }
  gDrawer.store(false);
  if (focusedField() == FieldSearch) blurField();
  gViewChangedAt.store(nowMs());
  resetScrollFor(n);
}
void goSection(int sec) {
  Nav n;
  n.sec = sec;
  setView(n);
}
void openDetail(const std::string &path, int tool = ToolOverview) {
  Nav n = nav();
  n.sub = SubDetail;
  n.detail = path;
  n.tool = tool;
  setView(n);
}
void setTool(int tool) {
  Nav n = nav();
  if (n.sub != SubDetail) return;
  n.tool = tool;
  setView(n);
}
void goBack() {
  Nav n = nav();
  if (n.sub == SubColor || n.sub == SubLanguage || n.sub == SubDetail || n.sub == SubSettings) {
    Nav b;
    b.sec = n.sec;
    // a block color is edited from Settings > Hologram, the language from Settings > General
    if (n.sec == SecSettings && n.sub == SubColor) { b.sub = SubSettings; b.page = 1; }
    if (n.sec == SecSettings && n.sub == SubLanguage) { b.sub = SubSettings; b.page = 0; }
    setView(b);
  }
}

KTone kitTone(Tone t) {
  switch (t) {
    case Tone::Success: return KTone::Success;
    case Tone::Warning: return KTone::Warning;
    case Tone::Error: return KTone::Error;
    case Tone::Info: break;
  }
  return KTone::Info;
}


struct Snap {
  std::shared_ptr<const Structure> S;
  std::shared_ptr<const std::vector<PreviewFace>> F;
  std::shared_ptr<CompareData> C;
  Placement P;
  bool placed = false;
  int layer = 0, layer2 = 0;
};
Snap snapshot() {
  Snap n;
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  n.S = m.structure; n.F = m.previewFaces; n.C = m.compare; n.P = m.placement; n.placed = m.placed;
  n.layer = m.layer; n.layer2 = m.layer2;
  return n;
}


struct MatRow {
  uint16_t idx;
  uint32_t total, missing;
};
std::vector<MatRow> gRows;
struct Problem {
  uint8_t kind;  
  uint16_t pal;
  int x, y, z;
  float d2;
};
std::vector<Problem> gNear;

void refreshStats(const std::shared_ptr<const Structure> &S, const std::shared_ptr<CompareData> &C,
                  const Placement &P, bool placed) {
  static const Structure *rowsFor = nullptr;
  static int64_t rowsAt = 0;
  static const CompareData *cmpFor = nullptr;
  if (rowsFor == S.get() && cmpFor == C.get() && nowMs() - rowsAt < 1000) return;
  rowsFor = S.get(); cmpFor = C.get(); rowsAt = nowMs();
  gRows.clear();
  gNear.clear();
  if (!S) return;
  std::vector<uint32_t> miss(S->palette.size(), 0);
  uint32_t ok = 0, wrong = 0, wrongState = 0, missing = 0, extra = 0, unknown = 0;
  auto &st = status();
  const float fx = st.feetX.load(), fy = st.feetY.load(), fz = st.feetZ.load();
  constexpr size_t kNear = 6;
  if (C && C->n == S->volume()) {
    
    const size_t n = C->n;
    const size_t syz = size_t(S->sy) * size_t(S->sz);
    for (size_t i = 0; i < n; ++i) {
      const uint16_t p = S->idx[i];
      if (p == kVoid) continue;
      const uint8_t c = C->cmp(i);
      const bool air = S->palette[p].air;
      switch (c) {
        case CmpCorrect: ++ok; break;
        case CmpWrong: ++wrong; break;
        case CmpWrongState: ++wrongState; break;
        case CmpMissing: ++missing; break;
        case CmpExtra: ++extra; break;
        case CmpUnknown: if (!air) ++unknown; break;
        default: break;
      }
      if (!air && c != CmpCorrect) ++miss[p];
      if (placed && (c == CmpWrong || c == CmpWrongState || c == CmpExtra)) {
        const int x = int(i / syz), y = int((i / size_t(S->sz)) % size_t(S->sy)), z = int(i % size_t(S->sz));
        int wx, wy, wz;
        localToWorld(*S, P, x, y, z, wx, wy, wz);
        const float ex = wx + 0.5f - fx, ey = wy + 0.5f - fy, ez = wz + 0.5f - fz;
        const float d2 = ex * ex + ey * ey + ez * ez;
        if (gNear.size() < kNear || d2 < gNear.back().d2) {
          Problem pr{c, p, wx, wy, wz, d2};
          auto it = std::upper_bound(gNear.begin(), gNear.end(), pr,
                                     [](const Problem &a, const Problem &b) { return a.d2 < b.d2; });
          gNear.insert(it, pr);
          if (gNear.size() > kNear) gNear.pop_back();
        }
      }
    }
  }
  st.cmpCorrect.store(ok); st.cmpWrong.store(wrong); st.cmpMissing.store(missing); st.cmpExtra.store(extra);
  st.cmpWrongState.store(wrongState); st.cmpUnknown.store(unknown);
  for (size_t i = 0; i < S->palette.size(); ++i)
    if (!S->palette[i].air && S->palette[i].count) gRows.push_back({uint16_t(i), S->palette[i].count, miss[i]});
  std::sort(gRows.begin(), gRows.end(), [](const MatRow &a, const MatRow &b) {
    return a.missing != b.missing ? a.missing > b.missing : a.total > b.total;
  });
}


std::string num(long long v) { return std::to_string(v); }
const char *const kTimes = " \xC3\x97 ";
const char *const kDot = "  \xC2\xB7  ";
const char *const kSep = " \xC2\xB7 ";
std::string dimsText(int x, int y, int z) { return num(x) + kTimes + num(y) + kTimes + num(z); }


float emptyState(Canvas &cv, const Rect &view, float y, const char *titleKey, const char *hintKey) {
  const auto &m = cv.m;
  float yy = y + m.s16;
  yy += cv.paragraph(view.x + m.s8, yy, view.w - m.s16, tr(titleKey), col::Text, m.fBody, 2, Align::Center);
  yy += m.s2;
  if (hintKey) yy += cv.paragraph(view.x + m.s8, yy, view.w - m.s16, tr(hintKey), col::TextSecondary,
                                  m.fSmall, 3, Align::Center);
  return yy - y + m.s8;
}


struct Cols {
  float x, w, gap;
  int n;
  Rect cell(int i, float y, float h, int span = 1) const {
    const float cw = (w - gap * (n - 1)) / n;
    return {x + i * (cw + gap), y, cw * span + gap * (span - 1), h};
  }
};

int typeOf(const std::string &source) {
  if (source == "Mine") return TypeMine;
  if (source == "Download" || source == "Documents") return TypeDownloads;
  if (source == "World") return TypeWorlds;
  if (source == "Pack") return TypePacks;
  return TypeGame;
}
const char *sourceLabel(const std::string &source) { return tr(kTypeKeys[typeOf(source)]); }


enum class Ic {
  Builds, Guide, Create, Favorites, Recent, Settings, Menu, Chevron, Dots, Dropdown, Cube, Search,
  Overview, Move, Layers, Items, Verify
};
const Ic kNavIcons[SecCount] = {Ic::Builds, Ic::Guide, Ic::Create, Ic::Favorites, Ic::Recent, Ic::Settings};
const Ic kToolIcons[ToolCount] = {Ic::Overview, Ic::Move, Ic::Layers, Ic::Items, Ic::Verify};


void icon(Canvas &cv, Ic k, float cx, float cy, float s, uint32_t c, uint32_t bg) {
  const Canvas::InkScope ink(cv, sty::InkIcon, bg);  
  const float t = std::max(1.5f, s * 0.11f);  
  const float h = s * 0.5f;
  switch (k) {
    case Ic::Overview: {  
      cv.circle(cx, cy, h * 0.86f, c);
      cv.circle(cx, cy, h * 0.86f - t, bg);
      cv.circle(cx, cy - h * 0.38f, std::max(1.2f, t * 0.75f), c);
      cv.line(cx, cy - h * 0.12f, cx, cy + h * 0.48f, c, t);
      break;
    }
    case Ic::Move: {  
      const float a = h * 0.86f, w = h * 0.3f;
      cv.line(cx - a + w, cy, cx + a - w, cy, c, t);
      cv.line(cx, cy - a + w, cx, cy + a - w, c, t);
      cv.triangle(cx - a, cy, cx - a + w * 1.3f, cy - w, cx - a + w * 1.3f, cy + w, c);
      cv.triangle(cx + a, cy, cx + a - w * 1.3f, cy - w, cx + a - w * 1.3f, cy + w, c);
      cv.triangle(cx, cy - a, cx - w, cy - a + w * 1.3f, cx + w, cy - a + w * 1.3f, c);
      cv.triangle(cx, cy + a, cx - w, cy + a - w * 1.3f, cx + w, cy + a - w * 1.3f, c);
      break;
    }
    case Ic::Layers: {  
      const float w = h * 0.84f, d = h * 0.42f, y0 = cy - h * 0.3f;
      cv.triangle(cx - w, y0, cx, y0 - d, cx + w, y0, c);
      cv.triangle(cx - w, y0, cx, y0 + d, cx + w, y0, c);
      for (int i = 1; i <= 2; ++i) {
        const float y = y0 + i * h * 0.36f;
        cv.line(cx - w, y, cx, y + d, c, t);
        cv.line(cx, y + d, cx + w, y, c, t);
      }
      break;
    }
    case Ic::Items: {  
      for (int i = -1; i <= 1; ++i) {
        const float y = cy + i * h * 0.62f, b = std::max(2.f, h * 0.3f);
        cv.fill({cx - h * 0.84f, y - b * 0.5f, b, b}, c, b * 0.2f);
        cv.line(cx - h * 0.84f + b + t, y, cx + h * 0.84f, y, c, t);
      }
      break;
    }
    case Ic::Verify:  
      cv.line(cx - h * 0.72f, cy + h * 0.02f, cx - h * 0.2f, cy + h * 0.52f, c, t * 1.2f);
      cv.line(cx - h * 0.2f, cy + h * 0.52f, cx + h * 0.76f, cy - h * 0.5f, c, t * 1.2f);
      break;
    case Ic::Builds: {  
      const float g = s * 0.12f, b = (s - g) * 0.5f * 0.9f, x0 = cx - b - g * 0.5f, y0 = cy - b - g * 0.5f;
      for (int i = 0; i < 4; ++i) cv.fill({x0 + (i % 2) * (b + g), y0 + (i / 2) * (b + g), b, b}, c, s * 0.06f);
      break;
    }
    case Ic::Guide: {  
      const float w = s * 0.42f, ph = s * 0.62f, y0 = cy - ph * 0.5f;
      cv.fill({cx - w - t * 0.3f, y0, w, ph}, c, s * 0.05f);
      cv.fill({cx + t * 0.3f, y0, w, ph}, c, s * 0.05f);
      for (int i = 1; i <= 2; ++i) {
        const float ly = y0 + ph * (0.3f * i);
        cv.line(cx - w + t * 0.6f, ly, cx - t * 1.2f, ly, bg, std::max(1.f, t * 0.6f));
        cv.line(cx + t * 1.2f, ly, cx + w - t * 0.6f, ly, bg, std::max(1.f, t * 0.6f));
      }
      break;
    }
    case Ic::Create: {  
      const float b = s * 0.36f;
      cv.line(cx - b, cy - b, cx + b, cy - b, c, t);
      cv.line(cx + b, cy - b, cx + b, cy + b, c, t);
      cv.line(cx + b, cy + b, cx - b, cy + b, c, t);
      cv.line(cx - b, cy + b, cx - b, cy - b, c, t);
      cv.line(cx - b * 0.5f, cy, cx + b * 0.5f, cy, c, t);
      cv.line(cx, cy - b * 0.5f, cx, cy + b * 0.5f, c, t);
      break;
    }
    case Ic::Favorites: {  
      float px[10], py[10];
      for (int i = 0; i < 10; ++i) {
        const float r = (i % 2 == 0) ? h * 0.92f : h * 0.4f;
        const float a = -1.5707963f + i * 0.6283185f;
        px[i] = cx + r * std::cos(a);
        py[i] = cy + s * 0.04f + r * std::sin(a);
      }
      for (int i = 0; i < 10; ++i) cv.triangle(cx, cy + s * 0.04f, px[i], py[i], px[(i + 1) % 10], py[(i + 1) % 10], c);
      break;
    }
    case Ic::Recent: {  
      cv.circle(cx, cy, h * 0.82f, c);
      cv.circle(cx, cy, h * 0.82f - t, bg);
      cv.line(cx, cy, cx, cy - h * 0.48f, c, t);
      cv.line(cx, cy, cx + h * 0.36f, cy + h * 0.1f, c, t);
      break;
    }
    case Ic::Settings: {  
      const float w = s * 0.4f;
      const float ks[3] = {0.35f, -0.3f, 0.1f};
      for (int i = 0; i < 3; ++i) {
        const float ly = cy + (i - 1) * s * 0.28f;
        cv.line(cx - w, ly, cx + w, ly, c, std::max(1.f, t * 0.8f));
        cv.circle(cx + ks[i] * w * 2.f * 0.5f, ly, t * 1.6f, c);
      }
      break;
    }
    case Ic::Menu:  
      for (int i = -1; i <= 1; ++i) cv.line(cx - s * 0.36f, cy + i * s * 0.26f, cx + s * 0.36f, cy + i * s * 0.26f, c, t);
      break;
    case Ic::Chevron:
      cv.line(cx - s * 0.12f, cy - s * 0.26f, cx + s * 0.14f, cy, c, t);
      cv.line(cx + s * 0.14f, cy, cx - s * 0.12f, cy + s * 0.26f, c, t);
      break;
    case Ic::Dots:
      for (int i = -1; i <= 1; ++i) cv.circle(cx, cy + i * s * 0.28f, std::max(1.5f, s * 0.09f), c);
      break;
    case Ic::Dropdown:
      cv.triangle(cx - s * 0.26f, cy - s * 0.12f, cx + s * 0.26f, cy - s * 0.12f, cx, cy + s * 0.16f, c);
      break;
    case Ic::Cube: {  
      const float r = h * 0.9f, dx = r * 0.866f, dy = r * 0.5f;
      const float tx = cx, ty = cy - r;  
      const uint32_t top = c, left = (c & 0xFF000000u) | ((c & 0xFEFEFEu) >> 1) + ((c & 0xFCFCFCu) >> 2),
                     right = (c & 0xFF000000u) | ((c & 0xFEFEFEu) >> 1);
      cv.triangle(tx, ty, cx + dx, cy - dy, cx, cy, top);
      cv.triangle(tx, ty, cx, cy, cx - dx, cy - dy, top);
      cv.triangle(cx - dx, cy - dy, cx, cy, cx, cy + r, left);
      cv.triangle(cx - dx, cy - dy, cx, cy + r, cx - dx, cy + dy, left);
      cv.triangle(cx, cy, cx + dx, cy - dy, cx + dx, cy + dy, right);
      cv.triangle(cx, cy, cx + dx, cy + dy, cx, cy + r, right);
      break;
    }
    case Ic::Search:
      cv.circle(cx - s * 0.08f, cy - s * 0.08f, s * 0.28f, c);
      cv.circle(cx - s * 0.08f, cy - s * 0.08f, s * 0.28f - t, bg);
      cv.line(cx + s * 0.12f, cy + s * 0.12f, cx + s * 0.34f, cy + s * 0.34f, c, t * 1.2f);
      break;
  }
}


std::vector<lib::Entry> gLib;
uint64_t gLibRev = ~0ull;
std::unordered_map<std::string, int> gPathIndex;
bool gHasType[TypeCount] = {};

void refreshLibrary() {
  const uint64_t rev = app::libraryRevision();
  if (rev == gLibRev) return;
  gLibRev = rev;
  gLib = app::library();
  gPathIndex.clear();
  std::fill(std::begin(gHasType), std::end(gHasType), false);
  gHasType[TypeAll] = true;
  for (size_t i = 0; i < gLib.size(); ++i) {
    gPathIndex[gLib[i].path] = int(i);
    gHasType[typeOf(gLib[i].source)] = true;
  }
  cat::syncLibrary(gLib, rev);
}
const lib::Entry *entryFor(const std::string &path) {
  auto it = gPathIndex.find(path);
  return it == gPathIndex.end() ? nullptr : &gLib[size_t(it->second)];
}
std::string lower(std::string_view s) {
  std::string o(s);
  for (auto &c : o) c = char(std::tolower(static_cast<unsigned char>(c)));
  return o;
}

enum ListKind { ListBuilds = 0, ListFavorites, ListRecent };

struct RowCache {
  uint64_t libRev = ~0ull, listsGen = ~0ull, catGen = ~0ull;
  int type = -1, sort = -1;
  std::string search;
  std::vector<int> rows;
} gRowCache[3];

int effectiveType() {
  const int t = std::clamp(gType.load(), 0, TypeCount - 1);
  return gHasType[t] ? t : TypeAll;
}

const std::vector<int> &rowsFor(ListKind kind) {
  RowCache &c = gRowCache[kind];
  const uint64_t lg = cat::listsGeneration();
  const int type = kind == ListBuilds ? effectiveType() : 0;
  const int sort = kind == ListBuilds ? std::clamp(gSort.load(), 0, SortCount - 1) : 0;
  const std::string search = kind == ListBuilds ? lower(searchText()) : std::string();
  const uint64_t cg = (kind == ListBuilds && sort == SortSize) ? cat::generation() : 0;
  if (c.libRev == gLibRev && c.listsGen == lg && c.catGen == cg && c.type == type && c.sort == sort &&
      c.search == search)
    return c.rows;
  c.libRev = gLibRev; c.listsGen = lg; c.catGen = cg; c.type = type; c.sort = sort; c.search = search;
  c.rows.clear();
  if (kind == ListRecent) {
    for (const auto &r : cat::recents())
      if (auto it = gPathIndex.find(r.first); it != gPathIndex.end()) c.rows.push_back(it->second);
    return c.rows;
  }
  for (size_t i = 0; i < gLib.size(); ++i) {
    const auto &e = gLib[i];
    if (kind == ListFavorites) {
      if (cat::isFavorite(e.path)) c.rows.push_back(int(i));
      continue;
    }
    if (type != TypeAll && typeOf(e.source) != type) continue;
    if (!search.empty() && lower(e.title).find(search) == std::string::npos) continue;
    c.rows.push_back(int(i));
  }
  if (kind == ListFavorites || sort == SortName) {
    std::vector<std::string> keys(gLib.size());
    for (int i : c.rows) keys[size_t(i)] = lower(gLib[size_t(i)].title);
    std::stable_sort(c.rows.begin(), c.rows.end(), [&](int a, int b) { return keys[size_t(a)] < keys[size_t(b)]; });
  } else if (sort == SortNewest) {
    std::vector<int64_t> t(gLib.size(), 0);
    for (int i : c.rows) t[size_t(i)] = cat::mtime(gLib[size_t(i)].path);
    std::stable_sort(c.rows.begin(), c.rows.end(), [&](int a, int b) { return t[size_t(a)] > t[size_t(b)]; });
  } else {  
    std::vector<int64_t> n(gLib.size(), -1);
    for (int i : c.rows) {
      cat::Info in;
      if (cat::get(gLib[size_t(i)].path, in, true) && in.state == cat::Info::Ready) n[size_t(i)] = in.blocks;
    }
    std::stable_sort(c.rows.begin(), c.rows.end(), [&](int a, int b) { return n[size_t(a)] > n[size_t(b)]; });
  }
  return c.rows;
}
bool filtersActive() { return effectiveType() != TypeAll || gSort.load() != SortNewest || !searchText().empty(); }
void clearFilters() {
  gType.store(TypeAll);
  gSort.store(SortNewest);
  {
    std::lock_guard<std::mutex> lk(gFieldMu);
    gSearch.clear();
  }
  blurField();
}



void registerThumbs() {
  uint64_t id;
  std::vector<uint8_t> px;
  for (int i = 0; i < 3 && cat::takeThumb(id, px); ++i) {
    char name[40];
    std::snprintf(name, sizeof(name), "st.t.%llu", (unsigned long long)id);
    perf::count(perf::TextureRebuild);
    if (pl::modmenu::registerImage(name, px, cat::kThumb, cat::kThumb)) gThumbReady.insert(id);
  }
}
bool thumbId(const cat::Info &in, std::string &id) {
  if (!in.thumbId || !gThumbReady.count(in.thumbId)) return false;
  char name[40];
  std::snprintf(name, sizeof(name), "st.t.%llu", (unsigned long long)in.thumbId);
  id = name;
  return true;
}



void dropdown(Canvas &cv, const Rect &r, const std::string &text, int kind) {
  const auto &m = cv.m;
  if (!cv.visible(r)) return;
  const bool down = cv.isPressed(r);
  cv.frame(r, down ? col::ControlPressed : col::Control, col::Divider, m.radius, m.border);
  const float tri = m.s12;
  cv.text({r.x + m.s8, r.y, r.w - m.s16 - tri, r.h}, text, col::Text, m.fSmall);
  icon(cv, Ic::Dropdown, r.r() - m.s6 - tri * 0.5f, r.cy(), tri, col::TextSecondary, col::Control);
  cv.hit(r, [r, kind] {
    std::lock_guard<std::mutex> lk(gNavMu);
    gPopup = Popup{};
    gPopup.kind = kind;
    gPopup.anchor = r;
  });
}
float dropdownWidth(const Canvas &cv, const std::string &text) {
  const auto &m = cv.m;  
  return kit::textWidth(text, m.fSmall) + m.s8 + m.s16 + m.s12 + m.s2;
}

void searchField(Canvas &cv, const Rect &r) {
  const auto &m = cv.m;
  const bool focused = focusedField() == FieldSearch;
  const std::string text = searchText();
  cv.frame(r, col::Surface, focused ? col::Accent : col::Divider, m.radius, focused ? std::max(2.f, m.px(1.5f)) : m.border);
  const float is = m.iconS;
  icon(cv, Ic::Search, r.x + m.s8 + is * 0.5f, r.cy(), is, col::TextSecondary, col::Surface);
  const Rect tr_{r.x + m.s14 + is, r.y, r.w - m.px(22) - is, r.h};
  if (text.empty()) {
    if (!focused) cv.text(tr_, tr("ui.search"), col::TextDisabled, m.fSmall);
  } else {
    
    std::string shown = text;
    while (!shown.empty() && kit::textWidth(shown, m.fSmall) > tr_.w - m.s4) {
      size_t i = 1;
      while (i < shown.size() && (static_cast<unsigned char>(shown[i]) & 0xC0) == 0x80) ++i;
      shown.erase(0, i);
    }
    cv.text(tr_, shown, col::Text, m.fSmall, Align::Left, false);
  }
  if (focused && (!animationsOn() || (nowMs() / 530) % 2 == 0)) {
    const float tw = text.empty() ? 0.f : std::min(tr_.w - m.s3, kit::textWidth(text, m.fSmall));
    cv.fill({tr_.x + tw + m.px(1), r.cy() - m.fSmall * 0.55f, std::max(1.f, m.px(1.5f)), m.fSmall * 1.1f}, col::Text);
  }
  {
    std::lock_guard<std::mutex> lk(gMu);
    gSearchRect = r;
  }
  cv.hit(r, [] { focusField(FieldSearch); });
}


void linkRow(Canvas &cv, const Rect &row, std::string_view label, std::string_view value, std::function<void()> fn) {
  const auto &m = cv.m;
  if (!cv.visible(row)) return;
  if (cv.isPressed(row)) cv.fill(row, col::ControlPressed, m.radius);
  const float chev = m.icon;
  icon(cv, Ic::Chevron, row.r() - m.s4 - chev * 0.5f, row.cy(), chev, col::TextSecondary, col::Panel);
  const float vw = std::min(row.w * 0.48f, kit::textWidth(value, m.fSmall) + m.s2);
  const Rect vr{row.r() - chev - m.s10 - vw, row.y, vw, row.h};
  cv.text(vr, value, col::TextSecondary, m.fSmall, Align::Right);
  cv.label({row.x + m.s4, row.y, vr.x - row.x - m.s12, row.h}, label, col::Text, m.fBody);
  cv.hit(row, std::move(fn));
}


void thumbBox(Canvas &cv, const Rect &r, const cat::Info &in, bool known) {
  const auto &m = cv.m;
  cv.frame(r, col::Thumb, col::Divider, m.radius, m.border);
  std::string id;
  if (known && thumbId(in, id)) {
    cv.image(r.inset(m.border), id);
    return;
  }
  const bool missing = known && in.state != cat::Info::Pending;
  icon(cv, Ic::Cube, r.cx(), r.cy(), std::min(r.w, r.h) * 0.42f, missing ? 0xFF3A3F47 : 0xFF4A505A, col::Thumb);
}


float drawMove(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  const Snap sn = snapshot();
  if (!sn.S) return emptyState(cv, view, y0, "ui.no_structure_loaded", "ui.no_structure_hint");
  const int s = gStep.load();
  const Cols c{view.x, view.w, m.gap, 3};
  float y = y0;
  if (sn.placed) {  
    std::string t = fmt("ui.coords", {num(sn.P.ox), num(sn.P.oy), num(sn.P.oz)}) + kDot +
                    fmt("ui.rotation", {num(sn.P.rot * 90)});
    if (sn.P.mirror) t += std::string(kDot) + tr("ui.mirrored");
    const float lh = cv.lineHeight(m.fSmall) + m.s4;
    cv.text({view.x, y, view.w, lh}, t, col::TextSecondary, m.fSmall);
    y += lh + m.s2;
  }
  auto mv = [&](int col_, const char *key, int f, int r, int u) {
    Canvas::ButtonOpts o;
    o.repeat = true;
    cv.button(c.cell(col_, y, m.row), tr(key), [f, r, u, s] { app::moveRel(f * s, r * s, u * s); }, o);
  };
  auto act = [&](int col_, const char *key, std::function<void()> fn, Canvas::Style st = Canvas::Style::Secondary) {
    Canvas::ButtonOpts o;
    o.style = st;
    cv.button(c.cell(col_, y, m.row), tr(key), std::move(fn), o);
  };
  
  mv(0, "ui.up", 0, 0, 1);
  mv(1, "ui.forward", 1, 0, 0);
  act(2, "ui.rotate_right", [] { app::rotate(); });
  y += m.row + m.gap;
  mv(0, "ui.left", 0, -1, 0);
  act(1, "ui.bring_here", [] { app::placeInFront(); }, Canvas::Style::Primary);
  mv(2, "ui.right", 0, 1, 0);
  y += m.row + m.gap;
  mv(0, "ui.down", 0, 0, -1);
  mv(1, "ui.backward", -1, 0, 0);
  act(2, "ui.rotate_left", [] { app::rotateLeft(); });
  y += m.row + m.gap;
  act(0, "ui.mirror", [] { app::mirror(); });
  
  {
    Rect r = c.cell(1, y, m.row, 2);
    const char *lbl = tr("ui.step");
    const float lw = std::min(r.w * 0.4f, kit::textWidth(lbl, m.fSmall) + m.s8);
    const Rect lr = r.takeLeft(lw, m.s2);
    cv.text(lr, lbl, col::TextSecondary, m.fSmall, Align::Right);
    static const char *const kSteps[3] = {"1", "4", "16"};
    const int sel = s == 16 ? 2 : s == 4 ? 1 : 0;
    const float sh = std::min(r.h, std::max(m.touch, r.h - m.s4));
    cv.segmented({r.x, r.cy() - sh * 0.5f, r.w, sh}, kSteps, sel,
                 [](int i) { gStep.store(i == 2 ? 16 : i == 1 ? 4 : 1); });
  }
  y += m.row + m.gap;
  auto &hol = settings().hologram;
  cv.switchRow({view.x, y, view.w, m.row}, tr("ui.hologram"), tr(hol.load() ? "ui.on" : "ui.off"), hol.load(),
               [&hol] { hol.store(!hol.load()); });
  y += m.row;
  return y - y0;
}


float drawLayers(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  const Snap sn = snapshot();
  if (!sn.S) return emptyState(cv, view, y0, "ui.no_structure_loaded", "ui.no_structure_hint");
  const int mode = std::clamp(settings().layerMode.load(), 0, 4);
  const int ax = std::clamp(settings().layerAxis.load(), 0, 2);
  const int n = std::max(1, app::layerSize());
  float y = y0;
  const float segH = std::max(m.ctl, m.row * 0.9f);
  y += cv.sectionTitle(view.x, y, view.w, tr("ui.mode"));
  const char *modes[5] = {tr("ui.layer_all"), tr("ui.layer_single"), tr("ui.layer_below"), tr("ui.layer_above"),
                          tr("ui.layer_range")};
  cv.segmented({view.x, y, view.w, segH}, modes, mode, [](int i) {
    for (int k = 0; k < 5 && settings().layerMode.load() != i; ++k) app::cycleLayerMode();
  });
  y += segH + m.section;
  y += cv.sectionTitle(view.x, y, view.w, tr("ui.axis"));
  static const char *const kAxis[3] = {"X", "Y", "Z"};
  cv.segmented({view.x, y, view.w, segH}, kAxis, ax, [](int i) {
    for (int k = 0; k < 3 && settings().layerAxis.load() != i; ++k) app::cycleLayerAxis();
  });
  y += segH + m.section;
  if (mode == int(LayerMode::All)) return y - y0;
  const std::string v1 = fmt("ui.of", {num(std::clamp(sn.layer, 0, n - 1) + 1), num(n)});
  cv.stepperRow({view.x, y, view.w, m.row}, tr(mode == int(LayerMode::Range) ? "ui.from" : "ui.layer"), v1,
                [] { app::layerDelta(-1); }, [] { app::layerDelta(1); }, [] { app::setLayerToFeet(); });
  y += m.row + m.gap;
  if (mode == int(LayerMode::Range)) {
    const std::string v2 = fmt("ui.of", {num(std::clamp(sn.layer2, 0, n - 1) + 1), num(n)});
    cv.stepperRow({view.x, y, view.w, m.row}, tr("ui.to"), v2, [] { app::layer2Delta(-1); },
                  [] { app::layer2Delta(1); });
    y += m.row + m.gap;
  }
  y += cv.paragraph(view.x, y + m.s2, view.w, tr("ui.layer_hint"), col::TextSecondary, m.fCaption, 2);
  return y - y0 + m.s4;
}


float drawItems(Canvas &cv, const Rect &view, float) {
  const auto &m = cv.m;
  const Snap sn = snapshot();
  gMats = {};
  if (!sn.S) return emptyState(cv, view, view.y, "ui.no_structure_loaded", "ui.no_structure_hint");
  refreshStats(sn.S, sn.C, sn.P, sn.placed);
  Rect area = view;
  
  const char *hdLabel = tr("ui.hide_done");
  const float swFull = std::max(cv.switchWidth(hdLabel, tr("ui.off")), cv.switchWidth(hdLabel, tr("ui.on")));
  uint32_t totalAll = 0, missAll = 0;
  for (const auto &r : gRows) {
    totalAll += r.total;
    missAll += r.missing;
  }
  const bool done = missAll == 0 && totalAll > 0;
  const std::string sum = done ? tr("ui.all_placed") : fmt("ui.missing_of", {num(missAll), num(totalAll)});
  const bool twoRows = swFull + m.gap + kit::textWidth(sum, m.fSmall) > area.w;
  const float sumH = cv.lineHeight(m.fSmall) + m.s4;
  const Rect footer = area.takeBottom(twoRows ? m.row + sumH : m.row, m.gap);
  const float headH = cv.lineHeight(m.fCaption) + m.s4;
  const Rect head = area.takeTop(headH);
  const Rect list = area;
  const float rowH = std::max(m.row * 0.8f, cv.lineHeight(m.fLabel) + m.s8);
  const float icon = rowH * 0.72f;
  const float totW = std::max(kit::textWidth(tr("ui.total"), m.fCaption), kit::textWidth("99999", m.fSmall)) + m.s8;
  const float missW = std::max(kit::textWidth(tr("ui.missing"), m.fCaption),
                               kit::textWidth("9999 (156\xC3\x97" "64+63)", m.fCaption)) + m.s8;
  const float nameX = list.x + m.s6 + icon + m.s8;
  const float totX = list.r() - m.s8 - missW - totW, missX = list.r() - m.s8 - missW;
  cv.text({nameX, head.y, totX - nameX, head.h}, tr("ui.block"), col::TextSecondary, m.fCaption);
  cv.text({totX, head.y, totW - m.s6, head.h}, tr("ui.total"), col::TextSecondary, m.fCaption, Align::Right);
  cv.text({missX, head.y, missW, head.h}, tr("ui.missing"), col::TextSecondary, m.fCaption, Align::Right);

  std::vector<const MatRow *> rows;
  const bool hideDone = gHideDone.load();
  for (const auto &r : gRows)
    if (!hideDone || r.missing) rows.push_back(&r);
  cv.frame(list, col::Surface, col::Divider, m.radius, m.border);
  const Rect inner = list.inset(m.border);
  gMats = inner;
  float scroll;
  {
    std::lock_guard<std::mutex> lk(gMu);
    const float maxScroll = std::max(0.f, rows.size() * rowH - inner.h);
    gMatsMax = maxScroll;
    gMatsScroll = std::clamp(gMatsScroll, 0.f, maxScroll);
    scroll = gMatsScroll;
  }
  const Rect saved = cv.clip;
  cv.setClip(inner);
  if (rows.empty()) cv.text({inner.x, inner.y + m.s8, inner.w, rowH}, tr(missAll ? "ui.no_items" : "ui.all_placed"),
                            col::TextSecondary, m.fLabel, Align::Center);
  char b2[48];
  for (int i = std::max(0, int(scroll / rowH)); i < int(rows.size()); ++i) {
    const float ry = inner.y + i * rowH - scroll;
    if (ry > inner.b()) break;
    const MatRow &r = *rows[size_t(i)];
    const auto &pe = sn.S->palette[r.idx];
    const Rect row{inner.x, ry, inner.w, rowH};
    if (i & 1) cv.fill(row, col::RowAlt);
    const Rect ic{row.x + m.s6, row.cy() - icon * 0.5f, icon, icon};
    const std::string icId = icons::iconFor(pe.name);
    if (!icId.empty()) cv.image(ic, icId);
    else cv.fill(ic.inset(icon * 0.1f), pe.color | 0xFF000000, m.s2);
    
    cv.text({nameX, row.y, totX - nameX - m.s4, row.h}, pe.label, r.missing ? col::Text : col::TextSecondary,
            m.fLabel);
    cv.text({totX, row.y, totW - m.s6, row.h}, num(r.total), col::TextSecondary, m.fSmall, Align::Right);
    if (r.missing) {
      if (r.missing >= 64) std::snprintf(b2, sizeof(b2), "%u (%u\xC3\x97" "64+%u)", r.missing, r.missing / 64, r.missing % 64);
      else std::snprintf(b2, sizeof(b2), "%u", r.missing);
      cv.text({missX, row.y, missW, row.h}, b2, col::Warning, m.fCaption, Align::Right);
    } else {
      const char *done = tr("ui.done");
      cv.text({missX, row.y, missW, row.h}, done, col::Success, m.fCaption, Align::Right);
    }
  }
  cv.scrollBar(inner, rows.size() * rowH, scroll);
  cv.setClip(saved);

  
  Rect f = footer;
  const char *hdState = tr(hideDone ? "ui.on" : "ui.off");
  const uint32_t sumCol = done ? col::Success : col::TextSecondary;
  if (twoRows) {
    const Rect sr = f.takeTop(sumH);
    cv.paragraph(sr.x, sr.y, sr.w, sum, sumCol, m.fSmall, 1, Align::Right);
    cv.switchRow(f, hdLabel, hdState, hideDone, [] { gHideDone.store(!gHideDone.load()); });
  } else {
    const Rect sw = f.takeLeft(swFull, m.gap);
    cv.switchRow(sw, hdLabel, hdState, hideDone, [] { gHideDone.store(!gHideDone.load()); });
    cv.text(f, sum, sumCol, m.fSmall, Align::Right);
  }
  return view.h;
}


float drawVerify(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  const Snap sn = snapshot();
  if (!sn.S) return emptyState(cv, view, y0, "ui.no_structure_loaded", "ui.no_structure_hint");
  if (!sn.placed) return emptyState(cv, view, y0, "ui.not_placed", "ui.not_placed_hint");
  refreshStats(sn.S, sn.C, sn.P, sn.placed);
  auto &st = status();
  const uint32_t ok = st.cmpCorrect.load(), wrong = st.cmpWrong.load(), wst = st.cmpWrongState.load(),
                 miss = st.cmpMissing.load(), extra = st.cmpExtra.load(), unk = st.cmpUnknown.load();
  const uint32_t solid = std::max<uint32_t>(1, sn.S->solidCount);
  const float pct = std::min(100.f, 100.f * ok / solid);
  float y = y0;
  char pbuf[16];
  std::snprintf(pbuf, sizeof(pbuf), "%.1f", pct);
  const float lh = cv.lineHeight(m.fBody);
  const std::string cnt = fmt("ui.progress_count", {num(ok), num(sn.S->solidCount)});
  const float cw = kit::textWidth(cnt, m.fSmall) + m.s4;
  cv.text({view.x, y, view.w - cw - m.s8, lh}, fmt("ui.progress", {pbuf}), pct >= 99.95f ? col::Success : col::Text,
          m.fBody);
  cv.text({view.r() - cw, y, cw, lh}, cnt, col::TextSecondary, m.fSmall, Align::Right);
  y += lh + m.s4;
  const float barH = m.s8;
  cv.fill({view.x, y, view.w, barH}, col::SurfaceRaised, barH * 0.5f);
  if (pct > 0) cv.fill({view.x, y, std::max(barH, view.w * pct / 100.f), barH}, col::Success, barH * 0.5f);
  y += barH + m.section;

  
  struct Item {
    uint32_t color;
    const char *key;
    uint32_t n;
  };
  const auto &bc = settings().blockColor;
  std::vector<Item> items = {{bc[ColMissing].load(), "ui.cmp_missing", miss},
                             {bc[ColWrong].load(), "ui.cmp_wrong", wrong},
                             {bc[ColWrongState].load(), "ui.cmp_state", wst},
                             {bc[ColExtra].load(), "ui.cmp_extra", extra},
                             {bc[ColCorrect].load(), "ui.cmp_correct", ok}};
  if (unk) items.push_back({col::CmpUnknown, "ui.cmp_unknown", unk});
  const Cols c2{view.x, view.w, m.s12, 2};
  const float rh = cv.lineHeight(m.fSmall) + m.s6;
  for (size_t i = 0; i < items.size(); ++i) {
    const Rect cell = c2.cell(int(i % 2), y + (i / 2) * rh, rh);
    const float sw = m.s10;
    cv.fill({cell.x, cell.cy() - sw * 0.5f, sw, sw}, items[i].color | 0xFF000000u, m.s2);
    const std::string n = num(items[i].n);
    const float nw = kit::textWidth(n, m.fSmall) + m.s2;
    cv.text({cell.x + sw + m.s6, cell.y, cell.w - sw - nw - m.s12, cell.h}, tr(items[i].key),
            items[i].n ? col::Text : col::TextSecondary, m.fSmall);
    cv.text({cell.r() - nw, cell.y, nw, cell.h}, n, items[i].n ? col::Text : col::TextDisabled, m.fSmall,
            Align::Right);
  }
  y += ((items.size() + 1) / 2) * rh + m.section;

  if (!gNear.empty()) {
    y += cv.sectionTitle(view.x, y, view.w, tr("ui.nearest"));
    const float prh = cv.lineHeight(m.fSmall) + m.s6;
    for (const auto &pr : gNear) {
      const uint32_t c = 0xFF000000u | settings().blockColor[pr.kind == CmpWrong        ? ColWrong
                                                             : pr.kind == CmpWrongState ? ColWrongState
                                                                                        : ColExtra].load();
      const char *what = tr(pr.kind == CmpExtra ? "ui.fix_remove" : pr.kind == CmpWrongState ? "ui.fix_rotate"
                                                                                             : "ui.fix_replace");
      std::string line = what;
      if (pr.kind != CmpExtra) line += " " + sn.S->palette[pr.pal].label;
      const std::string where = num(pr.x) + " " + num(pr.y) + " " + num(pr.z) + "  \xC2\xB7  " +
                                fmt("ui.distance", {num(std::lround(std::sqrt(pr.d2)))});
      const float ww = kit::textWidth(where, m.fCaption) + m.s2;
      const Rect row{view.x, y, view.w, prh};
      cv.circle(row.x + m.s4, row.cy(), m.px(3.5f), c);
      cv.text({row.x + m.s14, row.y, row.w - ww - m.px(22), row.h}, line, col::Text, m.fSmall);
      cv.text({row.r() - ww, row.y, ww, row.h}, where, col::TextSecondary, m.fCaption, Align::Right);
      y += prh;
    }
    y += m.s6;
  } else if (miss == 0 && wrong == 0 && wst == 0 && extra == 0 && unk == 0) {
    const float rh2 = cv.lineHeight(m.fBody);
    cv.text({view.x, y, view.w, rh2}, tr("ui.all_placed"), col::Success, m.fBody);
    y += rh2 + m.s6;
  }
  auto &hide = settings().hideCorrect;
  cv.switchRow({view.x, y, view.w, m.row}, tr("ui.show_correct"), tr(!hide.load() ? "ui.on" : "ui.off"),
               !hide.load(), [&hide] { hide.store(!hide.load()); });
  y += m.row;
  return y - y0;
}


const char *const kColorKeys[ColCount] = {"ui.cmp_missing", "ui.cmp_wrong", "ui.cmp_state", "ui.cmp_extra",
                                          "ui.cmp_correct"};

float drawColorPicker(Canvas &cv, const Rect &view, float y0, int which) {
  const auto &m = cv.m;
  auto &slot = settings().blockColor[which];
  float y = y0;
  const uint32_t cur = slot.load() & 0xFFFFFFu;
  const int n = int(sizeof(theme::color::Dyes) / sizeof(theme::color::Dyes[0]));
  const float gap = m.s4;
  const int cols = std::clamp(int((view.w + gap) / (m.px(sz::SwatchCell) + gap)), 4, 8);
  const float cell = (view.w - gap * (cols - 1)) / cols;
  for (int i = 0; i < n; ++i) {
    const uint32_t c = theme::color::Dyes[i];
    const Rect r{view.x + (i % cols) * (cell + gap), y + (i / cols) * (cell + gap), cell, cell};
    cv.swatch(r, c, (c & 0xFFFFFFu) == cur);
    cv.hit(r, [&slot, c] { slot.store(c); });
  }
  y += ((n + cols - 1) / cols) * (cell + gap) + m.gap;
  Canvas::ButtonOpts o;
  o.enabled = cur != (kDefaultBlockColor[which] & 0xFFFFFFu);
  cv.button({view.x, y, view.w, m.row}, tr("ui.reset_default"),
            [&slot, which] { slot.store(kDefaultBlockColor[which]); }, o);
  y += m.row;
  return y - y0 + m.s4;
}


float drawSave(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  auto &st = status();
  bool a, b;
  int ax, ay, az, bx, by, bz;
  {
    auto &mm = model();
    std::lock_guard<std::mutex> lk(mm.mu);
    a = mm.cornerA; b = mm.cornerB;
    ax = mm.ax; ay = mm.ay; az = mm.az; bx = mm.bx; by = mm.by; bz = mm.bz;
  }
  const Cols c{view.x, view.w, m.gap, 2};
  float y = y0;
  Canvas::ButtonOpts o1, o2;
  o1.style = a ? Canvas::Style::Success : Canvas::Style::Secondary;
  o2.style = b ? Canvas::Style::Success : Canvas::Style::Secondary;
  cv.button(c.cell(0, y, m.row), tr("ui.corner1"), [] { app::cornerHere(0); }, o1);
  cv.button(c.cell(1, y, m.row), tr("ui.corner2"), [] { app::cornerHere(1); }, o2);
  y += m.row + m.s2;
  const float ch = cv.lineHeight(m.fCaption);
  auto corner = [&](int i, bool set, int x, int yy, int z) {
    const Rect r = c.cell(i, y, ch);
    if (set) cv.text(r, num(x) + "  " + num(yy) + "  " + num(z), col::TextSecondary, m.fCaption, Align::Center);
    else cv.text(r, tr("ui.corner_unset"), col::TextDisabled, m.fCaption, Align::Center);
  };
  corner(0, a, ax, ay, az);
  corner(1, b, bx, by, bz);
  y += ch + m.gap;
  Canvas::ButtonOpts rep;
  rep.repeat = true;
  cv.button(c.cell(0, y, m.row), tr("ui.y_down"), [] { app::cornersY(-1); }, rep);
  cv.button(c.cell(1, y, m.row), tr("ui.y_up"), [] { app::cornersY(1); }, rep);
  y += m.row + m.gap;
  const int prog = st.captureProgress.load();
  Canvas::ButtonOpts sv;
  sv.style = Canvas::Style::Primary;
  if (prog >= 0) {
    sv.enabled = false;
    cv.button(c.cell(0, y, m.row), fmt("ui.saving", {num(prog)}), nullptr, sv);
  } else {
    
    sv.enabled = a && b;
    sv.callWhenDisabled = true;
    cv.button(c.cell(0, y, m.row), tr("ui.save_area"), [] { app::capture(); }, sv);
  }
  cv.button(c.cell(1, y, m.row), tr("ui.clear"), [] { app::clearCorners(); });
  y += m.row + m.section;
  if (a && b) {
    const long long vx = std::abs(ax - bx) + 1, vy = std::abs(ay - by) + 1, vz = std::abs(az - bz) + 1;
    const bool tooBig = vx * vy * vz > 2000000;
    const std::string t = tooBig ? std::string(tr("msg.area_too_large"))
                                 : fmt("ui.area_size", {num(vx), num(vy), num(vz), num(vx * vy * vz)});
    y += cv.paragraph(view.x, y, view.w, t, tooBig ? col::Error : col::Text, m.fSmall, 2);
  } else {
    y += cv.paragraph(view.x, y, view.w, tr("ui.save_hint"), col::TextSecondary, m.fSmall, 3);
  }
  return y - y0 + m.s4;
}


struct CardGeom {
  float h, thumb, nameLines;
  float topH = 0, btnH = 0;  
  bool narrow;
  bool compact = false;      
};
CardGeom cardGeom(const Canvas &cv, float w) {
  const auto &m = cv.m;
  CardGeom g;
  g.narrow = w < m.px(sz::CardNarrowBelow);
  g.compact = m.layout == sty::LayoutCompact;
  g.nameLines = g.narrow && !g.compact ? 2 : 1;
  const float lhB = cv.lineHeight(m.fBody), lhC = cv.lineHeight(m.fCaption);
  if (g.compact && !g.narrow) {
    g.h = std::max(lhB + lhC, m.ctlTall) + 2 * m.s6;
    g.thumb = std::min(m.px(sz::CardThumbCompact), g.h - 2 * m.s6);
    return g;
  }
  if (g.narrow) {
    g.thumb = m.px(g.compact ? sz::CardThumbCompact : sz::CardThumbNarrow);
    g.topH = std::max(g.thumb, g.nameLines * lhB + 2 * lhC);
    g.btnH = m.ctl;
    g.h = g.topH + m.s6 + g.btnH + 2 * m.s8;
    return g;
  }
  const float textH = g.nameLines * lhB + 2 * lhC + m.s2;
  g.h = std::max(textH, m.ctlTall) + 2 * m.s8;
  g.thumb = std::clamp(g.h - 2 * m.s8, m.px(sz::CardThumbMin), m.px(sz::CardThumbMax));
  return g;
}

void useStructure(const std::string &path) { app::select(path); }

void drawCard(Canvas &cv, const Rect &r, const lib::Entry &e, const CardGeom &g, const Snap &sn,
              const std::string &loadedPath) {
  const auto &m = cv.m;
  if (r.b() < cv.clip.y || r.y > cv.clip.b()) return;
  cat::Info in;
  const bool known = cat::get(e.path, in, true);
  const bool loaded = !loadedPath.empty() && e.path == loadedPath;
  cv.frame(r, col::Surface, loaded ? col::Accent : col::Divider, m.radius, loaded ? std::max(2.f, m.px(1.5f)) : m.border);
  const float pad = m.s8;
  
  const std::string path = e.path;
  const char *useL = tr("ui.use");
  const float useW = std::max(m.px(sz::ButtonMinW), kit::textWidth(useL, m.fLabel) + m.s20);
  Canvas::ButtonOpts prim;
  prim.style = Canvas::Style::Primary;
  float btnX;
  auto menuBtn = [&](const Rect &b) {
    if (!cv.visible(b)) return;
    const bool down = cv.isPressed(b);
    if (down) cv.fill(b, col::ControlPressed, m.radius);
    icon(cv, Ic::Dots, b.cx(), b.cy(), m.iconM, col::TextSecondary, col::Surface);
    cv.hit(b, [b, path] {
      std::lock_guard<std::mutex> lk(gNavMu);
      gPopup = Popup{};
      gPopup.kind = PopCard;
      gPopup.anchor = b;
      gPopup.path = path;
    });
  };
  if (g.narrow) {
    const Rect menu{r.r() - pad - m.ctl, r.y + pad, m.ctl, m.ctl};
    const Rect use{r.r() - pad - useW, r.b() - pad - g.btnH, useW, g.btnH};
    menuBtn(menu);
    cv.button(use, useL, [path] { useStructure(path); }, prim);
    btnX = menu.x;
  } else {
    const float bh = m.ctlTall, by = r.cy() - bh * 0.5f;
    const Rect menu{r.r() - pad - m.ctl, by, m.ctl, bh};
    const Rect det{menu.x - m.s4 - std::max(m.px(sz::IconButton), m.touch), by, std::max(m.px(sz::IconButton), m.touch), bh};
    const Rect use{det.x - m.s6 - useW, by, useW, bh};
    menuBtn(menu);
    if (cv.visible(det)) {
      cv.button(det, "", [path] { openDetail(path); });
      icon(cv, Ic::Chevron, det.cx(), det.cy() - m.edge * 0.5f, m.iconS, col::Text, col::Control);
    }
    cv.button(use, useL, [path] { useStructure(path); }, prim);
    btnX = use.x;
  }
  
  const Rect body = g.narrow ? Rect{r.x, r.y, btnX - m.s4 - r.x, g.topH + pad + m.s3}
                             : Rect{r.x, r.y, btnX - m.s6 - r.x, r.h};
  if (cv.isPressed(body)) cv.fill(body.inset(m.border), col::ControlPressed, m.radius);
  const Rect th = g.narrow ? Rect{r.x + pad, r.y + pad, g.thumb, g.thumb}
                           : Rect{r.x + pad, r.cy() - g.thumb * 0.5f, g.thumb, g.thumb};
  thumbBox(cv, th, in, known);
  const float tx = th.r() + m.s10, tw = btnX - m.s8 - tx;
  const float lhB = cv.lineHeight(m.fBody), lhC = cv.lineHeight(m.fCaption);
  const auto name = kit::wrap(e.title, tw, m.fBody, int(g.nameLines));
  const float lines = g.compact && !g.narrow ? 1.f : 2.f;  
  float y = g.narrow ? r.y + pad : r.cy() - (name.size() * lhB + lines * lhC) * 0.5f;
  for (const auto &l : name) {
    cv.text({tx, y, tw, lhB}, l, col::Text, m.fBody, Align::Left, false);
    y += lhB;
  }
  
  uint32_t ic = col::TextSecondary;
  std::string info, info2;
  if (!known || in.state == cat::Info::Pending) info = tr("ui.loading");
  else if (in.state == cat::Info::Ready) {
    info = dimsText(in.sx, in.sy, in.sz);
    info2 = fmt("ui.structure_info", {num(in.blocks)});
    if (!g.narrow) { info += kDot + info2; info2.clear(); }
  } else if (in.state == cat::Info::TooLarge) info = tr("ui.large_file");
  else { info = tr("msg.file_unreadable"); ic = col::Warning; }
  if (g.narrow && info2.empty() && kit::textWidth(info, m.fCaption) > tw) {  
    const auto lines2 = kit::wrap(info, tw, m.fCaption, 2);
    for (const auto &l : lines2) {
      cv.text({tx, y, tw, lhC}, l, ic, m.fCaption);
      y += lhC;
    }
  } else {
    cv.text({tx, y, tw, lhC}, info, ic, m.fCaption);
    y += lhC;
  }
  if (!info2.empty()) {
    cv.text({tx, y, tw, lhC}, info2, ic, m.fCaption);
    y += lhC;
  }
  if (g.compact && !g.narrow) {  
    cv.hit(body, [path] { openDetail(path); });
    return;
  }
  
  Rect st = g.narrow ? Rect{r.x + pad + m.s2, r.b() - pad - g.btnH, r.w - 2 * pad - useW - m.s10, g.btnH}
                     : Rect{tx, y, tw, lhC};
  if (loaded) {
    const char *use = tr("ui.in_use");
    std::string line = use;
    if (sn.placed && sn.C && sn.S && sn.S->solidCount) {
      char pbuf[16];
      std::snprintf(pbuf, sizeof(pbuf), "%.0f", std::min(100.0, 100.0 * status().cmpCorrect.load() / sn.S->solidCount));
      const std::string full = line + kDot + fmt("ui.progress", {pbuf});
      if (kit::textWidth(full, m.fCaption) <= st.w) line = full;  
    }
    cv.text(st, line, col::AccentText, m.fCaption);
  } else {
    const char *src = sourceLabel(e.source);
    const float sw = std::min(st.w, kit::textWidth(src, m.fCaption) + m.px(1));
    cv.text({st.x, st.y, sw, st.h}, src, col::TextSecondary, m.fCaption);
    if (known && in.state == cat::Info::Ready && !in.top.empty() && st.w - sw > m.px(60)) {
      const std::string main = std::string(kSep) + in.top[0].label;
      cv.text({st.x + sw, st.y, st.w - sw, st.h}, main, col::TextDisabled, m.fCaption);
    }
  }
  cv.hit(body, [path] { openDetail(path); });
}



int cardColumns(const kit::Metrics &m, float w) {
  const float gap = m.s6;
  switch (m.layout) {
    case sty::LayoutGrid: return std::max(1, int((w + gap) / (m.px(sz::GridCardMin) + gap)));
    case sty::LayoutVertical:
    case sty::LayoutHorizontal: return 1;
    default: {
      const float c = m.px(sz::CardColumnMin);
      return w >= 3 * c + 2 * gap ? 3 : w >= 2 * c + gap ? 2 : 1;
    }
  }
}

float drawCardList(Canvas &cv, const Rect &view, float y0, const std::vector<int> &rows) {
  const auto &m = cv.m;
  const float gap = m.s6;
  const float inner = view.w - m.s4;  
  const int cols = std::clamp(cardColumns(m, inner), 1, std::max(1, int(rows.size())));
  const float cw = (inner - float(cols - 1) * gap) / float(cols);
  const CardGeom g = cardGeom(cv, cw);
  const Snap sn = snapshot();
  const std::string loadedPath = sn.S ? app::selectedPath() : std::string();
  const int nRows = (int(rows.size()) + cols - 1) / cols;
  const int first = std::max(0, int((view.y - y0) / (g.h + gap)) - 1);
  for (int rr = first; rr < nRows; ++rr) {
    const float y = y0 + rr * (g.h + gap);
    if (y > view.b()) break;
    for (int c = 0; c < cols; ++c) {
      const size_t i = size_t(rr * cols + c);
      if (i >= rows.size()) break;
      drawCard(cv, {view.x + c * (cw + gap), y, cw, g.h}, gLib[size_t(rows[i])], g, sn, loadedPath);
    }
  }
  return nRows * (g.h + gap);
}



template <class F>
void scrolled(Canvas &cv, const Rect &view, int key, F &&draw) {
  const auto &m = cv.m;
  float scroll;
  {
    std::lock_guard<std::mutex> lk(gMu);
    scroll = gScroll[key];
  }
  float a = 1.f;
  if (animationsOn()) a = std::clamp(float(nowMs() - gViewChangedAt.load()) / theme::motion::TabFade, 0.f, 1.f);
  const float slide = (1.f - a) * m.px(theme::motion::TabSlideDp);
  const float savedA = cv.alpha;
  cv.alpha = 0.25f + 0.75f * a;
  const Rect savedClip = cv.clip;
  cv.setClip(view);
  const float contentH = draw(view.y - scroll + slide);
  cv.alpha = savedA;
  cv.scrollBar({view.x, view.y, view.w + m.pad * 0.5f, view.h}, contentH, scroll);
  cv.setClip(savedClip);
  std::lock_guard<std::mutex> lk(gMu);
  gScrollMax[key] = std::max(0.f, contentH - view.h);
  gScroll[key] = std::clamp(gScroll[key], 0.f, gScrollMax[key]);
  gContent = view;
  gContentKey = key;
}

void drawList(Canvas &cv, Rect body, const Nav &n) {
  const auto &m = cv.m;
  const ListKind kind = n.sec == SecFavorites ? ListFavorites : n.sec == SecRecent ? ListRecent : ListBuilds;
  if (kind == ListBuilds && status().oldModsLoaded.load()) {
    const float h = cv.paragraph(body.x, body.y, body.w, tr("status.warning"), col::Warning, m.fSmall, 2);
    body.takeTop(h, m.gap);
  }
  if (kind == ListBuilds && gameFailed()) {  
    const float h = cv.paragraph(body.x, body.y, body.w, tr("status.tab_unavailable"), col::Warning, m.fSmall, 2);
    const float h2 = cv.paragraph(body.x, body.y + h + m.s2, body.w,
                                  fmt("compat.see_details", {tr(kNavKeys[SecSettings]), tr("compat.title")}),
                                  col::AccentText, m.fSmall, 2);
    const Rect note{body.x, body.y, body.w, std::max(h + m.s2 + h2, m.touch)};
    cv.hit(note, [] {  
      goSection(SecSettings);
      Nav sn;
      sn.sec = SecSettings;
      std::lock_guard<std::mutex> lk(gMu);
      gScroll[viewKey(sn)] = 1e9f;
    });
    body.takeTop(note.h, m.gap);
  }
  if (kind == ListBuilds && !gLib.empty()) {
    
    const int type = effectiveType(), sort = std::clamp(gSort.load(), 0, SortCount - 1);
    const std::string typeT = fmt("ui.filter_value", {tr("ui.filter_type"), tr(kTypeKeys[type])});
    const std::string sortT = fmt("ui.filter_value", {tr("ui.sort"), tr(kSortKeys[sort])});
    const char *clearT = tr("ui.clear");
    const float rh = std::max(m.ctlTall, m.row * 0.9f);
    const float typeW = dropdownWidth(cv, typeT), sortW = dropdownWidth(cv, sortT);
    const float clearW = kit::textWidth(clearT, m.fLabel) + m.s20;
    const bool active = filtersActive();
    Canvas::ButtonOpts clr;
    clr.enabled = active;
    const bool oneRow = typeW + sortW + clearW + m.px(sz::SearchMinW) + 3 * m.gap <= body.w;
    Rect row = body.takeTop(rh, m.gap);
    if (oneRow) {
      dropdown(cv, row.takeLeft(typeW, m.gap), typeT, PopType);
      cv.button(row.takeRight(clearW, m.gap), clearT, [] { clearFilters(); }, clr);
      dropdown(cv, row.takeRight(sortW, m.gap), sortT, PopSort);
      searchField(cv, row);
    } else {
      const char *fl = tr("ui.filters");
      const float fw = kit::textWidth(fl, m.fLabel) + m.s20;
      Canvas::ButtonOpts fo;
      fo.style = gFiltersOpen.load() ? Canvas::Style::Primary : Canvas::Style::Secondary;
      cv.button(row.takeRight(fw, m.gap), fl, [] { gFiltersOpen.store(!gFiltersOpen.load()); }, fo);
      searchField(cv, row);
      if (gFiltersOpen.load()) {
        Rect r2 = body.takeTop(rh, m.gap);
        const Cols c{r2.x, r2.w - clearW - m.gap, m.gap, 2};
        dropdown(cv, c.cell(0, r2.y, rh), typeT, PopType);
        dropdown(cv, c.cell(1, r2.y, rh), sortT, PopSort);
        cv.button({r2.r() - clearW, r2.y, clearW, rh}, clearT, [] { clearFilters(); }, clr);
      }
    }
  }
  const auto &rows = rowsFor(kind);
  scrolled(cv, body, viewKey(n), [&](float y0) -> float {
    if (!rows.empty()) return drawCardList(cv, body, y0, rows);
    float h;
    if (kind == ListFavorites) return emptyState(cv, body, y0, "ui.no_favorites", "ui.no_favorites_hint");
    if (kind == ListRecent) return emptyState(cv, body, y0, "ui.no_recent", "ui.no_recent_hint");
    if (!gLib.empty()) {  
      h = emptyState(cv, body, y0, "ui.no_match", nullptr);
      const float bw = std::min(body.w, kit::textWidth(tr("ui.clear_filters"), m.fLabel) + m.px(40));
      cv.button({body.cx() - bw * 0.5f, y0 + h, bw, m.row}, tr("ui.clear_filters"), [] { clearFilters(); });
      return h + m.row + m.s8;
    }
    h = emptyState(cv, body, y0, "ui.no_structures", "ui.empty_builds_hint");
    Canvas::ButtonOpts p;
    p.style = Canvas::Style::Primary;
    const float bw = std::min(body.w, kit::textWidth(tr("ui.import_file"), m.fLabel) + m.px(40));
    cv.button({body.cx() - bw * 0.5f, y0 + h, bw, m.row}, tr("ui.import_file"), [] { app::importFile(); }, p);
    return h + m.row + m.s8;
  });
}


uint32_t diagColor(diag::DSt st);

float drawOverview(Canvas &cv, const Rect &view, float y0, const std::string &path, const lib::Entry *e,
                   const Snap &sn, bool loaded) {
  const auto &m = cv.m;
  cat::Info in;
  const bool known = cat::get(path, in, true);
  const bool wide = view.w >= m.px(sz::WideFrom);
  
  const float pv = std::max(m.px(sz::PreviewMin), std::min({wide ? view.w * 0.4f : view.w, m.px(sz::PreviewMax), view.h - m.s2}));
  Rect prev = wide ? Rect{view.x, y0, pv, pv} : Rect{view.cx() - pv * 0.5f, y0, pv, pv};
  
  if (loaded && sn.S && sn.F) {
    cv.frame(prev, col::Thumb, col::Divider, m.radius, m.border);
    if (sn.S.get() != gPrevStruct) { gPrevStruct = sn.S.get(); ++gPrevSerial; }
    float yaw, pitch;
    {
      std::lock_guard<std::mutex> lk(gMu);
      yaw = gYaw;
      pitch = gPitch;
    }
    const int ys = int(std::lround(yaw / 22.5f)) & 15;
    const int ps = pitch < 22 ? 0 : pitch < 45 ? 1 : 2;
    char id[64];
    std::snprintf(id, sizeof(id), "lm.p.%llu.%d.%d", (unsigned long long)gPrevSerial, ys, ps);
    if (!gRegisteredImages.count(id)) {
      std::vector<uint8_t> px;
      static const float kPitch[3] = {12.f, 32.f, 58.f};
      renderPreview(*sn.S, *sn.F, ys * 22.5f, kPitch[ps], 192, 192, px);
      perf::count(perf::TextureRebuild);
      if (pl::modmenu::registerImage(id, px, 192, 192)) gRegisteredImages.insert(id);
    }
    if (gRegisteredImages.count(id)) cv.image(prev.inset(m.border), id);
    std::lock_guard<std::mutex> lk(gMu);
    gPrev = prev.intersect(view);
  } else {
    thumbBox(cv, prev, in, known);
    if (known && in.state != cat::Info::Pending && !in.thumbId) {
      const float lh = cv.lineHeight(m.fCaption);
      cv.text({prev.x, prev.b() - lh - m.s6, prev.w, lh}, tr("ui.no_preview"), col::TextSecondary, m.fCaption,
              Align::Center);
    }
  }
  
  float fx = wide ? prev.r() + m.s14 : view.x;
  float fw = wide ? view.r() - fx : view.w;
  float y = wide ? y0 : prev.b() + m.s10;
  const std::string title = e ? e->title : (sn.S ? sn.S->title : std::string());
  y += cv.paragraph(fx, y, fw, title, col::Text, m.fTitle, 2);
  if (e) {
    const float lh = cv.lineHeight(m.fSmall);
    cv.text({fx, y, fw, lh}, sourceLabel(e->source), col::TextSecondary, m.fSmall);
    y += lh + m.s6;
  }
  struct Fact {
    const char *key;
    std::string value;
    uint32_t color;
  };
  std::vector<Fact> facts;
  if (known && in.state == cat::Info::Ready) {
    facts.push_back({"ui.dimensions", dimsText(in.sx, in.sy, in.sz), col::Text});
    facts.push_back({"ui.blocks", num(in.blocks), col::Text});
  } else if (known && in.state == cat::Info::TooLarge) {
    facts.push_back({"ui.dimensions", tr("ui.large_file"), col::TextSecondary});
  } else if (known && in.state == cat::Info::Failed) {
    facts.push_back({"ui.dimensions", tr("msg.file_unreadable"), col::Warning});
  } else {
    facts.push_back({"ui.dimensions", tr("ui.loading"), col::TextSecondary});
  }
  if (loaded && sn.S) {
    if (sn.placed && sn.C && sn.S->solidCount) {
      char pbuf[16];
      std::snprintf(pbuf, sizeof(pbuf), "%.1f", std::min(100.0, 100.0 * status().cmpCorrect.load() / sn.S->solidCount));
      facts.push_back({"ui.progress_label", fmt("ui.progress", {pbuf}), col::Text});
    } else {
      facts.push_back({"ui.progress_label", tr("ui.not_placed"), col::TextSecondary});
    }
  } else {
    facts.push_back({"ui.progress_label", tr("ui.not_in_use"), col::TextSecondary});
  }
  // Hologram lifecycle for the structure in use (or the one being loaded): ready / loading / failed.
  {
    const diag::Snapshot ds = diag::snapshot();
    const bool mine = loaded || (ds.loadPath == path && (ds.state == hs::HState::StructureLoading || ds.canRetryLoad));
    if (mine) {
      std::string v;
      uint32_t c = col::TextSecondary;
      if (!loaded && ds.canRetryLoad) {
        v = diag::message(ds.rows[int(diag::Row::File)].st == diag::DSt::Failed ? ds.rows[int(diag::Row::File)]
            : ds.rows[int(diag::Row::Parser)].st == diag::DSt::Failed       ? ds.rows[int(diag::Row::Parser)]
            : ds.rows[int(diag::Row::Palette)].st == diag::DSt::Failed      ? ds.rows[int(diag::Row::Palette)]
            : ds.rows[int(diag::Row::Indices)].st == diag::DSt::Failed      ? ds.rows[int(diag::Row::Indices)]
                                                                            : ds.rows[int(diag::Row::Structure)]);
        c = col::Error;
      } else {
        const diag::RowData &hr = ds.rows[int(diag::Row::Hologram)];
        v = diag::message(hr);
        c = diagColor(hr.st);
      }
      facts.push_back({"diag.r_hologram", v, c});
    }
  }
  float lw = 0;
  for (const auto &f : facts) lw = std::max(lw, kit::textWidth(tr(f.key), m.fSmall));
  lw = std::min(lw + m.s10, fw * 0.45f);
  const float rh = cv.lineHeight(m.fSmall) + m.s4;
  for (const auto &f : facts) {
    cv.text({fx, y, lw - m.s6, rh}, tr(f.key), col::TextSecondary, m.fSmall);
    cv.text({fx + lw, y, fw - lw, rh}, f.value, f.color, m.fSmall);
    y += rh;
  }
  y += m.s8;
  
  {
    const Cols c{fx, fw, m.gap, 2};
    Canvas::ButtonOpts p;
    p.style = Canvas::Style::Primary;
    cv.button(c.cell(0, y, m.row), tr("ui.use"), [path] { useStructure(path); }, p);
    cv.button(c.cell(1, y, m.row), tr("ui.place"), [path, loaded] {
      if (loaded) app::placeInFront();
      else useStructure(path);
      setTool(ToolMove);
    });
    y += m.row;
  }
  y = std::max(y, prev.b()) + m.section;
  
  if (known && in.state == cat::Info::Ready && !in.top.empty()) {
    y += cv.sectionTitle(view.x, y, view.w, tr("ui.materials"));
    const float rh2 = std::max(m.px(30), cv.lineHeight(m.fLabel) + m.s8);
    const float ic = rh2 * 0.72f;
    for (size_t i = 0; i < in.top.size() && i < 5; ++i) {
      const auto &t = in.top[i];
      const Rect row{view.x, y, view.w, rh2};
      if (i & 1) cv.fill(row, col::RowAlt);
      const Rect icr{row.x + m.s6, row.cy() - ic * 0.5f, ic, ic};
      const std::string icId = icons::iconFor(t.name);
      if (!icId.empty()) cv.image(icr, icId);
      else cv.fill(icr.inset(ic * 0.1f), t.color | 0xFF000000, m.s2);
      const std::string n = num(t.count);
      const float nw = kit::textWidth(n, m.fSmall) + m.s4;
      cv.text({icr.r() + m.s8, row.y, row.r() - icr.r() - nw - m.s20, row.h}, t.label, col::Text, m.fLabel);
      cv.text({row.r() - nw - m.s8, row.y, nw, row.h}, n, col::TextSecondary, m.fSmall, Align::Right);
      y += rh2;
    }
    if (in.kinds > 5) {
      const float lh = cv.lineHeight(m.fCaption) + m.s4;
      cv.text({view.x + m.s6, y, view.w - m.s12, lh}, fmt("ui.more_kinds", {num(in.kinds - 5)}),
              col::TextSecondary, m.fCaption);
      y += lh;
    }
  }
  return y - y0 + m.s6;
}


void toolContent(Canvas &cv, const Rect &seg, int i, bool sel, bool icons, bool text, Align a = Align::Center) {
  const auto &m = cv.m;
  const uint32_t c = sel ? col::TextOnAccent : col::TextSecondary;
  const uint32_t bg = sel ? col::Accent : col::Surface;
  const char *label = tr(kToolKeys[i]);
  const float is = m.iconS;
  if (icons && !text) {
    icon(cv, kToolIcons[i], seg.cx(), seg.cy(), is, c, bg);
    return;
  }
  if (!icons) {
    cv.text(seg.inset(m.s3, 0), label, c, m.fSmall, a);
    return;
  }
  const float tw = std::min(kit::textWidth(label, m.fSmall), seg.w - is - m.s6 - 2 * m.s4);
  const float x0 = a == Align::Center ? seg.cx() - (is + m.s6 + tw) * 0.5f : seg.x + m.iconLead;
  icon(cv, kToolIcons[i], x0 + is * 0.5f, seg.cy(), is, c, bg);
  cv.text({x0 + is + m.s6, seg.y, std::max(0.f, seg.r() - m.s3 - (x0 + is + m.s6)), seg.h}, label, c, m.fSmall,
          Align::Left);
}


void toolTabs(Canvas &cv, const Rect &r, int first, int count, int tool, bool icons, bool text) {
  const auto &m = cv.m;
  static const char *const kBlank[ToolCount] = {"", "", "", "", ""};
  const int sel = tool >= first && tool < first + count ? tool - first : -1;
  cv.segmented(r, std::span<const char *const>(kBlank, size_t(count)), sel, [first](int i) { setTool(first + i); });
  const float inset = m.s2, sw = (r.w - 2 * inset) / float(count);
  for (int i = 0; i < count; ++i) {
    const Rect seg{r.x + inset + i * sw, r.y + inset, sw, r.h - 2 * inset};
    toolContent(cv, seg, first + i, i == sel, icons, text);
    gToolRect[first + i] = seg;
  }
}


Rect drawToolSelector(Canvas &cv, Rect body, int tool) {
  const auto &m = cv.m;
  const bool icons = m.showIcons(), text = m.showText();
  float textW = 0;
  for (int i = 0; i < ToolCount; ++i) textW = std::max(textW, kit::textWidth(tr(kToolKeys[i]), m.fSmall));
  auto need = [&](bool ic, bool tx) {  
    return (ic ? m.iconS : 0.f) + (ic && tx ? m.s6 : 0.f) + (tx ? textW : 0.f) + 2 * m.s6;
  };
  const float segH = std::max(m.ctl, m.row * 0.85f);
  const float avail = body.w - m.s4;
  const int lay = m.layout;
  
  if (lay == sty::LayoutVertical) {
    const float colW = std::max(need(icons, text) + m.iconLead, m.touch + 2 * m.s2);  
    if (colW <= body.w * sz::ToolColumnMax && body.w - colW - m.gap >= m.px(sz::ToolAreaMin)) {
      const Rect tc = body.takeLeft(colW, m.gap);
      cv.frame({tc.x, tc.y, tc.w, std::min(tc.h, float(ToolCount) * (m.row + m.s2) + m.s2)}, col::Surface, col::Divider,
               m.radius, m.border);
      for (int i = 0; i < ToolCount; ++i) {
        const Rect r{tc.x + m.s2, tc.y + m.s2 + i * (m.row + m.s2), tc.w - 2 * m.s2, m.row};
        const bool sel = i == tool;
        if (sel) cv.fill(r, col::Accent, m.radius);
        else if (cv.isPressed(r)) cv.fill(r, col::ControlPressed, m.radius);
        toolContent(cv, r, i, sel, icons, text, icons ? Align::Left : Align::Center);
        cv.hit(r, [i] { setTool(i); });
        gToolRect[i] = r;
      }
      return body;
    }
  }
  bool ic = icons, tx = text;
  int rows = 1;  
  switch (lay) {
    case sty::LayoutCompact:  
      if (icons) tx = false;
      if (need(ic, tx) * float(ToolCount) > avail) rows = 2;
      break;
    case sty::LayoutGrid: rows = 2; break;
    case sty::LayoutHorizontal:  
      if (need(ic, tx) * float(ToolCount) > avail && icons) tx = false;
      break;
    default:  
      if (need(ic, tx) * float(ToolCount) <= avail) break;
      if (need(ic, tx) * 3 <= avail) { rows = 2; break; }
      if (icons) { tx = false; rows = need(true, false) * float(ToolCount) <= avail ? 1 : 2; }
      else rows = 2;
      break;
  }
  if (!ic && !tx) tx = true;
  if (rows == 1) {
    toolTabs(cv, body.takeTop(segH, m.gap), 0, ToolCount, tool, ic, tx);
  } else {
    const Rect r1 = body.takeTop(segH, m.s4);
    const Rect r2 = body.takeTop(segH, m.gap);
    toolTabs(cv, r1, 0, 3, tool, ic, tx);
    toolTabs(cv, {r2.x, r2.y, r2.w * 2.f / 3.f, r2.h}, 3, 2, tool, ic, tx);
  }
  return body;
}

void drawDetail(Canvas &cv, Rect body, const Nav &n) {
  const auto &m = cv.m;
  const Snap sn = snapshot();
  const std::string sel = app::selectedPath();
  const bool loaded = sn.S && sel == n.detail;
  const lib::Entry *e = entryFor(n.detail);
  const int tool = std::clamp(n.tool, 0, ToolCount - 1);
  body = drawToolSelector(cv, body, tool);
  const int key = viewKey(n);
  if (tool == ToolOverview) {
    scrolled(cv, body, key, [&](float y0) { return drawOverview(cv, body, y0, n.detail, e, sn, loaded); });
    return;
  }
  
  if (!loaded || (gameFailed() && toolNeedsGame(tool))) {
    const std::string path = n.detail;
    scrolled(cv, body, key, [&](float y0) -> float {
      if (gameFailed() && toolNeedsGame(tool)) return emptyState(cv, body, y0, "status.tab_unavailable", nullptr);
      const float h = emptyState(cv, body, y0, "ui.not_in_use", "ui.not_in_use_hint");
      Canvas::ButtonOpts p;
      p.style = Canvas::Style::Primary;
      const float bw = std::min(body.w, kit::textWidth(tr("ui.use"), m.fLabel) + m.px(60));
      cv.button({body.cx() - bw * 0.5f, y0 + h, bw, m.row}, tr("ui.use"), [path] { useStructure(path); }, p);
      return h + m.row + m.s8;
    });
    return;
  }
  if (tool == ToolItems) {  
    const float savedA = cv.alpha;
    float a = 1.f;
    if (animationsOn()) a = std::clamp(float(nowMs() - gViewChangedAt.load()) / theme::motion::TabFade, 0.f, 1.f);
    cv.alpha = 0.25f + 0.75f * a;
    const Rect saved = cv.clip;
    cv.setClip(body);
    drawItems(cv, body, body.y);
    cv.setClip(saved);
    cv.alpha = savedA;
    return;
  }
  scrolled(cv, body, key, [&](float y0) -> float {
    switch (tool) {
      case ToolMove: return drawMove(cv, body, y0);
      case ToolLayers: return drawLayers(cv, body, y0);
      default: return drawVerify(cv, body, y0);
    }
  });
}


float drawCreate(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  float y = y0;
  y += cv.paragraph(view.x, y, view.w, tr("ui.import_title"), col::Text, m.fBody, 2);
  y += m.s2;
  y += cv.paragraph(view.x, y, view.w, tr("ui.import_hint"), col::TextSecondary, m.fSmall, 5);
  y += m.s8;
  Canvas::ButtonOpts p;
  p.style = Canvas::Style::Primary;
  const float bw = std::min(view.w, std::max(m.px(sz::ActionMinW), kit::textWidth(tr("ui.import_file"), m.fLabel) + m.px(40)));
  cv.button({view.x, y, bw, m.row}, tr("ui.import_file"), [] { app::importFile(); }, p);
  y += m.row + m.section;
  cv.divider(view.x, y, view.w);
  y += m.section;
  y += cv.paragraph(view.x, y, view.w, tr("ui.capture_title"), col::Text, m.fBody, 2);
  y += m.s6;
  if (gameFailed()) {
    y += cv.paragraph(view.x, y, view.w, tr("status.tab_unavailable"), col::Warning, m.fSmall, 2);
    return y - y0 + m.s6;
  }
  y += drawSave(cv, view, y);
  return y - y0;
}


float drawGuide(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  static const char *const kGuide[][2] = {{"guide.import_title", "guide.import_text"},
                                          {"guide.open_title", "guide.open_text"},
                                          {"guide.move_title", "guide.move_text"},
                                          {"guide.layers_title", "guide.layers_text"},
                                          {"guide.overlay_title", "guide.overlay_text"},
                                          {"guide.ep_title", "guide.ep_text"},
                                          {"guide.modes_title", "guide.modes_text"},
                                          {"guide.settings_title", "guide.settings_text"},
                                          {"guide.panel_title", "guide.panel_text"},
                                          {"guide.colors_title", "guide.colors_text"}};
  float y = y0;
  for (const auto &g : kGuide) {
    y += cv.paragraph(view.x, y, view.w, tr(g[0]), col::Text, m.fBody, 2);
    y += m.s2;
    y += cv.paragraph(view.x, y, view.w, tr(g[1]), col::TextSecondary, m.fSmall, 10);
    y += m.section;
  }
  
  const float rh = cv.lineHeight(m.fSmall) + m.s8;
  for (int i = 0; i < ColCount; ++i) {
    const Rect row{view.x, y, view.w, rh};
    const float sw = m.s14;
    cv.fill({row.x + m.s2, row.cy() - sw * 0.5f, sw, sw}, settings().blockColor[i].load() | 0xFF000000u, m.s2);
    cv.text({row.x + sw + m.s12, row.y, row.w - sw - m.s14, row.h}, tr(kColorKeys[i]), col::Text, m.fSmall);
    y += rh;
  }
  return y - y0 + m.s6;
}




float choiceRow(Canvas &cv, const Rect &view, float y, const char *lbl, const char *const *opts, int n, int sel,
                const std::function<void(int)> &pick) {
  const auto &m = cv.m;
  const float segH = std::max(m.ctl, m.row * 0.85f);
  const float lw = kit::textWidth(lbl, m.fBody) + m.s16;
  float one = 0;
  for (int i = 0; i < n; ++i) one = std::max(one, kit::textWidth(opts[i], m.fSmall) + m.s16);
  const float segW = std::max(one * float(n), m.px(sz::SegmentMinW));
  if (lw + segW <= view.w) {
    cv.label({view.x + m.s4, y, view.w - segW - m.s8, m.row}, lbl, col::Text, m.fBody);
    cv.segmented({view.r() - segW, y + (m.row - segH) * 0.5f, segW, segH}, std::span<const char *const>(opts, size_t(n)),
                 sel, pick);
    return m.row;
  }
  const float lh = cv.lineHeight(m.fBody);
  cv.label({view.x + m.s4, y, view.w - m.s4, lh}, lbl, col::Text, m.fBody);
  float h = lh + m.s4;
  if (segW <= view.w || n < 4) {
    cv.segmented({view.x, y + h, view.w, segH}, std::span<const char *const>(opts, size_t(n)), sel, pick);
    return h + segH;
  }
  const int a = (n + 1) / 2, b = n - a;  
  const float w1 = view.w, w2 = view.w * float(b) / float(a);
  cv.segmented({view.x, y + h, w1, segH}, std::span<const char *const>(opts, size_t(a)), sel < a ? sel : -1, pick);
  cv.segmented({view.x, y + h + segH + m.s4, w2, segH}, std::span<const char *const>(opts + a, size_t(b)),
               sel >= a ? sel - a : -1, [pick, a](int i) { pick(a + i); });
  return h + 2 * segH + m.s4;
}


float infoRow(Canvas &cv, const Rect &view, float y, std::string_view lbl, std::string_view value, uint32_t vc) {
  const auto &m = cv.m;
  const float lw = kit::textWidth(lbl, m.fBody), vw = kit::textWidth(value, m.fBody);
  const float h = std::max(m.ctl, cv.lineHeight(m.fBody) + m.s8);
  if (lw + vw + m.s16 + m.s8 <= view.w) {
    cv.label({view.x + m.s4, y, lw + m.s4, h}, lbl, col::TextSecondary, m.fBody);
    cv.text({view.x + m.s4 + lw + m.s16, y, view.w - lw - m.s16 - m.s8, h}, value, vc, m.fBody, Align::Right);
    return h;
  }
  const float lh = cv.lineHeight(m.fBody);
  cv.label({view.x + m.s4, y, view.w - m.s8, lh}, lbl, col::TextSecondary, m.fBody);
  const float ph = cv.paragraph(view.x + m.s4, y + lh + m.s2, view.w - m.s8, value, vc, m.fBody, 3);
  return lh + m.s2 + ph + m.s4;
}

uint32_t stateColor(compat::State st) {
  switch (st) {
    case compat::State::Ok: return col::Success;
    case compat::State::Limited: return col::Warning;
    case compat::State::Failed: return col::Error;
    default: return col::TextSecondary;
  }
}


struct CompatView {
  unsigned rev = 0, lang = ~0u;
  compat::Level level = compat::Level::Starting;
  std::string mc, launcher, abi, api;
  compat::State st[compat::kCount] = {};
  compat::Reason why[compat::kCount] = {};
};
const CompatView &compatView() {
  static CompatView v;
  const unsigned rev = compat::revision();
  if (v.rev == rev && v.lang == i18n::generation()) return v;
  v.rev = rev;
  v.lang = i18n::generation();
  const compat::Env e = compat::env();
  v.level = compat::level();
  v.mc = e.mc.valid() ? ver::normalized(e.mc) : std::string(tr("compat.unknown"));
  if (e.mc.valid() && !e.buildId.empty())
    v.mc += std::string(" ") + tr(e.tested ? "compat.build_tested" : "compat.build_untested");
  v.launcher = e.launcher.empty() ? std::string(tr("compat.unknown")) : e.launcher;
  v.abi = e.abi.empty() ? std::string(tr("compat.unknown")) : e.abi;
  if (!e.deviceAbi.empty() && e.deviceAbi != e.abi) v.abi += " / " + e.deviceAbi;
  v.api = e.androidApi > 0 ? fmt("compat.api_value", {num(e.androidApi)}) : std::string(tr("compat.unknown"));
  for (int i = 0; i < compat::kCount; ++i) {
    const compat::Entry en = compat::get(compat::Comp(i));
    v.st[i] = en.state;
    v.why[i] = en.reason;
  }
  return v;
}


uint32_t diagColor(diag::DSt st) {
  switch (st) {
    case diag::DSt::Ok:
    case diag::DSt::Ready:
    case diag::DSt::Active: return col::Success;
    case diag::DSt::Warning: return col::Warning;
    case diag::DSt::Failed: return col::Error;
    case diag::DSt::Loading: return col::Accent;
    default: return col::TextSecondary;
  }
}

// One row per subsystem (never blank: "Waiting"/"Not checked" are explicit states).
float drawDiagnosticRows(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  const diag::Snapshot snap = diag::snapshot();
  float y = y0 + cv.sectionTitle(view.x, y0, view.w, tr("diag.title"));
  const int64_t now = hs::monoMs();
  for (int i = 0; i < diag::kRows; ++i) {
    const diag::RowData &r = snap.rows[i];
    y += infoRow(cv, view, y, tr(diag::rowKey(diag::Row(i))), tr(diag::statusKey(r.st)), diagColor(r.st));
    y += cv.paragraph(view.x + m.s12, y, view.w - m.s16, diag::message(r), col::Text, m.fSmall, 3);
    std::string meta = r.detail;
    if (!r.error.empty()) meta += (meta.empty() ? "" : " | ") + std::string(tr("diag.error")) + ": " + r.error;
    const int64_t age = r.changedMs ? std::max<int64_t>(0, now - r.changedMs) / 1000 : 0;
    meta += (meta.empty() ? "" : " | ") + fmt("diag.age", {num(int(std::min<int64_t>(age, 1 << 30))), num(int(r.gen & 0x7FFFFFFF))});
    y += cv.paragraph(view.x + m.s12, y + m.s2, view.w - m.s16, meta, col::TextSecondary, m.fSmall, 4) + m.s2;
    y += m.s6;
  }
  // Actions: refresh (reads state only), retry hologram / retry load when something failed.
  const char *labels[3] = {tr("diag.refresh"), tr("diag.retry"), tr("diag.retry_load")};
  float bx = view.x;
  auto btn = [&](const char *label, std::function<void()> fn) {
    const float bw = std::min(view.w, std::max(m.px(sz::ActionMinW), kit::textWidth(label, m.fLabel) + m.s20));
    if (bx > view.x && bx + bw > view.r()) { bx = view.x; y += m.row + m.s6; }
    cv.button({bx, y, bw, m.row}, label, std::move(fn));
    bx += bw + m.s8;
  };
  btn(labels[0], [] {
    diag::requestRefresh();
    notify("diag.refreshed", Tone::Info, 1200);
  });
  if (snap.canRetryHologram)
    btn(labels[1], [] {
      hs::rt().retryRequest.store(true);
      diag::requestRefresh();
      notify("diag.retrying", Tone::Info, 1500);
    });
  if (snap.canRetryLoad) {
    const std::string path = snap.loadPath;
    btn(labels[2], [path] { app::select(path); });
  }
  y += m.row + m.s6;
  return y - y0;
}

float drawCompatibility(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  const CompatView &v = compatView();
  float y = y0 + cv.sectionTitle(view.x, y0, view.w, tr("compat.title"));
  const uint32_t lc = v.level == compat::Level::Full          ? col::Success
                      : v.level == compat::Level::Unavailable ? col::Error
                      : v.level == compat::Level::Partial     ? col::Warning
                                                              : col::TextSecondary;
  y += infoRow(cv, view, y, tr("compat.status"), tr(compat::levelKey(v.level)), lc);
  y += infoRow(cv, view, y, tr("compat.minecraft"), v.mc, col::Text);
  y += infoRow(cv, view, y, tr("compat.launcher"), v.launcher, col::Text);
  y += infoRow(cv, view, y, tr("compat.abi"), v.abi, col::Text);
  y += infoRow(cv, view, y, tr("compat.android"), v.api, col::Text);
  y += m.s6;
  // Reasons/actions of failed init components stay visible (they explain hook-level problems).
  for (int i = 0; i < compat::kCount; ++i) {
    if (v.why[i] == compat::Reason::None || v.st[i] == compat::State::Ok || v.st[i] == compat::State::Pending) continue;
    if (v.why[i] == compat::Reason::BuildNotTested || v.why[i] == compat::Reason::NeedsPlayerUpdate) continue;
    y += cv.paragraph(view.x + m.s4, y, view.w - m.s8,
                      std::string(tr(compat::compKey(compat::Comp(i)))) + ": " + tr(compat::reasonKey(v.why[i])),
                      stateColor(v.st[i]), m.fSmall, 4);
    if (const char *ak = compat::actionKey(v.why[i]))
      y += cv.paragraph(view.x + m.s12, y + m.s2, view.w - m.s16, tr(ak), col::Text, m.fSmall, 4) + m.s2;
    y += m.s6;
  }
  y += drawDiagnosticRows(cv, view, y);
  y += m.s6;
  const float bw = std::min(view.w, std::max(m.px(sz::ActionMinW), kit::textWidth(tr("compat.copy"), m.fLabel) + m.s20));
  cv.button({view.x, y, bw, m.row}, tr("compat.copy"), [] {
    const auto h = gDiagHandler.load();
    const int r = h ? h() : 0;
    if (r == 1) notify("compat.copied", Tone::Success, 2500);
    else if (r == 2) notify("compat.saved", Tone::Info, 4000);
    else notify("compat.copy_failed", Tone::Warning, 3000);
  });
  y += m.row;
  return y - y0;
}

// Settings: a hub of categories, each one its own page (back arrow returns to the hub)
enum SetPage { PageGeneral = 0, PageHologram, PageEasyPlace, PageOverlay, PagePanel, PageAdvanced, PageCount };
const char *const kPageKeys[PageCount] = {"set.general", "set.hologram", "set.easy_place",
                                          "set.overlay", "set.panel",    "set.advanced"};
const char *const kPageHints[PageCount] = {"set.general_hint", "set.hologram_hint", "set.easy_place_hint",
                                           "set.overlay_hint", "set.panel_hint",    "set.advanced_hint"};

float setGeneral(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  auto &s = settings();
  (void)s;
  float y = y0;
  {
    std::string cur = i18n::choice() == "auto" ? fmt("ui.language_auto_value", {i18n::activeName()}) : i18n::activeName();
    linkRow(cv, {view.x, y, view.w, m.row}, tr("ui.language"), cur, [] {
      Nav n = nav();
      n.sub = SubLanguage;
      setView(n);
    });
    y += m.row + m.gap;
  }
  {
    const char *themes[theme::ThemeCount] = {tr("ui.theme_emerald"), tr("ui.theme_blue")};
    y += choiceRow(cv, view, y, tr("ui.theme"), themes, theme::ThemeCount,
                   std::clamp(s.theme.load(), 0, theme::ThemeCount - 1), [](int i) { settings().theme.store(i); });
    y += m.gap;
  }
  auto &an = s.animations;
  cv.switchRow({view.x, y, view.w, m.row}, tr("ui.animations"), tr(an.load() ? "ui.on" : "ui.off"), an.load(),
               [&an] { an.store(!an.load()); });
  y += m.row + m.section;

  
  return y - y0 + m.s4;
}

float setHologram(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  auto &s = settings();
  (void)s;
  float y = y0;
  cv.stepperRow({view.x, y, view.w, m.row}, tr("ui.opacity"), num(int(s.alpha.load() * 100 + 0.5f)) + "%",
                [] { settings().alpha.store(std::max(0.1f, settings().alpha.load() - 0.05f)); },
                [] { settings().alpha.store(std::min(1.f, settings().alpha.load() + 0.05f)); });
  y += m.row + m.gap;
  cv.stepperRow({view.x, y, view.w, m.row}, tr("ui.range"), fmt("ui.range_value", {num(s.radius.load())}),
                [] { settings().radius.store(std::max(6, settings().radius.load() - 4)); },
                [] { settings().radius.store(std::min(48, settings().radius.load() + 4)); });
  y += m.row + m.gap;
  auto &hol = s.hologram;
  cv.switchRow({view.x, y, view.w, m.row}, tr("ui.show_hologram"), tr(hol.load() ? "ui.on" : "ui.off"), hol.load(),
               [&hol] { hol.store(!hol.load()); });
  y += m.row + m.gap;
  {  // display filter only: never changes what Easy Place places
    const char *flt[4] = {tr("prog.filter_all"), tr("prog.filter_missing"), tr("prog.filter_incorrect"),
                          tr("prog.filter_unverified")};
    y += choiceRow(cv, view, y, tr("prog.holo_filter"), flt, 4, std::clamp(s.holoFilter.load(), 0, 3),
                   [](int i) { settings().holoFilter.store(i); });
    y += m.gap;
  }
  y += m.section;
  y += cv.sectionTitle(view.x, y, view.w, tr("ui.block_colors"));
  for (int i = 0; i < ColCount; ++i) {
    const Rect row{view.x, y, view.w, m.row};
    if (cv.visible(row)) {
      if (cv.isPressed(row)) cv.fill(row, col::ControlPressed, m.radius);
      const float chev = m.icon, sw = m.px(28);
      icon(cv, Ic::Chevron, row.r() - m.s4 - chev * 0.5f, row.cy(), chev, col::TextSecondary, col::Panel);
      const Rect swr{row.r() - chev - m.s10 - sw, row.cy() - sw * 0.5f, sw, sw};
      cv.swatch(swr, s.blockColor[i].load(), false);
      cv.label({row.x + m.s4, row.y, swr.x - row.x - m.s12, row.h}, tr(kColorKeys[i]), col::Text, m.fBody);
    }
    cv.hit(row, [i] {
      Nav n = nav();
      n.sub = SubColor;
      n.color = i;
      setView(n);
    });
    y += m.row + m.s2;
  }
  
  y += m.section;
  return y - y0 + m.s4;
}

float setEasyPlace(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  auto &s = settings();
  (void)s;
  float y = y0;
  {
    const bool installed = ep::state().installed.load();
    const bool on = installed && ep::state().enabled.load();
    cv.switchRow({view.x, y, view.w, m.row}, tr("ui.easy_place"),
                 tr(!installed ? "ui.unavailable" : on ? "ui.on" : "ui.off"), on, [on] {
                   if (auto h = gEpHandler.load()) h(!on);
                 });
    y += m.row + m.gap;
    // placement mode: what Easy Place does about block states (default Safe)
    const char *modes[5] = {tr("ui.ep_mode_missing"), tr("ui.ep_mode_verify"), tr("ui.ep_mode_safe"),
                            tr("ui.ep_mode_correct"), tr("ui.ep_mode_strict")};
    y += choiceRow(cv, view, y, tr("ui.ep_mode"), modes, 5, std::clamp(s.epMode.load(), 0, 4),
                   [](int i) { settings().epMode.store(i); });
    y += m.gap;
    auto sw = [&](const char *key, std::atomic_bool &a) {
      cv.switchRow({view.x, y, view.w, m.row}, tr(key), tr(a.load() ? "ui.on" : "ui.off"), a.load(), [&a] {
        a.store(!a.load());
        ep::invalidate("setting changed");
      });
      y += m.row + m.gap;
    };
    sw("prog.ep_layer_only", s.epLayerOnly);
    sw("prog.ep_bottom_up", s.epBottomUp);
    sw("prog.ep_safe_only", s.epSafeOnly);
    cv.stepperRow({view.x, y, view.w, m.row}, tr("prog.ep_rate"), num(s.epRate.load()),
                  [] { settings().epRate.store(std::max(1, settings().epRate.load() - 1)); },
                  [] { settings().epRate.store(std::min(20, settings().epRate.load() + 1)); });
    y += m.row + m.gap;
    cv.stepperRow({view.x, y, view.w, m.row}, tr("prog.ep_batch"), num(s.epBatch.load()),
                  [] { settings().epBatch.store(std::max(1, settings().epBatch.load() - 1)); },
                  [] { settings().epBatch.store(std::min(4, settings().epBatch.load() + 1)); });
    y += m.row + m.section;
  }

  // what "only visible layer" means, in plain words (it now also covers taps left to the game)
  y += cv.paragraph(view.x + m.s4, y, view.w - m.s8, tr("set.ep_layer_note"), col::TextSecondary, m.fSmall, 9);
  y += m.gap;
  return y - y0 + m.s4;
}

float setOverlay(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  auto &s = settings();
  (void)s;
  float y = y0;
  // progress / layer overlay (separate touch panel)
  y += cv.sectionTitle(view.x, y, view.w, tr("prog.section"));
  {
    auto &ov = s.ovVisible;
    cv.switchRow({view.x, y, view.w, m.row}, tr("prog.show"), tr(ov.load() ? "ui.on" : "ui.off"), ov.load(),
                 [&ov] { ov.store(!ov.load()); });
    y += m.row + m.gap;
    auto step = [&](const char *key, std::atomic<float> &a, float lo, float hi, float st) {
      cv.stepperRow({view.x, y, view.w, m.row}, tr(key), num(std::lround(a.load() * 100)) + "%",
                    [&a, lo, st] { a.store(std::max(lo, std::round((a.load() - st) * 100.f) / 100.f)); },
                    [&a, hi, st] { a.store(std::min(hi, std::round((a.load() + st) * 100.f) / 100.f)); });
      y += m.row + m.gap;
    };
    step("prog.scale", s.ovScale, 0.7f, 1.6f, 0.1f);
    step("prog.width", s.ovWidth, 0.8f, 1.6f, 0.1f);
    step("prog.opacity", s.ovAlpha, 0.3f, 1.f, 0.1f);
    const char *disp[3] = {tr("prog.disp_both"), tr("prog.disp_blocks"), tr("prog.disp_layer")};
    y += choiceRow(cv, view, y, tr("prog.display"), disp, 3, std::clamp(s.ovDisplay.load(), 0, 2),
                   [](int i) { settings().ovDisplay.store(i); });
    y += m.gap;
    cv.button({view.x, y, view.w, m.row}, tr("prog.reset_pos"), [] {
      settings().ovX.store(-1.f);
      settings().ovY.store(-1.f);
      settings().ovScale.store(1.f);
      settings().ovWidth.store(1.f);
    });
    y += m.row + m.section;
  }

  
  return y - y0 + m.s4;
}

float setPanel(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  auto &s = settings();
  (void)s;
  float y = y0;
  {
    const float ps = std::clamp(s.panelSize.load(), kSizeMin, kSizeMax);
    Canvas::StepperOpts so;
    so.repeat = false;  
    so.decEnabled = ps > kSizeMin + 0.001f;
    so.incEnabled = ps < kSizeMax - 0.001f;
    cv.stepperRow({view.x, y, view.w, m.row}, tr("ui.panel_size"), num(std::lround(ps * 100)) + "%",
                  [] {
                    const float v = std::round(settings().panelSize.load() * 20.f - 1.f) / 20.f;
                    settings().panelSize.store(std::clamp(v, kSizeMin, kSizeMax));
                  },
                  [] {
                    const float v = std::round(settings().panelSize.load() * 20.f + 1.f) / 20.f;
                    settings().panelSize.store(std::clamp(v, kSizeMin, kSizeMax));
                  },
                  nullptr, so);
    y += m.row + m.gap;
  }
  {  
    const char *sizes[sty::SizeModeCount] = {tr("ui.size_compact"), tr("ui.size_medium"), tr("ui.size_large"),
                                             tr("ui.auto")};
    y += choiceRow(cv, view, y, tr("ui.control_size"), sizes, sty::SizeModeCount,
                   std::clamp(s.controlSize.load(), 0, sty::SizeModeCount - 1),
                   [](int i) { settings().controlSize.store(i); });
    y += m.gap;
  }
  {  
    static const char *const kPct[4] = {"25%", "50%", "75%", "100%"};
    const char *modes[sty::OpacityModeCount] = {kPct[0], kPct[1], kPct[2], kPct[3], tr("ui.custom")};
    const int mode = std::clamp(s.opacityMode.load(), 0, sty::OpacityModeCount - 1);
    y += choiceRow(cv, view, y, tr("ui.panel_opacity"), modes, sty::OpacityModeCount, mode, [](int i) {
      auto &st = settings();
      if (i == sty::OpCustom && st.opacityMode.load() != sty::OpCustom &&
          st.opacityMode.load() >= sty::Op25 && st.opacityMode.load() <= sty::Op100) {
        
        for (int k = 0; k < sty::InkCount; ++k) st.opacityPct[k].store(sty::OpacityPreset[st.opacityMode.load()]);
      }
      st.opacityMode.store(i);
    });
    y += m.gap;
    static std::atomic_bool sCustomOpen{false};  
    if (mode == sty::OpCustom) {
      char sum[48];
      std::snprintf(sum, sizeof(sum), "%d / %d / %d / %d / %d", int(std::lround(m.op[0] * 100)),
                    int(std::lround(m.op[1] * 100)), int(std::lround(m.op[2] * 100)), int(std::lround(m.op[3] * 100)),
                    int(std::lround(m.op[4] * 100)));
      const bool open = sCustomOpen.load();
      const Rect row{view.x, y, view.w, m.row};
      if (cv.visible(row)) {
        if (cv.isPressed(row)) cv.fill(row, col::ControlPressed, m.radius);
        const float chev = m.icon;
        const float cx = row.r() - m.s4 - chev * 0.5f;
        if (open) icon(cv, Ic::Dropdown, cx, row.cy(), chev, col::TextSecondary, col::Panel);
        else icon(cv, Ic::Chevron, cx, row.cy(), chev, col::TextSecondary, col::Panel);
        const float vw = kit::textWidth(sum, m.fSmall) + m.s8;
        const char *lbl = tr("ui.custom_values");
        if (kit::textWidth(lbl, m.fBody) + vw + chev + m.s20 <= row.w)
          cv.text({row.r() - chev - m.s10 - vw, row.y, vw, row.h}, sum, col::TextSecondary, m.fSmall, Align::Right);
        cv.label({row.x + m.s4, row.y, row.w - chev - m.s16 - vw, row.h}, lbl, col::Text, m.fBody);
      }
      cv.hit(row, [] { sCustomOpen.store(!sCustomOpen.load()); });
      y += m.row + m.s2;
    }
    if (mode == sty::OpCustom && sCustomOpen.load()) {
      static const char *const kInkKeys[sty::InkCount] = {"ui.op_background", "ui.op_borders", "ui.op_text",
                                                          "ui.op_icons", "ui.op_selected"};
      const float *eff = m.op;
      for (int k = 0; k < sty::InkCount; ++k) {
        const int shown = std::lround(eff[k] * 100.f);  
        Canvas::StepperOpts so;
        so.decEnabled = std::lround(eff[k] * 100.f) - sty::OpacityStepPct >=
                        std::lround((k == sty::InkText ? sty::textFloor(eff[sty::InkBg]) : sty::OpacityFloor[k]) * 100.f);
        so.incEnabled = shown < sty::OpacityMaxPct;
        cv.stepperRow({view.x + m.s12, y, view.w - m.s12, m.row}, tr(kInkKeys[k]), num(shown) + "%",
                      [k, shown] {
                        settings().opacityPct[k].store(std::max(sty::OpacityMinPct, shown - sty::OpacityStepPct));
                      },
                      [k, shown] {
                        settings().opacityPct[k].store(std::min(sty::OpacityMaxPct, shown + sty::OpacityStepPct));
                      },
                      nullptr, so);
        y += m.row + m.s2;
      }
      y += m.gap - m.s2;
    }
    if (m.op[sty::InkBg] < sty::OpacityWarnBelow) {
      y += cv.paragraph(view.x + m.s4, y, view.w - m.s8, tr("ui.opacity_warning"), col::Warning, m.fSmall, 3);
      y += m.gap;
    }
  }
  {
    const char *lays[sty::LayoutModeCount] = {tr("ui.auto"), tr("ui.layout_compact"), tr("ui.layout_grid"),
                                              tr("ui.layout_vertical"), tr("ui.layout_horizontal")};
    y += choiceRow(cv, view, y, tr("ui.layout"), lays, sty::LayoutModeCount,
                   std::clamp(s.uiLayout.load(), 0, sty::LayoutModeCount - 1),
                   [](int i) { settings().uiLayout.store(i); });
    y += m.gap;
    const char *labs[sty::LabelModeCount] = {tr("ui.labels_icons_text"), tr("ui.labels_icons"), tr("ui.labels_text")};
    y += choiceRow(cv, view, y, tr("ui.labels"), labs, sty::LabelModeCount,
                   std::clamp(s.uiLabels.load(), 0, sty::LabelModeCount - 1),
                   [](int i) { settings().uiLabels.store(i); });
    y += m.gap;
  }
  {
    const char *rl = tr("ui.restore_defaults");
    const float bw = std::min(view.w, std::max(m.px(sz::ActionMinW), kit::textWidth(rl, m.fLabel) + m.s20));
    cv.button({view.x, y, bw, m.row}, rl, [] {
      resetAppearance();
      notify("msg.defaults_restored", Tone::Success, 2000);
    });
    y += m.row + m.section;
  }

  
  return y - y0 + m.s4;
}

float drawSettingsPage(Canvas &cv, const Rect &view, float y0, int page) {
  switch (std::clamp(page, 0, PageCount - 1)) {
    case PageGeneral: return setGeneral(cv, view, y0);
    case PageHologram: return setHologram(cv, view, y0);
    case PageEasyPlace: return setEasyPlace(cv, view, y0);
    case PageOverlay: return setOverlay(cv, view, y0);
    case PagePanel: return setPanel(cv, view, y0);
    default: return drawCompatibility(cv, view, y0) + cv.m.s4;
  }
}

float drawSettings(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  auto &s = settings();
  float y = y0;
  auto onOff = [](bool v) { return std::string(tr(v ? "ui.on" : "ui.off")); };
  std::string val[PageCount];
  val[PageGeneral] = i18n::activeName();
  val[PageHologram] = s.hologram.load() ? num(int(s.alpha.load() * 100 + 0.5f)) + "%" : onOff(false);
  {
    const bool installed = ep::state().installed.load();
    static const char *const kModes[5] = {"ui.ep_mode_missing", "ui.ep_mode_verify", "ui.ep_mode_safe",
                                          "ui.ep_mode_correct", "ui.ep_mode_strict"};
    val[PageEasyPlace] = !installed ? std::string(tr("ui.unavailable"))
                         : ep::state().enabled.load()
                             ? std::string(tr(kModes[std::clamp(s.epMode.load(), 0, 4)]))
                             : onOff(false);
  }
  val[PageOverlay] = onOff(s.ovVisible.load());
  val[PagePanel] = num(std::lround(std::clamp(s.panelSize.load(), kSizeMin, kSizeMax) * 100)) + "%";
  const float hintH = cv.lineHeight(m.fSmall);
  for (int i = 0; i < PageCount; ++i) {
    // category row + one short line saying what is inside
    linkRow(cv, {view.x, y, view.w, m.row}, tr(kPageKeys[i]), val[i], [i] {
      Nav n = nav();
      n.sub = SubSettings;
      n.page = i;
      setView(n);
    });
    y += m.row;
    y += cv.paragraph(view.x + m.s4, y, view.w - m.s8, tr(kPageHints[i]), col::TextSecondary, m.fSmall, 2);
    y += std::max(m.gap, hintH * 0.5f);
  }
  return y - y0 + m.s4;
}

float drawLanguages(Canvas &cv, const Rect &view, float y0) {
  const auto &m = cv.m;
  float y = y0;
  const std::string current = i18n::choice();
  const auto langs = i18n::languages();
  std::string detected = i18n::detectedCode();
  for (const auto &l : langs)
    if (l.code == detected) { detected = l.name; break; }
  
  auto option = [&](const Rect &row, const std::string &code, const std::string &label) {
    if (cv.visible(row)) {
      const bool sel = code == current;
      if (sel) cv.fill(row, col::AccentSoft, m.radius);
      else if (cv.isPressed(row)) cv.fill(row, col::ControlPressed, m.radius);
      const float rr = m.px(7), cx = row.x + m.s10 + rr, cy = row.cy();
      cv.circle(cx, cy, rr, sel ? col::Accent : col::PanelBorder);
      cv.circle(cx, cy, rr - m.s2, col::Panel);
      if (sel) cv.circle(cx, cy, rr - m.s4, col::Accent);
      const float tx = cx + rr + m.s8;
      cv.label({tx, row.y, row.r() - tx - m.s6, row.h}, label, sel ? col::Text : col::TextSecondary, m.fBody);
    }
    cv.hit(row, [code] { i18n::setChoice(code); });
  };
  const float step = m.row + m.s2;
  option({view.x, y, view.w, m.row}, "auto", fmt("ui.language_auto_value", {detected}));
  y += step;
  const int cols = view.w >= m.px(sz::TwoColumnsFrom) ? 2 : 1;
  const Cols c{view.x, view.w, m.s4, cols};
  for (size_t i = 0; i < langs.size(); ++i)
    option(c.cell(int(i % cols), y + float(i / cols) * step, m.row), langs[i].code, langs[i].name);
  y += float((langs.size() + cols - 1) / cols) * step;
  return y - y0 + m.s4;
}


struct Layout {
  kit::Metrics m;
  Rect panel, header, nav, main, title, body;
  bool rail = false;        
  bool topNav = false;      
  int navCols = SecCount, navRows = 1;
  bool navIcons = true, navText = true;  
  bool menuButton = false;  
  float margin = 8;
  float scale = 1;  
  theme::UiStyle style;
};




float autoScale(float W, float H, float density) {
  const float shortDp = std::min(W, H) / density, wDp = W / density;
  float sc = sty::SizeScale[sty::SizeMedium];
  if (shortDp < sty::AutoSmallShortSide) sc = sty::SizeScale[sty::SizeCompact];
  else if (shortDp >= sty::AutoLargeShortSide) sc = sty::SizeScale[sty::SizeLarge];
  else if (shortDp >= sty::AutoTabletShortSide) sc = 1.f;
  if (H > W && wDp < sty::AutoPortraitNarrow) sc = std::min(sc, sty::SizeScale[sty::SizeCompact] + 0.05f);
  
  float label = 0;
  for (const char *k : kNavKeys) label = std::max(label, kit::textWidth(tr(k), theme::type::Label));
  const float navNeedDp = sz::IconLead + sz::NavIcon + sz::IconTextGap + label + sz::IconTextGap;
  if (navNeedDp * sc > sz::NavMax * sc && sc > sty::AutoScaleMin) sc -= 0.05f;
  
  float tool = 0;
  for (const char *k : kToolKeys) tool = std::max(tool, kit::textWidth(tr(k), theme::type::Small));
  const float ps = std::clamp(settings().panelSize.load(), 0.5f, 1.f);
  const float contentDp = std::max(sz::PanelNarrowW, wDp * ps) - sz::NavMin - 2 * sz::Pad;
  const float rowDp = float(ToolCount) * (sz::IconSmall + 6.f + tool + 12.f);
  if (rowDp * sc > contentDp && sc > sty::AutoScaleMin) sc -= 0.05f;
  return std::clamp(sc, sty::AutoScaleMin, sty::AutoScaleMax);
}


theme::UiStyle currentStyle(float W, float H, float density) {
  auto &s = settings();
  theme::UiStyle u;
  u.size = std::clamp(s.controlSize.load(), 0, sty::SizeModeCount - 1);
  u.layout = std::clamp(s.uiLayout.load(), 0, sty::LayoutModeCount - 1);
  u.labels = std::clamp(s.uiLabels.load(), 0, sty::LabelModeCount - 1);
  int pct[sty::InkCount];
  for (int i = 0; i < sty::InkCount; ++i) pct[i] = s.opacityPct[i].load();
  theme::resolveOpacity(std::clamp(s.opacityMode.load(), 0, sty::OpacityModeCount - 1), pct, u.op);
  if (u.size == sty::SizeAuto) {
    u.scale = autoScale(W, H, density);
    const float t = (u.scale - sty::AutoScaleMin) / (sty::AutoScaleMax - sty::AutoScaleMin);
    u.spacing = sty::SpacingScale[0] + (sty::SpacingScale[2] - sty::SpacingScale[0]) * std::clamp(t, 0.f, 1.f);
  } else {
    u.scale = sty::SizeScale[u.size];
    u.spacing = sty::SpacingScale[u.size];
  }
  if (u.layout == sty::LayoutCompact) u.spacing *= 0.85f;  
  return u;
}

float navLabelNeed(const kit::Metrics &m, bool icons = true) {
  float w = 0;
  for (const char *k : kNavKeys) w = std::max(w, kit::textWidth(tr(k), m.fLabel));
  return m.iconLead + (icons ? m.iconM + m.iconGap : 0.f) + w + m.iconGap;
}


bool buildLayout(float W, float H, float dp, Layout &L, const theme::UiStyle &style, float density) {
  const bool compact = H / dp < 400.f || W / dp < 400.f;
  L.style = style;
  L.m = kit::makeMetrics(dp, compact, &style, density);
  const auto &m = L.m;
  L.margin = m.px(sz::Margin);
  const float availW = W - 2 * L.margin, availH = H - 2 * L.margin;
  const float ps = std::clamp(settings().panelSize.load(), kSizeMin, kSizeMax);
  const float titleH = std::max({m.px(compact ? sz::TitleCompact : sz::Title), m.fTitle * 1.35f + m.s10,
                                 m.touch + 2 * m.s3});  
  const float w = std::clamp(ps * availW, std::min(m.px(sz::PanelNarrowW), availW), std::max(availW, 1.f));
  
  const int lay = m.layout, lab = m.labels;
  L.navIcons = lab != sty::LabelsText;
  L.navText = lab != sty::LabelsIcons;
  L.topNav = lay == sty::LayoutHorizontal || lay == sty::LayoutGrid;
  L.rail = false;
  float navW = 0;
  if (!L.topNav) {
    navW = std::clamp(w * 0.27f, m.px(sz::NavMin), m.px(sz::NavMax));
    if (!L.navText || lay == sty::LayoutCompact) {
      L.rail = true;  
    } else {
      
      L.rail = w < m.px(sz::NavFullFrom) && lay != sty::LayoutVertical;
      if (!L.rail) {
        const float need = navLabelNeed(m, L.navIcons);
        if (need > navW) navW = std::min(need, w * 0.34f);
        if (need > navW + 0.5f) L.rail = true;
      }
    }
    if (L.rail && !L.navIcons) L.topNav = true;  
    if (L.rail && !L.topNav) navW = std::max(m.px(sz::NavRail), m.touch + 2 * m.s4);
  }
  
  const float navNeedH = float(SecCount) * m.row + float(SecCount - 1) * m.s2 + 2 * m.s6;
  const bool oneRowOnly = !L.topNav && m.header + navNeedH > availH + 0.5f;
  if (oneRowOnly) L.topNav = true;
  float navH = 0;
  if (L.topNav) {
    L.rail = false;
    navW = 0;
    
    float label = 0;
    for (const char *k : kNavKeys) label = std::max(label, kit::textWidth(tr(k), m.fLabel));
    const float inner = w - 2 * m.s4;
    auto fitsRow = [&](bool ic, bool tx) {
      const float item = (ic ? m.iconM : 0.f) + (ic && tx ? m.s8 : 0.f) + (tx ? label : 0.f) + 2 * m.s8;
      return item * float(SecCount) + float(SecCount - 1) * m.s2 <= inner;
    };
    L.navCols = SecCount;
    if (!fitsRow(L.navIcons, L.navText)) {
      if ((lay == sty::LayoutHorizontal || oneRowOnly) && L.navIcons && fitsRow(true, false)) L.navText = false;
      else L.navCols = SecCount / 2;
    }
    L.navRows = (SecCount + L.navCols - 1) / L.navCols;
    navH = L.navRows * m.row + (L.navRows - 1) * m.s2 + 2 * m.s4;
  }
  L.menuButton = L.rail && L.navText;
  const float minH = L.topNav ? m.header + navH + titleH + m.px(sz::ContentMinH)
                              : m.header + std::max(navNeedH, titleH + m.px(sz::ContentMinH));
  const float h = std::clamp(ps * availH, std::min(minH, availH), std::max(availH, 1.f));
  const bool fits = minH <= availH + 0.5f && w - navW >= m.px(sz::MainMinW) - 0.5f && m.px(sz::PanelMinW) <= availW + 0.5f;
  const float fx = std::clamp(settings().panelFX.load(), 0.f, 1.f);
  const float fy = std::clamp(settings().panelFY.load(), 0.f, 1.f);
  L.panel = {L.margin + fx * std::max(0.f, availW - w), L.margin + fy * std::max(0.f, availH - h), w, h};
  Rect body = L.panel;
  L.header = body.takeTop(m.header);
  L.nav = L.topNav ? body.takeTop(navH) : body.takeLeft(navW);
  L.main = body;
  Rect inner = body.inset(m.pad, 0);
  L.title = inner.takeTop(titleH);
  inner.takeTop(m.gap);
  inner.takeBottom(m.pad);
  L.body = inner;
  return fits;
}

Layout computeLayoutNow(float W, float H, float density);


Layout computeLayout(float W, float H) {
  struct Key {
    float W, H, density, size, fx, fy;
    int controlSize, layout, labels, opMode, pct[sty::InkCount];
    unsigned lang;
    bool operator==(const Key &o) const { return std::memcmp(this, &o, sizeof(Key)) == 0; }
  };
  auto &s = settings();
  Key k{};
  k.W = W;
  k.H = H;
  k.density = kit::deviceDensity(W, H);
  k.size = s.panelSize.load();
  k.fx = s.panelFX.load();
  k.fy = s.panelFY.load();
  k.controlSize = s.controlSize.load();
  k.layout = s.uiLayout.load();
  k.labels = s.uiLabels.load();
  k.opMode = s.opacityMode.load();
  for (int i = 0; i < sty::InkCount; ++i) k.pct[i] = s.opacityPct[i].load();
  k.lang = i18n::generation();
  static std::mutex mu;  
  static Key last{};
  static Layout cached;
  static bool have = false;
  {
    std::lock_guard<std::mutex> lk(mu);
    if (have && k == last) return cached;
  }
  Layout L = computeLayoutNow(W, H, k.density);
  perf::count(perf::LayoutRebuild);
  std::lock_guard<std::mutex> lk(mu);
  cached = L;
  last = k;
  have = true;
  return L;
}

Layout computeLayoutNow(float W, float H, float density) {
  const theme::UiStyle style = currentStyle(W, H, density);
  float scale = std::clamp(style.scale, kScaleMin, kScaleMax);
  Layout L;
  
  
  if (!buildLayout(W, H, density * scale, L, style, density)) {
    float lo = 0.5f, hi = scale;
    for (int i = 0; i < 12; ++i) {
      const float mid = (lo + hi) * 0.5f;
      Layout t;
      if (buildLayout(W, H, density * mid, t, style, density)) lo = mid;
      else hi = mid;
    }
    scale = lo;
    buildLayout(W, H, density * scale, L, style, density);
  }
  L.scale = scale;
  return L;
}

void drawHeader(Canvas &cv, const Layout &L) {
  const auto &m = cv.m;
  const Rect &h = L.header;
  
  if (m.op[sty::InkBg] >= 0.999f) {  
    cv.fill(h, col::Header, m.radiusPanel);
    cv.fill({h.x, h.cy(), h.w, h.h * 0.5f}, col::Header);
  } else {  
    cv.fill(h, col::Header);
  }
  cv.fill({h.x, h.b() - m.border, h.w, m.border}, col::HeaderBorder);
  float x = h.x + m.s10;
  if (L.menuButton) {
    const Rect b{h.x + m.s2, h.y, std::max({m.px(44), h.h, m.touch}), h.h};
    if (cv.isPressed(b) || gDrawer.load()) cv.fill(b.inset(m.s3), col::HeaderPressed, m.radius);
    icon(cv, Ic::Menu, b.cx(), b.cy(), m.iconM, col::HeaderText, col::Header);
    cv.hit(b, [] {
      {
        std::lock_guard<std::mutex> lk(gNavMu);
        gPopup = Popup{};
      }
      gDrawer.store(!gDrawer.load());
    });
    x = b.r() + m.s4;
  }
  const float is = m.iconM;
  icon(cv, Ic::Cube, x + is * 0.5f, h.cy(), is, 0xFF5B6270, col::Header);
  cv.text({x + is + m.s8, h.y, h.r() - x - is - m.s16, h.h}, "Structura", col::HeaderText, m.fTitle);
}



void navItem(Canvas &cv, const Rect &r, int i, bool selected, bool showIcon, bool showText, uint32_t bg,
             bool centered = false) {
  const auto &m = cv.m;
  if (selected) cv.fill(r, col::Accent, m.radius);
  else if (cv.isPressed(r)) cv.fill(r, col::ControlPressed, m.radius);
  const uint32_t ic = selected ? col::TextOnAccent : col::TextSecondary;
  const uint32_t tc = selected ? col::TextOnAccent : col::Text;
  const float is = m.iconM;
  const char *label = tr(kNavKeys[i]);
  if (showIcon && !showText) {
    icon(cv, kNavIcons[i], r.cx(), r.cy(), is, ic, selected ? col::Accent : bg);
  } else if (!showIcon) {
    if (centered) cv.label(r.inset(m.s4, 0), label, tc, m.fLabel, Align::Center);
    else cv.label({r.x + m.iconLead, r.y, r.w - m.iconLead - m.s6, r.h}, label, tc, m.fLabel);
  } else {
    float x0 = r.x + m.iconLead;
    if (centered) {
      const float tw = std::min(kit::textWidth(label, m.fLabel), r.w - is - m.s8 - 2 * m.s4);
      x0 = r.cx() - (is + m.s8 + tw) * 0.5f;
    }
    icon(cv, kNavIcons[i], x0 + is * 0.5f, r.cy(), is, ic, selected ? col::Accent : bg);
    const float tx = x0 + is + (centered ? m.s8 : m.iconGap);
    cv.label({tx, r.y, r.r() - tx - m.s4, r.h}, label, tc, m.fLabel);
  }
  cv.hit(r, [i] { goSection(i); });
}

void drawNav(Canvas &cv, const Layout &L, int sec) {
  const auto &m = cv.m;
  const Rect &n = L.nav;
  cv.fill(n, col::Nav);
  if (L.topNav) {  
    cv.fill({n.x, n.b() - m.border, n.w, m.border}, col::Divider);
    const float gap = m.s2, inset = m.s4;
    const float cw = (n.w - 2 * inset - (L.navCols - 1) * gap) / float(L.navCols);
    for (int i = 0; i < SecCount; ++i) {
      const int c = i % L.navCols, r = i / L.navCols;
      const Rect cell{n.x + inset + c * (cw + gap), n.y + inset + r * (m.row + gap), cw, m.row};
      navItem(cv, cell, i, i == sec, L.navIcons, L.navText, col::Nav, true);
      gNavRect[i] = cell;
    }
    return;
  }
  cv.fill({n.r() - m.border, n.y, m.border, n.h}, col::Divider);
  const float ih = m.row, gap = m.s2, inset = L.rail ? m.s4 : m.s6;
  for (int i = 0; i < SecCount; ++i) {
    const Rect r{n.x + inset, n.y + m.s6 + i * (ih + gap), n.w - 2 * inset - m.border, ih};
    navItem(cv, r, i, i == sec, L.rail || L.navIcons, !L.rail && L.navText, col::Nav);
    gNavRect[i] = r;
  }
}

void drawTitle(Canvas &cv, const Layout &L, const Nav &n) {
  const auto &m = cv.m;
  Rect t = L.title;
  cv.fill({L.main.x, t.b() - m.border, L.main.w, m.border}, col::Divider);
  std::string title;
  bool back = false;
  if (n.sub == SubDetail) {
    back = true;
    const lib::Entry *e = entryFor(n.detail);
    title = e ? e->title : tr("ui.nav_builds");
  } else if (n.sub == SubLanguage) {
    back = true;
    title = tr("ui.language");
  } else if (n.sub == SubColor) {
    back = true;
    title = tr(kColorKeys[std::clamp(n.color, 0, ColCount - 1)]);
  } else if (n.sub == SubSettings) {
    back = true;
    title = tr(kPageKeys[std::clamp(n.page, 0, PageCount - 1)]);
  } else {
    title = tr(n.sec == SecBuilds ? "ui.title_builds" : n.sec == SecCreate ? "ui.title_create" : kNavKeys[n.sec]);
  }
  Rect row = t.inset(0, m.s3);
  if (back) {
    const float b = std::min(row.h, std::max(m.px(sz::IconButton), m.touch));
    cv.iconButton(row.takeLeft(b, m.s10), Canvas::Glyph::Back, [] { goBack(); }, false);
  }
  if (n.sub == SubNone && n.sec == SecBuilds) {
    const char *rf = tr("ui.refresh");
    const float rw = std::max(kit::textWidth(rf, m.fSmall) + m.s20, m.touch);
    Canvas::ButtonOpts o;
    o.fontSize = m.fSmall;
    cv.button(row.takeRight(rw, m.s8), rf, [] { app::rescan(); }, o);
  }
  cv.text(row, title, col::Text, m.fTitle);
}



void scrimAround(Canvas &cv, const Rect &area, const Rect &hole, std::function<void()> close) {
  const auto &m = cv.m;
  const Rect pieces[4] = {{area.x, area.y, area.w, hole.y - area.y},
                          {area.x, hole.b(), area.w, area.b() - hole.b()},
                          {area.x, hole.y, hole.x - area.x, hole.h},
                          {hole.r(), hole.y, area.r() - hole.r(), hole.h}};
  for (const auto &p : pieces)
    if (p.w >= m.touch && p.h >= m.touch) cv.hit(p, close);
}

void drawDrawer(Canvas &cv, const Layout &L, int sec) {
  const auto &m = cv.m;
  const Rect area{L.panel.x, L.header.b(), L.panel.w, L.panel.b() - L.header.b()};
  cv.fill(area, col::Scrim);
  float need = navLabelNeed(m, L.navIcons) + m.s14;
  const Rect d{area.x, area.y, std::min(std::max(m.px(sz::Drawer), need), area.w * 0.85f), area.h};
  cv.fill(d, col::Nav);
  cv.fill({d.r() - m.border, d.y, m.border, d.h}, col::Divider);
  scrimAround(cv, area, d, [] { gDrawer.store(false); });
  const float ih = m.row, gap = m.s2, inset = m.s6;
  for (int i = 0; i < SecCount; ++i)
    navItem(cv, {d.x + inset, d.y + m.s6 + i * (ih + gap), d.w - 2 * inset - m.border, ih}, i, i == sec, L.navIcons,
            true, col::Nav);
}

struct PopItem {
  std::string label;
  std::function<void()> action;
  bool selected = false, enabled = true, danger = false;
};

void drawPopup(Canvas &cv, const Layout &L, const Popup &p) {
  const auto &m = cv.m;
  std::vector<PopItem> items;
  auto closeFn = [] {
    std::lock_guard<std::mutex> lk(gNavMu);
    gPopup = Popup{};
  };
  if (p.kind == PopType) {
    for (int t = 0; t < TypeCount; ++t) {
      if (!gHasType[t]) continue;
      items.push_back({tr(kTypeKeys[t]), [t, closeFn] { gType.store(t); closeFn(); }, t == effectiveType()});
    }
  } else if (p.kind == PopSort) {
    for (int s = 0; s < SortCount; ++s)
      items.push_back({tr(kSortKeys[s]), [s, closeFn] { gSort.store(s); closeFn(); }, s == gSort.load()});
  } else if (p.kind == PopCard) {
    const lib::Entry *e = entryFor(p.path);
    if (!e) {
      closeFn();
      return;
    }
    const std::string path = p.path, title = e->title;
    const bool fav = cat::isFavorite(path);
    const bool mod = app::canModify(*e);
    items.push_back({tr(fav ? "ui.unfavorite" : "ui.favorite"), [path, fav, closeFn] {
                       cat::setFavorite(path, !fav);
                       notify(fav ? "msg.favorite_removed" : "msg.favorite_added", Tone::Success, 1500);
                       closeFn();
                     }});
    items.push_back({tr("ui.rename"),
                     mod ? std::function<void()>([path, title, closeFn] {
                       closeFn();
                       if (!gKbShow.load()) {
                         notify("msg.no_keyboard", Tone::Warning, 3000);
                         return;
                       }
                       {
                         std::lock_guard<std::mutex> lk(gFieldMu);
                         gRenameText = title;
                       }
                       {
                         std::lock_guard<std::mutex> lk(gNavMu);
                         gRename.open = true;
                         gRename.path = path;
                       }
                       focusField(FieldRename);
                     })
                         : std::function<void()>([closeFn] {
                             notify("msg.read_only", Tone::Info, 3000);
                             closeFn();
                           }),
                     false, mod && gKbShow.load() != nullptr});
    items.push_back({tr("ui.export"), [path, closeFn] {
                       app::exportFile(path);
                       closeFn();
                     }});
    const bool armed = p.armedAt && nowMs() - p.armedAt < 3000;
    if (!mod) {
      items.push_back({tr("ui.delete"), [closeFn] {
                         notify("msg.read_only", Tone::Info, 3000);
                         closeFn();
                       }, false, false, true});
    } else if (armed) {
      items.push_back({tr("ui.confirm"), [path, closeFn] {
                         app::removeFile(path);
                         closeFn();
                       }, false, true, true});
    } else {
      items.push_back({tr("ui.delete"), [title] {
                         {
                           std::lock_guard<std::mutex> lk(gNavMu);
                           gPopup.armedAt = nowMs();
                         }
                         notify("msg.confirm_delete", Tone::Warning, 3000, title);
                       }, false, true, true});
    }
  }
  if (items.empty()) return;
  const bool armedNow = p.kind == PopCard && p.armedAt && nowMs() - p.armedAt < 3000;
  const float rh = m.row;
  float w = p.anchor.w;
  for (const auto &it : items) w = std::max(w, kit::textWidth(it.label, m.fBody) + m.px(44));
  const Rect area{L.panel.x, L.header.b(), L.panel.w, L.panel.b() - L.header.b()};
  w = std::min(w, area.w - 2 * m.s6);
  const float h = items.size() * rh + 2 * m.s4;
  float x = p.kind == PopCard ? p.anchor.r() - w : p.anchor.x;
  x = std::clamp(x, area.x + m.s6, area.r() - m.s6 - w);
  float y = p.anchor.b() + m.s4;
  if (y + h > area.b() - m.s6) y = p.anchor.y - m.s4 - h;
  y = std::clamp(y, area.y + m.s6, std::max(area.y + m.s6, area.b() - m.s6 - h));
  const Rect box{x, y, w, std::min(h, area.h - 2 * m.s6)};
  scrimAround(cv, area, box, closeFn);
  cv.frame(box, col::SurfaceRaised, col::PanelBorder, m.radiusPanel, m.border);
  const Rect saved = cv.clip;
  cv.setClip(box);
  for (size_t i = 0; i < items.size(); ++i) {
    const auto &it = items[i];
    const Rect r{box.x + m.border, box.y + m.s4 + i * rh, box.w - 2 * m.border, rh};
    if (it.selected) cv.fill(r, col::AccentSoft);
    else if (cv.isPressed(r)) cv.fill(r, col::ControlPressed);
    if (it.selected) cv.fill({r.x, r.y + m.s6, m.indicator, r.h - m.s12}, col::Accent);
    const uint32_t c = !it.enabled ? col::TextDisabled : it.danger ? (armedNow ? col::Error : 0xFFE88A8A) : col::Text;
    cv.text({r.x + m.s16, r.y, r.w - m.px(24), r.h}, it.label, c, m.fBody);
    cv.hit(r, it.action);
  }
  cv.setClip(saved);
}

void closeRename() {
  {
    std::lock_guard<std::mutex> lk(gNavMu);
    gRename = Rename{};
  }
  blurField();
}
void commitRename() {
  std::string path, text;
  {
    std::lock_guard<std::mutex> lk(gNavMu);
    path = gRename.path;
  }
  {
    std::lock_guard<std::mutex> lk(gFieldMu);
    text = gRenameText;
  }
  closeRename();
  if (!path.empty()) app::renameFile(path, text);
}

void drawRename(Canvas &cv, const Layout &L) {
  const auto &m = cv.m;
  const Rect area{L.panel.x, L.header.b(), L.panel.w, L.panel.b() - L.header.b()};
  cv.fill(area, col::Scrim);
  const float w = std::min(area.w - 2 * m.s12, m.px(sz::Dialog));
  const float lhT = cv.lineHeight(m.fTitle);
  const float fh = std::max(m.px(sz::Field), m.row);
  const float h = m.s12 + lhT + m.s10 + fh + m.s12 + m.row + m.s12;
  
  const Rect box{area.cx() - w * 0.5f, area.y + std::min(m.s12, std::max(0.f, area.h - h)), w, std::min(h, area.h)};
  scrimAround(cv, area, box, [] { closeRename(); });
  cv.frame(box, col::SurfaceRaised, col::PanelBorder, m.radiusPanel, m.border);
  Rect in = box.inset(m.s12);
  cv.text(in.takeTop(lhT, m.s10), tr("ui.rename_title"), col::Text, m.fTitle);
  const Rect field = in.takeTop(fh, m.s12);
  std::string text;
  bool focused;
  {
    std::lock_guard<std::mutex> lk(gFieldMu);
    text = gRenameText;
    focused = gField == FieldRename;
  }
  cv.frame(field, col::Surface, focused ? col::Accent : col::Divider, m.radius, focused ? std::max(2.f, m.px(1.5f)) : m.border);
  const Rect tr_ = field.inset(m.s10, 0);
  std::string shown = text;
  while (!shown.empty() && kit::textWidth(shown, m.fBody) > tr_.w - m.s4) {
    size_t i = 1;
    while (i < shown.size() && (static_cast<unsigned char>(shown[i]) & 0xC0) == 0x80) ++i;
    shown.erase(0, i);
  }
  if (shown.empty()) {
    if (!focused) cv.text(tr_, tr("ui.name_hint"), col::TextDisabled, m.fBody);
  } else {
    cv.text(tr_, shown, col::Text, m.fBody, Align::Left, false);
  }
  if (focused && (!animationsOn() || (nowMs() / 530) % 2 == 0)) {
    const float tw = shown.empty() ? 0.f : kit::textWidth(shown, m.fBody);
    cv.fill({tr_.x + tw + m.px(1), field.cy() - m.fBody * 0.55f, std::max(1.f, m.px(1.5f)), m.fBody * 1.1f}, col::Text);
  }
  cv.hit(field, [] { focusField(FieldRename); });
  const Cols c{in.x, in.w, m.gap, 2};
  cv.button(c.cell(0, in.y, m.row), tr("ui.cancel"), [] { closeRename(); });
  Canvas::ButtonOpts p;
  p.style = Canvas::Style::Primary;
  cv.button(c.cell(1, in.y, m.row), tr("ui.save"), [] { commitRename(); }, p);
}


struct Message {
  bool has = false;
  KTone tone = KTone::Info;
  std::string text;
  float alpha = 1.f;
};

Message currentMessage() {
  Message msg;
  Notice n;
  if (currentNotice(n)) {
    msg.has = true;
    msg.tone = kitTone(n.tone);
    msg.text = n.key.empty() ? n.arg : fmt(n.key, {n.arg});
    if (msg.text.empty()) msg.has = false;  
    if (animationsOn()) {
      const int64_t now = nowMs();
      const float fin = float(now - n.start) / theme::motion::MessageFade;
      const float fout = float(n.until - now) / theme::motion::MessageFade;
      msg.alpha = std::clamp(std::min(fin, fout), 0.f, 1.f);
    }
  }
  return msg;
}

uint32_t toneText(KTone t) {
  switch (t) {
    case KTone::Success: return col::Success;
    case KTone::Warning: return col::Warning;
    case KTone::Error: return col::Error;
    case KTone::Neutral: return col::TextSecondary;
    default: return col::Text;
  }
}


void drawToast(Canvas &cv, float cx, float y, float maxW, bool fromBottom) {
  const Message msg = currentMessage();
  if (!msg.has) return;
  const auto &m = cv.m;
  const float padX = m.s14;
  const auto lines = kit::wrap(msg.text, maxW - 2 * padX, m.fLabel, 2);
  float tw = 0;
  for (const auto &l : lines) tw = std::max(tw, kit::textWidth(l, m.fLabel));
  const float lh = cv.lineHeight(m.fLabel);
  const float w = tw + 2 * padX;
  const float h = std::max(m.px(36), lines.size() * lh + m.s12);
  const Rect r{cx - w * 0.5f, fromBottom ? y - h : y, w, h};
  const float saved = cv.alpha;
  cv.alpha = msg.alpha;
  cv.frame(r, 0xF7202328, col::PanelBorder, m.radiusPanel, m.border);
  cv.fill({r.x + m.border, r.y + m.border, m.indicator, r.h - 2 * m.border}, toneText(msg.tone));
  float ty = r.cy() - lines.size() * lh * 0.5f;
  for (const auto &l : lines) {
    cv.text({r.x + padX, ty, tw + m.s2, lh}, l, toneText(msg.tone), m.fLabel, Align::Left, false);
    ty += lh;
  }
  cv.alpha = saved;
}



std::vector<DrawCommand> gSent;
int64_t gSentAt = 0;
bool sameCommand(const DrawCommand &a, const DrawCommand &b) {
  return a.type == b.type && a.x == b.x && a.y == b.y && a.w == b.w && a.h == b.h && a.x3 == b.x3 && a.y3 == b.y3 &&
         a.color == b.color && a.size == b.size && a.text == b.text && a.imageId == b.imageId && a.fontId == b.fontId;
}

std::atomic_bool gButtonsSent{false};

pthread_mutex_t gWakeMu = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t gWakeCv;
bool gWakeFlag = false;
[[maybe_unused]] const bool gWakeInit = [] {
  pthread_condattr_t a;
  pthread_condattr_init(&a);
  pthread_condattr_setclock(&a, CLOCK_MONOTONIC);
  pthread_cond_init(&gWakeCv, &a);
  pthread_condattr_destroy(&a);
  return true;
}();

void submit(std::span<const DrawCommand> c) {
  const int64_t now = nowMs();
  if (now - gSentAt < 1000 && c.size() == gSent.size() &&
      std::equal(c.begin(), c.end(), gSent.begin(), sameCommand))
    return;
  if (c.size() > gSent.capacity()) perf::count(perf::Alloc);
  gSent.assign(c.begin(), c.end());
  gSentAt = now;
  perf::count(perf::GuiSubmit);
  perf::count(perf::GuiCommands, c.size());
  pl::modmenu::submitDrawCommands(gModuleId, c);
}
void submitEmpty() { submit({}); }


void popCodepoint(std::string &s) {
  if (s.empty()) return;
  size_t i = s.size() - 1;
  while (i > 0 && (static_cast<unsigned char>(s[i]) & 0xC0) == 0x80) --i;
  s.erase(i);
}
void appendCodepoint(std::string &s, uint32_t cp) {
  if (cp < 0x80) s.push_back(char(cp));
  else if (cp < 0x800) { s.push_back(char(0xC0 | (cp >> 6))); s.push_back(char(0x80 | (cp & 0x3F))); }
  else if (cp < 0x10000) {
    s.push_back(char(0xE0 | (cp >> 12))); s.push_back(char(0x80 | ((cp >> 6) & 0x3F))); s.push_back(char(0x80 | (cp & 0x3F)));
  } else {
    s.push_back(char(0xF0 | (cp >> 18))); s.push_back(char(0x80 | ((cp >> 12) & 0x3F)));
    s.push_back(char(0x80 | ((cp >> 6) & 0x3F))); s.push_back(char(0x80 | (cp & 0x3F)));
  }
}
constexpr size_t kMaxFieldBytes = 160;

}  

void setModuleId(const char *moduleId) { gModuleId = moduleId; }
void setVersion(const char *version) { gVersion = version ? version : ""; }
void setKeyboard(void (*show)(), void (*hide)()) {
  gKbShow.store(show);
  gKbHide.store(hide);
}
void setEasyPlaceHandler(void (*handler)(bool)) { gEpHandler.store(handler); }
void setDiagnosticHandler(int (*handler)()) { gDiagHandler.store(handler); }
bool isOpen() { return gOpen.load(); }
void setOpen(bool open) {
  gOpen.store(open);
  if (!open) {
    closeOverlays();
    {
      std::lock_guard<std::mutex> lk(gNavMu);
      gRename = Rename{};
    }
    blurField();
  }
  {
    std::lock_guard<std::mutex> lk(gMu);
    gHits.clear();
    gPtr = -1;
    gPressed = {};
    if (!open) gPanel = {};
  }
  wake();  
}
void clear() {
  gSentAt = 0;
  gButtonsSent = false;
  submitEmpty();
}
void wake() {
  pthread_mutex_lock(&gWakeMu);
  gWakeFlag = true;
  pthread_cond_signal(&gWakeCv);
  pthread_mutex_unlock(&gWakeMu);
}
void waitFrame(int ms) {
  timespec until{};
  clock_gettime(CLOCK_MONOTONIC, &until);
  until.tv_sec += ms / 1000;
  until.tv_nsec += long(ms % 1000) * 1000000L;
  if (until.tv_nsec >= 1000000000L) {
    until.tv_sec += 1;
    until.tv_nsec -= 1000000000L;
  }
  pthread_mutex_lock(&gWakeMu);
  while (!gWakeFlag)
    if (pthread_cond_timedwait(&gWakeCv, &gWakeMu, &until) != 0) break;  
  gWakeFlag = false;
  pthread_mutex_unlock(&gWakeMu);
}

#ifdef STRUCTURA_UI_TEST
std::vector<DebugRect> debugHits() {
  std::lock_guard<std::mutex> lk(gMu);
  std::vector<DebugRect> out;
  for (const auto &h : gHits) out.push_back({h.r.x, h.r.y, h.r.w, h.r.h});
  return out;
}
DebugRect debugPanel() {
  std::lock_guard<std::mutex> lk(gMu);
  return {gPanel.x, gPanel.y, gPanel.w, gPanel.h};
}
DebugRect debugContent() {
  std::lock_guard<std::mutex> lk(gMu);
  return {gContent.x, gContent.y, gContent.w, gContent.h};
}
float debugDp() { return gCv.m.dp; }
DebugRect debugNavItem(int i) {
  const Rect r = gNavRect[std::clamp(i, 0, SecCount - 1)];
  return {r.x, r.y, r.w, r.h};
}
DebugRect debugToolItem(int i) {
  const Rect r = gToolRect[std::clamp(i, 0, ToolCount - 1)];
  return {r.x, r.y, r.w, r.h};
}
bool debugTopNav() {
  const Rect &a = gNavRect[0], &b = gNavRect[1];
  return std::fabs(a.y - b.y) < 0.5f;
}
bool debugRail() {
  std::lock_guard<std::mutex> lk(gMu);
  return gRailNow;
}
bool debugOverlay() {
  std::lock_guard<std::mutex> lk(gMu);
  return gOverlayNow;
}
std::string debugSearch() { return searchText(); }
#endif

void frame() {
  
  static std::mutex frameMu;
  std::lock_guard<std::mutex> frameLock(frameMu);
  app::poll();
  diag::refresh();
  theme::applyTheme(settings().theme.load());
  registerThumbs();
  static unsigned langGen = 0;
  if (langGen != i18n::generation()) {  
    langGen = i18n::generation();
    kit::resetTextCache();
  }
  
  static bool cleared = false;
  
  const bool buttons = hudbtn::active();
  if (!gOpen.load()) {
    Notice n;
    const bool notice = currentNotice(n);
    const bool ov = overlay::wanted();  // progress / layer overlay (independent of the panel)
    if (!ov) overlay::hidden();
    if (!notice && !buttons && !ov) {
      gButtonsSent = false;
      if (!cleared) { submitEmpty(); cleared = true; }
      return;
    }
    const auto surf = pl::modmenu::getHudSurfaceSize();
    if (surf.width <= 0 || surf.height <= 0) return;
    cleared = false;
    const float W = float(surf.width), H = float(surf.height);
    if (!notice) {
      const bool lookB = buttons && hudbtn::changed(W, H);
      const bool lookO = ov && overlay::changed(W, H);
      static bool lastOv = false;
      if (gButtonsSent && !lookB && !lookO && lastOv == ov) return;
      lastOv = ov;
      gCv.begin(gCv.m);
      if (ov) overlay::draw(gCv, W, H);
      if (buttons) hudbtn::draw(gCv, W, H);
      submit(gCv.commands());
      gButtonsSent = true;
      return;
    }
    gButtonsSent = false;
    const Layout L = computeLayout(W, H);
    gCv.begin(L.m);
    if (ov) {
      overlay::changed(W, H);
      overlay::draw(gCv, W, H);
    }
    drawToast(gCv, W * 0.5f, H * 0.16f, std::min(W - 2 * L.m.s16, L.m.px(sz::ToastMax)), false);
    if (buttons) {
      hudbtn::changed(W, H);
      hudbtn::draw(gCv, W, H);
    }
    submit(gCv.commands());
    return;
  }
  cleared = false;
  gButtonsSent = false;
  overlay::hidden();  // main panel open: the overlay is not drawn and takes no touches
  const auto surf = pl::modmenu::getHudSurfaceSize();
  if (surf.width <= 0 || surf.height <= 0) return;
  const float W = float(surf.width), H = float(surf.height);
  refreshLibrary();
  const Layout L = computeLayout(W, H);
  Canvas &cv = gCv;
  cv.begin(L.m);
  const auto &m = L.m;
  gEffScale.store(L.scale);
  if (!L.menuButton) gDrawer.store(false);
  Nav n = nav();
  if (n.sub == SubDetail && !entryFor(n.detail)) {  
    Nav b;
    b.sec = n.sec;
    setView(b);
    n = b;
  }
  Popup pop;
  bool renaming;
  {
    std::lock_guard<std::mutex> lk(gNavMu);
    pop = gPopup;
    renaming = gRename.open;
  }
  const bool drawer = gDrawer.load() && L.menuButton;
  const bool overlay = drawer || pop.kind != PopNone || renaming;
  {
    std::lock_guard<std::mutex> lk(gMu);
    
    
    static float lastDp = 0.f;
    if (lastDp > 0.f && std::fabs(m.dp - lastDp) > 0.0005f) {
      const float k = m.dp / lastDp;
      for (float &sc : gScroll) sc *= k;
      for (float &sc : gScrollMax) sc *= k;
      const int key = viewKey(n);
      if (gAnchor.key == key && nowMs() - gAnchor.at < 5000)
        gScroll[key] = std::max(0.f, gAnchor.yDp * m.dp - gAnchor.viewFrac * L.body.h);
      gMatsScroll *= k;
      gMatsMax *= k;
      gDownHit = -1;
      gPressed = {};
    }
    lastDp = m.dp;
    gDpNow = m.dp;
    cv.pressed = gPressed;
    gPrev = gMats = gContent = gSearchRect = {};  
    for (Rect &r : gToolRect) r = {};
  }

  
  cv.frame(L.panel, col::Panel, col::PanelBorder, m.radiusPanel, m.border);
  drawHeader(cv, L);
  const size_t headerHits = cv.hits.size();
  drawNav(cv, L, n.sec);
  drawTitle(cv, L, n);
  if (n.sub == SubDetail) {
    drawDetail(cv, L.body, n);
  } else if (n.sub == SubLanguage) {
    scrolled(cv, L.body, viewKey(n), [&](float y0) { return drawLanguages(cv, L.body, y0); });
  } else if (n.sub == SubColor) {
    const int c = std::clamp(n.color, 0, ColCount - 1);
    scrolled(cv, L.body, viewKey(n), [&](float y0) { return drawColorPicker(cv, L.body, y0, c); });
  } else if (n.sub == SubSettings) {
    scrolled(cv, L.body, viewKey(n), [&](float y0) { return drawSettingsPage(cv, L.body, y0, n.page); });
  } else {
    switch (n.sec) {
      case SecGuide: scrolled(cv, L.body, viewKey(n), [&](float y0) { return drawGuide(cv, L.body, y0); }); break;
      case SecCreate: scrolled(cv, L.body, viewKey(n), [&](float y0) { return drawCreate(cv, L.body, y0); }); break;
      case SecSettings:
        scrolled(cv, L.body, viewKey(n), [&](float y0) { return drawSettings(cv, L.body, y0); });
        break;
      default: drawList(cv, L.body, n); break;
    }
  }
  
  if (overlay) {
    cv.hits.resize(headerHits);
    {
      std::lock_guard<std::mutex> lk(gMu);
      gPrev = gMats = gContent = {};
    }
    if (renaming) drawRename(cv, L);
    else if (pop.kind != PopNone) drawPopup(cv, L, pop);
    else drawDrawer(cv, L, n.sec);
  }
  drawToast(cv, L.main.cx(), L.panel.b() - m.s10, L.main.w - 2 * m.pad, true);

  {
    std::lock_guard<std::mutex> lk(gMu);
    gPanel = L.panel;
    gHead = L.header;
    gSurfW = W; gSurfH = H;
    gMargin = L.margin;
    gSlop = m.s8;
    gRailNow = L.menuButton;
    gOverlayNow = overlay;
    gHits.swap(cv.hits);
    
    if (gPtr >= 0 && nowMs() - gLastEvAt > 1500) {
      gPtr = -1;
      gDragging = false;
      gDownHit = -1;
      gPressed = {};
    }
    if (gPtr >= 0 && !gDragging && gDownHit >= 0 && gDownHit < int(gHits.size()) && gHits[size_t(gDownHit)].repeat) {
      const int64_t now = nowMs();
      if (now - gDownAt > 450 && now - gLastRepeat > 120) {
        gLastRepeat = now;
        if (gHits[size_t(gDownHit)].action) gHits[size_t(gDownHit)].action();
      }
    }
  }
  if (buttons) {  
    hudbtn::changed(W, H);
    hudbtn::draw(cv, W, H);
  }
  submit(cv.commands());
}

bool onText(const std::string &text) {
  if (!gOpen.load()) return false;
  bool commit = false;
  int field;
  {
    std::lock_guard<std::mutex> lk(gFieldMu);
    field = gField;
    if (field == FieldNone) return false;
    std::string &s = field == FieldSearch ? gSearch : gRenameText;
    for (char c : text) {
      if (c == '\n' || c == '\r') { commit = true; continue; }
      if (static_cast<unsigned char>(c) < 0x20) continue;
      if (s.size() < kMaxFieldBytes) s.push_back(c);
    }
    
    size_t i = s.size();
    while (i > 0 && (static_cast<unsigned char>(s[i - 1]) & 0xC0) == 0x80) --i;
    if (i > 0) {
      const unsigned char lead = static_cast<unsigned char>(s[i - 1]);
      const size_t need = lead >= 0xF0 ? 4 : lead >= 0xE0 ? 3 : lead >= 0xC0 ? 2 : 1;
      if (s.size() - (i - 1) < need) s.resize(i - 1);
    }
  }
  if (commit) {
    if (field == FieldRename) commitRename();
    else blurField();
  }
  return true;
}

bool onKey(int keyCode, unsigned int unicodeChar, bool down) {
  if (!gOpen.load()) return false;
  int field;
  {
    std::lock_guard<std::mutex> lk(gFieldMu);
    field = gField;
  }
  if (field == FieldNone) return false;
  if (!down) return true;
  constexpr int kDel = 67, kEnter = 66, kNumEnter = 160, kBack = 4, kEscape = 111;
  if (keyCode == kDel) {
    std::lock_guard<std::mutex> lk(gFieldMu);
    popCodepoint(field == FieldSearch ? gSearch : gRenameText);
  } else if (keyCode == kEnter || keyCode == kNumEnter) {
    if (field == FieldRename) commitRename();
    else blurField();
  } else if (keyCode == kBack || keyCode == kEscape) {
    if (field == FieldRename) closeRename();
    else blurField();
  } else if (unicodeChar >= 0x20 && unicodeChar != 0x7F) {  
    std::lock_guard<std::mutex> lk(gFieldMu);
    std::string &s = field == FieldSearch ? gSearch : gRenameText;
    if (s.size() + 4 <= kMaxFieldBytes) appendCodepoint(s, unicodeChar);
  }
  return true;
}

bool onTouch(const pl::input::TouchEvent &ev) {
  if (!gOpen.load()) return false;
  std::function<void()> fire;
  bool consumed = false, blur = false;
  {
    std::lock_guard<std::mutex> lk(gMu);
    auto hitAt = [&](float x, float y) {
      for (int i = int(gHits.size()) - 1; i >= 0; --i)
        if (gHits[size_t(i)].r.contains(x, y)) return i;
      return -1;
    };
    switch (ev.action) {
      case 0:
      case 5:
        if (ev.action == 0) {  
          gPtr = -1;
          gDragging = false;
          gDownHit = -1;
          gPressed = {};
        }
        if (!gPanel.contains(ev.x, ev.y)) return false;
        gLastEvAt = nowMs();
        if (gPtr < 0) {
          gPtr = ev.pointerId;
          gDownX = gLastX = ev.x; gDownY = gLastY = ev.y;
          gDragging = false;
          gDragArea = gHead.contains(ev.x, ev.y)      ? AreaHandle
                      : gPrev.contains(ev.x, ev.y)    ? AreaPreview
                      : gMats.contains(ev.x, ev.y)    ? AreaMats
                      : gContent.contains(ev.x, ev.y) ? AreaContent
                                                      : AreaNone;
          gDownHit = hitAt(ev.x, ev.y);
          gPressed = gDownHit >= 0 ? gHits[size_t(gDownHit)].r : Rect{};
          gDownAt = gLastRepeat = nowMs();
          if (gDownHit >= 0 && gHits[size_t(gDownHit)].repeat) fire = gHits[size_t(gDownHit)].action;
          blur = !gSearchRect.contains(ev.x, ev.y);  
        }
        consumed = true;
        break;
      case 2:
        if (ev.pointerId != gPtr) return false;
        gLastEvAt = nowMs();
        if (!gDragging && std::hypot(ev.x - gDownX, ev.y - gDownY) > gSlop) {
          gDragging = true;
          gPressed = {};
        }
        if (gDragging) {
          const float dx = ev.x - gLastX, dy = ev.y - gLastY;
          if (gDragArea == AreaHandle) {
            auto &st = settings();
            const float mg = gMargin;
            gPanel.x = std::clamp(gPanel.x + dx, mg, std::max(mg, gSurfW - gPanel.w - mg));
            gPanel.y = std::clamp(gPanel.y + dy, mg, std::max(mg, gSurfH - gPanel.h - mg));
            st.panelFX.store(std::clamp((gPanel.x - mg) / std::max(1.f, gSurfW - gPanel.w - 2 * mg), 0.f, 1.f));
            st.panelFY.store(std::clamp((gPanel.y - mg) / std::max(1.f, gSurfH - gPanel.h - 2 * mg), 0.f, 1.f));
            gDownHit = -1;  
          } else if (gDragArea == AreaMats) gMatsScroll = std::clamp(gMatsScroll - dy, 0.f, gMatsMax);
          else if (gDragArea == AreaPreview) {
            gYaw = std::fmod(gYaw - dx * 0.6f + 360.f, 360.f);
            gPitch = std::clamp(gPitch + dy * 0.4f, 5.f, 80.f);
          } else if (gDragArea == AreaContent) {
            gScroll[gContentKey] = std::clamp(gScroll[gContentKey] - dy, 0.f, gScrollMax[gContentKey]);
          }
        }
        gLastX = ev.x; gLastY = ev.y;
        consumed = true;
        break;
      case 1:
      case 6:
      case 3:
        
        if (ev.pointerId != gPtr && ev.action == 6) return gPanel.contains(ev.x, ev.y);
        if (gPtr < 0) return gPanel.contains(ev.x, ev.y);
        if (ev.action != 3 && !gDragging && gDownHit >= 0 && gDownHit < int(gHits.size()) &&
            !gHits[size_t(gDownHit)].repeat) {
          
          const kit::Hit &hh = gHits[size_t(gDownHit)];
          const float mg = gSlop;
          if (ev.x >= hh.r.x - mg && ev.y >= hh.r.y - mg && ev.x < hh.r.r() + mg && ev.y < hh.r.b() + mg) {
            fire = hh.action;
            if (gContent.contains(hh.r.cx(), hh.r.cy()) && gContent.h > 0)
              gAnchor = {gContentKey, (hh.r.cy() - gContent.y + gScroll[gContentKey]) / gDpNow,
                         (hh.r.cy() - gContent.y) / gContent.h, nowMs()};
          }
        }
        gPtr = -1;
        gDragging = false;
        gDownHit = -1;
        gPressed = {};
        consumed = true;
        break;
      default:
        break;
    }
  }
  if (blur && focusedField() == FieldSearch) blurField();
  if (fire) fire();
  return consumed;
}

}  
