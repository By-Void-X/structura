#pragma once
#include <pl/Input.hpp>

#include <string>
#include <vector>

namespace lm::ui {

void setModuleId(const char *moduleId);
void setVersion(const char *version);
bool onTouch(const pl::input::TouchEvent &ev);  

bool onText(const std::string &text);
bool onKey(int keyCode, unsigned int unicodeChar, bool down);

void setKeyboard(void (*show)(), void (*hide)());

void setEasyPlaceHandler(void (*handler)(bool on));

void setDiagnosticHandler(int (*handler)());
void frame();  
bool isOpen();
void setOpen(bool open);
void clear();
void wake();              
void waitFrame(int ms);   

#ifdef STRUCTURA_UI_TEST

struct DebugRect {
  float x, y, w, h;
};
std::vector<DebugRect> debugHits();
DebugRect debugPanel();
DebugRect debugContent();
float debugDp();
bool debugRail();            
DebugRect debugNavItem(int i);   
DebugRect debugToolItem(int i);  
bool debugTopNav();              
bool debugOverlay();         
std::string debugSearch();   
#endif

}  
