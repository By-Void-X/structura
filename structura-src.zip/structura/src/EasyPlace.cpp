





#include "EasyPlace.hpp"
#include "PlayerContext.hpp"
#include "Resolver.hpp"

#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdlib>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <deque>
#include <fstream>
#include <mutex>
#include <unordered_map>

#include <pl/Logger.hpp>
#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include "BlockStates.hpp"
#include "Game.hpp"
#include "Hologram.hpp"
#include "Nbt.hpp"
#include "PlacePlan.hpp"
#include "Progress.hpp"
#include "State.hpp"
#include "StructuraApi.h"

namespace ep {

int64_t nowMs() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch())
      .count();
}
State &state() {
  static State s;
  return s;
}

void toast(const std::string &text, uint32_t, int ms) { lm::toast(text, ms); }


namespace {
std::mutex gLogMu;
std::deque<std::string> gLogLines;
bool gLogDirty = false;
std::string gLogPath;
}  

void setLogPath(const std::string &path) {
  std::lock_guard<std::mutex> lk(gLogMu);
  gLogPath = path;
}
void logf(const char *fmt, ...) {
  char buf[320];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  char line[360];
  snprintf(line, sizeof(line), "[%lld] %s", static_cast<long long>(nowMs() % 100000000), buf);
  std::lock_guard<std::mutex> lk(gLogMu);
  gLogLines.emplace_back(line);
  while (gLogLines.size() > 120) gLogLines.pop_front();
  gLogDirty = true;
}
void flushLog() {
  std::lock_guard<std::mutex> lk(gLogMu);
  if (!gLogDirty || gLogPath.empty()) return;
  std::ofstream out(gLogPath, std::ios::trunc);
  if (!out) return;
  for (const auto &l : gLogLines) out << l << "\n";
  gLogDirty = false;
}



namespace {
std::mutex gTraceMu;
int gTraceFd = -1;
std::string gTracePath;
off_t gTraceSize = 0;
constexpr off_t kTraceMax = 256 * 1024;  
}  
void trace(const char *fmt, ...) {
  char buf[256];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  char line[300];
  const int n = snprintf(line, sizeof(line), "[%lld] %s\n", static_cast<long long>(nowMs() % 100000000), buf);
  if (n <= 0) return;
  std::lock_guard<std::mutex> lk(gTraceMu);
  if (gTracePath.empty()) {
    std::lock_guard<std::mutex> lk2(gLogMu);
    if (gLogPath.empty()) return;
    gTracePath = gLogPath;
    const size_t sl = gTracePath.find_last_of('/');
    gTracePath = (sl == std::string::npos ? std::string() : gTracePath.substr(0, sl + 1)) + "easyplace-trace.txt";
  }
  if (gTraceFd >= 0 && gTraceSize > kTraceMax) {
    ::close(gTraceFd);
    gTraceFd = -1;
    ::rename(gTracePath.c_str(), (gTracePath + ".old").c_str());
  }
  if (gTraceFd < 0) {
    gTraceFd = ::open(gTracePath.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0644);
    if (gTraceFd < 0) return;
    struct stat stt{};
    gTraceSize = ::fstat(gTraceFd, &stt) == 0 ? stt.st_size : 0;
  }
  const ssize_t w = ::write(gTraceFd, line, size_t(std::min(n, int(sizeof(line)) - 1)));
  if (w > 0) gTraceSize += w;
}

namespace {


inline uintptr_t untag(uintptr_t p) { return p & 0x00FFFFFFFFFFFFFFULL; }
inline bool plausiblePtr(uintptr_t p) {
  p = untag(p);
  return p >= 0x10000 && p < (1ULL << 48) && (p & 0x7) == 0;
}
inline bool safeRead(uintptr_t src, void *dst, size_t n) {
  src = untag(src);
  if (src < 0x10000) return false;
  iovec local{dst, n}, remote{reinterpret_cast<void *>(src), n};
  return process_vm_readv(getpid(), &local, 1, &remote, 1, 0) == static_cast<ssize_t>(n);
}
template <class T>
inline bool rd(uintptr_t a, T &out) {
  return safeRead(a, &out, sizeof(T));
}
inline uintptr_t rdp(uintptr_t a) {
  uintptr_t v = 0;
  return rd(a, v) && plausiblePtr(v) ? v : 0;
}


struct BlockPos {
  int x, y, z;
};
struct Vec3 {
  float x, y, z;
};
struct BTPair {  
  void *blockType;
  uint64_t extra;
};


using BuildBlockFn = bool (*)(void *gm, const BlockPos *pos, uint8_t face, uint8_t hand, bool flag);
using TickFn = void (*)(void *gm);
using ItemBlockTypeFn = BTPair (*)(const void *stack);
using HandItemFn = const void *(*)(void *player, uint8_t hand);
using HitResultFn = void *(*)(void *level);

using UseItemFn = bool (*)(void *gm, void *stack, uint32_t flag);

using PlacementFn = uintptr_t (*)(void *bt, void *actor, const BlockPos *pos, uint8_t face, const Vec3 *click, int aux);

namespace sig {
constexpr const char *BuildBlock =
    "FF C3 04 D1 FD 7B 0D A9 FC 73 00 F9 FA 67 0F A9 F8 5F 10 A9 F6 57 11 A9 F4 4F 12 A9 FD 43 03 91 5A D0 3B D5 F7 "
    "03 04 2A";
constexpr const char *GameModeTick = "FD 7B BE A9 F3 0B 00 F9 FD 03 00 91 F3 03 00 AA 00 5C 40 F9 08 00 40 F9";
constexpr const char *SurvivalModeTick =
    "FF 83 03 D1 FD 7B 0A A9 F7 5B 00 F9 F6 57 0C A9 F4 4F 0D A9 FD 83 02 91 55 D0 3B D5 F3 03 00 AA A8 16 40 F9 A8 "
    "83 1F F8 00 5C 40 F9";
constexpr const char *ItemBlockType =
    "FD 7B BE A9 F4 4F 01 A9 FD 03 00 91 F4 03 00 AA ? ? ? ? ? ? ? ? E0 03 14 AA ? ? ? ? F3 03 00 AA";
constexpr const char *HandItem = "28 1C 00 12 1F 05 00 71 ? ? ? ? 08 00 40 F9 01 39 41 F9 20 00 1F D6";

constexpr const char *BaseUseItem =
    "FD 7B BC A9 FC 5F 01 A9 F6 57 02 A9 F4 4F 03 A9 FD 03 00 91 FF 83 0C D1 57 D0 3B D5 F4 03 00 AA E0 03 00 91 "
    "E8 16 40 F9 F5 03 02 2A F3 03 01 AA";


constexpr const char *SelectSlot =
    "FD 7B BA A9 FC 0B 00 F9 FA 67 02 A9 F8 5F 03 A9 F6 57 04 A9 F4 4F 05 A9 FD 03 00 91 FF C3 09 D1 57 D0 3B D5 F5 "
    "03 00 AA F3 03 02 2A E8 16 40 F9 F6 03 01 2A A8 83 1F F8 00 5C 40 F9 ? ? ? ? DF 02 00 71 04 A0 56 7A E0 D7 9F 1A "
    "1F 04 00 71 ? ? ? ? BA 12 40 B9 7F 1E 00 72 B6 12 00 B9";
}  

constexpr uintptr_t kGM_Player = 0x8;          
constexpr uintptr_t kGM_AltHitFlag = 0x41;     
constexpr uintptr_t kGM_AltHit = 0x6c;
constexpr uintptr_t kGM_BuildState = 0x40;     
constexpr uintptr_t kActor_Level = 0x1d0;      
constexpr uintptr_t kActor_Rotation = 0x218;   
constexpr uintptr_t kActor_State = 0x208;      
constexpr uintptr_t kLevel_VtHitResult = 0xa80;
constexpr uintptr_t kHR_Dir = 0xc;  
constexpr uintptr_t kHR_Start = 0x0, kHR_Type = 0x18, kHR_Face = 0x1c, kHR_Pos = 0x20, kHR_Hit = 0x2c;
constexpr uintptr_t kBlock_Type = 0x68;        
constexpr uintptr_t kBT_Default = 0x200;       
constexpr uintptr_t kBT_VtPlacement = 0x278;
constexpr uintptr_t kPlayer_Inventory = 0x570;  

constexpr uintptr_t kGameModeVt = 0x13016d98, kSurvivalModeVt = 0x13016ec8;
constexpr uintptr_t kClientInstanceVt = 0x12bc3300, kGetLocalPlayerStatic = 0x9808050;
constexpr unsigned kVT_ClientInstance_getLocalPlayer = 32;
uintptr_t gBase = 0;  
bool isGameModeOf(uintptr_t p, uintptr_t pl);
float reachOf(void *gm);
bool stackEmpty(const void *stack);

BuildBlockFn oBuildBlock = nullptr;
UseItemFn oUseItem = nullptr;
TickFn oGameModeTick = nullptr;
TickFn oSurvivalTick = nullptr;
ItemBlockTypeFn sItemBlockType = nullptr;
HandItemFn sHandItem = nullptr;
using SelectSlotFn = bool (*)(void *inv, int slot, uint8_t containerId);
using GetItemFn = const void *(*)(void *container, int slot);
SelectSlotFn sSelectSlot = nullptr;
pl::log::Logger *gLog = nullptr;

std::atomic<int64_t> gGameBuildAt{0};  





pthread_key_t gInKey;
pthread_once_t gInOnce = PTHREAD_ONCE_INIT;
void makeInKey() { pthread_key_create(&gInKey, nullptr); }
bool easyPlaceInProgress() {
  pthread_once(&gInOnce, makeInKey);
  return pthread_getspecific(gInKey) != nullptr;
}
struct InProgressScope {
  bool prev;
  InProgressScope() : prev(easyPlaceInProgress()) { pthread_setspecific(gInKey, reinterpret_cast<void *>(1)); }
  ~InProgressScope() { pthread_setspecific(gInKey, prev ? reinterpret_cast<void *>(1) : nullptr); }
  InProgressScope(const InProgressScope &) = delete;
  InProgressScope &operator=(const InProgressScope &) = delete;
};


std::atomic<pid_t> gGameTid{0};
pid_t curTid() { return static_cast<pid_t>(syscall(SYS_gettid)); }
bool onGameThread() {
  const pid_t t = gGameTid.load(std::memory_order_relaxed);
  return t != 0 && t == curTid();
}


std::atomic_bool gPlacementValidated{false};
std::string gDisabledReason;  



std::atomic<uint64_t> gGen{1};
// Run controls (UI thread writes, game thread acts). A forced refresh drops the queue/pending turn/fixes on
// the game thread (layer change, cancel) without touching game-thread-only containers from the UI thread.
std::atomic_bool gPaused{false};
std::atomic_bool gForceRefresh{false};
std::atomic<int> gRunScope{0};  // 0 = crosshair auto (existing), 1 = current layer, 2 = all visible missing
std::atomic<int> gOp{0};        // ep::Op for the progress overlay
uint64_t gSeenModelGen = 0;
const void *gSeenStructure = nullptr;  
bool gSeenPlaced = false, gSeenHolo = false;
uintptr_t gSeenPlayer = 0;  


constexpr int kMaxPlacePerFrame = 1;        
constexpr int kMaxQueue = 1;                
constexpr int kMaxAttempts = 3;             
constexpr int kDiscardMs = 15000;           
constexpr double kFrameBudgetMs = 6.0;      
uint64_t gFrameNo = 0, gPlacedFrame = 0;
int gPlacedThisFrame = 0;
struct FailRec {
  int x, y, z;
  uint64_t gen;
  int attempts;
  int64_t lastAt;
};
std::vector<FailRec> gFails;  


const StructuraApiV1 *api() { return lm::holo::api(); }

std::string nameOf(const StructuraApiV1 *A, uintptr_t block) {
  char buf[128];
  if (block && A->blockName(block, buf, sizeof(buf))) return buf;
  return {};
}


bool replaceableName(const std::string &n) {
  static const char *kList[] = {"air", "water", "flowing_water", "lava", "flowing_lava", "short_grass", "tallgrass",
                                "tall_grass", "fern", "large_fern", "deadbush", "dead_bush", "seagrass", "snow_layer",
                                "vine", "fire", "soul_fire", "structure_void", "bubble_column", "glow_lichen",
                                "light_block", "short_dry_grass", "tall_dry_grass", "bush"};
  for (const char *k : kList)
    if (n == k) return true;
  return n.rfind("light_block", 0) == 0;
}


std::mutex gRepMu;
std::unordered_map<uintptr_t, int8_t> gRepCache;
int replaceableBlock(const StructuraApiV1 *A, uintptr_t b, uintptr_t air) {
  if (air && b == air) return 1;
  {
    std::lock_guard<std::mutex> lk(gRepMu);
    const auto it = gRepCache.find(b);
    if (it != gRepCache.end()) return it->second;
  }
  const std::string n = nameOf(A, b);
  if (n.empty()) return air ? 0 : -1;
  const int r = replaceableName(n) ? 1 : 0;
  std::lock_guard<std::mutex> lk(gRepMu);
  if (gRepCache.size() > 8192) gRepCache.clear();
  gRepCache.emplace(b, int8_t(r));
  return r;
}

struct World {
  const StructuraApiV1 *A;
  uintptr_t air = 0;
  explicit World(const StructuraApiV1 *a) : A(a) { air = A->worldBlock(0, 32767, 0); }  
  
  int replaceable(int x, int y, int z, uintptr_t *out = nullptr) const {
    const uintptr_t b = A->worldBlock(x, y, z);
    if (out) *out = b;
    if (!b) return -1;
    return replaceableBlock(A, b, air);
  }
  bool solidNeighbor(int x, int y, int z) const {
    return replaceable(x, y - 1, z) == 0 || replaceable(x, y + 1, z) == 0 || replaceable(x, y, z - 1) == 0 ||
           replaceable(x, y, z + 1) == 0 || replaceable(x - 1, y, z) == 0 || replaceable(x + 1, y, z) == 0;
  }
};


struct Target {
  BlockPos t{};          
  uintptr_t expected = 0;
  bool mergeSlab = false;  
  bool topSlab = false;    
  bool fixState = false;   // Correct mode: block exists with a state that a tap can fix
};

namespace st = lm::states;
st::Mode epMode() {
  return st::Mode(std::clamp(lm::settings().epMode.load(std::memory_order_relaxed), 0, int(st::Mode::Count) - 1));
}

// Blocks that react to a tap (open a screen, toggle, ...): never clicked as the placement face,
// because the game would interact with them instead of placing.
bool opensOnTapName(const std::string &n) {
  static const char *kExact[] = {"chest", "trapped_chest", "ender_chest", "barrel", "furnace", "lit_furnace",
                                 "blast_furnace", "lit_blast_furnace", "smoker", "lit_smoker", "crafting_table",
                                 "crafter", "enchanting_table", "anvil", "chipped_anvil", "damaged_anvil",
                                 "grindstone", "stonecutter_block", "loom", "smithing_table", "cartography_table",
                                 "brewing_stand", "beacon", "hopper", "dispenser", "dropper", "lectern", "lever",
                                 "unpowered_repeater", "powered_repeater", "unpowered_comparator", "powered_comparator",
                                 "daylight_detector", "daylight_detector_inverted", "noteblock", "jukebox", "bed",
                                 "cake", "respawn_anchor", "flower_pot", "chiseled_bookshelf", "command_block",
                                 "repeating_command_block", "chain_command_block", "structure_block", "jigsaw",
                                 "composter", "cauldron", "bell", "campfire", "soul_campfire", "decorated_pot",
                                 "vault", "trial_spawner", "dragon_egg", "redstone_wire", "crafter"};
  for (const char *k : kExact)
    if (n == k) return true;
  auto ends = [&](const char *suf) {
    const size_t m = std::strlen(suf);
    return n.size() >= m && n.compare(n.size() - m, m, suf) == 0;
  };
  if (n == "iron_door" || n == "iron_trapdoor") return false;
  return ends("door") || ends("fence_gate") || ends("_button") || ends("shulker_box") || ends("_cake") ||
         ends("hanging_sign") || ends("_sign") || n == "standing_sign" || n == "wall_sign";
}
std::mutex gTapMu;
std::unordered_map<uintptr_t, int8_t> gTapCache;
bool opensOnTap(const StructuraApiV1 *A, uintptr_t b) {
  if (!b) return false;
  {
    std::lock_guard<std::mutex> lk(gTapMu);
    const auto it = gTapCache.find(b);
    if (it != gTapCache.end()) return it->second != 0;
  }
  const std::string n = nameOf(A, b);
  if (n.empty()) return false;
  const bool r = opensOnTapName(n);
  std::lock_guard<std::mutex> lk(gTapMu);
  if (gTapCache.size() > 4096) gTapCache.clear();
  gTapCache.emplace(b, int8_t(r));
  return r;
}

// ---- statistics + last placement records (diagnostics)
struct StatsImpl {
  std::atomic<uint32_t> placed{0}, exact{0}, mismatch{0}, corrected{0}, failed{0}, unsupported{0}, skipped{0};
} gStats;
std::mutex gRecMu;
constexpr int kRecords = 16;
ep::Record gRec[kRecords];
int gRecHead = 0, gRecCount = 0;

void report(const lm::holo::Expect &E, const char *result, const std::string &expected, const std::string &actual,
            const std::string &correction, const std::string &detail) {
  logf("Placement: %s | Block: %s | Position: %d %d %d (structure %d %d %d) | Expected state: %s | Actual state: %s | "
       "Correction attempt: %s | Result: %s",
       result, E.name.c_str(), E.x, E.y, E.z, E.lx, E.ly, E.lz, expected.c_str(), actual.c_str(), correction.c_str(),
       detail.c_str());
  std::lock_guard<std::mutex> lk(gRecMu);
  ep::Record &r = gRec[gRecHead];
  r.x = E.x;
  r.y = E.y;
  r.z = E.z;
  r.status = result;
  r.block = E.name;
  r.expected = expected;
  r.actual = actual;
  r.correction = correction;
  r.result = detail;
  r.at = nowMs();
  gRecHead = (gRecHead + 1) % kRecords;
  if (gRecCount < kRecords) ++gRecCount;
}

std::string diffText(const st::Compared &c) {
  std::string out;
  for (const auto &d : c.diffs) {
    if (!out.empty()) out += ", ";
    out += d.key + " (" + st::clsName(d.cls) + ")";
  }
  return out;
}

// toasts at most every 2.5 s per message
std::string gToastKey;
int64_t gToastAt = 0;
void toastOnce(const char *key, const std::string &arg, lm::Tone tone = lm::Tone::Warning) {
  const int64_t now = nowMs();
  const std::string k = std::string(key) + "|" + arg;
  if (k == gToastKey && now - gToastAt < 2500) return;
  if (now - gToastAt < 700) return;
  gToastKey = k;
  gToastAt = now;
  lm::notify(key, tone, 2200, arg);
}

std::string stripDouble(const std::string &n) {
  const auto k = n.find("double_slab");
  if (k == std::string::npos) return {};
  return n.substr(0, k) + "slab";
}



constexpr int kNdx[6] = {0, 0, 0, 0, -1, 1}, kNdy[6] = {-1, 1, 0, 0, 0, 0}, kNdz[6] = {0, 0, -1, 1, 0, 0};
bool findTargetRay(const StructuraApiV1 *A, const World &W, const Vec3 &s, const Vec3 &e, const BlockPos &hitBlock,
                   const Vec3 *eye, Target &out) {
  
  
  float bx0 = 1e9f, bx1 = -1e9f, by0 = 1e9f, by1 = -1e9f, bz0 = 1e9f, bz1 = -1e9f;
  if (eye) {
    bx0 = eye->x - 0.3f; bx1 = eye->x + 0.3f;
    bz0 = eye->z - 0.3f; bz1 = eye->z + 0.3f;
    by0 = eye->y - 1.62f; by1 = by0 + 1.8f;
  }
  const float dx = e.x - s.x, dy = e.y - s.y, dz = e.z - s.z;
  const float len = std::sqrt(dx * dx + dy * dy + dz * dz);
  if (!(len > 1e-3f) || len > 64.f) return false;
  const float ux = dx / len, uy = dy / len, uz = dz / len;
  int x = int(std::floor(s.x)), y = int(std::floor(s.y)), z = int(std::floor(s.z));
  const int sx = ux > 0 ? 1 : -1, sy = uy > 0 ? 1 : -1, sz = uz > 0 ? 1 : -1;
  auto first = [](float p, float u, int c) {
    if (u == 0.f) return 1e30f;
    const float b = u > 0 ? float(c + 1) : float(c);
    return (b - p) / u;
  };
  float tx = first(s.x, ux, x), ty = first(s.y, uy, y), tz = first(s.z, uz, z);
  const float ddx = ux != 0.f ? std::fabs(1.f / ux) : 1e30f, ddy = uy != 0.f ? std::fabs(1.f / uy) : 1e30f,
              ddz = uz != 0.f ? std::fabs(1.f / uz) : 1e30f;
  float t = 0.f;
  Target cand[6];
  int nc = 0;
  for (int guard = 0; guard < 96 && t <= len + 0.01f; ++guard) {
    if (x == hitBlock.x && y == hitBlock.y && z == hitBlock.z) break;  
    uintptr_t exp = 0;
    const bool body = float(x) < bx1 && float(x + 1) > bx0 && float(y) < by1 && float(y + 1) > by0 &&
                      float(z) < bz1 && float(z + 1) > bz0;
    if (!body && A->expectedAt(x, y, z, &exp)) {
      uintptr_t wb = 0;
      const int r = W.replaceable(x, y, z, &wb);
      if (r == 1 && wb != exp) {
        Target c;
        c.t = {x, y, z};
        c.expected = exp;
        if (W.solidNeighbor(x, y, z)) {
          out = c;
          return true;
        }
        if (nc < 6) cand[nc++] = c;
      }
      if (r == 0 && exp && wb != exp) {  
        const std::string en = nameOf(A, exp), wn = nameOf(A, wb);
        const std::string half = stripDouble(en);
        if (!half.empty() && wn == half) {
          out.t = {x, y, z};
          out.expected = exp;
          out.mergeSlab = true;
          out.topSlab = A->stateValue(wb, "minecraft:vertical_half") == 1 || A->stateValue(wb, "top_slot_bit") == 1;
          return true;
        }
      }
      if (r == 0 && exp && wb != exp && epMode() == st::Mode::Correct && !body) {
        lm::holo::Expect E;
        if (lm::holo::expectAt(x, y, z, E) && E.unsupported.empty()) {
          const auto c = lm::holo::compareWorld(E, wb);
          if (c.match == st::Match::StateMismatch && c.diffs.size() == 1 &&
              st::correctionPresses(E.name, c.diffs[0].key, c.diffs[0].expected, c.diffs[0].actual) > 0) {
            out = Target{};
            out.t = {x, y, z};
            out.expected = exp;
            out.fixState = true;
            return true;
          }
        }
      }
      if (r == 0) break;  
    } else if (W.replaceable(x, y, z) == 0) {
      break;
    }
    if (tx < ty && tx < tz) { x += sx; t = tx; tx += ddx; }
    else if (ty < tz) { y += sy; t = ty; ty += ddy; }
    else { z += sz; t = tz; tz += ddz; }
  }
  if (nc > 0) {
    
    
    for (int i = 0; i < nc; ++i) {
      const BlockPos &c = cand[i].t;
      for (int f = 0; f < 6; ++f) {
        const int nx = c.x + kNdx[f], ny = c.y + kNdy[f], nz = c.z + kNdz[f];
        const bool body = float(nx) < bx1 && float(nx + 1) > bx0 && float(ny) < by1 && float(ny + 1) > by0 &&
                          float(nz) < bz1 && float(nz + 1) > bz0;
        if (body) continue;
        if (eye) {  
          const float ex = nx + 0.5f - eye->x, ey = ny + 0.5f - eye->y, ez = nz + 0.5f - eye->z;
          if (ex * ex + ey * ey + ez * ez > (len + 0.5f) * (len + 0.5f)) continue;
        }
        uintptr_t exp = 0, wb = 0;
        if (!A->expectedAt(nx, ny, nz, &exp) || !exp) continue;
        if (W.replaceable(nx, ny, nz, &wb) != 1 || wb == exp || !W.solidNeighbor(nx, ny, nz)) continue;
        out = Target{};
        out.t = {nx, ny, nz};
        out.expected = exp;
        return true;
      }
    }
    out = cand[0];  
    return true;
  }
  return false;
}


float gFindReach = 6.7f;




bool missingAt(const StructuraApiV1 *A, const World &W, int x, int y, int z, uintptr_t &exp) {
  exp = 0;
  uintptr_t wb = 0;
  if (!A->expectedAt(x, y, z, &exp) || !exp) return false;
  return W.replaceable(x, y, z, &wb) == 1 && wb != exp;
}
bool usable(const Vec3 *eye, int x, int y, int z) {
  if (!eye) return true;
  
  const float bx0 = eye->x - 0.3f, bx1 = eye->x + 0.3f, bz0 = eye->z - 0.3f, bz1 = eye->z + 0.3f;
  const float by0 = eye->y - 1.62f, by1 = by0 + 1.8f;
  if (float(x) < bx1 && float(x + 1) > bx0 && float(y) < by1 && float(y + 1) > by0 && float(z) < bz1 && float(z + 1) > bz0)
    return false;
  const float dx = x + 0.5f - eye->x, dy = y + 0.5f - eye->y, dz = z + 0.5f - eye->z;
  return dx * dx + dy * dy + dz * dz <= (gFindReach + 0.5f) * (gFindReach + 0.5f);
}
void settleDown(const StructuraApiV1 *A, const World &W, const Vec3 *eye, Target &T) {
  if (T.mergeSlab || T.fixState) return;
  for (int k = 1; k <= 8; ++k) {
    const int x = T.t.x, y = T.t.y - k, z = T.t.z;
    uintptr_t exp = 0;
    if (!missingAt(A, W, x, y, z, exp) || !usable(eye, x, y, z)) break;
    T = Target{};
    T.t = {x, y, z};
    T.expected = exp;
  }
}
bool findTarget(const StructuraApiV1 *A, const World &W, const Vec3 &s, const Vec3 &e, const BlockPos &hitBlock,
                const Vec3 *eye, Target &out) {
  if (findTargetRay(A, W, s, e, hitBlock, eye, out)) {
    settleDown(A, W, eye, out);
    return true;
  }
  
  if (hitBlock.x != INT32_MIN) {
    uintptr_t exp = 0;
    if (A->expectedAt(hitBlock.x, hitBlock.y, hitBlock.z, &exp) && exp) {
      for (int k = 1; k <= 8; ++k) {
        const int x = hitBlock.x, y = hitBlock.y - k, z = hitBlock.z;
        uintptr_t ex = 0, wb = 0;
        if (missingAt(A, W, x, y, z, ex)) {
          if (!usable(eye, x, y, z)) return false;
          out = Target{};
          out.t = {x, y, z};
          out.expected = ex;
          settleDown(A, W, eye, out);
          return true;
        }
        if (W.replaceable(x, y, z, &wb) != 0) return false;  
        if (!A->expectedAt(x, y, z, &ex)) return false;       
      }
    }
  }
  return false;
}



constexpr int kFdx[6] = {0, 0, 0, 0, -1, 1}, kFdy[6] = {-1, 1, 0, 0, 0, 0}, kFdz[6] = {0, 0, -1, 1, 0, 0};

struct Plan {
  bool ok = false;
  BlockPos n{};      
  uint8_t face = 1;  
  Vec3 click{};      
  bool rotate = false;
  float pitch = 0, yaw = 0;
  int score = 0;  
  int sims = 0;
};

std::string pretty(const std::string &n);

// Tries clicked faces x hit positions x player rotations through the game's own getPlacementBlock and
// scores the simulated block with the shared state classifier (exact = 3, only game-decided /
// tap-changeable states differ = 2). The search itself is lm::plan::search (PlacePlan.hpp).
Plan choosePlan(const StructuraApiV1 *A, const World &W, void *player, uintptr_t blockType, const Target &T,
                const lm::holo::Expect &E) {
  Plan best;
  bool solid[6];
  for (int f = 0; f < 6; ++f) {
    const int nx = T.t.x - kFdx[f], ny = T.t.y - kFdy[f], nz = T.t.z - kFdz[f];
    uintptr_t nb = 0;
    solid[f] = W.replaceable(nx, ny, nz, &nb) == 0 && !opensOnTap(A, nb);
  }
  uintptr_t vt = 0, fnp = 0;
  float *rot = reinterpret_cast<float *>(rdp(reinterpret_cast<uintptr_t>(player) + kActor_Rotation));
  PlacementFn place = nullptr;
  if (blockType && rd(blockType, vt) && plausiblePtr(vt) && rd(vt + kBT_VtPlacement, fnp) && fnp)
    place = reinterpret_cast<PlacementFn>(fnp);
  float orig[2] = {0, 0};
  const bool haveRot = rot && rd(reinterpret_cast<uintptr_t>(rot), orig);
  const bool canSim = place && E.block && haveRot;
  struct Memo {
    uintptr_t b;
    int sc;
  } memo[24];
  int nm = 0;
  auto simAt = [&](int f, const Vec3 &cv, float pitch, float yaw) -> uintptr_t {
    rot[0] = pitch;
    rot[1] = yaw;
    return place(reinterpret_cast<void *>(blockType), player, &T.t, uint8_t(f), &cv, 0);
  };
  auto sim = [&](int f, const lm::plan::V3 &c, bool rotate, float pitch, float yaw) -> int {
    if (!canSim) return 0;
    const Vec3 cv{c.x, c.y, c.z};
    const uintptr_t r = simAt(f, cv, rotate ? pitch : orig[0], rotate ? yaw : orig[1]);
    if (!plausiblePtr(r)) return 0;
    if (!rotate && E.directional) {
      // No turn: the server uses the rotation of the last auth-input packet (up to a tick older than this
      // frame). Accept the current rotation only when +-12 deg of yaw and pitch give the same block, so a
      // camera moving near a 45 deg (or up/down) boundary can't make client and server disagree.
      static const float kD[4][2] = {{0, 12.f}, {0, -12.f}, {12.f, 0}, {-12.f, 0}};
      for (const auto &d : kD)
        if (simAt(f, cv, std::clamp(orig[0] + d[0], -90.f, 90.f), orig[1] + d[1]) != r) return 0;
    }
    for (int i = 0; i < nm; ++i)
      if (memo[i].b == r) return memo[i].sc;
    const int sc = r == E.block ? 3 : st::planScore(lm::holo::compareWorld(E, r));
    if (nm < 24) memo[nm++] = Memo{r, sc};
    return sc;
  };
  float extra[1];
  int ne = 0;
  for (const auto &sv : E.states)  // 16-step rotation (signs, banners): yaw = r * 22.5 - 180
    if (sv.key == "ground_sign_direction" && sv.type != lm::nbt::String) {
      extra[ne++] = float(sv.i & 15) * 22.5f - 180.f;
      break;
    }
  // Air placement (see PlacePlan.hpp): allowed for non-directional blocks, and for blocks whose only facing is the
  // player's horizontal look (fence gate: cardinal_direction). Face-based facings (hopper, piston, trapdoor, stairs)
  // are decided by the clicked face or hit point, so an air result can differ from the hologram.
  bool airOk = !E.directional;
  if (E.directional) {
    bool yawOnly = true, anyFacing = false;
    for (const auto &sv : E.states) {
      const bool facingKey = sv.key.find("direction") != std::string::npos || sv.key.find("facing") != std::string::npos;
      if (!facingKey) continue;
      anyFacing = true;
      if (sv.key != "minecraft:cardinal_direction" && sv.key != "cardinal_direction") yawOnly = false;
    }
    airOk = anyFacing && yawOnly;
  }
  const lm::plan::Candidate c = lm::plan::search(solid, canSim, orig[0], orig[1], extra, ne, airOk, sim);
  if (haveRot) {
    rot[0] = orig[0];
    rot[1] = orig[1];
  }
  best.ok = c.ok;
  best.face = uint8_t(c.face);
  best.click = {c.click.x, c.click.y, c.click.z};
  best.rotate = c.rotate;
  best.pitch = c.pitch;
  best.yaw = c.yaw;
  best.score = c.score;
  best.sims = c.simulations;
  best.n = c.inAir ? T.t : BlockPos{T.t.x - kFdx[c.face], T.t.y - kFdy[c.face], T.t.z - kFdz[c.face]};
  return best;
}


struct Pending {
  bool active = false;
  int stage = 0;  
  uint64_t gen = 0;  
  BlockPos n{};
  uint8_t face = 1, hand = 0;
  bool flag = false;
  Vec3 click{};
  float pitch = 0, yaw = 0, origPitch = 0, origYaw = 0;
  int64_t t0 = 0, t1 = 0;
  BlockPos target{};
  int attempts = 0;
  int ticks = 0;          // distinct game ticks spent in the current stage (turn / hold)
  int64_t lastTickAt = 0;
};
std::mutex gPendMu;
Pending gPend;  
std::atomic<int64_t> gTickAt{0};
void setRot(void *player, float pitch, float yaw);
void resetCaches();
void verifyPlaced(const BlockPos &t, const char *how);
void runFix(void *gm, void *player);
void processRechecks();
void resetFixes();



void refreshGeneration(uintptr_t player) {
  const bool forced = gForceRefresh.exchange(false, std::memory_order_acq_rel);
  if (!forced && lm::model().genSeen.load(std::memory_order_acquire) == gSeenModelGen &&
      lm::settings().hologram.load(std::memory_order_relaxed) == gSeenHolo && untag(player) == gSeenPlayer)
    return;
  uint64_t mg = 0;
  const void *str = nullptr;
  bool placed = false;
  {
    auto &m = lm::model();
    std::lock_guard<std::mutex> lk(m.mu);
    mg = m.gen;
    str = m.structure.get();
    placed = m.placed;
  }
  const bool holo = lm::settings().hologram.load(std::memory_order_relaxed);
  const uintptr_t pl = untag(player);
  if (!forced && mg == gSeenModelGen && str == gSeenStructure && placed == gSeenPlaced && holo == gSeenHolo &&
      pl == gSeenPlayer)
    return;
  const bool samePlayer = pl == gSeenPlayer && pl != 0;
  gSeenModelGen = mg;
  gSeenStructure = str;
  gSeenPlaced = placed;
  gSeenHolo = holo;
  gSeenPlayer = pl;
  const uint64_t g = gGen.fetch_add(1) + 1;
  {
    std::lock_guard<std::mutex> lk(gPendMu);
    if (gPend.active) {
      
      if (samePlayer) setRot(reinterpret_cast<void *>(player), gPend.origPitch, gPend.origYaw);
      if (gPend.stage == 0) lm::progress::noteWorld(gPend.target.x, gPend.target.y, gPend.target.z, lm::EpNone);
      gPend = Pending{};
      trace("queue updated: cancelled (structure/world changed) gen=%llu", static_cast<unsigned long long>(g));
    }
  }
  gFails.clear();
  resetCaches();
  resetFixes();
}

bool discarded(const BlockPos &t) {
  const int64_t now = nowMs();
  const uint64_t g = gGen.load();
  for (const FailRec &f : gFails)
    if (f.x == t.x && f.y == t.y && f.z == t.z && f.gen == g)
      return f.attempts >= kMaxAttempts ? now - f.lastAt < kDiscardMs : now - f.lastAt < 1500;
  return false;
}
void noteFail(const BlockPos &t, const char *why) {
  const int64_t now = nowMs();
  const uint64_t g = gGen.load();
  for (FailRec &f : gFails) {
    if (f.x != t.x || f.y != t.y || f.z != t.z) continue;
    if (f.gen != g || (f.attempts >= kMaxAttempts && now - f.lastAt >= kDiscardMs)) f = FailRec{t.x, t.y, t.z, g, 0, 0};
    ++f.attempts;
    f.lastAt = now;
    if (f.attempts >= kMaxAttempts) {
      trace("queue updated: %d %d %d dropped after %d tries (%s)", t.x, t.y, t.z, f.attempts, why);
      logf("dropped %d %d %d after %d tries: %s", t.x, t.y, t.z, f.attempts, why);
    }
    return;
  }
  if (gFails.size() >= 64) gFails.erase(gFails.begin());
  gFails.push_back(FailRec{t.x, t.y, t.z, g, 1, now});
}
void noteOk(const BlockPos &t) {
  for (size_t i = 0; i < gFails.size(); ++i)
    if (gFails[i].x == t.x && gFails[i].y == t.y && gFails[i].z == t.z) {
      gFails.erase(gFails.begin() + long(i));
      return;
    }
}


uintptr_t hitResultOf(void *gm) {
  const uintptr_t player = rdp(reinterpret_cast<uintptr_t>(gm) + kGM_Player);
  const uintptr_t level = player ? rdp(player + kActor_Level) : 0;
  uintptr_t vt = 0, fn = 0;
  if (!level || !rd(level, vt) || !plausiblePtr(vt) || !rd(vt + kLevel_VtHitResult, fn) || !fn) return 0;
  const uintptr_t hr = reinterpret_cast<uintptr_t>(reinterpret_cast<HitResultFn>(fn)(reinterpret_cast<void *>(level)));
  return plausiblePtr(hr) ? hr : 0;
}

bool vptrReadable(uintptr_t obj) {
  uintptr_t vt = 0, f0 = 0;
  return plausiblePtr(obj) && rd(obj, vt) && plausiblePtr(vt) && rd(untag(vt), f0);
}


const char *validatePlacement(void *gm, const BlockPos &n, uint8_t hand, uint64_t gen, bool interact,
                              const BlockPos *cell) {
  if (!gPlacementValidated.load(std::memory_order_acquire) || !oBuildBlock) return "placement function not validated";
  if (!onGameThread()) return "not on the game thread";
  if (easyPlaceInProgress() == false) return "no easy place scope";
  const uintptr_t g = reinterpret_cast<uintptr_t>(gm);
  const uintptr_t localPlayer = lm::status().player.load(std::memory_order_relaxed);
  refreshGeneration(localPlayer);  
  if (gen != gGen.load()) return "structure changed";
  if (!api()) return "structura not ready";
  {
    auto &m = lm::model();
    std::lock_guard<std::mutex> lk(m.mu);
    if (!m.structure || !m.placed) return "no structure";
  }
  // final visible-layer gate, right before the game call: the cell Easy Place is about to fill (or correct)
  // must be in the layers the hologram shows. A layer change during a turn/hold or a queued run can never
  // place or correct a block in a hidden layer.
  if (!cell) return "no target cell";
  if (lm::holo::layerGate(cell->x, cell->y, cell->z) != 1) return "target outside the visible layer";
  
  if (!localPlayer || !plausiblePtr(g)) return "no player";
  const uintptr_t player = rdp(g + kGM_Player);
  if (untag(player) != untag(localPlayer) || !vptrReadable(player)) return "player invalid";
  if (!isGameModeOf(g, player)) return "gamemode invalid";
  
  const uintptr_t level = rdp(player + kActor_Level);
  if (!vptrReadable(level)) return "level invalid";
  const uintptr_t dim = rdp(player + lm::off::Actor_mDimension);
  if (!vptrReadable(dim)) return "dimension invalid";
  const uintptr_t region = rdp(dim + lm::off::Dimension_mBlockSource);
  if (!vptrReadable(region)) return "blocksource invalid";
  
  const uintptr_t inv = rdp(player + kPlayer_Inventory);
  if (!vptrReadable(inv)) return "inventory invalid";
  if (hand > 1 || !sHandItem) return "hand invalid";
  const void *stack = sHandItem(reinterpret_cast<void *>(player), hand);
  if (interact) {  // correction tap: the hand must be EMPTY so the game can only interact, never place
    if (stack && !stackEmpty(stack)) return "hand not empty for a correction tap";
  } else if (!stack || !plausiblePtr(reinterpret_cast<uintptr_t>(stack)) || stackEmpty(stack)) {
    return "hand item empty";
  }
  
  if (n.y < -64 || n.y > 319) return "position out of world";
  Vec3 eye{};
  const uintptr_t sv = rdp(player + kActor_State);
  if (!sv || !rd(sv, eye) || !std::isfinite(eye.x) || !std::isfinite(eye.y) || !std::isfinite(eye.z)) return "no eye";
  const float dx = n.x + 0.5f - eye.x, dy = n.y + 0.5f - eye.y, dz = n.z + 0.5f - eye.z;
  const float lim = reachOf(gm) + 2.f;
  if (!(dx * dx + dy * dy + dz * dz <= lim * lim)) return "position out of reach";
  return nullptr;
}



int placeNow(void *gm, const BlockPos &n, uint8_t face, const Vec3 &click, uint8_t hand, bool flag, uint64_t gen,
             const BlockPos &cell, bool interact = false) {
  if (gPlacedFrame == gFrameNo && gPlacedThisFrame >= kMaxPlacePerFrame) {
    trace("easyplace end: frame limit");
    return -1;
  }
  if (const char *why = validatePlacement(gm, n, hand, gen, interact, &cell)) {
    trace("easyplace end: cancelled (%s)", why);
    logf("placement cancelled: %s", why);
    return -1;
  }
  trace("player validated");
  trace("placement function validated");
  if (gPlacedFrame != gFrameNo) {
    gPlacedFrame = gFrameNo;
    gPlacedThisFrame = 0;
  }
  ++gPlacedThisFrame;
  const BlockPos pos = n;  
  const uintptr_t hr = hitResultOf(gm);
  if (!hr) {
    trace("calling original placement %d %d %d face %d (no hit result)", pos.x, pos.y, pos.z, face);
    const bool r = oBuildBlock(gm, &pos, face, hand, flag);
    trace("original placement returned %d", int(r));
    return r ? 1 : 0;
  }
  
  
  const uintptr_t g = reinterpret_cast<uintptr_t>(gm);
  uint8_t saved[0x20];
  std::memcpy(saved, reinterpret_cast<void *>(hr + kHR_Type), sizeof(saved));  
  uint8_t alt = 0;
  float altSaved[3] = {0, 0, 0};
  rd(g + kGM_AltHitFlag, alt);
  if (alt) std::memcpy(altSaved, reinterpret_cast<void *>(g + kGM_AltHit), sizeof(altSaved));

  const Vec3 hit{float(pos.x) + click.x, float(pos.y) + click.y, float(pos.z) + click.z};
  const int type = 0, f = face;
  std::memcpy(reinterpret_cast<void *>(hr + kHR_Type), &type, 4);
  std::memcpy(reinterpret_cast<void *>(hr + kHR_Face), &f, 4);
  std::memcpy(reinterpret_cast<void *>(hr + kHR_Pos), &pos, 12);
  std::memcpy(reinterpret_cast<void *>(hr + kHR_Hit), &hit, 12);
  if (alt) std::memcpy(reinterpret_cast<void *>(g + kGM_AltHit), &hit, 12);

  trace("calling original placement %d %d %d face %d hand %d", pos.x, pos.y, pos.z, face, hand);
  const bool r = oBuildBlock(gm, &pos, face, hand, flag);
  trace("original placement returned %d", int(r));

  
  if (hitResultOf(gm) == hr) std::memcpy(reinterpret_cast<void *>(hr + kHR_Type), saved, sizeof(saved));
  if (alt && !r) std::memcpy(reinterpret_cast<void *>(g + kGM_AltHit), altSaved, sizeof(altSaved));
  return r ? 1 : 0;
}


// The turn is measured in GAME TICKS: the server takes the player rotation from the auth-input packet sent
// once per client tick, so the placement may only be sent after >= kTurnTicks ticks with the new rotation,
// and the rotation is held >= kHoldTicks ticks after it (plus a minimum wall time each, for low TPS and
// frame drops). Time-only waits (1.0.21: 120/150 ms) can be shorter than two ticks.
constexpr int kTurnTicks = 3, kHoldTicks = 3;
constexpr int kTurnMs = 110;
constexpr int kHoldMs = 130;
constexpr int kGiveUpMs = 2500;
constexpr int kTickDedupMs = 25;  // GameMode::tick and SurvivalMode::tick may both fire in one tick

void setRot(void *player, float pitch, float yaw) {
  float *rot = reinterpret_cast<float *>(rdp(reinterpret_cast<uintptr_t>(player) + kActor_Rotation));
  if (!rot || !plausiblePtr(reinterpret_cast<uintptr_t>(rot))) return;
  rot[0] = pitch;
  rot[1] = yaw;
}

void onTick(void *gm) {
  
  if (!onGameThread() || easyPlaceInProgress() || !gBase) return;
  const uintptr_t localPlayer = lm::status().player.load(std::memory_order_relaxed);
  const uintptr_t g = reinterpret_cast<uintptr_t>(gm);
  // A game tick on the game thread is recorded before the GameMode identity check: the turn logic only needs
  // "the game is ticking", and the identity check was the reason no tick was ever seen on some builds.
  gTickAt.store(nowMs(), std::memory_order_relaxed);
  static std::atomic<int> sTickTraces{0};
  if (sTickTraces.fetch_add(1, std::memory_order_relaxed) < 5) {
    const bool gmOk = localPlayer && isGameModeOf(g, localPlayer);
    logf("tick hook called: gm=%p player=%p gameModeMatches=%d", gm, reinterpret_cast<void *>(localPlayer), int(gmOk));
  }
  if (!localPlayer || !isGameModeOf(g, localPlayer)) return;
  InProgressScope scope;
  refreshGeneration(localPlayer);
  processRechecks();
  std::unique_lock<std::mutex> lk(gPendMu, std::try_to_lock);
  if (!lk.owns_lock()) return;
  void *player = reinterpret_cast<void *>(localPlayer);
  if (!gPend.active) {
    if (!gPaused.load(std::memory_order_relaxed)) runFix(gm, player);
    return;
  }
  const int64_t now = nowMs();
  if (gPend.gen != gGen.load()) {
    setRot(player, gPend.origPitch, gPend.origYaw);  // never leave the player turned
    if (gPend.stage == 0) lm::progress::noteWorld(gPend.target.x, gPend.target.y, gPend.target.z, lm::EpNone);
    gPend = Pending{};
    trace("queue updated: dropped (old structure)");
    return;
  }
  if (gPend.stage == 0 && gPaused.load(std::memory_order_relaxed)) {  // pause: cancel before placing
    setRot(player, gPend.origPitch, gPend.origYaw);
    lm::progress::noteWorld(gPend.target.x, gPend.target.y, gPend.target.z, lm::EpNone);
    gPend = Pending{};
    trace("queue updated: cancelled (paused)");
    return;
  }
  if (now - gPend.t0 > kGiveUpMs) {
    setRot(player, gPend.origPitch, gPend.origYaw);
    gPend.active = false;
    noteFail(gPend.target, "timeout");
    if (gPend.stage == 0)
      lm::progress::noteWorld(gPend.target.x, gPend.target.y, gPend.target.z, lm::EpFailed, lm::ErrTimeout);
    trace("queue updated: gave up (timeout)");
    return;
  }
  const bool newTick = now - gPend.lastTickAt >= kTickDedupMs;
  if (newTick) {
    gPend.lastTickAt = now;
    ++gPend.ticks;
  }
  if (gPend.stage == 0) {
    setRot(player, gPend.pitch, gPend.yaw);
    gOp.store(1, std::memory_order_relaxed);
    // ticks counts this tick too: > kTurnTicks means kTurnTicks full ticks were sent with the new rotation
    if (gPend.ticks > kTurnTicks && now - gPend.t0 >= kTurnMs) {
      const Pending P = gPend;  
      trace("easyplace begin src=turn target %d %d %d gen=%llu", P.target.x, P.target.y, P.target.z,
            static_cast<unsigned long long>(P.gen));
      trace("target validated");
      const int r = placeNow(gm, P.n, P.face, P.click, P.hand, P.flag, P.gen, P.target);
      if (r < 0) {  
        setRot(player, P.origPitch, P.origYaw);
        gPend = Pending{};
        noteFail(P.target, "validation");
        lm::progress::noteWorld(P.target.x, P.target.y, P.target.z, lm::EpNone, lm::ErrValidation);
        trace("queue updated: cancelled");
        return;
      }
      const StructuraApiV1 *A = api();
      bool ok = false;
      if (A) {
        World W(A);
        ok = W.replaceable(P.target.x, P.target.y, P.target.z) != 1;  
      }
      logf("turn: placed=%d changed=%d", r, int(ok));
      if (ok) {
        noteOk(P.target);
        verifyPlaced(P.target, "turn");
      } else {
        noteFail(P.target, "game refused");
        lm::progress::noteWorld(P.target.x, P.target.y, P.target.z, lm::EpFailed, lm::ErrRefused);
        if (gRunScope.load(std::memory_order_relaxed) == 0) lm::notify("msg.ep_cant_place", lm::Tone::Warning, 2000);
      }
      gPend.stage = 1;
      gPend.t1 = now;
      gPend.ticks = 0;
      trace("queue updated: placed=%d", int(ok));
      trace("easyplace end");
    }
  } else {
    if (gPend.ticks >= kHoldTicks && now - gPend.t1 >= kHoldMs) {
      setRot(player, gPend.origPitch, gPend.origYaw);
      gPend.active = false;
      gOp.store(0, std::memory_order_relaxed);
    } else {
      setRot(player, gPend.pitch, gPend.yaw);
    }
  }
}

void clientStep(bool runAuto);

// Player context from the GameMode tick: only the GameMode whose mPlayer is the LOCAL player counts
// (server-side GameModes of singleplayer tick too and are rejected by vtable). When the context came
// from here (ClientInstance::update unavailable), this tick also runs Easy Place's per-client step.
void contextTick(void *gm) {
  if (lm::ctx::publishGameMode(reinterpret_cast<uintptr_t>(gm), kGM_Player)) clientStep(true);
}

// First calls are logged unconditionally: if these lines never appear in the log, the GameMode / SurvivalMode
// tick hooks are not reached on this build, and every turn-based placement waits for a tick that never comes.
void gameModeTickDetour(void *gm) {
  static std::atomic<int> sCalls{0};
  if (sCalls.fetch_add(1, std::memory_order_relaxed) < 3) logf("GameMode tick detour called (gm=%p)", gm);
  oGameModeTick(gm);
  contextTick(gm);
  onTick(gm);
}
void survivalTickDetour(void *gm) {
  static std::atomic<int> sCalls{0};
  if (sCalls.fetch_add(1, std::memory_order_relaxed) < 3) logf("SurvivalMode tick detour called (gm=%p)", gm);
  oSurvivalTick(gm);
  contextTick(gm);
  onTick(gm);
}

std::string pretty(const std::string &n) {
  std::string out;
  bool up = true;
  for (char c : n) {
    if (c == '_') { out += ' '; up = true; continue; }
    out += up ? char(std::toupper(static_cast<unsigned char>(c))) : c;
    up = false;
  }
  return out;
}


constexpr uintptr_t kInv_Selected = 0x10, kInv_ContainerId = 0xb0, kInv_Container = 0xb8;
constexpr uintptr_t kVtContainer_GetItem = 0x40;
constexpr int kHotbarSize = 9;
constexpr int kSwitchSettleMs = 130;  
std::atomic<int64_t> gSwitchAt{0};
std::atomic<int> gHotbarOk{0};  
std::atomic<int64_t> gHotbarOffAt{0};

bool stackEmpty(const void *stack) {
  if (!stack) return true;
  const uintptr_t st = reinterpret_cast<uintptr_t>(stack);
  uint8_t count = 0;
  if (!rd(st + 0x23, count)) return false;
  if (count == 0) return true;
  const uintptr_t w = rdp(st + 8);
  return !w || !rdp(w);
}
uintptr_t blockTypeOfStack(const void *stack) {
  if (!stack || !sItemBlockType || stackEmpty(stack)) return 0;
  const uintptr_t bt = reinterpret_cast<uintptr_t>(sItemBlockType(stack).blockType);
  return plausiblePtr(bt) ? bt : 0;
}

struct Hotbar {
  void *inv = nullptr;
  void *cont = nullptr;
  GetItemFn get = nullptr;
  int sel = -1;
  const void *item(int i) const { return get ? get(cont, i) : nullptr; }
};
bool hotbarOf(void *player, Hotbar &H) {
  if (!sSelectSlot) return false;
  if (gHotbarOk.load() <= -8) {  
    if (nowMs() - gHotbarOffAt.load() < 10000) return false;
    gHotbarOk.store(0);
  }
  const uintptr_t inv = rdp(reinterpret_cast<uintptr_t>(player) + kPlayer_Inventory);
  const uintptr_t cont = inv ? rdp(inv + kInv_Container) : 0;
  uintptr_t vt = 0, fn = 0;
  if (!cont || !rd(cont, vt) || !plausiblePtr(vt) || !rd(untag(vt) + kVtContainer_GetItem, fn) || !fn) return false;
  int sel = -1;
  uint8_t cid = 0xff;
  if (!rd(inv + kInv_Selected, sel) || !rd(inv + kInv_ContainerId, cid) || cid != 0 || sel < 0 || sel >= kHotbarSize)
    return false;
  H.inv = reinterpret_cast<void *>(inv);
  H.cont = reinterpret_cast<void *>(cont);
  H.get = reinterpret_cast<GetItemFn>(fn);
  H.sel = sel;
  if (gHotbarOk.load() != 1) {  
    const void *hand = sHandItem ? sHandItem(player, 0) : nullptr;
    const void *slot = H.item(sel);
    
    
    if (stackEmpty(hand) && slot && stackEmpty(slot)) return true;
    const bool ok = hand && hand == slot;
    if (ok) gHotbarOk.store(1);
    else if (gHotbarOk.fetch_sub(1) - 1 <= -8) gHotbarOffAt.store(nowMs());
    logf("switch: hotbar check %s (inv=%p slot=%d)", ok ? "ok" : "failed", H.inv, sel);
    if (!ok) return false;
  }
  return true;
}


// The held item must place the expected block TYPE (its block, not item metadata). Equivalent types
// (powered/unpowered repeater, lit/unlit furnace, ...) place the same block.
bool itemServes(const StructuraApiV1 *A, uintptr_t heldBT, uintptr_t expBT, const std::string &half,
                const std::string &expName = {}) {
  if (!heldBT) return false;
  if (heldBT == expBT) return true;
  const std::string hn = nameOf(A, rdp(heldBT + kBT_Default));
  if (!half.empty() && hn == half) return true;
  return !expName.empty() && !hn.empty() && st::placeableName(expName) != expName && st::sameBlockType(hn, expName);
}

// Hotbar slot changed by Easy Place: restored after ~700 ms without Easy Place activity (or when it
// is turned off), unless the player picked another slot meanwhile.
std::atomic<int> gOrigSlot{-1}, gEpSlot{-1};
std::atomic<int64_t> gEpActiveAt{0};
void noteSlotSwitch(int from, int to) {
  int expect = -1;
  gOrigSlot.compare_exchange_strong(expect, from);
  gEpSlot.store(to);
  gEpActiveAt.store(nowMs());
}






constexpr uintptr_t kPickBlockStatic = 0xaad146c, kIsCreativeStatic = 0xf58e894;
constexpr uint8_t kPickBlockHead[] = {0xff, 0xc3, 0x02, 0xd1, 0xfd, 0x7b, 0x07, 0xa9, 0xf7, 0x43, 0x00, 0xf9, 0xf6,
                                      0x57, 0x09, 0xa9, 0xf4, 0x4f, 0x0a, 0xa9, 0xfd, 0xc3, 0x01, 0x91, 0x57, 0xd0,
                                      0x3b, 0xd5, 0xe8, 0x16, 0x40, 0xf9, 0xa8, 0x83, 0x1f, 0xf8, 0x28, 0x18, 0x40,
                                      0xb9, 0x08, 0x11, 0x00, 0x51, 0x1f, 0x0d, 0x00, 0x31};
constexpr uint8_t kIsCreativeHead[] = {0xfd, 0x7b, 0xbe, 0xa9, 0xf4, 0x4f, 0x01, 0xa9,
                                       0xfd, 0x03, 0x00, 0x91, 0xf4, 0x03, 0x00, 0xaa};
using PickBlockFn = void (*)(void *player, const void *hitResult, bool withData);
using IsCreativeFn = bool (*)(void *player);
PickBlockFn sPickBlock = nullptr;
IsCreativeFn sIsCreative = nullptr;
constexpr int kInventorySize = 36;  
struct PickWait {
  uintptr_t bt = 0;
  int64_t at = 0;
} gPick;

bool headMatches(uintptr_t a, const uint8_t *head, size_t n) {
  uint8_t buf[64];
  if (n > sizeof(buf) || !a) return false;
  for (size_t i = 0; i < n; i += 8) {
    uint64_t w = 0;
    if (!rd(a + i, w)) return false;
    std::memcpy(buf + i, &w, std::min<size_t>(8, n - i));
  }
  return std::memcmp(buf, head, n) == 0;
}


int pickFromInventory(const StructuraApiV1 *A, void *player, const Hotbar &H, uintptr_t expBT) {
  if (!sPickBlock || !expBT) return 0;
  const int64_t now = nowMs();
  if (gPick.bt == expBT && now - gPick.at < 1200) return 1;  
  if (gPick.bt == expBT && now - gPick.at < 3000) return 0;  
  // only into an EMPTY hotbar slot: no hotbar item is ever pushed out
  int empty = -1;
  for (int i = 0; i < kHotbarSize && empty < 0; ++i)
    if (stackEmpty(H.item(i))) empty = i;
  if (empty < 0) return 0;
  bool have = sIsCreative && sIsCreative(player);  
  for (int i = kHotbarSize; i < kInventorySize && !have; ++i)
    have = blockTypeOfStack(H.item(i)) == expBT;
  if (!have) return 0;
  Vec3 eye{};
  const uintptr_t sv = rdp(reinterpret_cast<uintptr_t>(player) + kActor_State);
  if (!sv || !rd(sv, eye) || !std::isfinite(eye.x) || !std::isfinite(eye.y) || !std::isfinite(eye.z)) return 0;
  
  const int ex = int(std::floor(eye.x)), ey = int(std::floor(eye.y)), ez = int(std::floor(eye.z));
  constexpr int R = 4;
  BlockPos best{INT32_MIN, 0, 0};
  int bestD = 1 << 30;
  for (int dy = -R; dy <= R; ++dy)
    for (int dz = -R; dz <= R; ++dz)
      for (int dx = -R; dx <= R; ++dx) {
        const int d = dx * dx + dy * dy + dz * dz;
        if (d >= bestD || d > R * R + 2) continue;
        const uintptr_t wb = A->worldBlock(ex + dx, ey + dy, ez + dz);
        if (wb && untag(rdp(wb + kBlock_Type)) == untag(expBT)) {
          best = {ex + dx, ey + dy, ez + dz};
          bestD = d;
        }
      }
  if (best.x == INT32_MIN) return 0;
  if (empty != H.sel) {  // select the empty slot first, pick on the next attempt
    if (!sSelectSlot(H.inv, empty, 0)) return 0;
    noteSlotSwitch(H.sel, empty);
    gSwitchAt.store(now);
    logf("switch: slot %d -> empty slot %d before picking", H.sel, empty);
    return 1;
  }
  alignas(16) uint8_t hr[0x100] = {};  
  const int type = 0, face = 1;
  const Vec3 hit{best.x + 0.5f, best.y + 1.f, best.z + 0.5f};
  std::memcpy(hr + kHR_Start, &eye, 12);
  std::memcpy(hr + kHR_Type, &type, 4);
  std::memcpy(hr + kHR_Face, &face, 4);
  std::memcpy(hr + kHR_Pos, &best, 12);
  std::memcpy(hr + kHR_Hit, &hit, 12);
  trace("pick block request %d %d %d", best.x, best.y, best.z);
  sPickBlock(player, hr, false);
  trace("pick block returned");
  gPick = PickWait{expBT, now};
  gSwitchAt.store(now);
  logf("switch: pick from inventory via %d %d %d", best.x, best.y, best.z);
  return 1;
}


int trySwitch(const StructuraApiV1 *A, void *player, uintptr_t expBT, const std::string &half,
              const std::string &expName = {}) {
  Hotbar H;
  if (!hotbarOf(player, H)) return 0;
  int found = -1;
  for (int i = 0; i < kHotbarSize && found < 0; ++i) {
    if (i == H.sel) continue;
    if (itemServes(A, blockTypeOfStack(H.item(i)), expBT, half, expName)) found = i;
  }
  if (found < 0) return pickFromInventory(A, player, H, expBT);
  trace("select slot %d -> %d", H.sel, found);
  const bool ok = sSelectSlot(H.inv, found, 0);
  trace("select slot returned %d", int(ok));
  logf("switch: slot %d -> %d %s", H.sel, found, ok ? "ok" : "refused");
  if (!ok) return 0;
  noteSlotSwitch(H.sel, found);
  gSwitchAt.store(nowMs());
  return 1;
}



// ---- verification after every placement ------------------------------------------------------
constexpr int kMaxFixTaps = 4;
constexpr int kFixGapMs = 250;  // >= 150 ms between taps: the game applies the toggle first
struct Fix {
  bool active = false;
  uint64_t gen = 0;
  BlockPos pos{};
  int taps = 0;
  int64_t t0 = 0, nextAt = 0;
  std::string first;  // "key a -> b" at the start (report)
};
std::mutex gFixMu;
Fix gFix;

struct Recheck {
  BlockPos p{};
  uint64_t gen = 0;
  int64_t at = 0;
  bool used = false;
};
constexpr int kRechecks = 32;
constexpr int kRecheckMs = 400;
Recheck gRe[kRechecks];
int gReHead = 0;
std::mutex gReMu;

void resetFixes() {
  {
    std::lock_guard<std::mutex> lk(gFixMu);
    gFix = Fix{};
  }
  std::lock_guard<std::mutex> lk(gReMu);
  for (auto &r : gRe) r = Recheck{};
}

bool fixable(const lm::holo::Expect &E, const st::Compared &c) {
  return c.match == st::Match::StateMismatch && c.diffs.size() == 1 &&
         st::correctionPresses(E.name, c.diffs[0].key, c.diffs[0].expected, c.diffs[0].actual) > 0;
}

bool startFix(const BlockPos &t, const std::string &what) {
  if (nowMs() - gTickAt.load() > 500) return false;  // taps run in the game tick
  std::lock_guard<std::mutex> lk(gFixMu);
  if (gFix.active) return gFix.pos.x == t.x && gFix.pos.y == t.y && gFix.pos.z == t.z;
  gFix = Fix{};
  gFix.active = true;
  gFix.gen = gGen.load();
  gFix.pos = t;
  gFix.t0 = nowMs();
  gFix.nextAt = gFix.t0 + 150;
  gFix.first = what;
  gEpActiveAt.store(gFix.t0);
  gOp.store(4, std::memory_order_relaxed);
  return true;
}

void pushRecheck(const BlockPos &t) {
  std::lock_guard<std::mutex> lk(gReMu);
  gRe[gReHead] = Recheck{t, gGen.load(), nowMs() + kRecheckMs, true};
  gReHead = (gReHead + 1) % kRechecks;
}

// companion part (door upper half, bed head, tall plant top) of a just placed base part
bool companionOk(const StructuraApiV1 *A, const lm::holo::Expect &E, std::string &exp, std::string &act) {
  if (!E.companion) return true;
  const uintptr_t wb = A->worldBlock(E.cx, E.cy, E.cz);
  lm::holo::Expect C;
  if (E.companionInStructure && lm::holo::expectAt(E.cx, E.cy, E.cz, C) && C.block) {
    const auto c = lm::holo::compareWorld(C, wb);
    if (c.match == st::Match::Exact || c.match == st::Match::Equivalent) return true;
    exp = std::string(E.companionWhat) + ": " + lm::holo::describeWorld(C, C.block, true);
    act = c.match == st::Match::StateMismatch ? lm::holo::describeWorld(C, wb) + " [" + diffText(c) + "]"
                                              : nameOf(A, wb);
    return false;
  }
  // not part of the structure (layer cut): the game must still have created it
  if (wb && wb != A->worldBlock(0, 32767, 0)) return true;
  exp = std::string(E.companionWhat) + " present";
  act = "missing";
  return false;
}

void verifyPlaced(const BlockPos &t, const char *how) {
  gStats.placed.fetch_add(1, std::memory_order_relaxed);
  gOp.store(3, std::memory_order_relaxed);
  const st::Mode mode = epMode();
  const StructuraApiV1 *A = api();
  lm::holo::Expect E;
  if (!A || !lm::holo::expectAt(t.x, t.y, t.z, E) || !st::verifies(mode)) {
    // not verified here: the hologram compare pass (world read-back) still decides the progress state
    lm::progress::noteWorld(t.x, t.y, t.z, lm::EpNone);
    return;
  }
  const uintptr_t wb = A->worldBlock(t.x, t.y, t.z);
  const auto c = lm::holo::compareWorld(E, wb);
  lm::progress::verifiedWorld(t.x, t.y, t.z,
                              c.match == st::Match::Exact || c.match == st::Match::Equivalent ? lm::CmpCorrect
                              : c.match == st::Match::StateMismatch                          ? lm::CmpWrongState
                              : c.match == st::Match::WrongBlock                             ? lm::CmpWrong
                                                                                             : lm::CmpMissing);
  const std::string expS = lm::holo::describeWorld(E, E.block, true);
  if (c.match == st::Match::Exact || c.match == st::Match::Equivalent) {
    std::string ce, ca;
    if (companionOk(A, E, ce, ca)) {
      gStats.exact.fetch_add(1, std::memory_order_relaxed);
      report(E, "OK", expS, c.match == st::Match::Exact ? "identical" : "equivalent (game-computed states differ)",
             "none", how);
      pushRecheck(t);
      return;
    }
    gStats.mismatch.fetch_add(1, std::memory_order_relaxed);
    lm::progress::verifiedWorld(t.x, t.y, t.z, lm::CmpWrongState);
    lm::progress::noteWorld(t.x, t.y, t.z, lm::EpFailed, lm::ErrCompanion);
    report(E, "PARTIAL", ce, ca, "none (the game decides the second part)", "second part differs");
    toastOnce("msg.ep_state_mismatch", pretty(E.name));
    return;
  }
  if (c.match == st::Match::StateMismatch) {
    const std::string actS = lm::holo::describeWorld(E, wb) + " [" + diffText(c) + "]";
    if (st::correctsOwn(mode) && fixable(E, c) &&
        startFix(t, c.diffs[0].key + " " + std::to_string(c.diffs[0].actual) + " -> " +
                        std::to_string(c.diffs[0].expected))) {
      report(E, "PARTIAL", expS, actS, "tap scheduled (empty hand)", "correcting");
      return;
    }
    gStats.mismatch.fetch_add(1, std::memory_order_relaxed);
    report(E, "PARTIAL", expS, actS, fixable(E, c) ? "off in this mode" : "not possible without breaking",
           "state mismatch");
    toastOnce("msg.ep_state_mismatch", pretty(E.name));
    return;
  }
  gStats.failed.fetch_add(1, std::memory_order_relaxed);
  lm::progress::noteWorld(t.x, t.y, t.z, lm::EpFailed, lm::ErrMismatch);
  report(E, "FAILED", expS, c.match == st::Match::WrongBlock ? nameOf(A, wb) : std::string("nothing"), "none",
         st::matchName(c.match));
}

// Delayed second check (~400 ms): neighbour updates, server corrections in multiplayer.
void processRechecks() {
  const int64_t now = nowMs();
  const uint64_t g = gGen.load();
  const StructuraApiV1 *A = nullptr;
  for (int n = 0, i = 0; i < kRechecks && n < 4; ++i) {
    Recheck r;
    {
      std::lock_guard<std::mutex> lk(gReMu);
      if (!gRe[i].used || gRe[i].at > now) continue;
      r = gRe[i];
      gRe[i].used = false;
    }
    if (r.gen != g) continue;
    ++n;
    if (!A && !(A = api())) return;
    lm::holo::Expect E;
    if (!lm::holo::expectAt(r.p.x, r.p.y, r.p.z, E)) continue;
    const uintptr_t wb = A->worldBlock(r.p.x, r.p.y, r.p.z);
    if (!wb) continue;  // chunk unloaded meanwhile
    const auto c = lm::holo::compareWorld(E, wb);
    if (c.match == st::Match::Exact || c.match == st::Match::Equivalent) continue;
    gStats.exact.fetch_sub(1, std::memory_order_relaxed);
    lm::progress::verifiedWorld(r.p.x, r.p.y, r.p.z,
                                c.match == st::Match::StateMismatch ? lm::CmpWrongState
                                : c.match == st::Match::WrongBlock  ? lm::CmpWrong
                                                                    : lm::CmpMissing);
    if (c.match == st::Match::StateMismatch) {
      gStats.mismatch.fetch_add(1, std::memory_order_relaxed);
      report(E, "PARTIAL", lm::holo::describeWorld(E, E.block, true),
             lm::holo::describeWorld(E, wb) + " [" + diffText(c) + "]", "none", "changed after placement");
    } else {
      gStats.failed.fetch_add(1, std::memory_order_relaxed);
      report(E, "FAILED", lm::holo::describeWorld(E, E.block, true),
             c.match == st::Match::Missing ? std::string("removed (server/neighbour)") : nameOf(A, wb), "none",
             "changed after placement");
    }
  }
}

uint8_t faceToward(const Vec3 &eye, const BlockPos &p, Vec3 &click) {
  const float dx = eye.x - (p.x + 0.5f), dy = eye.y - (p.y + 0.5f), dz = eye.z - (p.z + 0.5f);
  const float ax = std::fabs(dx), ay = std::fabs(dy), az = std::fabs(dz);
  click = {0.5f, 0.5f, 0.5f};
  if (ay >= ax && ay >= az) {
    click.y = dy > 0 ? 1.f : 0.f;
    return dy > 0 ? 1 : 0;
  }
  if (ax >= az) {
    click.x = dx > 0 ? 1.f : 0.f;
    return dx > 0 ? 5 : 4;
  }
  click.z = dz > 0 ? 1.f : 0.f;
  return dz > 0 ? 3 : 2;
}

// Corrects a tap-changeable state (open, repeater delay, comparator mode) with an EMPTY hand,
// at most kMaxFixTaps taps, re-verified before each tap. Never breaks blocks.
void runFix(void *gm, void *player) {
  std::unique_lock<std::mutex> lk(gFixMu, std::try_to_lock);
  if (!lk.owns_lock() || !gFix.active) return;
  const int64_t now = nowMs();
  if (gFix.gen != gGen.load()) {
    gFix = Fix{};
    return;
  }
  if (now < gFix.nextAt) return;
  gEpActiveAt.store(now);
  const StructuraApiV1 *A = api();
  lm::holo::Expect E;
  if (!A || !lm::holo::expectAt(gFix.pos.x, gFix.pos.y, gFix.pos.z, E)) {
    gFix = Fix{};
    return;
  }
  const uintptr_t wb = A->worldBlock(gFix.pos.x, gFix.pos.y, gFix.pos.z);
  const auto c = lm::holo::compareWorld(E, wb);
  const std::string expS = lm::holo::describeWorld(E, E.block, true);
  auto finish = [&](const char *status, const std::string &result) {
    report(E, status, expS, lm::holo::describeWorld(E, wb), gFix.first + ", " + std::to_string(gFix.taps) + " tap(s)",
           result);
    gFix = Fix{};
  };
  if (c.match == st::Match::Exact || c.match == st::Match::Equivalent) {
    gStats.corrected.fetch_add(1, std::memory_order_relaxed);
    finish("OK", "corrected");
    return;
  }
  if (!fixable(E, c) || gFix.taps >= kMaxFixTaps || now - gFix.t0 > 6000) {
    gStats.mismatch.fetch_add(1, std::memory_order_relaxed);
    finish("PARTIAL", c.match == st::Match::StateMismatch ? "correction stopped: " + diffText(c)
                                                          : std::string("block changed: ") + st::matchName(c.match));
    toastOnce("msg.ep_state_mismatch", pretty(E.name));
    return;
  }
  const void *stack = sHandItem ? sHandItem(player, 0) : nullptr;
  if (stack && !stackEmpty(stack)) {
    Hotbar H;
    if (!hotbarOf(player, H)) {
      gStats.mismatch.fetch_add(1, std::memory_order_relaxed);
      finish("PARTIAL", "no hotbar access for a safe tap");
      return;
    }
    int empty = -1;
    for (int i = 0; i < kHotbarSize && empty < 0; ++i)
      if (stackEmpty(H.item(i))) empty = i;
    if (empty < 0 || !sSelectSlot(H.inv, empty, 0)) {
      gStats.mismatch.fetch_add(1, std::memory_order_relaxed);
      finish("PARTIAL", "no empty hotbar slot: a tap with an item could place it");
      toastOnce("msg.ep_state_mismatch", pretty(E.name));
      return;
    }
    noteSlotSwitch(H.sel, empty);
    gSwitchAt.store(now);
    gFix.nextAt = now + kSwitchSettleMs;
    return;
  }
  Vec3 eye{};
  const uintptr_t sv = rdp(reinterpret_cast<uintptr_t>(player) + kActor_State);
  if (!sv || !rd(sv, eye) || !std::isfinite(eye.x)) {
    finish("PARTIAL", "no player position");
    return;
  }
  Vec3 click{};
  const uint8_t face = faceToward(eye, gFix.pos, click);
  // fence gates turn toward the player when opened: face the gate's own direction for the tap
  float orig[2] = {0, 0};
  bool turned = false;
  if (E.name.size() >= 10 && std::string_view(E.name).substr(E.name.size() - 10) == "fence_gate") {
    int card = -1;
    for (const auto &stv : E.states) {
      if (stv.key == "direction" && stv.type != lm::nbt::String) card = (stv.i & 3) == 0 ? 2 : (stv.i & 3) == 1 ? 3 : (stv.i & 3) == 2 ? 0 : 1;
      if (stv.key == "minecraft:cardinal_direction" && stv.type == lm::nbt::String)
        card = stv.s == "north" ? 0 : stv.s == "east" ? 1 : stv.s == "south" ? 2 : stv.s == "west" ? 3 : -1;
    }
    static const float kYaw[4] = {180.f, -90.f, 0.f, 90.f};  // north east south west
    const uintptr_t rp = rdp(reinterpret_cast<uintptr_t>(player) + kActor_Rotation);
    if (card >= 0 && rp && rd(rp, orig)) {
      setRot(player, orig[0], kYaw[card]);
      turned = true;
    }
  }
  const int r = placeNow(gm, gFix.pos, face, click, 0, false, gFix.gen, gFix.pos, true);
  if (turned) setRot(player, orig[0], orig[1]);
  ++gFix.taps;
  gFix.nextAt = now + kFixGapMs;
  logf("correction tap %d at %d %d %d face %d -> %d", gFix.taps, gFix.pos.x, gFix.pos.y, gFix.pos.z, face, r);
  if (r < 0) finish("PARTIAL", "correction tap refused by validation");
}

void maybeRestoreSlot(void *player, bool force) {
  const int orig = gOrigSlot.load();
  if (orig < 0) return;
  if (!force) {
    if (nowMs() - gEpActiveAt.load() < 700) return;
    {
      std::lock_guard<std::mutex> lk(gFixMu);
      if (gFix.active) return;
    }
  }
  Hotbar H;
  if (player && hotbarOf(player, H) && H.sel == gEpSlot.load() && H.sel != orig && sSelectSlot) {
    const bool ok = sSelectSlot(H.inv, orig, 0);
    logf("switch: restored slot %d -> %d %s", H.sel, orig, ok ? "ok" : "refused");
  }
  gOrigSlot.store(-1);
  gEpSlot.store(-1);
}

// one structure position next to T that is missing and can be placed now (support first)
// A block that already failed twice in this structure generation is not used as a support again. Without this,
// two blocks that each need the other as support (e.g. upside-down stairs stacked on each other) retried forever.
bool failedTwice(const BlockPos &t) {
  const uint64_t g = gGen.load();
  for (const FailRec &f : gFails)
    if (f.x == t.x && f.y == t.y && f.z == t.z && f.gen == g && f.attempts >= 2) return true;
  return false;
}

bool supportTarget(const StructuraApiV1 *A, const World &W, const Target &T, Target &out) {
  static const int order[6] = {0, 2, 3, 4, 5, 1};  // below first, then sides, above last
  for (int k = 0; k < 6; ++k) {
    const int f = order[k];
    const int x = T.t.x + kNdx[f], y = T.t.y + kNdy[f], z = T.t.z + kNdz[f];
    uintptr_t exp = 0;
    if (!missingAt(A, W, x, y, z, exp) || !W.solidNeighbor(x, y, z)) continue;
    if (failedTwice(BlockPos{x, y, z})) continue;
    const std::string n = nameOf(A, exp);
    if (n.empty() || replaceableName(n)) continue;
    out = Target{};
    out.t = {x, y, z};
    out.expected = exp;
    return true;
  }
  return false;
}


using PickRangeFn = float (*)(void *gm, const int *inputMode, bool);
float reachOf(void *gm) {
  uintptr_t vt = 0, fn = 0;
  if (gm && rd(reinterpret_cast<uintptr_t>(gm), vt) && plausiblePtr(vt) && rd(untag(vt) + 11 * 8, fn) && fn) {
    const int touch = 2;
    const float r = reinterpret_cast<PickRangeFn>(fn)(gm, &touch, false);
    if (std::isfinite(r) && r >= 3.f && r <= 12.5f) return r;
  }
  return 5.6f;
}




int placeTarget(const StructuraApiV1 *A, const World &W, void *gm, void *player, uint8_t hand, bool flag, Target T,
                bool &ret, const char *how, bool quiet = false, int depth = 0) {
  const uint64_t gen = gGen.load();
  const st::Mode mode = epMode();
  gEpActiveAt.store(nowMs());
  if (T.fixState) {  // Correct mode: an existing block with a tap-fixable state
    lm::holo::Expect E;
    if (!lm::holo::expectAt(T.t.x, T.t.y, T.t.z, E)) return 0;
    const auto c = lm::holo::compareWorld(E, A->worldBlock(T.t.x, T.t.y, T.t.z));
    if (!fixable(E, c)) return 0;
    if (startFix(T.t, c.diffs[0].key + " " + std::to_string(c.diffs[0].actual) + " -> " +
                          std::to_string(c.diffs[0].expected)))
      logf("%s: correcting %s at %d %d %d", how, E.name.c_str(), T.t.x, T.t.y, T.t.z);
    return 1;
  }
  const BlockPos asked = T.t;
  if (A->placeTarget(&T.t.x, &T.t.y, &T.t.z)) {
    uintptr_t exp = 0, wb = 0;
    if (!A->expectedAt(T.t.x, T.t.y, T.t.z, &exp)) return 0;
    if (W.replaceable(T.t.x, T.t.y, T.t.z, &wb) != 1) {
      // second part (door top, bed head) asked but the base already stands: the game creates the second
      // part with the base, Easy Place never places it on its own -> report, move on (no retry loop)
      noteFail(asked, "second part missing");
      lm::progress::noteWorld(asked.x, asked.y, asked.z, lm::EpFailed, lm::ErrCompanion);
      if (!quiet) lm::notify("msg.ep_already_placed", lm::Tone::Info, 2000);
      return 1;
    }
    T.expected = exp;
    T.mergeSlab = false;
  }
  const void *stack = sHandItem ? sHandItem(player, hand) : nullptr;
  const uintptr_t heldBT = blockTypeOfStack(stack);
  const bool emptyHand = hand == 0 && stackEmpty(stack);
  if (!heldBT && !emptyHand) {
    if (!quiet) logf("%s: target %d %d %d, item is not a block -> vanilla", how, T.t.x, T.t.y, T.t.z);
    return 0;
  }
  uintptr_t expBT = 0;
  if (!T.expected || !rd(T.expected + kBlock_Type, expBT) || !plausiblePtr(expBT)) {
    if (!quiet) logf("%s: target %d %d %d, hologram block unresolved -> vanilla", how, T.t.x, T.t.y, T.t.z);
    return 0;  
  }
  // shared pipeline: the same transformed states and Block* the hologram shows
  lm::holo::Expect E;
  if (!lm::holo::expectAt(T.t.x, T.t.y, T.t.z, E) || !E.block) {
    if (!quiet) logf("%s: target %d %d %d, expected state unresolved -> vanilla", how, T.t.x, T.t.y, T.t.z);
    return 0;
  }
  T.expected = E.block;
  if (st::isSecondaryPart(E.states, E.name)) {
    // door top / bed head / tall plant top whose base is not targetable (outside the visible layers or the
    // structure): the game creates this part together with its base, so it is never placed on its own
    gStats.skipped.fetch_add(1, std::memory_order_relaxed);
    noteFail(asked, "second part: place its base");
    lm::progress::noteWorld(asked.x, asked.y, asked.z, lm::EpSkipped, lm::ErrCompanion);
    if (!quiet) report(E, "SKIPPED", st::describe(E.states, E.name), "-", "none", "second part: place its base");
    return 1;
  }
  const bool safeOnly = lm::settings().epSafeOnly.load(std::memory_order_relaxed);
  if (!E.unsupported.empty() && (st::correctsOwn(mode) || safeOnly)) {
    gStats.unsupported.fetch_add(1, std::memory_order_relaxed);
    noteFail(T.t, "unsupported state");
    lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpUnsupported, lm::ErrUnsupported);
    report(E, "SKIPPED", st::describe(E.original, E.name), "-", "none", "unsupported: " + E.unsupported);
    toastOnce("msg.ep_unsupported", pretty(E.name));
    return 1;
  }
  if (E.companion && !T.mergeSlab) {  // multi-block: the second part needs its cell
    uintptr_t cb = 0;
    const int cr = W.replaceable(E.cx, E.cy, E.cz, &cb);
    lm::holo::Expect C;
    const char *why = nullptr;
    if (cr < 0) why = "second part position not loaded";
    else if (cr == 0) why = "no room for the second part";
    else if (lm::holo::expectAt(E.cx, E.cy, E.cz, C) && !st::sameBlockType(C.name, E.name))
      why = "structure has another block where the second part goes";
    if (why) {
      gStats.skipped.fetch_add(1, std::memory_order_relaxed);
      noteFail(T.t, why);
      lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpSkipped, lm::ErrCompanion);
      report(E, "SKIPPED", st::describe(E.states, E.name), "-", "none", why);
      if (!quiet) lm::notify("msg.ep_cant_place", lm::Tone::Warning, 2000);
      return 1;
    }
  }
  const std::string en = nameOf(A, T.expected);
  const std::string half = stripDouble(en);
  const bool slabToDouble = heldBT && heldBT != expBT && itemServes(A, heldBT, expBT, half);
  if (!itemServes(A, heldBT, expBT, half, en)) {
    
    if (trySwitch(A, player, expBT, half, en) == 1) return 1;  
    if (emptyHand) return 0;  
    char nm[96];
    std::string want = A->expectedName(T.t.x, T.t.y, T.t.z, nm, sizeof(nm)) ? std::string(nm) : pretty(en);
    if (want.empty()) want = "block";
    if (!quiet)
      logf("%s: target %d %d %d wants %s, hand has %s -> blocked", how, T.t.x, T.t.y, T.t.z, en.c_str(),
           nameOf(A, rdp(heldBT + kBT_Default)).c_str());
    lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpSkipped, lm::ErrNoItem);
    gOp.store(5, std::memory_order_relaxed);
    if (gRunScope.load(std::memory_order_relaxed) != 0) {
      noteFail(T.t, "no item");  // a run moves on to the next block instead of waiting here
      toastOnce("msg.ep_need", want);
    } else {
      lm::notify("msg.ep_need", lm::Tone::Warning, 2000, want);  
    }
    return 1;
  }
  if (nowMs() - gSwitchAt.load() < kSwitchSettleMs) return 1;  
  
  const uintptr_t before = A->worldBlock(T.t.x, T.t.y, T.t.z);
  auto changed = [&] {
    const uintptr_t now = A->worldBlock(T.t.x, T.t.y, T.t.z);
    return now && now != before;
  };
  auto placed = [&](int r, bool ok) {
    if (r < 0) {  
      noteFail(T.t, "validation");
      lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpNone, lm::ErrValidation);
      trace("queue updated: cancelled");
      return 0;   
    }
    if (ok) {
      noteOk(T.t);
      verifyPlaced(T.t, how);
    } else {
      noteFail(T.t, "game refused");
      lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpFailed, lm::ErrRefused);
    }
    trace("queue updated: placed=%d", int(ok));
    trace("easyplace end");
    return ok ? 2 : 3;
  };
  trace("easyplace begin src=%s target %d %d %d gen=%llu", how, T.t.x, T.t.y, T.t.z, static_cast<unsigned long long>(gen));

  if (T.mergeSlab) {
    trace("target validated");
    lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpPlacing, lm::ErrNone, true);
    const int r = placeNow(gm, T.t, T.topSlab ? 0 : 1, Vec3{0.5f, 0.5f, 0.5f}, hand, flag, gen, T.t);
    ret = r > 0;
    const bool ok = r >= 0 && changed();
    logf("%s: double slab at %d %d %d -> game=%d changed=%d", how, T.t.x, T.t.y, T.t.z, r, int(ok));
    return placed(r, ok);
  }

  const Plan P = choosePlan(A, W, player, slabToDouble ? 0 : heldBT, T, E);
  if (!P.ok) {
    trace("easyplace end: no plan");
    return 0;
  }
  // Safe-only: just plans whose simulated result is the exact expected state (score 3).
  if (!st::acceptPlan(mode, P.score, E.directional) || (safeOnly && P.score < 3)) {
    // no click/rotation gives the exact state: maybe a support block is still missing
    Target S;
    if (depth == 0 && supportTarget(A, W, T, S)) {
      logf("%s: %s at %d %d %d needs support first -> %d %d %d", how, E.name.c_str(), T.t.x, T.t.y, T.t.z, S.t.x,
           S.t.y, S.t.z);
      if (!quiet) toastOnce("msg.ep_needs_support", pretty(E.name), lm::Tone::Info);
      return placeTarget(A, W, gm, player, hand, flag, S, ret, how, quiet, 1);
    }
    gStats.skipped.fetch_add(1, std::memory_order_relaxed);
    noteFail(T.t, "no exact placement");
    lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpSkipped, lm::ErrNoExactPlan);
    report(E, "SKIPPED", lm::holo::describeWorld(E, E.block, true), "-", "none",
           "no face/hit/rotation from here gives this state (" + std::to_string(P.sims) + " simulated)");
    toastOnce("msg.ep_no_exact", pretty(E.name));
    return 1;
  }
  trace("target validated");
  const bool ticking = nowMs() - gTickAt.load() < 500;
  logf("%s: target %d %d %d (%s) via %d %d %d face %d click %.2f %.2f %.2f score %d/%d sims turn %d (%.0f %.0f) "
       "tick %d mode %s", how, T.t.x, T.t.y, T.t.z, en.c_str(), P.n.x, P.n.y, P.n.z, P.face, P.click.x, P.click.y,
       P.click.z, P.score, P.sims, int(P.rotate), P.pitch, P.yaw, int(ticking), st::modeName(mode));

  if (P.rotate && ticking) {
    float orig[2] = {0, 0};
    const uintptr_t rp = rdp(reinterpret_cast<uintptr_t>(player) + kActor_Rotation);
    if (rp && rd(rp, orig)) {
      std::lock_guard<std::mutex> lk(gPendMu);
      if (gPend.active) {  
        trace("easyplace end: queue full");
        return 1;
      }
      gPend = Pending{};
      gPend.active = true;
      gPend.gen = gen;
      gPend.n = P.n;
      gPend.face = P.face;
      gPend.click = P.click;
      gPend.hand = hand;
      gPend.flag = flag;
      gPend.pitch = P.pitch;
      gPend.yaw = P.yaw;
      gPend.origPitch = orig[0];
      gPend.origYaw = orig[1];
      gPend.t0 = nowMs();
      gPend.target = T.t;
      gPend.ticks = 0;
      gPend.lastTickAt = 0;
      setRot(player, P.pitch, P.yaw);
      lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpPlacing, lm::ErrNone, true);
      trace("queue updated: turn queued (%d/%d)", 1, kMaxQueue);
      trace("easyplace end");
      return 1;
    }
  }
  if (P.rotate) {
    // The plan needs another facing but no game tick is running (or the rotation is unreadable). A same-frame
    // turn is never sent to the server (no auth-input packet in between), so the server would place the block
    // with the player's real facing: skip instead of placing it wrong.
    gStats.skipped.fetch_add(1, std::memory_order_relaxed);
    noteFail(T.t, "rotation needs the game tick");
    lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpSkipped, lm::ErrNoExactPlan);
    report(E, "SKIPPED", lm::holo::describeWorld(E, E.block, true), "-", "none",
           "needs a turn; game tick not available");
    trace("easyplace end: turn needs tick");
    return 1;
  }
  lm::progress::noteWorld(T.t.x, T.t.y, T.t.z, lm::EpPlacing, lm::ErrNone, true);
  gOp.store(2, std::memory_order_relaxed);
  const int r = placeNow(gm, P.n, P.face, P.click, hand, flag, gen, T.t);
  ret = r > 0;
  const bool ok = r >= 0 && changed();
  logf("%s: game=%d changed=%d", how, r, int(ok));
  return placed(r, ok);
}

bool pendingBusy() {
  std::lock_guard<std::mutex> lk(gPendMu);
  return gPend.active && nowMs() - gPend.t0 < 400;  
}


int easyPlace(void *gm, const BlockPos *pos, uint8_t face, uint8_t hand, bool flag, bool &ret) {
  const StructuraApiV1 *A = api();
  if (!A) return 0;
  if (pendingBusy()) return 1;
  void *player = reinterpret_cast<void *>(rdp(reinterpret_cast<uintptr_t>(gm) + kGM_Player));
  const uintptr_t hr = hitResultOf(gm);
  if (!player || !hr) {
    logf("tap: no player/hit (player=%p hr=%p)", player, reinterpret_cast<void *>(hr));
    return 0;
  }
  Vec3 s{}, e{};
  int type = -1;
  if (!rd(hr + kHR_Start, s) || !rd(hr + kHR_Hit, e) || !rd(hr + kHR_Type, type) || type != 0) {
    logf("tap: hit type %d -> vanilla", type);
    return 0;
  }
  Vec3 eye{};
  const uintptr_t sv = rdp(reinterpret_cast<uintptr_t>(player) + kActor_State);
  const bool haveEye = sv && rd(sv, eye) && std::isfinite(eye.x) && std::isfinite(eye.y) && std::isfinite(eye.z);
  if (haveEye) {
    const float d2 = (s.x - eye.x) * (s.x - eye.x) + (s.y - eye.y) * (s.y - eye.y) + (s.z - eye.z) * (s.z - eye.z);
    if (!(d2 < 16.f * 16.f)) s = eye;
  }
  World W(A);
  Target T;
  gFindReach = reachOf(gm);
  if (!findTarget(A, W, s, e, *pos, haveEye ? &eye : nullptr, T)) {
    logf("tap: block %d %d %d face %d hand %d | ray (%.1f %.1f %.1f)->(%.1f %.1f %.1f) no target -> vanilla", pos->x,
         pos->y, pos->z, face, hand, s.x, s.y, s.z, e.x, e.y, e.z);
    return 0;
  }
  return placeTarget(A, W, gm, player, hand, flag, T, ret, "tap");
}


bool viewDir(void *player, Vec3 &d) {
  float r[2] = {0, 0};
  const uintptr_t rp = rdp(reinterpret_cast<uintptr_t>(player) + kActor_Rotation);
  if (!rp || !rd(rp, r) || !std::isfinite(r[0]) || !std::isfinite(r[1])) return false;
  const float p = r[0] * 0.017453292f, y = r[1] * 0.017453292f;
  d = {-std::sin(y) * std::cos(p), -std::sin(p), std::cos(y) * std::cos(p)};
  return true;
}

bool unitDir(Vec3 &d) {
  const float len = std::sqrt(d.x * d.x + d.y * d.y + d.z * d.z);
  if (!std::isfinite(len) || len < 1e-4f) return false;
  d = {d.x / len, d.y / len, d.z / len};
  return true;
}



std::atomic<int64_t> gLastAirAt{0};
int easyPlaceAir(void *gm, bool &ret) {
  const StructuraApiV1 *A = api();
  if (!A) return 0;
  if (pendingBusy()) return 1;
  if (nowMs() - gLastAirAt.load() < 150) return 1;  
  void *player = reinterpret_cast<void *>(rdp(reinterpret_cast<uintptr_t>(gm) + kGM_Player));
  const uintptr_t hr = hitResultOf(gm);
  if (!player || !hr) return 0;
  int type = -1;
  Vec3 s{}, d{};
  if (!rd(hr + kHR_Type, type) || type == 0 || type == 1) return 0;  
  if (!rd(hr + kHR_Start, s) || !rd(hr + kHR_Dir, d)) return 0;
  Vec3 eye{};
  const uintptr_t sv = rdp(reinterpret_cast<uintptr_t>(player) + kActor_State);
  const bool haveEye = sv && rd(sv, eye) && std::isfinite(eye.x) && std::isfinite(eye.y) && std::isfinite(eye.z);
  bool okStart = std::isfinite(s.x) && std::isfinite(s.y) && std::isfinite(s.z);
  if (haveEye && okStart) {
    const float d2 = (s.x - eye.x) * (s.x - eye.x) + (s.y - eye.y) * (s.y - eye.y) + (s.z - eye.z) * (s.z - eye.z);
    if (!(d2 < 16.f * 16.f)) okStart = false;
  }
  if (!okStart) {
    if (!haveEye) return 0;
    s = eye;
  }
  float len = std::sqrt(d.x * d.x + d.y * d.y + d.z * d.z);
  if (!std::isfinite(len) || len < 1e-4f) {  
    float r[2] = {0, 0};
    const uintptr_t rp = rdp(reinterpret_cast<uintptr_t>(player) + kActor_Rotation);
    if (!rp || !rd(rp, r) || !std::isfinite(r[0]) || !std::isfinite(r[1])) return 0;
    const float p = r[0] * 0.017453292f, y = r[1] * 0.017453292f;
    d = {-std::sin(y) * std::cos(p), -std::sin(p), std::cos(y) * std::cos(p)};
    len = 1.f;
  }
  const float reach = reachOf(gm);
  gFindReach = reach;
  const Vec3 e{s.x + d.x / len * reach, s.y + d.y / len * reach, s.z + d.z / len * reach};
  World W(A);
  Target T;
  const BlockPos none{INT32_MIN, INT32_MIN, INT32_MIN};
  bool found = findTarget(A, W, s, e, none, haveEye ? &eye : nullptr, T);
  Vec3 vd{};
  if (!found && haveEye && viewDir(player, vd)) {  
    const Vec3 e2{eye.x + vd.x * reach, eye.y + vd.y * reach, eye.z + vd.z * reach};
    found = findTarget(A, W, eye, e2, none, &eye, T);
  }
  if (!found) return 0;  
  
  const uint32_t zero = 0;
  std::memcpy(reinterpret_cast<uint8_t *>(gm) + kGM_BuildState, &zero, sizeof(zero));
  const int r = placeTarget(A, W, gm, player, 0, false, T, ret, "air");
  
  std::memcpy(reinterpret_cast<uint8_t *>(gm) + kGM_BuildState, &zero, sizeof(zero));
  if (r == 2) gLastAirAt.store(nowMs());
  return r;
}

bool useItemDetour(void *gm, void *stack, uint32_t flag) {
  
  if (easyPlaceInProgress() || !onGameThread()) return oUseItem(gm, stack, flag);
  gGameBuildAt.store(nowMs(), std::memory_order_relaxed);
  if (!state().enabled.load(std::memory_order_relaxed) || !gm || !gPlacementValidated.load(std::memory_order_acquire))
    return oUseItem(gm, stack, flag);
  InProgressScope scope;
  refreshGeneration(lm::status().player.load(std::memory_order_relaxed));
  bool ret = false;
  const int r = easyPlaceAir(gm, ret);
  if (r == 1) return false;
  if (r == 2) return true;
  if (r == 3) lm::notify("msg.ep_cant_place", lm::Tone::Warning, 2000);
  return oUseItem(gm, stack, flag);
}




constexpr uintptr_t kBuildBlockStatic = 0xf8a117c, kBaseUseItemStatic = 0xf8a2eb0, kPickRangeStatic = 0xf8a34fc;
constexpr uintptr_t kStairBlockVt = 0x13143568, kStairPlacementStatic = 0x1077cfe0;
constexpr uintptr_t kSurvBuildStatic = 0xf8a4220, kSurvUseStatic = 0xf8a4244;  
constexpr int kAutoEveryMs = 50;  

struct NoTarget {
  Vec3 s{}, d{};
  uintptr_t held = 0;
  int64_t at = 0;
  bool valid = false;
} gNoTarget;
int64_t gLastAuto = 0;




bool isGameModeOf(uintptr_t p, uintptr_t pl) {
  uintptr_t vt = 0;
  if (!gBase || !p || !pl || !rd(p, vt)) return false;
  vt = untag(vt);
  if (vt != gBase + kGameModeVt && vt != gBase + kSurvivalModeVt) return false;
  return untag(rdp(p + kGM_Player)) == untag(pl);
}
uintptr_t gGmOff = 0;  
int64_t gGmScanAt = 0;

void *gameModeOf(void *player) {
  const uintptr_t pl = reinterpret_cast<uintptr_t>(player);
  if (!gBase || !pl) return nullptr;
  if (gGmOff) {
    const uintptr_t p = rdp(pl + gGmOff);
    if (isGameModeOf(p, pl)) return reinterpret_cast<void *>(p);
  }
  const int64_t now = nowMs();
  if (now - gGmScanAt < 2000) return nullptr;
  gGmScanAt = now;
  for (uintptr_t off = 0; off < 0x3000; off += 8) {
    const uintptr_t p = rdp(pl + off);
    if (!isGameModeOf(p, pl)) continue;
    if (off != gGmOff) logf("auto: player GameMode at +%#lx", static_cast<unsigned long>(off));
    gGmOff = off;
    return reinterpret_cast<void *>(p);
  }
  logf("auto: player GameMode not found");
  return nullptr;
}

void resetCaches() {
  gNoTarget.valid = false;
  gPick = PickWait{};
}

// Run target: the missing block of the run scope (1 = selected layer, 2 = every visible layer) nearest to the
// eye within reach; with bottom-up, the lowest world Y that has one wins. The scan is clipped to the
// structure box, so it is bounded by the reach cube (<= 13^3 cells) and runs at most epRate times a second.
bool runTarget(const StructuraApiV1 *A, const World &W, const Vec3 &eye, float reach, Target &T) {
  int b[6];
  int axis = 1, only = INT_MIN;
  {
    auto &m = lm::model();
    std::lock_guard<std::mutex> lk(m.mu);
    if (!m.structure || !m.placed) return false;
    const lm::Structure &S = *m.structure;
    const lm::Placement &P = m.placement;
    int dx, dz;
    lm::rotatedSize(S, P.rot, dx, dz);
    b[0] = P.ox; b[1] = P.ox + dx - 1; b[2] = P.oy; b[3] = P.oy + S.sy - 1; b[4] = P.oz; b[5] = P.oz + dz - 1;
    if (gRunScope.load(std::memory_order_relaxed) == 1) {
      axis = std::clamp(lm::settings().layerAxis.load(std::memory_order_relaxed), 0, 2);
      const int n = lm::progress::layerCount(S, P, axis);
      if (n <= 0) return false;
      only = lm::progress::layerWorld(S, P, axis, std::clamp(m.layer, 0, n - 1));
    }
  }
  if (only != INT_MIN) b[axis * 2] = b[axis * 2 + 1] = only;
  const int r = int(std::ceil(reach));
  const int ex = int(std::floor(eye.x)), ey = int(std::floor(eye.y)), ez = int(std::floor(eye.z));
  const int x0 = std::max(b[0], ex - r), x1 = std::min(b[1], ex + r);
  const int y0 = std::max(b[2], ey - r), y1 = std::min(b[3], ey + r);
  const int z0 = std::max(b[4], ez - r), z1 = std::min(b[5], ez + r);
  if (x0 > x1 || y0 > y1 || z0 > z1) return false;
  const bool bottomUp = lm::settings().epBottomUp.load(std::memory_order_relaxed);
  const float lim = (reach - 0.5f) * (reach - 0.5f);
  float best = 1e30f;
  bool found = false;
  for (int y = y0; y <= y1; ++y) {
    for (int x = x0; x <= x1; ++x)
      for (int z = z0; z <= z1; ++z) {
        const float ddx = x + 0.5f - eye.x, ddy = y + 0.5f - eye.y, ddz = z + 0.5f - eye.z;
        const float d2 = ddx * ddx + ddy * ddy + ddz * ddz;
        if (d2 > lim || d2 >= best) continue;
        uintptr_t exp = 0;
        if (!A->expectedAt(x, y, z, &exp) || !exp) continue;  // air / outside the visible layers
        if (W.replaceable(x, y, z) != 1) continue;           // occupied (never replaced) or not loaded
        const BlockPos p{x, y, z};
        if (discarded(p)) continue;
        best = d2;
        T = Target{};
        T.t = p;
        T.expected = exp;
        found = true;
      }
    if (found && bottomUp) break;
  }
  return found;
}

void autoTick() {
  const int runScope = gRunScope.load(std::memory_order_relaxed);
  if (easyPlaceInProgress() || (!state().enabled.load(std::memory_order_relaxed) && runScope == 0) ||
      gPaused.load(std::memory_order_relaxed))
    return;
  const int64_t now = nowMs();
  // blocks per second (epRate, default 20 = the previous fixed 50 ms step)
  const int gap = std::max(kAutoEveryMs, 1000 / std::clamp(lm::settings().epRate.load(std::memory_order_relaxed), 1, 20));
  if (now - gLastAuto < gap) return;
  const StructuraApiV1 *A = api();
  if (!A) return;
  
  void *player = reinterpret_cast<void *>(lm::status().player.load(std::memory_order_relaxed));
  if (!player || !plausiblePtr(reinterpret_cast<uintptr_t>(player))) return;
  InProgressScope scope;
  const auto t0 = std::chrono::steady_clock::now();
  void *gm = gameModeOf(player);
  if (!gm) return;
  uint32_t build = 0;
  if (!rd(reinterpret_cast<uintptr_t>(gm) + kGM_BuildState, build)) return;
  if (build != 0) {
    
    
    if (now - gGameBuildAt.load(std::memory_order_relaxed) < 450) return;
    const uint32_t zero = 0;
    std::memcpy(reinterpret_cast<uint8_t *>(gm) + kGM_BuildState, &zero, sizeof(zero));
  }
  if (pendingBusy()) return;
  
  const void *stack = sHandItem ? sHandItem(player, 0) : nullptr;
  const uintptr_t heldBT = blockTypeOfStack(stack);
  if (!heldBT && !(sSelectSlot && stackEmpty(stack))) return;
  if (now - gSwitchAt.load() < kSwitchSettleMs) return;  
  if (runScope != 0) {  // deliberate run: missing blocks of the layer / visible layers within reach
    Vec3 eye{};
    const uintptr_t sv = rdp(reinterpret_cast<uintptr_t>(player) + kActor_State);
    if (!sv || !rd(sv, eye) || !std::isfinite(eye.x) || !std::isfinite(eye.y) || !std::isfinite(eye.z)) return;
    gLastAuto = now;
    World W(A);
    const float reach = reachOf(gm);
    const int batch = std::clamp(lm::settings().epBatch.load(std::memory_order_relaxed), 1, 4);
    for (int b = 0; b < batch; ++b) {
      Target T;
      if (!runTarget(A, W, eye, reach, T)) {
        if (b == 0) gOp.store(7, std::memory_order_relaxed);  // nothing missing within reach
        break;
      }
      bool ret = false;
      const int r = placeTarget(A, W, gm, player, 0, false, T, ret, "run", true);
      if (r != 2) break;  // turn queued, skipped, item missing: continue next step
      if (std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() > kFrameBudgetMs)
        break;
    }
    void *gm2 = gameModeOf(player);
    if (gm2) {
      const uint32_t zero = 0;
      std::memcpy(reinterpret_cast<uint8_t *>(gm2) + kGM_BuildState, &zero, sizeof(zero));
    }
    return;
  }
  const uintptr_t hr = hitResultOf(gm);
  if (!hr) return;
  int type = -1;
  Vec3 s{}, e{}, d{};
  BlockPos hitBlock{INT32_MIN, INT32_MIN, INT32_MIN};
  if (!rd(hr + kHR_Type, type) || !rd(hr + kHR_Start, s)) return;
  if (type == 1) return;  
  Vec3 eye{};
  const uintptr_t sv = rdp(reinterpret_cast<uintptr_t>(player) + kActor_State);
  const bool haveEye = sv && rd(sv, eye) && std::isfinite(eye.x) && std::isfinite(eye.y) && std::isfinite(eye.z);
  if (!haveEye) return;
  if (!(std::isfinite(s.x) && std::isfinite(s.y) && std::isfinite(s.z)) ||
      (s.x - eye.x) * (s.x - eye.x) + (s.y - eye.y) * (s.y - eye.y) + (s.z - eye.z) * (s.z - eye.z) > 16.f * 16.f)
    s = eye;
  
  
  Vec3 vd{};
  bool tryView = false;
  const float reach = reachOf(gm);
  gFindReach = reach;
  if (type == 0) {
    if (!rd(hr + kHR_Hit, e) || !rd(hr + kHR_Pos, hitBlock)) return;
  } else {
    const bool haveView = viewDir(player, vd);
    if (!rd(hr + kHR_Dir, d) || !unitDir(d)) {
      if (!haveView) return;
      d = vd;
      s = eye;
    } else if (haveView && d.x * vd.x + d.y * vd.y + d.z * vd.z < 0.9995f) {
      tryView = true;
    }
    e = {s.x + d.x * reach, s.y + d.y * reach, s.z + d.z * reach};
  }
  
  const Vec3 du = [&] {
    const float dx = e.x - s.x, dy = e.y - s.y, dz = e.z - s.z;
    const float l = std::sqrt(dx * dx + dy * dy + dz * dz);
    return l > 1e-4f ? Vec3{dx / l, dy / l, dz / l} : Vec3{0, 0, 0};
  }();
  if (gNoTarget.valid && gNoTarget.held == heldBT && now - gNoTarget.at < 250 &&
      std::fabs(gNoTarget.s.x - s.x) < 0.02f && std::fabs(gNoTarget.s.y - s.y) < 0.02f &&
      std::fabs(gNoTarget.s.z - s.z) < 0.02f && std::fabs(gNoTarget.d.x - du.x) < 0.003f &&
      std::fabs(gNoTarget.d.y - du.y) < 0.003f && std::fabs(gNoTarget.d.z - du.z) < 0.003f)
    return;
  World W(A);
  Target T;
  bool found = findTarget(A, W, s, e, hitBlock, &eye, T);
  if (!found && tryView) {
    const Vec3 e2{eye.x + vd.x * reach, eye.y + vd.y * reach, eye.z + vd.z * reach};
    found = findTarget(A, W, eye, e2, hitBlock, &eye, T);
  }
  if (!found) {
    gNoTarget = NoTarget{s, du, heldBT, now, true};
    return;
  }
  gNoTarget.valid = false;
  if (discarded(T.t)) return;  
  gLastAuto = now;
  
  const double spent = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
  if (spent > kFrameBudgetMs) {
    gLastAuto = now + 100;  
    return;
  }
  bool ret = false;
  placeTarget(A, W, gm, player, 0, false, T, ret, "auto", true);
  
  
  void *gm2 = gameModeOf(player);
  if (gm2) {
    const uint32_t zero = 0;
    std::memcpy(reinterpret_cast<uint8_t *>(gm2) + kGM_BuildState, &zero, sizeof(zero));
  }
}

// With Easy Place on and "only visible layer" set, a tap that Easy Place leaves to the game would put the held
// block into the cell next to the clicked face (or into the clicked cell when it is replaceable, like grass).
// When that cell belongs to the structure but to a hidden layer, the tap is swallowed: Easy Place mode builds
// only on the layers that are shown. Interactions (doors, chests, buttons, ...) and non-block items still go to
// the game; cells outside the structure are untouched.
std::atomic<int64_t> gHiddenToastAt{0};
bool hiddenLayerTap(void *gm, const BlockPos &pos, uint8_t face, uint8_t hand) {
  if (!lm::settings().epLayerOnly.load(std::memory_order_relaxed) || face > 5) return false;
  if (lm::settings().layerMode.load(std::memory_order_relaxed) == int(lm::LayerMode::All)) return false;
  const StructuraApiV1 *A = api();
  void *player = reinterpret_cast<void *>(rdp(reinterpret_cast<uintptr_t>(gm) + kGM_Player));
  if (!A || !player || !sHandItem) return false;
  const void *stack = sHandItem(player, hand);
  if (!blockTypeOfStack(stack)) return false;  // not a block item: the game decides (buckets, food, tools...)
  const uintptr_t clicked = A->worldBlock(pos.x, pos.y, pos.z);
  if (opensOnTap(A, clicked)) return false;     // opening a door/chest is not building
  World W(A);
  const bool intoClicked = W.replaceable(pos.x, pos.y, pos.z) == 1;
  const BlockPos cell = intoClicked ? pos : BlockPos{pos.x + kNdx[face], pos.y + kNdy[face], pos.z + kNdz[face]};
  if (lm::holo::layerGate(cell.x, cell.y, cell.z) != 2) return false;
  logf("tap: vanilla placement into hidden layer at %d %d %d refused", cell.x, cell.y, cell.z);
  const int64_t now = nowMs();
  if (now - gHiddenToastAt.load(std::memory_order_relaxed) > 1500) {
    gHiddenToastAt.store(now, std::memory_order_relaxed);
    lm::notify("msg.ep_hidden_layer", lm::Tone::Info, 2000);
  }
  return true;
}

bool buildBlockDetour(void *gm, const BlockPos *pos, uint8_t face, uint8_t hand, bool flag) {
  
  if (easyPlaceInProgress() || !onGameThread()) return oBuildBlock(gm, pos, face, hand, flag);
  gGameBuildAt.store(nowMs(), std::memory_order_relaxed);
  if (!state().enabled.load(std::memory_order_relaxed) || gPaused.load(std::memory_order_relaxed) || !gm || !pos ||
      hand > 1 || !gPlacementValidated.load(std::memory_order_acquire))
    return oBuildBlock(gm, pos, face, hand, flag);
  const BlockPos orig = *pos;  
  InProgressScope scope;
  refreshGeneration(lm::status().player.load(std::memory_order_relaxed));
  bool ret = false;
  const int r = easyPlace(gm, pos, face, hand, flag, ret);
  if (r == 1) return false;
  if (r == 2) return ret;
  if (hiddenLayerTap(gm, orig, face, hand)) return false;  // no vanilla block into a hidden layer either
  if (r == 3) lm::notify("msg.ep_cant_place", lm::Tone::Warning, 2000);
  return oBuildBlock(gm, &orig, face, hand, flag);  
}

// Per-client-tick step: remembers the game thread and runs automatic placement. Driven by
// ClientInstance::update when it is hooked, otherwise by the local player's tick (contextTick /
// localPlayerTick) on the same client thread.
void clientStep(bool runAuto) {
  if (!state().installed.load(std::memory_order_acquire)) return;
  
  
  static std::atomic<pthread_t> sLastSelf{};
  const pthread_t self = pthread_self();
  if (sLastSelf.load(std::memory_order_relaxed) != self) {
    sLastSelf.store(self, std::memory_order_relaxed);
    const pid_t me = curTid();
    if (gGameTid.load(std::memory_order_relaxed) != me) {
      const pid_t old = gGameTid.exchange(me);
      if (old != 0) logf("game thread changed %d -> %d", int(old), int(me));
    }
  }
  ++gFrameNo;
  if (easyPlaceInProgress()) return;
  refreshGeneration(lm::status().player.load(std::memory_order_relaxed));  
  if (runAuto) autoTick();
  if (gOrigSlot.load(std::memory_order_relaxed) >= 0 && !easyPlaceInProgress()) {
    InProgressScope scope;
    const uintptr_t pl = lm::status().player.load(std::memory_order_relaxed);
    if (pl && plausiblePtr(pl)) maybeRestoreSlot(reinterpret_cast<void *>(pl), !state().enabled.load());
  }
}

}  


std::atomic_bool gHkTick{false}, gHkSurvTick{false}, gHkUseItem{false}, gHkBuild{false};
std::atomic_bool gBaseChecked{false};
constexpr const char *kNotValidated = "Easy Place disabled: placement function not validated for this game version";

const char *disabledReason() { return gDisabledReason.empty() ? nullptr : gDisabledReason.c_str(); }

Stats stats() {
  Stats r;
  r.placed = gStats.placed.load();
  r.exact = gStats.exact.load();
  r.mismatch = gStats.mismatch.load();
  r.corrected = gStats.corrected.load();
  r.failed = gStats.failed.load();
  r.unsupported = gStats.unsupported.load();
  r.skipped = gStats.skipped.load();
  return r;
}
std::vector<Record> recent() {
  std::lock_guard<std::mutex> lk(gRecMu);
  std::vector<Record> out;
  out.reserve(size_t(gRecCount));
  for (int k = 0; k < gRecCount; ++k) out.push_back(gRec[(gRecHead - 1 - k + kRecords) % kRecords]);
  return out;
}
const char *modeText() { return st::modeName(epMode()); }

// GameMode/SurvivalMode tick hooks as a player context source. Independent of Easy Place validation:
// the hooks only observe (Easy Place's own per-tick work stays gated by its validation).
bool installContextTicks(pl::log::Logger &log, std::string &detail) {
  gLog = &log;
  std::string how, howS;
  const uintptr_t gmVt = lm::rsv::classVtable("8GameMode", kGameModeVt, &how);
  const uintptr_t smVt = lm::rsv::classVtable("12SurvivalMode", kSurvivalModeVt, &howS);
  const uintptr_t lpVt = lm::ctx::localPlayerVtable();
  if (!lpVt) { detail = "LocalPlayer vtable unknown: the tick player cannot be validated"; return false; }
  if (!gmVt && !smVt) { detail = "GameMode vtables: " + how + "; " + howS; return false; }
  lm::ctx::setGameModeVtables(gmVt, smVt);
  auto res = [&](const char *key, const char *name, const char *pat) {
    const lm::rsv::Hit h = lm::rsv::find(key, pat);
    if (h) log.info("[sig] {}: FOUND (+{:#x}, {})", name, h.addr - lm::rsv::game().base, lm::rsv::viaText(h.via));
    else log.error("[sig] {}: NOT FOUND", name);
    return h.addr;
  };
  const uintptr_t gt = gHkTick.load() || !gmVt ? 0 : res("GameModeTick", "GameMode::tick", sig::GameModeTick);
  const uintptr_t st = gHkSurvTick.load() || !smVt ? 0 : res("SurvivalModeTick", "SurvivalMode::tick", sig::SurvivalModeTick);
  // The tick function must be the one these classes actually dispatch to (vtable slot proof).
  if (gt && !lm::rsv::vtableContains(gmVt, gt, 64)) { log.error("GameMode::tick not in the GameMode vtable"); }
  else if (gt) {
    if (pl::memory::hook(reinterpret_cast<void *>(gt), reinterpret_cast<void *>(&gameModeTickDetour),
                         reinterpret_cast<void **>(&oGameModeTick)) == 0)
      gHkTick.store(true);
    else log.error("hook GameMode::tick failed");
    lm::rsv::markHook("GameModeTick", gHkTick.load());
  }
  if (st && !lm::rsv::vtableContains(smVt, st, 64)) { log.error("SurvivalMode::tick not in the SurvivalMode vtable"); }
  else if (st) {
    if (pl::memory::hook(reinterpret_cast<void *>(st), reinterpret_cast<void *>(&survivalTickDetour),
                         reinterpret_cast<void **>(&oSurvivalTick)) == 0)
      gHkSurvTick.store(true);
    else log.error("hook SurvivalMode::tick failed");
    lm::rsv::markHook("SurvivalModeTick", gHkSurvTick.load());
  }
  const bool ok = gHkTick.load() || gHkSurvTick.load();
  detail = ok ? std::string("GameMode::tick ") + (gHkTick.load() ? "hooked" : "unavailable") + ", SurvivalMode::tick " +
                    (gHkSurvTick.load() ? "hooked" : "unavailable") + "; mPlayer must have the LocalPlayer vtable"
              : std::string("GameMode tick functions not found or not hookable");
  return ok;
}

bool install(pl::log::Logger &log) {
  gLog = &log;
  if (state().installed.load(std::memory_order_acquire)) return true;
  auto res = [&](const char *key, const char *name, const char *pat) {
    const lm::rsv::Hit h = lm::rsv::find(key, pat);
    if (h) log.info("[sig] {}: FOUND (+{:#x}, {})", name, h.addr - lm::rsv::game().base, lm::rsv::viaText(h.via));
    else log.error("[sig] {}: NOT FOUND", name);
    return h.addr;
  };
  if (!sItemBlockType) sItemBlockType = reinterpret_cast<ItemBlockTypeFn>(res("ItemBlockType", "ItemBlockType", sig::ItemBlockType));
  if (!sHandItem) sHandItem = reinterpret_cast<HandItemFn>(res("HandItem", "HandItem", sig::HandItem));
  if (!sSelectSlot) sSelectSlot = reinterpret_cast<SelectSlotFn>(res("SelectSlot", "PlayerInventory::selectSlot", sig::SelectSlot));
  const uintptr_t bb = res("BuildBlock", "GameMode::buildBlock", sig::BuildBlock);
  const uintptr_t gt = gHkTick.load() ? 0 : res("GameModeTick", "GameMode::tick", sig::GameModeTick);
  const uintptr_t st = gHkSurvTick.load() ? 0 : res("SurvivalModeTick", "SurvivalMode::tick", sig::SurvivalModeTick);
  if (!bb || !sItemBlockType || !sHandItem) {
    log.error("Easy Place: essential functions missing (buildBlock={}, itemBlockType={}, handItem={})", bb != 0,
              sItemBlockType != nullptr, sHandItem != nullptr);
    gDisabledReason = kNotValidated;
    log.error(kNotValidated);
    return false;
  }
  
  
  
  
  
  
  if (!gBaseChecked.exchange(true)) {
    const lm::rsv::GameInfo &gi = lm::rsv::game();
    const uintptr_t base = bb - kBuildBlockStatic;
    auto slotIs = [&](uintptr_t vtFuncs, unsigned slot, uintptr_t fnStatic) {
      uintptr_t v = 0;
      return rd(base + vtFuncs + slot * 8, v) && untag(v) == base + fnStatic;
    };
    const bool tested = gi.found && gi.tested != nullptr && gi.base == base;
    
    
    auto tailTo = [&](uintptr_t at, uintptr_t dst) {
      uint32_t w = 0;
      return rd(base + at, w) && (w & 0xFC000000u) == 0x14000000u &&
             at + uintptr_t(int64_t(int32_t(w << 6) >> 6) * 4) == dst;
    };
    const bool okBuild = slotIs(kGameModeVt, 7, kBuildBlockStatic) && slotIs(kSurvivalModeVt, 7, kSurvBuildStatic) &&
                         tailTo(kSurvBuildStatic + 0x20, kBuildBlockStatic);
    const bool okRange = slotIs(kGameModeVt, 11, kPickRangeStatic) && slotIs(kSurvivalModeVt, 11, kPickRangeStatic);
    const bool okUse = slotIs(kGameModeVt, 12, kBaseUseItemStatic) && slotIs(kSurvivalModeVt, 12, kSurvUseStatic) &&
                       tailTo(kSurvUseStatic + 0x30, kBaseUseItemStatic);
    const bool okLocal = slotIs(kClientInstanceVt, kVT_ClientInstance_getLocalPlayer, kGetLocalPlayerStatic);
    const bool okPlacement = slotIs(kStairBlockVt, kBT_VtPlacement / 8, kStairPlacementStatic);
    log.info("Easy Place validation: tested={} buildBlock={} pickRange={} baseUseItem={} getLocalPlayer={} "
             "getPlacementBlock={}", tested, okBuild, okRange, okUse, okLocal, okPlacement);
    if (tested && okBuild && okRange && okUse && okLocal && okPlacement) {
      gBase = base;
      gPlacementValidated.store(true, std::memory_order_release);
    }
    if (gBase && headMatches(gBase + kPickBlockStatic, kPickBlockHead, sizeof(kPickBlockHead)))
      sPickBlock = reinterpret_cast<PickBlockFn>(gBase + kPickBlockStatic);
    else log.error("Easy Place: pick block not found (inventory switch off)");
    if (gBase && headMatches(gBase + kIsCreativeStatic, kIsCreativeHead, sizeof(kIsCreativeHead)))
      sIsCreative = reinterpret_cast<IsCreativeFn>(gBase + kIsCreativeStatic);
  }
  if (!gPlacementValidated.load(std::memory_order_acquire)) {
    gDisabledReason = kNotValidated;
    log.error(kNotValidated);
    logf("%s", kNotValidated);
    return false;  
  }
  
  if (gt && !gHkTick.load()) {
    if (pl::memory::hook(reinterpret_cast<void *>(gt), reinterpret_cast<void *>(&gameModeTickDetour),
                         reinterpret_cast<void **>(&oGameModeTick)) == 0)
      gHkTick.store(true);
    else log.error("hook GameMode::tick failed");
    lm::rsv::markHook("GameModeTick", gHkTick.load());
  }
  if (st && !gHkSurvTick.load()) {
    if (pl::memory::hook(reinterpret_cast<void *>(st), reinterpret_cast<void *>(&survivalTickDetour),
                         reinterpret_cast<void **>(&oSurvivalTick)) == 0)
      gHkSurvTick.store(true);
    else log.error("hook SurvivalMode::tick failed");
    lm::rsv::markHook("SurvivalModeTick", gHkSurvTick.load());
  }
  uintptr_t ui = 0;
  if (!gHkUseItem.load()) {
    ui = res("BaseUseItem", "GameMode::baseUseItem", sig::BaseUseItem);
    if (ui && pl::memory::hook(reinterpret_cast<void *>(ui), reinterpret_cast<void *>(&useItemDetour),
                               reinterpret_cast<void **>(&oUseItem)) == 0)
      gHkUseItem.store(true);
    else if (ui) {
      log.error("hook GameMode::baseUseItem failed");
      oUseItem = nullptr;
    }
    if (ui) lm::rsv::markHook("BaseUseItem", gHkUseItem.load());
  }
  if (!gHkBuild.load()) {
    if (pl::memory::hook(reinterpret_cast<void *>(bb), reinterpret_cast<void *>(&buildBlockDetour),
                         reinterpret_cast<void **>(&oBuildBlock)) != 0) {
      log.error("hook GameMode::buildBlock failed");
      lm::rsv::markHook("BuildBlock", false);
      return false;
    }
    gHkBuild.store(true);
    lm::rsv::markHook("BuildBlock", true);
  }
  state().installed.store(true);
  log.info("Easy Place: hooks installed");
  logf("auto: base=%p selectSlot=%p", reinterpret_cast<void *>(gBase),
       reinterpret_cast<void *>(sSelectSlot));
  logf("installed: buildBlock=%p useItem=%p tick=%p survTick=%p itemBT=%p hand=%p", reinterpret_cast<void *>(bb),
       reinterpret_cast<void *>(ui), reinterpret_cast<void *>(gt), reinterpret_cast<void *>(st),
       reinterpret_cast<void *>(sItemBlockType), reinterpret_cast<void *>(sHandItem));
  return true;
}

void onClientUpdate(void *ci) { clientStep(ci != nullptr); }

void onLocalPlayerTick() { clientStep(true); }

// ---- run controls (UI thread) ----
void invalidate(const char *why) {
  gGen.fetch_add(1);  // pending turn / fixes / rechecks of the old generation are dropped on the next tick
  gForceRefresh.store(true, std::memory_order_release);
  logf("queue invalidated: %s", why ? why : "?");
}
void pause() {
  gPaused.store(true, std::memory_order_relaxed);
  logf("paused");
}
void resume() {
  gPaused.store(false, std::memory_order_relaxed);
  logf("resumed");
}
bool paused() { return gPaused.load(std::memory_order_relaxed); }
void cancel() {
  gRunScope.store(0, std::memory_order_relaxed);
  gPaused.store(false, std::memory_order_relaxed);
  state().enabled.store(false, std::memory_order_relaxed);
  gOp.store(0, std::memory_order_relaxed);
  invalidate("cancelled");
}
void startRun(int scope) {
  gRunScope.store(std::clamp(scope, 0, 2), std::memory_order_relaxed);
  gPaused.store(false, std::memory_order_relaxed);
  invalidate(scope ? "run started" : "run stopped");
}
int runScope() { return gRunScope.load(std::memory_order_relaxed); }
int currentOp() {
  if (gPaused.load(std::memory_order_relaxed)) return OpPaused;
  if (!state().enabled.load(std::memory_order_relaxed) && gRunScope.load(std::memory_order_relaxed) == 0) return OpIdle;
  if (nowMs() - gEpActiveAt.load() > 1500) return gRunScope.load(std::memory_order_relaxed) ? OpNoTarget : OpIdle;
  return std::clamp(gOp.load(std::memory_order_relaxed), 0, int(OpCount) - 1);
}

}  
