#pragma once



#include <string>

namespace lm::platform {

int androidApi();              
std::string deviceAbi();       
std::string launcherVersion(); 
bool copyText(const std::string &label, const std::string &text);  

void setTestValues(int api, const std::string &abi, const std::string &launcher);  

}  
