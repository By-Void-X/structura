#pragma once






#include <pl/Input.hpp>

#include "UiKit.hpp"

namespace lm::hudbtn {

bool probe();                
void setActive(bool on);     
bool active();
void setModuleOn(bool on);   
bool gameHudVisible();       
void setActions(void (*panel)(), void (*easyPlace)(), bool (*easyPlaceOn)());
void setWake(void (*wake)());  

bool onTouch(const pl::input::TouchEvent &ev);  


bool changed(float W, float H);                      
void draw(ui::kit::Canvas &cv, float W, float H);    
ui::kit::Rect rectOf(int which);                     


void setStateFnsForTest(bool (*hud)(), bool (*menu)(), bool (*pause)());

}  
