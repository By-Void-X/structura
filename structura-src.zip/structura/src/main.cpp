



#include <exception>
#include <cstdlib>
#include <dlfcn.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <initializer_list>
#include <iterator>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include <pl/Input.hpp>
#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>
#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include "App.hpp"
#include "Compat.hpp"
#include "Diag.hpp"
#include "EasyPlace.hpp"
#include "Game.hpp"
#include "Hologram.hpp"
#include "I18n.hpp"
#include "Icons.hpp"
#include "Platform.hpp"
#include "Resolver.hpp"
#include "State.hpp"
#include "Ui.hpp"
#include "HudButtons.hpp"
#include "Overlay.hpp"
#include "Perf.hpp"
#include "PlayerContext.hpp"

namespace lm {
namespace {

constexpr const char *kGameLib = "libminecraftpe.so";
constexpr const char *kModuleId = "structura.main";
constexpr const char *kBtnPanel = "structura.btn.panel";
constexpr const char *kBtnEasyPlace = "structura.btn.easyplace";
constexpr const char *kVersion = "1.0.3";
constexpr int kSettleDelayMs = 5000;

std::atomic_bool gEnabled{false};


void *gUpdateOrig = nullptr;  
std::atomic_bool gUpdateHooked{false};  

void *updateDetour(void *ci, bool flag, uint32_t extra) {
  void *o;
  while (!(o = __atomic_load_n(&gUpdateOrig, __ATOMIC_ACQUIRE))) {
  }
  void *r = reinterpret_cast<game::UpdateFn>(o)(ci, flag, extra);
  perf::count(perf::PlayerUpdate);
  void *player = nullptr;
  if (ci) {
    auto **vt = *reinterpret_cast<void ***>(ci);
    if (vt && vt[off::VT_ClientInstance_getLocalPlayer])
      player = reinterpret_cast<void *(*)(void *)>(vt[off::VT_ClientInstance_getLocalPlayer])(ci);
  }
  ctx::publishUpdate(reinterpret_cast<uintptr_t>(ci), reinterpret_cast<uintptr_t>(player));
  ep::onClientUpdate(ci);  
  return r;
}

// LocalPlayer::normalTick: last player context fallback (only hooked when neither ClientInstance::update
// nor the GameMode ticks are available). `this` is always the local player (LocalPlayer vtable only).
void *gLpTickOrig = nullptr;
std::atomic_bool gLpTickHooked{false};
void lpTickDetour(void *self) {
  void *o;
  while (!(o = __atomic_load_n(&gLpTickOrig, __ATOMIC_ACQUIRE))) {
  }
  reinterpret_cast<void (*)(void *)>(o)(self);
  if (ctx::publishLocalPlayer(reinterpret_cast<uintptr_t>(self))) ep::onLocalPlayerTick();
}

std::atomic_int gPanelKey{0};  
std::atomic_int gEasyPlaceKey{0};  



std::atomic_bool gOldSchematica{false}, gOldEasyPlace{false};

void detectOldMods() {
  std::ifstream maps("/proc/self/maps");
  std::string line;
  bool sch = false, epl = false;
  while (std::getline(maps, line)) {
    if (!sch && line.find("/libSchematica.so") != std::string::npos) sch = true;
    if (!epl && line.find("/libEasyPlace.so") != std::string::npos) epl = true;
  }
  gOldSchematica.store(sch);
  gOldEasyPlace.store(epl);
  status().oldModsLoaded.store(sch || epl);
}


void retireOldMods() {
  if (gOldEasyPlace.load()) {
    pl::modmenu::unregisterButton("easyplace.btn.toggle");
    pl::modmenu::unregisterModule("easyplace.main");
  }
  if (gOldSchematica.load()) {
    pl::modmenu::unregisterButton("schem.btn.panel");
    pl::modmenu::unregisterModule("schem.main");
  }
}




void ensureModuleShown() {
  using Fn = void (*)(std::string_view, bool);
  static Fn fn = reinterpret_cast<Fn>(
      dlsym(RTLD_DEFAULT, "_ZN2pl7modmenu16setModuleEnabledENSt6__ndk117basic_string_viewIcNS1_11char_traitsIcEEEEb"));
  if (fn) fn(kModuleId, true);
  if (fn) hudbtn::setModuleOn(true);
}



struct Keyboard {
  void (*show)() = nullptr;
  void (*hide)() = nullptr;
  void (*onText)(pl::input::TextInputCallback) = nullptr;
  void (*onKey)(pl::input::KeyCallback) = nullptr;
};
const Keyboard &keyboard() {
  static const Keyboard kb = [] {
    Keyboard k;
    k.show = reinterpret_cast<void (*)()>(dlsym(RTLD_DEFAULT, "_ZN2pl5input12showKeyboardEv"));
    k.hide = reinterpret_cast<void (*)()>(dlsym(RTLD_DEFAULT, "_ZN2pl5input12hideKeyboardEv"));
    k.onText = reinterpret_cast<void (*)(pl::input::TextInputCallback)>(dlsym(
        RTLD_DEFAULT, "_ZN2pl5input25registerTextInputCallbackENSt6__ndk18functionIFbRKNS0_14TextInputEventEEEE"));
    k.onKey = reinterpret_cast<void (*)(pl::input::KeyCallback)>(
        dlsym(RTLD_DEFAULT, "_ZN2pl5input19registerKeyCallbackENSt6__ndk18functionIFbRKNS0_8KeyEventEEEE"));
    return k;
  }();
  return kb;
}

void togglePanel() {
  ensureModuleShown();
  ui::setOpen(!ui::isOpen());
}

bool structurePlaced() {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  return m.structure && m.placed;
}

void setEasyPlace(bool on) {
  ensureModuleShown();
  if (on && !ep::state().installed.load()) {
    if (ep::disabledReason()) {
      notify("msg.ep_not_validated", Tone::Warning, 4000);
      return;
    }
    const Phase ph = status().phase.load();
    const bool settled = ph == Phase::Active || ph == Phase::Failed;
    notify(settled ? "msg.ep_unavailable" : "msg.not_ready", Tone::Warning, settled ? 3500 : 3000);
    return;
  }
  ep::state().enabled.store(on);
  if (on && (gOldSchematica.load() || gOldEasyPlace.load())) notify("msg.ep_old_mods", Tone::Warning, 4000);
  else if (on && !structurePlaced()) notify("msg.ep_on_no_structure", Tone::Warning, 2500);
  else notify(on ? "msg.ep_on" : "msg.ep_off", on ? Tone::Success : Tone::Info, 1500);
}

bool parseBool(std::string_view v) { return v == "true" || v == "1" || v == "on" || v == "enabled"; }

class StructuraMod {
public:
  static StructuraMod &instance() { static StructuraMod m; return m; }
  StructuraMod() : mSelf(*ll::mod::NativeMod::current()) {}

  bool load() {
    i18n::setLogger([](const std::string &m) { ll::mod::NativeMod::current()->getLogger().info("{}", m); });
    i18n::init(mSelf.getConfigDir().string());  
    loadSettings();
    mSelf.getLogger().info("Structura {} loaded", kVersion);
    return true;
  }

  bool enable() {
    gEnabled.store(true);
    settings().hologram.store(true);
    const std::string dir = (mSelf.getConfigDir() / "structures").string();
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    try {
      migrateFromSchematica(dir);
    } catch (...) {
      mSelf.getLogger().warn("could not copy structures from Schematica");
    }
    ep::setLogPath((mSelf.getConfigDir() / "easyplace-log.txt").string());
    std::set_terminate([] {
      // Uncaught C++ exception (or other terminate): write what() and the last step to the mod log before the abort.
      std::string what = "unknown";
      if (std::exception_ptr ep = std::current_exception()) {
        try { std::rethrow_exception(ep); }
        catch (const std::exception &e) { what = e.what(); }
        catch (...) { what = "non-std exception"; }
      }
      ep::logf("TERMINATE: %s | last step: %s", what.c_str(), ep::currentStep());
      ep::flushLog();
      std::abort();
    });
    app::init(dir, &mSelf.getLogger());
    ui::setModuleId(kModuleId);
    ui::setVersion(kVersion);
    
    
    mOwnButtons = hudbtn::probe();
    mMenuTries = 0;
    registerMenu();
    hudbtn::setActions(&togglePanel, [] { setEasyPlace(!ep::state().enabled.load()); },
                       [] { return ep::state().enabled.load(); });
    hudbtn::setWake(&ui::wake);
    overlay::setActions(&togglePanel, &ui::wake);
    applyButtonMode();
    ui::setEasyPlaceHandler(&setEasyPlace);
    ui::setDiagnosticHandler([] {
      
      const std::string text = instance().diagnostic();
      if (platform::copyText("Structura", text)) return 1;
      std::ofstream out(instance().mSelf.getConfigDir() / "structura-diagnostic.txt", std::ios::trunc);
      if (out && (out << text)) return 2;
      return 0;
    });
    if (!mTouchRegistered.exchange(true)) {
      
      pl::input::registerTouchCallback([](const pl::input::TouchEvent &ev) {
        if (!gEnabled.load(std::memory_order_relaxed)) return false;
        if (hudbtn::onTouch(ev)) return true;  
        if (overlay::onTouch(ev)) return true;  // only touches that start inside the overlay
        
        
        if (hudbtn::active() && !hudbtn::gameHudVisible()) return false;
        return ui::onTouch(ev);
      });
      const Keyboard &kb = keyboard();
      if (kb.show && kb.hide && kb.onText) {
        kb.onText([](const pl::input::TextInputEvent &ev) {
          return gEnabled.load(std::memory_order_relaxed) && ui::onText(ev.text);
        });
        if (kb.onKey)
          kb.onKey([](const pl::input::KeyEvent &ev) {
            return gEnabled.load(std::memory_order_relaxed) && ui::onKey(ev.keyCode, ev.unicodeChar, ev.isKeyDown);
          });
        ui::setKeyboard(kb.show, kb.hide);
      }
      mSelf.getLogger().info("keyboard: {}", (kb.show && kb.hide && kb.onText) ? "available" : "not available");
    }
    app::rescan();
    mStop.store(false);
    if (!mWatcherStarted.exchange(true)) std::thread([this] { watcher(); }).detach();
    
    if (!mUiStarted.exchange(true)) std::thread([this] { uiLoop(); }).detach();
    return true;
  }

  bool disable() {
    gEnabled.store(false);
    mStop.store(true);
    ui::setOpen(false);
    settings().hologram.store(false);  
    ep::state().enabled.store(false);
    pl::modmenu::unregisterButton(kBtnPanel);
    pl::modmenu::unregisterButton(kBtnEasyPlace);
    hudbtn::setActive(false);
    ui::clear();
    pl::modmenu::unregisterModule(kModuleId);
    mWatcherStarted.store(false);
    return true;
  }

  bool unload() {
    app::shutdown();
    return true;
  }

private:
  ll::mod::NativeMod &mSelf;
  std::atomic_bool mStop{false};
  std::atomic_bool mWatcherStarted{false};
  std::atomic_bool mUiStarted{false};
  std::atomic_bool mMenuOk{false};
  std::atomic_bool mOwnButtons{false};  
  int mMenuTries = 0;                   
  static constexpr int kMenuRetries = 3;
  std::atomic_bool mTouchRegistered{false};
  std::mutex mInstallMutex;
  bool mInstalled = false;
  std::mutex mSaveMutex;

  
  std::filesystem::path settingsPath() const { return mSelf.getConfigDir() / "settings.txt"; }

  void loadSettings() {
    std::ifstream in(settingsPath());
    std::string line;
    while (std::getline(in, line)) {
      const auto eq = line.find('=');
      if (eq != std::string::npos) applyKey(line.substr(0, eq), line.substr(eq + 1));
    }
  }

  
  std::string settingsText() const {
    auto &s = settings();
    std::string out;
    out.reserve(640);
    auto b = [](bool v) { return v ? "true" : "false"; };
    auto put = [&out](const char *k, const std::string &v) { out.append(k).append("=").append(v).append("\n"); };
    auto f = [](float v) {  
      char t[32];
      std::snprintf(t, sizeof(t), "%g", double(v));
      return std::string(t);
    };
    put("lines", b(s.showLines.load()));
    put("twoSided", b(s.twoSided.load()));
    put("blockLook", std::to_string(s.blockLook.load()));
    put("opacity", f(s.alpha.load()));
    put("radius", std::to_string(s.radius.load()));
    put("hideCorrect", b(s.hideCorrect.load()));
    put("uiScale", f(s.uiScale.load()));
    put("downloads", b(s.scanDownloads.load()));
    put("panelRight", b(s.panelRight.load()));
    put("panelX", f(s.panelFX.load()));
    put("panelY", f(s.panelFY.load()));
    put("panelSize", f(s.panelSize.load()));
    put("theme", std::to_string(s.theme.load()));
    put("layerMode", std::to_string(s.layerMode.load()));
    put("layerAxis", std::to_string(s.layerAxis.load()));
    put("panelKey", std::to_string(gPanelKey.load()));
    put("easyPlaceKey", std::to_string(gEasyPlaceKey.load()));
    put("language", i18n::choice());
    put("animations", b(s.animations.load()));
    put("controlSize", std::to_string(s.controlSize.load()));
    put("opacityMode", std::to_string(s.opacityMode.load()));
    static const char *const kOpNames[theme::style::InkCount] = {"opacityBackground", "opacityBorders", "opacityText",
                                                                 "opacityIcons", "opacitySelected"};
    for (int i = 0; i < theme::style::InkCount; ++i) put(kOpNames[i], std::to_string(s.opacityPct[i].load()));
    put("layout", std::to_string(s.uiLayout.load()));
    put("labels", std::to_string(s.uiLabels.load()));
    put("stPosX", f(s.stX.load()));
    put("stPosY", f(s.stY.load()));
    put("epPosX", f(s.epX.load()));
    put("epPosY", f(s.epY.load()));
    if (s.perfLog.load()) put("perfLog", "true");  
    put("epMode", std::to_string(s.epMode.load()));
    // 1.0.2: hologram filter, progress overlay, Easy Place run controls
    put("holoFilter", std::to_string(s.holoFilter.load()));
    put("ovVisible", s.ovVisible.load() ? "true" : "false");
    put("ovX", f(s.ovX.load()));
    put("ovY", f(s.ovY.load()));
    put("ovScale", f(s.ovScale.load()));
    put("ovWidth", f(s.ovWidth.load()));
    put("ovAlpha", f(s.ovAlpha.load()));
    put("ovExpanded", s.ovExpanded.load() ? "true" : "false");
    put("ovDisplay", std::to_string(s.ovDisplay.load()));
    put("ovLayer", std::to_string(s.ovLayer.load()));
    put("epLayerOnly", s.epLayerOnly.load() ? "true" : "false");
    put("epRate", std::to_string(s.epRate.load()));
    put("epBatch", std::to_string(s.epBatch.load()));
    put("epBottomUp", s.epBottomUp.load() ? "true" : "false");
    put("epSafeOnly", s.epSafeOnly.load() ? "true" : "false");
    static const char *const kColorNames[ColCount] = {"colorMissing", "colorWrong", "colorWrongState", "colorExtra",
                                                      "colorCorrect"};
    for (int i = 0; i < ColCount; ++i) {
      char hex[16];
      std::snprintf(hex, sizeof(hex), "#%06X", unsigned(s.blockColor[i].load() & 0xFFFFFFu));
      put(kColorNames[i], hex);
    }
    return out;
  }

  void saveSettings() { writeSettings(settingsText()); }
  void writeSettings(const std::string &text) {
    std::lock_guard<std::mutex> lk(mSaveMutex);
    std::error_code ec;
    std::filesystem::create_directories(settingsPath().parent_path(), ec);
    std::ofstream out(settingsPath(), std::ios::trunc);
    if (out) out << text;
  }

  bool applyKey(std::string_view key, std::string_view value) {
    auto &s = settings();
    try {
      const std::string v(value);
      if (key == "faces") s.showFaces.store(true);  
      else if (key == "lines") s.showLines.store(parseBool(value));
      else if (key == "twoSided") s.twoSided.store(parseBool(value));
      else if (key == "blockLook") s.blockLook.store(std::clamp(std::stoi(v), 0, holo::blockLookCount() - 1));
      else if (key == "faceMaterial") s.faceMaterial.store(0);  
      else if (key == "alpha") {}  
      else if (key == "opacity") s.alpha.store(std::clamp(std::stof(v), 0.1f, 1.f));
      else if (key == "radius") s.radius.store(std::clamp(std::stoi(v), 6, 48));
      else if (key == "hideCorrect") s.hideCorrect.store(parseBool(value));
      else if (key == "uiScale") {  
        const float u = std::clamp(std::stof(v), 0.6f, 1.6f);
        s.uiScale.store(u);
        s.controlSize.store(u < 0.85f ? theme::style::SizeCompact : u < 1.f ? theme::style::SizeMedium
                                                                           : theme::style::SizeLarge);
      }
      else if (key == "controlSize") s.controlSize.store(std::clamp(std::stoi(v), 0, theme::style::SizeModeCount - 1));
      else if (key == "opacityMode") s.opacityMode.store(std::clamp(std::stoi(v), 0, theme::style::OpacityModeCount - 1));
      else if (key.substr(0, 7) == "opacity" && key.size() > 7) {
        static const char *const kOpNames[theme::style::InkCount] = {"opacityBackground", "opacityBorders",
                                                                     "opacityText", "opacityIcons", "opacitySelected"};
        int which = -1;
        for (int i = 0; i < theme::style::InkCount; ++i)
          if (key == kOpNames[i]) which = i;
        if (which < 0) return false;
        s.opacityPct[which].store(std::clamp(std::stoi(v), theme::style::OpacityMinPct, theme::style::OpacityMaxPct));
      }
      else if (key == "layout") s.uiLayout.store(std::clamp(std::stoi(v), 0, theme::style::LayoutModeCount - 1));
      else if (key == "labels") s.uiLabels.store(std::clamp(std::stoi(v), 0, theme::style::LabelModeCount - 1));
      else if (key == "downloads") s.scanDownloads.store(parseBool(value));
      else if (key == "panelRight") s.panelRight.store(parseBool(value));
      else if (key == "packs") s.scanPacks.store(false);  
      else if (key == "panelFX" || key == "panelFY") {}  
      else if (key == "panelX") s.panelFX.store(std::clamp(std::stof(v), 0.f, 1.f));  
      else if (key == "panelY") s.panelFY.store(std::clamp(std::stof(v), 0.f, 1.f));
      else if (key == "panelSize") s.panelSize.store(std::clamp(std::stof(v), 0.5f, 1.f));
      else if (key == "theme") s.theme.store(std::clamp(std::stoi(v), 0, 1));
      else if (key == "hologram") s.hologram.store(parseBool(value));
      else if (key == "layerMode") s.layerMode.store(std::clamp(std::stoi(v), 0, 4));
      else if (key == "epMode") s.epMode.store(std::clamp(std::stoi(v), 0, 4));
      else if (key == "holoFilter") s.holoFilter.store(std::clamp(std::stoi(v), 0, 3));
      else if (key == "ovVisible") s.ovVisible.store(parseBool(value));
      else if (key == "ovX" || key == "ovY") {
        const float fv = std::stof(v);
        (key == "ovX" ? s.ovX : s.ovY).store(fv < 0.f ? -1.f : std::min(fv, 1.f));
      } else if (key == "ovScale") s.ovScale.store(std::clamp(std::stof(v), 0.7f, 1.6f));
      else if (key == "ovWidth") s.ovWidth.store(std::clamp(std::stof(v), 0.8f, 1.6f));
      else if (key == "ovAlpha") s.ovAlpha.store(std::clamp(std::stof(v), 0.3f, 1.f));
      else if (key == "ovExpanded") s.ovExpanded.store(parseBool(value));
      else if (key == "ovDisplay") s.ovDisplay.store(std::clamp(std::stoi(v), 0, 2));
      else if (key == "ovLayer") s.ovLayer.store(std::max(-1, std::stoi(v)));
      else if (key == "epLayerOnly") s.epLayerOnly.store(parseBool(value));
      else if (key == "epRate") s.epRate.store(std::clamp(std::stoi(v), 1, 20));
      else if (key == "epBatch") s.epBatch.store(std::clamp(std::stoi(v), 1, 4));
      else if (key == "epBottomUp") s.epBottomUp.store(parseBool(value));
      else if (key == "epSafeOnly") s.epSafeOnly.store(parseBool(value));
      else if (key == "layerAxis") s.layerAxis.store(std::clamp(std::stoi(v), 0, 2));
      else if (key == "panelKey") gPanelKey.store(v.empty() ? 0 : std::max(0, std::stoi(v)));
      else if (key == "easyPlaceKey") gEasyPlaceKey.store(v.empty() ? 0 : std::max(0, std::stoi(v)));
      else if (key == "language") i18n::setChoice(v);  
      else if (key == "animations") s.animations.store(parseBool(value));
      else if (key == "stPosX" || key == "stPosY" || key == "epPosX" || key == "epPosY") {
        const float fv = std::stof(v);
        const float c = fv < 0.f ? -1.f : std::min(fv, 1.f);
        (key == "stPosX" ? s.stX : key == "stPosY" ? s.stY : key == "epPosX" ? s.epX : s.epY).store(c);
      } else if (key == "perfLog") s.perfLog.store(parseBool(value));
      else if (key == "devMode") i18n::setDevMode(parseBool(value));  
      else if (key.substr(0, 5) == "color") {  
        static const char *const kColorNames[ColCount] = {"colorMissing", "colorWrong", "colorWrongState",
                                                          "colorExtra", "colorCorrect"};
        const std::string h = (!v.empty() && v[0] == '#') ? v.substr(1) : v;
        if (h.size() != 6 || h.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos) return false;
        int which = -1;
        for (int i = 0; i < ColCount; ++i)
          if (key == kColorNames[i]) which = i;
        if (which < 0) return false;
        s.blockColor[which].store(0xFF000000u | uint32_t(std::strtoul(h.c_str(), nullptr, 16)));
      }
      else return false;
    } catch (...) {
      return false;
    }
    return true;
  }

  
  static bool libraryMapped() {
    void *h = dlopen(kGameLib, RTLD_NOW | RTLD_NOLOAD);
    if (!h) return false;
    dlclose(h);
    return true;
  }

  
  
  struct InitLog {
    pl::log::Logger &log;
    std::string text;
    void info(const std::string &l) { log.info("{}", l); text += l + "\n"; }
    void error(const std::string &l) { log.error("{}", l); text += l + "\n"; }
  };

  static std::string hex(uintptr_t v) {
    char b[24];
    std::snprintf(b, sizeof(b), "%#lx", static_cast<unsigned long>(v));
    return b;
  }

  
  static rsv::Hit probe(InitLog &L, const char *label, const char *key, const char *pattern) {
    const rsv::Hit h = rsv::find(key, pattern);
    if (h) L.info(std::string(label) + ": FOUND (+" + hex(h.addr - rsv::game().base) + ", " + rsv::viaText(h.via) + ")");
    else L.error(std::string(label) + ": NOT FOUND");
    return h;
  }

  void writeInitLog(const InitLog &L) {
    std::error_code ec;
    std::filesystem::create_directories(mSelf.getConfigDir(), ec);
    std::ofstream out(mSelf.getConfigDir() / "structura-log.txt", std::ios::trunc);
    if (out) out << "Structura " << kVersion << "\n" << L.text;
  }

  static std::vector<std::string> splitLines(const std::string &t) {
    std::vector<std::string> out;
    size_t a = 0;
    while (a < t.size()) {
      size_t b = t.find('\n', a);
      if (b == std::string::npos) b = t.size();
      if (b > a) out.push_back(t.substr(a, b - a));
      a = b + 1;
    }
    return out;
  }

  
  static void updateComponents(const rsv::Hit &upd, std::initializer_list<rsv::Hit> renderEss, bool renderMesh,
                               holo::InstallResult hr, bool epOk) {
    using compat::Comp;
    using compat::Reason;
    using compat::State;
    const auto &st = status();
    
    const bool anyCtx = ctx::anySource();
    if (gUpdateHooked.load()) {
      compat::set(Comp::PlayerUpdate, State::Ok,
                  upd.via == rsv::Via::TestedBuildHooked || upd.via == rsv::Via::SignatureHooked ? Reason::ChainedOtherMod
                                                                                                  : Reason::None);
    } else {
      // Optional: unavailable is reported, but it is not a failure while a fallback provides the player.
      const Reason r = upd ? Reason::HookRejected : upd.why;
      compat::set(Comp::PlayerUpdate, anyCtx ? State::Unavailable : State::Failed, anyCtx ? Reason::NotRequired : r,
                  std::string("ClientInstance::update: ") + compat::reasonName(r));
    }
    if (ctx::installed(ctx::Source::UpdateHook)) compat::set(Comp::PlayerContext, State::Ok, Reason::None, "via ClientInstance::update");
    else if (ctx::installed(ctx::Source::GameModeTick))
      compat::set(Comp::PlayerContext, State::Ok, Reason::None, "fallback: GameModeTick (" + ctx::detail(ctx::Source::GameModeTick) + ")");
    else if (ctx::installed(ctx::Source::LocalPlayerTick))
      compat::set(Comp::PlayerContext, State::Ok, Reason::None, "fallback: LocalPlayer tick (" + ctx::detail(ctx::Source::LocalPlayerTick) + ")");
    else
      compat::set(Comp::PlayerContext, State::Unavailable, Reason::NoContextSource,
                  "GameModeTick: " + ctx::detail(ctx::Source::GameModeTick) + "; LocalPlayer tick: " +
                      ctx::detail(ctx::Source::LocalPlayerTick));
    if (hr != holo::InstallResult::Ok) compat::set(Comp::Hologram, State::Failed, Reason::HookRejected, "render hook unavailable");
    else if (!anyCtx) compat::set(Comp::Hologram, State::Limited, Reason::NoContextSource, "waiting for player context");
    else compat::set(Comp::Hologram, State::Ok);
    if (hr == holo::InstallResult::Ok) {
      if (!anyCtx) compat::set(Comp::Rendering, State::Limited, Reason::NoContextSource);
      else if (st.texSigMissing.load() > 0)
        compat::set(Comp::Rendering, State::Limited, Reason::TexturesMissing,
                    std::to_string(st.texSigMissing.load()) + " optional functions missing");
      else compat::set(Comp::Rendering, State::Ok);
    } else if (hr == holo::InstallResult::HookFailed) {
      compat::set(Comp::Rendering, State::Failed, Reason::HookRejected, "renderLevel");
    } else {
      static const char *const kNames[] = {"RenderLevel", "TessellatorBegin", "TessellatorColor", "TessellatorVertex"};
      Reason r = Reason::SignatureNotFound;
      std::string d = "RenderMeshImmediately";
      size_t i = 0;
      bool found = false;
      for (const rsv::Hit &h : renderEss) {
        if (!h && !found) { r = h.why; d = kNames[i]; found = true; }
        ++i;
      }
      if (!found && renderMesh) d.clear();
      compat::set(Comp::Rendering, State::Failed, r == Reason::None ? Reason::SignatureNotFound : r, d);
    }
    
    if (!st.hasGetBlock.load()) {
      std::string d;
      const Reason r = rsv::componentFailure(Comp::Verification, &d);
      compat::set(Comp::Verification, State::Failed, r == Reason::None ? Reason::SignatureNotFound : r, d);
    } else if (!anyCtx) {
      compat::set(Comp::Verification, State::Limited, Reason::NoContextSource);
    } else {
      compat::set(Comp::Verification, State::Ok);
    }
    
    if (epOk && !anyCtx) {
      compat::set(Comp::Placement, State::Limited, Reason::NoContextSource);
    } else if (epOk) {
      compat::set(Comp::Placement, State::Ok);
    } else {
      std::string d;
      Reason r = rsv::componentFailure(Comp::Placement, &d);
      if (r == Reason::None) r = ep::disabledReason() ? Reason::PlacementNotValidated : Reason::HookRejected;
      compat::set(Comp::Placement, State::Failed, r, d);
    }
  }

  
  std::string diagnostic() { return compat::diagnosticText(kVersion, rsv::signatureLines()) + diag::text(); }

  
  
  bool initAttempt(int n, InitLog &L) {
    auto &st = status();
    st.initAttempt.store(n);
    rsv::beginAttempt();
    L.info("Structura initialization attempt " + std::to_string(n) + "/" + std::to_string(kInitAttempts));
    if (!rsv::refresh()) {
      L.error("libminecraftpe.so: NOT FOUND in memory");
      for (compat::Comp c : {compat::Comp::Versions, compat::Comp::PlayerUpdate, compat::Comp::Rendering,
                             compat::Comp::Verification, compat::Comp::Placement})
        compat::set(c, compat::State::Failed, compat::Reason::LibraryNotFound);
      st.failReason.store(FailReason::GameLibraryNotFound);
      L.error("Final status: FAILED (" + std::string(failReasonText(FailReason::GameLibraryNotFound)) + ")");
      return false;
    }
    const auto &g = rsv::game();
    setGameLabel(g.version);  
    L.info("Game: Minecraft " + (g.version.empty() ? std::string("version unknown") : g.version) + ", build-id " +
           (g.buildId.empty() ? std::string("none") : g.buildId) +
           (g.tested ? std::string(", tested build (") + g.tested + ")"
                     : std::string(", NOT a tested build: each function is checked by signature")));
    
    compat::resetGame();
    compat::Env env;
    env.mc = g.parsed;
    env.buildId = g.buildId;
    env.tested = g.tested != nullptr;
    env.launcher = platform::launcherVersion();
    env.abi = g.abi;
    env.deviceAbi = platform::deviceAbi();
    env.androidApi = platform::androidApi();
    env.rule = g.tested ? std::string("tested build-id: verified offsets, each re-checked against its signature")
                        : std::string("signature scan: each function must match exactly once and pass validation");
    compat::setEnv(env);
    auto orUnknown = [](const std::string &v) { return v.empty() ? std::string("unknown") : v; };
    L.info("Minecraft version=" + orUnknown(g.version));
    L.info("Normalized version=" + orUnknown(ver::normalized(g.parsed)));
    L.info("Channel=" + std::string(g.parsed.valid() ? ver::channelName(g.parsed.channel) : "unknown") +
           (g.parsed.valid() && g.parsed.channelFromBuild ? " (from the build number)" : ""));
    L.info("Build=" + (g.buildId.empty() ? std::string("none") : g.buildId) + (g.tested ? " (tested)" : " (not tested)"));
    L.info("LeviLauncher version=" + orUnknown(env.launcher));
    L.info("Android API=" + (env.androidApi > 0 ? std::to_string(env.androidApi) : std::string("unknown")));
    L.info("ABI=" + orUnknown(g.abi) + (env.deviceAbi.empty() ? std::string() : " (device " + env.deviceAbi + ")"));
    L.info("Compatibility rule=" + env.rule);
    if (!g.abiOk) compat::set(compat::Comp::Versions, compat::State::Failed, compat::Reason::AbiIncompatible, g.abi);
    else if (g.tested) compat::set(compat::Comp::Versions, compat::State::Ok);
    else if (g.parsed.valid()) compat::set(compat::Comp::Versions, compat::State::Limited, compat::Reason::BuildNotTested);
    else compat::set(compat::Comp::Versions, compat::State::Limited, compat::Reason::VersionUnknown);

    const rsv::Hit rl = probe(L, "RenderLevel", "RenderLevel", sig::RenderLevel);
    const bool build1260 = g.buildId == "eb291b883dfdfaff70c4999c2eabd61885ae3e15";
    const rsv::Hit upd = probe(L, "ClientInstance::update", "ClientInstanceUpdate",
                               build1260 ? sig::ClientInstanceUpdate1260 : sig::ClientInstanceUpdate);
    const rsv::Hit tb = probe(L, "TessellatorBegin", "TessellatorBegin", sig::TessellatorBegin);
    const rsv::Hit tc = probe(L, "TessellatorColor", "TessellatorColor", sig::TessellatorColor);
    const rsv::Hit tv = probe(L, "TessellatorVertex", "TessellatorVertex", sig::TessellatorVertex);
    const rsv::Hit rm4 = probe(L, "RenderMeshImmediately (4 args)", "RenderMeshImmediately2", sig::RenderMeshImmediately2);
    const rsv::Hit rm5 = probe(L, "RenderMeshImmediately (5 args)", "RenderMeshImmediately", sig::RenderMeshImmediately);
    probe(L, "BlockSourceGetBlock (optional: verifier)", "BlockSourceGetBlock", sig::BlockSourceGetBlock);
    const bool renderSigs = rl && tb && tc && tv && (rm4 || rm5);

    
    // ClientInstance::update is the preferred player context source, never a requirement. When another
    // mod hooked it first the resolver proves the address (recognised patch + exact tail + original
    // bytes from the library file) and preloader chains both detours on its single trampoline.
    if (!gUpdateHooked.load() && upd) {
      if (pl::memory::hook(reinterpret_cast<void *>(upd.addr), reinterpret_cast<void *>(&updateDetour), &gUpdateOrig,
                           pl::memory::HookPriority::Normal) == 0 && gUpdateOrig) {
        gUpdateHooked.store(true);
        st.hkUpdate.store(true);
      }
      rsv::markHook("ClientInstanceUpdate", gUpdateHooked.load());
    }
    const bool updChained = upd.via == rsv::Via::TestedBuildHooked || upd.via == rsv::Via::SignatureHooked;
    ctx::setInstalled(ctx::Source::UpdateHook, gUpdateHooked.load(),
                      gUpdateHooked.load() ? (updChained ? "chained with another mod's hook" : "hooked")
                      : !upd               ? std::string("not found: ") + compat::reasonName(upd.why)
                                           : std::string("hook rejected"));
    L.info(std::string("ClientInstance update: ") +
           (gUpdateHooked.load() ? (updChained ? "OK (chained with another mod's hook)" : "OK") : "unavailable"));

    // Fallback sources need the LocalPlayer vtable (RTTI) to tell the local player from any other.
    std::string lpHow;
    const uintptr_t lpVt = rsv::localPlayerVtable(&lpHow);
    ctx::setLocalPlayerVtable(lpVt);
    L.info("LocalPlayer vtable: " + (lpVt ? hex(lpVt - g.base) + " (" + lpHow + ")" : "unknown (" + lpHow + ")"));
    if (!ctx::installed(ctx::Source::GameModeTick)) {
      std::string d;
      const bool ok = lpVt && ep::installContextTicks(mSelf.getLogger(), d);
      ctx::setInstalled(ctx::Source::GameModeTick, ok, lpVt ? d : "LocalPlayer vtable unknown: " + lpHow);
    }
    L.info("Player context fallback GameModeTick: " + std::string(ctx::installed(ctx::Source::GameModeTick) ? "OK" : "unavailable") +
           " (" + ctx::detail(ctx::Source::GameModeTick) + ")");
    if (!gUpdateHooked.load() && !ctx::installed(ctx::Source::GameModeTick) && !gLpTickHooked.load()) {
      std::string d = "LocalPlayer vtable unknown: " + lpHow;
      if (lpVt) {
        const rsv::Hit lt = probe(L, "LocalPlayer::normalTick (player context fallback)", "LocalPlayerNormalTick",
                                  sig::LocalPlayerNormalTick);
        if (!lt) d = std::string("not found: ") + compat::reasonName(lt.why);
        else if (!rsv::vtableContains(lpVt, lt.addr, 400)) {
          d = "rejected: not in the LocalPlayer vtable";
          rsv::markHook("LocalPlayerNormalTick", false);
        } else {
          if (pl::memory::hook(reinterpret_cast<void *>(lt.addr), reinterpret_cast<void *>(&lpTickDetour), &gLpTickOrig,
                               pl::memory::HookPriority::Normal) == 0 && gLpTickOrig)
            gLpTickHooked.store(true);
          rsv::markHook("LocalPlayerNormalTick", gLpTickHooked.load());
          d = gLpTickHooked.load() ? (lt.via == rsv::Via::TestedBuildHooked || lt.via == rsv::Via::SignatureHooked
                                          ? "hooked (chained with another mod's hook), in the LocalPlayer vtable"
                                          : "hooked, in the LocalPlayer vtable")
                                   : "hook rejected";
        }
      }
      ctx::setInstalled(ctx::Source::LocalPlayerTick, gLpTickHooked.load(), d);
    } else if (!gLpTickHooked.load()) {
      ctx::setInstalled(ctx::Source::LocalPlayerTick, false, "not needed: another source is active");
    }
    L.info(std::string("Player context: ") +
           (ctx::installed(ctx::Source::UpdateHook)        ? "ClientInstance::update"
            : ctx::installed(ctx::Source::GameModeTick)    ? "fallback GameModeTick"
            : ctx::installed(ctx::Source::LocalPlayerTick) ? "fallback LocalPlayer tick"
                                                           : "UNAVAILABLE (no validated player context source)"));

    
    const holo::InstallResult hr = holo::install(mSelf.getLogger());
    const bool holoOk = hr == holo::InstallResult::Ok;
    L.info(std::string("Hologram hook: ") + (holoOk ? "OK" : "FAILED"));
    if (holoOk && st.texSigMissing.load() > 0)
      L.info("Block textures: " + std::to_string(st.texSigMissing.load()) + " optional functions missing (solid color)");

    
    const bool epOk = ep::install(mSelf.getLogger());
    st.hkEasyPlace.store(epOk);
    L.info(std::string("Easy Place hook: ") + (epOk ? "OK" : "FAILED (optional)"));
    if (!epOk && ep::disabledReason()) L.info(ep::disabledReason());

    FailReason why = FailReason::None;
    if (!renderSigs) why = FailReason::RenderSignatureMissing;
    else if (!holoOk) why = hr == holo::InstallResult::SignatureMissing ? FailReason::RenderSignatureMissing
                                                                        : FailReason::RenderHookFailed;
    else if (!ctx::anySource()) why = FailReason::NoPlayerContext;
    else if (!epOk) why = FailReason::EasyPlaceHookFailed;  
    st.failReason.store(why);
    updateComponents(upd, {rl, tb, tc, tv}, rm4 || rm5, hr, epOk);
    L.info("Signatures:");
    for (const std::string &line : splitLines(rsv::signatureLines())) L.info(line);
    for (int i = 0; i < compat::kCount; ++i) {
      const compat::Entry e = compat::get(compat::Comp(i));
      L.info(std::string("Component ") + compat::compName(compat::Comp(i)) + ": " + compat::stateName(e.state) +
             (e.reason != compat::Reason::None ? std::string(" - ") + compat::reasonName(e.reason) : std::string()) +
             (e.detail.empty() ? std::string() : " (" + e.detail + ")"));
    }
    L.info(std::string("Compatibility: ") + compat::levelName(compat::level()));
    const bool coreOk = holoOk && ctx::anySource();
    if (coreOk)
      L.info(std::string("Final status: ACTIVE") + (gUpdateHooked.load() ? "" : " (player context from a fallback source)") +
             (epOk ? "" : " (Easy Place unavailable)"));
    else {  
      const compat::Comp fc = holoOk ? compat::Comp::PlayerContext : compat::Comp::Rendering;
      const compat::Entry fe = compat::get(fc);
      const std::string extra = fe.reason != compat::Reason::None && fe.reason != compat::Reason::NeedsPlayerUpdate
                                    ? std::string(" - ") + compat::compName(fc) + ": " + compat::reasonName(fe.reason)
                                    : std::string();
      L.error("Final status: FAILED (" + std::string(failReasonText(why)) + ")" + extra);
    }
    return coreOk;
  }

  void watcher() {
    auto &log = mSelf.getLogger();
    auto &st = status();
    bool mapped = false;
    for (int i = 0; i < 18000 && !mStop.load(); ++i) {
      if (libraryMapped()) { mapped = true; break; }
      std::this_thread::sleep_for(std::chrono::milliseconds(i < 6000 ? 1 : 50));
    }
    auto sleepMs = [&](int ms) {
      for (int w = 0; w < ms && !mStop.load(); w += 100) std::this_thread::sleep_for(std::chrono::milliseconds(100));
      return !mStop.load();
    };
    if (!mapped) {
      if (!mStop.load()) {
        st.failReason.store(FailReason::GameLibraryNotFound);
        st.phase.store(Phase::Failed);
        InitLog L{log, {}};
        L.error("libminecraftpe.so was not loaded: Structura not started");
        for (compat::Comp c : {compat::Comp::Versions, compat::Comp::PlayerUpdate, compat::Comp::Rendering,
                               compat::Comp::Verification, compat::Comp::Placement})
          compat::set(c, compat::State::Failed, compat::Reason::LibraryNotFound);
        L.error("Final status: FAILED (" + std::string(failReasonText(FailReason::GameLibraryNotFound)) + ")");
        writeInitLog(L);
      }
      mWatcherStarted.store(false);
      return;
    }
    {
      std::lock_guard<std::mutex> lock(mInstallMutex);
      if (mInstalled) {  
        st.phase.store(Phase::Active);
        mWatcherStarted.store(false);
        return;
      }
    }
    st.phase.store(Phase::Settling);
    if (!sleepMs(kSettleDelayMs)) { mWatcherStarted.store(false); return; }
    InitLog L{log, {}};
    bool oldModsChecked = false;
    for (int n = 1; n <= kInitAttempts && !mStop.load(); ++n) {
      {
        std::lock_guard<std::mutex> lock(mInstallMutex);
        if (mInstalled) break;
        st.phase.store(Phase::Installing);
        const bool coreOk = initAttempt(n, L);
        if (!oldModsChecked) {
          oldModsChecked = true;
          detectOldMods();
          if (gOldSchematica.load() || gOldEasyPlace.load()) {
            retireOldMods();
            L.info("old mods loaded (Schematica=" + std::string(gOldSchematica.load() ? "yes" : "no") +
                   ", EasyPlace=" + (gOldEasyPlace.load() ? "yes" : "no") + "): uninstall them");
          }
        }
        mInstalled = coreOk;  
        // Only a missing render hook makes the hologram impossible; a missing player hook is a limited
        // mode (camera fallback), not a global failure.
        st.phase.store(coreOk ? Phase::Active
                              : n < kInitAttempts ? Phase::Installing
                              : st.hkRender.load() ? Phase::Active
                                                   : Phase::Failed);
        writeInitLog(L);
        if (coreOk) break;
      }
      if (n < kInitAttempts && !sleepMs(2000 * n)) break;  // backoff: 2 s, 4 s
    }
    if (!mInstalled && !mStop.load()) st.phase.store(st.hkRender.load() ? Phase::Active : Phase::Failed);  
    mWatcherStarted.store(false);
  }

  void uiLoop() {
    icons::start();  
    int64_t lastSave = 0;
    std::string lastSnapshot;
    int64_t lastLog = 0;
    while (!mStop.load()) {
      ui::frame();
      if (nowMs() - lastLog > 2000) {
        lastLog = nowMs();
        ep::flushLog();
        retireOldMods();  
        
        
        if (!mMenuOk.load() && mMenuTries < kMenuRetries) {
          ++mMenuTries;
          pl::modmenu::unregisterModule(kModuleId);
          registerMenu();
          applyButtonMode();  
          if (!mMenuOk.load() && mMenuTries == kMenuRetries)
            mSelf.getLogger().warn("menu registration rejected {} times: stopped retrying", kMenuRetries);
        }
        perf::setEnabled(settings().perfLog.load());
      }
      {
        char line[640];
        if (perf::takeLine(line, sizeof(line))) mSelf.getLogger().info("{}", line);
      }
      
      if (nowMs() - lastSave > 2000) {
        lastSave = nowMs();
        std::string text = settingsText();
        if (text != lastSnapshot) {
          if (!lastSnapshot.empty()) writeSettings(text);
          lastSnapshot = std::move(text);
        }
      }
      
      ui::waitFrame(ui::isOpen() ? 33 : 100);
    }
    mUiStarted.store(false);
  }

  
  
  void applyButtonMode() {
    const bool own = mOwnButtons.load() && mMenuOk.load();
    hudbtn::setActive(own);
    if (own) {
      pl::modmenu::unregisterButton(kBtnPanel);  
      pl::modmenu::unregisterButton(kBtnEasyPlace);
    } else {
      registerPanelButton();
      registerEasyPlaceButton();
    }
    mSelf.getLogger().info("ST/EP buttons: {}", own ? "drawn in the HUD" : "launcher buttons");
  }

  
  void registerPanelButton() {
    (void)pl::modmenu::ButtonBuilder(kBtnPanel, "Structura")
        .moduleId(kModuleId)
        .modId(mSelf.getId())
        .label("ST")
        .behavior(pl::modmenu::ButtonBehavior::Click)
        .stylePreset(pl::modmenu::ButtonStylePreset::Accent)
        .sizeScale(0.75f, 0.75f)
        .onEvent([](std::string_view, pl::modmenu::ButtonEvent ev, float) {
          if (ev == pl::modmenu::ButtonEvent::Click) togglePanel();
        })
        .registerButton();
  }

  void registerEasyPlaceButton() {
    (void)pl::modmenu::ButtonBuilder(kBtnEasyPlace, "Easy Place")
        .moduleId(kModuleId)
        .modId(mSelf.getId())
        .label("EP")
        .behavior(pl::modmenu::ButtonBehavior::Click)
        .stylePreset(pl::modmenu::ButtonStylePreset::Accent)
        .sizeScale(0.7f, 0.7f)
        .onEvent([](std::string_view, pl::modmenu::ButtonEvent ev, float) {
          if (ev == pl::modmenu::ButtonEvent::Click) setEasyPlace(!ep::state().enabled.load());
        })
        .registerButton();
  }

  
  
  void migrateFromSchematica(const std::string &dir) {
    namespace fs = std::filesystem;
    std::error_code ec;
    const fs::path marker = fs::path(dir) / ".migrated";
    if (fs::exists(marker, ec)) return;
    const fs::path self = mSelf.getModDir();
    int copied = 0;
    for (const auto &d : fs::directory_iterator(self.parent_path(), ec)) {
      if (!d.is_directory(ec) || fs::equivalent(d.path(), self, ec)) continue;
      const fs::path old = d.path() / "config" / "structures";
      if (!fs::is_directory(old, ec)) continue;
      std::ifstream mf(d.path() / "manifest.json");
      const std::string m((std::istreambuf_iterator<char>(mf)), std::istreambuf_iterator<char>());
      if (m.find("\"Schematica\"") == std::string::npos && d.path().filename().string().find("chematica") == std::string::npos)
        continue;
      for (const auto &f : fs::directory_iterator(old, ec)) {
        const std::string n = f.path().filename().string();
        if (n.empty() || n[0] == '.' || n == "Exemplo - blocos.mcstructure" || f.path().extension() != ".mcstructure")
          continue;
        if (fs::copy_file(f.path(), fs::path(dir) / n, fs::copy_options::skip_existing, ec)) ++copied;
      }
      const fs::path oldSettings = d.path() / "config" / "settings.txt";
      if (!fs::exists(settingsPath(), ec) && fs::exists(oldSettings, ec)) {
        fs::copy_file(oldSettings, settingsPath(), ec);
        loadSettings();
      }
    }
    std::ofstream(marker) << copied;
    if (copied) mSelf.getLogger().info("migrated {} structures from Schematica", copied);
  }

  
  void registerMenu() {
    using pl::modmenu::ConfigType;
    const bool ok =
        pl::modmenu::ModuleBuilder(kModuleId, "Structura")
            .modId(mSelf.getId())
            .description(i18n::tr("menu.description"))  
            .defaultEnabled(true)
            .hideInHudEditor(!mOwnButtons.load())  
            .config("panelKey", i18n::tr("menu.key_panel"), ConfigType::Keybind, std::to_string(gPanelKey.load()))
            .config("easyPlaceKey", i18n::tr("menu.key_easy_place"), ConfigType::Keybind,
                    std::to_string(gEasyPlaceKey.load()))
            .onKeybind([](std::string_view, std::string_view key, bool isDown) {
              if (!isDown) return;
              if (key == "panelKey") togglePanel();
              else if (key == "easyPlaceKey") setEasyPlace(!ep::state().enabled.load());
            })
            .onToggle([](std::string_view, bool on) { hudbtn::setModuleOn(on); })
            .onConfigChanged([this](std::string_view, std::string_view key, std::string_view value) {
              if (applyKey(key, value)) saveSettings();
            })
            .registerModule();
    mMenuOk.store(ok);
    mSelf.getLogger().info("menu registered: {}", ok);
    if (ok) compat::set(compat::Comp::Gui, compat::State::Ok);
    else if (compat::get(compat::Comp::Gui).state != compat::State::Ok)
      compat::set(compat::Comp::Gui, compat::State::Limited, compat::Reason::MenuRejected);
  }
};

}  
}  

PL_REGISTER_MOD(lm::StructuraMod, lm::StructuraMod::instance())
