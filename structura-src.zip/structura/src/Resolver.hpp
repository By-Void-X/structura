#pragma once






#include <cstdint>
#include <string>
#include <vector>

#include "Compat.hpp"
#include "GameVersion.hpp"

namespace lm::rsv {

struct GameInfo {
  bool found = false;        
  uintptr_t base = 0;
  std::string buildId;       
  std::string version;       
  const char *tested = nullptr;  
  ver::GameVersion parsed;   
  std::string abi;           
  bool abiOk = false;        
};


bool refresh();
const GameInfo &game();  


void beginAttempt();

enum class Via : int { None = 0, TestedBuild, TestedBuildHooked, Signature, SignatureHooked };
struct Hit {
  uintptr_t addr = 0;
  Via via = Via::None;
  int matches = 0;                              
  compat::Reason why = compat::Reason::None;    
  explicit operator bool() const { return addr != 0; }
};





Hit find(const char *name, const char *pattern);
const char *viaText(Via v);


void markHook(const char *name, bool installed);
// RTTI helpers (game library segments only): `vt` is the primary vtable of the class with this mangled name.
bool vtableIs(uintptr_t vt, const char *mangled);
// LocalPlayer primary vtable: tested offset verified through RTTI, otherwise located through RTTI. 0 = unknown.
uintptr_t localPlayerVtable(std::string *how = nullptr);
// Primary vtable of any class by mangled RTTI name ("8GameMode"); `testedOff` is the verified offset on
// the tested build (0 = none). Ambiguous or missing RTTI returns 0.
uintptr_t classVtable(const char *mangled, uintptr_t testedOff, std::string *how = nullptr);
// `fn` is one of the first `maxSlots` entries of the vtable.
bool vtableContains(uintptr_t vt, uintptr_t fn, int maxSlots);

compat::Comp componentOf(const char *name);



std::string signatureLines();

compat::Reason componentFailure(compat::Comp c, std::string *detail = nullptr);


void resetForTest();
struct TestRegion { uintptr_t start, end; bool exec; };
void injectForTest(uintptr_t base, const std::vector<TestRegion> &regions, const char *buildId);

}  
