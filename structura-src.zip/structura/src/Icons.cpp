
#include "Icons.hpp"

#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <zlib.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include <nlohmann/json.hpp>

#include <pl/ModMenu.hpp>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_PNG
#define STBI_ONLY_TGA
#define STBI_NO_STDIO
#define STBI_NO_FAILURE_STRINGS
#define STBI_NO_THREAD_LOCALS
#define STBI_NO_LINEAR
#define STBI_NO_HDR
#define STBI_ASSERT(x) ((void)0)
#if defined(__clang__)
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-function"
#pragma clang diagnostic ignored "-Wunused-but-set-variable"
#endif
#include "../third_party/stb_image.h"
#if defined(__clang__)
#pragma clang diagnostic pop
#endif



extern "C" {
extern const uint8_t structura_block_pack[] __attribute__((weak));
extern const uint8_t structura_block_pack_end[] __attribute__((weak));
}

namespace icons {
namespace {

using json = nlohmann::json;


struct ZipEntry {
  uint32_t lho = 0, csize = 0, usize = 0;
  uint16_t method = 0;
};
struct Zip {
  int fd = -1;
  std::string path;
  const uint8_t *mem = nullptr;  
  uint64_t memSize = 0;
};
struct FileRef {
  int zip = -1;  
  ZipEntry e;
  std::string diskPath;
};

std::vector<Zip> gZips;
std::unordered_map<std::string, FileRef> gFiles;  
std::unordered_map<std::string, FileRef> gEmbeddedFiles;  
std::string gTestSource;

bool relevant(const std::string &rel) {
  if (rel.compare(0, 15, "resource_packs/") != 0) return false;
  
  if (rel.find("/textures/blocks/") != std::string::npos || rel.find("/textures/items/") != std::string::npos) return true;
  const auto ends = [&](const char *s) {
    const size_t n = std::strlen(s);
    return rel.size() >= n && rel.compare(rel.size() - n, n, s) == 0;
  };
  return ends("/blocks.json") || ends("/textures/terrain_texture.json");
}

bool preadAll(int fd, void *buf, size_t n, uint64_t off) {
  auto *p = static_cast<uint8_t *>(buf);
  while (n) {
    const ssize_t r = ::pread(fd, p, n, off_t(off));
    if (r <= 0) return false;
    p += r;
    n -= size_t(r);
    off += uint64_t(r);
  }
  return true;
}
uint16_t le16(const uint8_t *p) { return uint16_t(p[0] | (p[1] << 8)); }
uint32_t le32(const uint8_t *p) { return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24); }
bool zread(const Zip &z, void *buf, size_t n, uint64_t off) {
  if (z.mem) {
    if (off > z.memSize || n > z.memSize - off) return false;
    std::memcpy(buf, z.mem + off, n);
    return true;
  }
  return preadAll(z.fd, buf, n, off);
}


bool indexZipCore(Zip z, uint64_t size) {
  if (size < 22) return false;
  const size_t tail = size_t(std::min<uint64_t>(size, 65557));
  std::vector<uint8_t> t(tail);
  if (!zread(z, t.data(), tail, size - tail)) return false;
  long eocd = -1;
  for (long i = long(tail) - 22; i >= 0; --i)
    if (le32(&t[size_t(i)]) == 0x06054b50) { eocd = i; break; }
  if (eocd < 0) return false;
  const uint32_t cdSize = le32(&t[size_t(eocd) + 12]), cdOff = le32(&t[size_t(eocd) + 16]);
  if (cdOff == 0xffffffffu || uint64_t(cdOff) + cdSize > size || cdSize > (64u << 20)) return false;
  std::vector<uint8_t> cd(cdSize);
  if (!zread(z, cd.data(), cdSize, cdOff)) return false;
  const int zi = int(gZips.size());
  size_t added = 0;
  for (size_t p = 0; p + 46 <= cd.size();) {
    if (le32(&cd[p]) != 0x02014b50) break;
    const uint16_t method = le16(&cd[p + 10]);
    const uint32_t csize = le32(&cd[p + 20]), usize = le32(&cd[p + 24]);
    const uint16_t nlen = le16(&cd[p + 28]), xlen = le16(&cd[p + 30]), clen = le16(&cd[p + 32]);
    const uint32_t lho = le32(&cd[p + 42]);
    if (p + 46 + nlen > cd.size()) break;
    std::string name(reinterpret_cast<const char *>(&cd[p + 46]), nlen);
    p += 46 + size_t(nlen) + xlen + clen;
    if (name.compare(0, 7, "assets/") != 0) continue;
    std::string rel = name.substr(7);
    if (!relevant(rel) || (method != 0 && method != 8) || usize > (16u << 20)) continue;
    FileRef f;
    f.zip = zi;
    f.e = ZipEntry{lho, csize, usize, method};
    gFiles[rel] = f;  
    ++added;
  }
  if (!added) return false;
  gZips.push_back(std::move(z));
  return true;
}

bool indexZip(const std::string &path) {
  const int fd = ::open(path.c_str(), O_RDONLY | O_CLOEXEC);
  if (fd < 0) return false;
  struct stat st {};
  Zip z;
  z.fd = fd;
  z.path = path;
  if (::fstat(fd, &st) != 0 || !indexZipCore(z, uint64_t(st.st_size))) { ::close(fd); return false; }
  return true;
}


bool indexEmbedded() {
  const uint8_t *begin = structura_block_pack, *end = structura_block_pack_end;
  if (!begin || !end || end <= begin) return false;
  Zip z;
  z.path = "<embedded>";
  z.mem = begin;
  z.memSize = uint64_t(end - begin);
  return indexZipCore(z, z.memSize);
}

void indexDir(const std::string &root, const std::string &rel) {
  DIR *d = ::opendir((root + "/" + rel).c_str());
  if (!d) return;
  while (dirent *e = ::readdir(d)) {
    const std::string n = e->d_name;
    if (n == "." || n == "..") continue;
    const std::string r = rel + "/" + n;
    struct stat st {};
    if (::stat((root + "/" + r).c_str(), &st) != 0) continue;
    if (S_ISDIR(st.st_mode)) {
      
      if (rel == "resource_packs" && n.compare(0, 7, "vanilla") != 0) continue;
      indexDir(root, r);
    } else if (relevant(r)) {
      FileRef f;
      f.diskPath = root + "/" + r;
      gFiles[r] = f;
    }
  }
  ::closedir(d);
}

bool readRef(const FileRef &f, std::string &out) {
  if (f.zip < 0) {
    FILE *fp = std::fopen(f.diskPath.c_str(), "rb");
    if (!fp) return false;
    out.clear();
    char buf[65536];
    size_t n;
    while ((n = std::fread(buf, 1, sizeof(buf), fp)) > 0) out.append(buf, n);
    std::fclose(fp);
    return true;
  }
  const Zip &z = gZips[size_t(f.zip)];
  uint8_t lh[30];
  if (!zread(z, lh, 30, f.e.lho) || le32(lh) != 0x04034b50) return false;
  const uint64_t data = uint64_t(f.e.lho) + 30 + le16(lh + 26) + le16(lh + 28);
  std::string comp(f.e.csize, '\0');
  if (f.e.csize && !zread(z, comp.data(), f.e.csize, data)) return false;
  if (f.e.method == 0) { out = std::move(comp); return true; }
  out.assign(f.e.usize, '\0');
  z_stream zs{};
  if (inflateInit2(&zs, -MAX_WBITS) != Z_OK) return false;
  zs.next_in = reinterpret_cast<Bytef *>(comp.data());
  zs.avail_in = uInt(comp.size());
  zs.next_out = reinterpret_cast<Bytef *>(out.data());
  zs.avail_out = uInt(out.size());
  const int r = inflate(&zs, Z_FINISH);
  inflateEnd(&zs);
  return r == Z_STREAM_END && zs.total_out == out.size();
}
bool readRel(const std::string &rel, std::string &out) {
  if (const auto it = gFiles.find(rel); it != gFiles.end() && readRef(it->second, out)) return true;
  if (const auto it = gEmbeddedFiles.find(rel); it != gEmbeddedFiles.end() && readRef(it->second, out)) return true;
  return false;
}


void findSources() {
  std::set<std::string> apks, dirs;
  auto dirOf = [](const std::string &p) { const auto k = p.rfind('/'); return k == std::string::npos ? std::string() : p.substr(0, k); };
  if (FILE *fp = std::fopen("/proc/self/maps", "r")) {
    char line[1024];
    while (std::fgets(line, sizeof(line), fp)) {
      const char *sl = std::strchr(line, '/');
      if (!sl) continue;
      std::string p(sl);
      while (!p.empty() && (p.back() == '\n' || p.back() == ' ')) p.pop_back();
      const auto bang = p.find(".apk!/");
      if (bang != std::string::npos) { apks.insert(p.substr(0, bang + 4)); continue; }
      if (p.size() > 4 && p.compare(p.size() - 4, 4, ".apk") == 0) apks.insert(p);
      if (p.find("libminecraftpe.so") != std::string::npos) {
        std::string d = dirOf(p);
        for (int i = 0; i < 4 && !d.empty(); ++i, d = dirOf(d)) dirs.insert(d);
      }
    }
    std::fclose(fp);
  }
  if (DIR *d = ::opendir("/proc/self/fd")) {
    while (dirent *e = ::readdir(d)) {
      char buf[512];
      const std::string l = std::string("/proc/self/fd/") + e->d_name;
      const ssize_t n = ::readlink(l.c_str(), buf, sizeof(buf) - 1);
      if (n <= 4) continue;
      std::string p(buf, size_t(n));
      if (p.compare(p.size() - 4, 4, ".apk") == 0) apks.insert(p);
    }
    ::closedir(d);
  }
  
  std::set<std::string> scan = dirs;
  for (const auto &a : apks) scan.insert(dirOf(a));
  for (const auto &s : scan) {
    if (DIR *d = ::opendir(s.c_str())) {
      while (dirent *e = ::readdir(d)) {
        const std::string n = e->d_name;
        if (n.size() > 4 && n.compare(n.size() - 4, 4, ".apk") == 0) apks.insert(s + "/" + n);
      }
      ::closedir(d);
    }
  }
  
  std::vector<std::string> order(apks.begin(), apks.end());
  std::stable_sort(order.begin(), order.end(), [](const std::string &a, const std::string &b) {
    return (a.find("base.apk") != std::string::npos) > (b.find("base.apk") != std::string::npos);
  });
  for (const auto &a : order) indexZip(a);
  for (const auto &d : dirs) {
    struct stat st {};
    if (::stat((d + "/assets/resource_packs").c_str(), &st) == 0 && S_ISDIR(st.st_mode)) indexDir(d + "/assets", "resource_packs");
  }
}


struct TexRef {
  std::string path;  
  uint32_t tint = 0, overlay = 0;  
};
struct Faces {
  std::string up, side, east;  
};

std::vector<std::string> gPacks;  
std::unordered_map<std::string, Faces> gBlocks;
std::unordered_map<std::string, std::vector<TexRef>> gTerrain;  
std::atomic<int> gState{0};  

int cmpVersion(const std::string &a, const std::string &b) {  
  size_t i = 0, j = 0;
  while (i < a.size() && j < b.size()) {
    if (std::isdigit(uint8_t(a[i])) && std::isdigit(uint8_t(b[j]))) {
      long x = 0, y = 0;
      while (i < a.size() && std::isdigit(uint8_t(a[i]))) x = x * 10 + (a[i++] - '0');
      while (j < b.size() && std::isdigit(uint8_t(b[j]))) y = y * 10 + (b[j++] - '0');
      if (x != y) return x < y ? -1 : 1;
    } else {
      if (a[i] != b[j]) return a[i] < b[j] ? -1 : 1;
      ++i;
      ++j;
    }
  }
  return a.size() == b.size() ? 0 : (a.size() < b.size() ? -1 : 1);
}

uint32_t parseColor(const json &v) {
  if (!v.is_string()) return 0;
  std::string s = v.get<std::string>();
  if (!s.empty() && s[0] == '#') s.erase(0, 1);
  if (s.size() == 8) s.erase(0, 2);  
  if (s.size() != 6) return 0;
  return (uint32_t(std::strtoul(s.c_str(), nullptr, 16)) & 0xFFFFFF) | 0x01000000u;
}
TexRef texOne(const json *v) {
  TexRef r;
  if (v->is_string()) {
    r.path = v->get<std::string>();
  } else if (v->is_object()) {
    if (v->contains("path") && (*v)["path"].is_string()) r.path = (*v)["path"].get<std::string>();
    if (v->contains("tint_color")) r.tint = parseColor((*v)["tint_color"]);
    if (v->contains("overlay_color")) r.overlay = parseColor((*v)["overlay_color"]);
  }
  return r;
}

std::vector<TexRef> texOf(const json &t) {
  std::vector<TexRef> out;
  if (t.is_array()) {
    for (const auto &e : t) {
      TexRef r = texOne(&e);
      if (!r.path.empty()) out.push_back(std::move(r));
    }
  } else {
    TexRef r = texOne(&t);
    if (!r.path.empty()) out.push_back(std::move(r));
  }
  return out;
}
std::string faceName(const json &tex, const char *k1, const char *k2 = nullptr, const char *k3 = nullptr) {
  if (tex.is_string()) return tex.get<std::string>();
  if (!tex.is_object()) return {};
  for (const char *k : {k1, k2, k3})
    if (k && tex.contains(k) && tex[k].is_string()) return tex[k].get<std::string>();
  for (auto it = tex.begin(); it != tex.end(); ++it)
    if (it.value().is_string()) return it.value().get<std::string>();
  return {};
}

void buildIndex() {
  if (indexEmbedded()) gEmbeddedFiles = gFiles;  
  if (!gTestSource.empty()) {
    struct stat st {};
    if (::stat(gTestSource.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) indexDir(gTestSource, "resource_packs");
    else indexZip(gTestSource);
  } else {
    findSources();
  }
  std::set<std::string> packs;
  for (const auto &kv : gFiles) {
    const std::string &r = kv.first;
    const size_t a = 15, b = r.find('/', a);
    if (b == std::string::npos) continue;
    const std::string p = r.substr(a, b - a);
    if (p.compare(0, 7, "vanilla") == 0) packs.insert(p);
  }
  std::vector<std::string> ord(packs.begin(), packs.end());
  std::sort(ord.begin(), ord.end(), [](const std::string &x, const std::string &y) {
    if (x == "vanilla" || y == "vanilla") return x == "vanilla" && y != "vanilla";
    return cmpVersion(x, y) < 0;
  });
  
  for (const auto &p : ord) {
    std::string txt;
    if (readRel("resource_packs/" + p + "/textures/terrain_texture.json", txt)) {
      const json j = json::parse(txt, nullptr, false, true);
      if (j.is_object() && j.contains("texture_data") && j["texture_data"].is_object())
        for (auto it = j["texture_data"].begin(); it != j["texture_data"].end(); ++it)
          if (it.value().is_object() && it.value().contains("textures")) {
            std::vector<TexRef> r = texOf(it.value()["textures"]);
            if (!r.empty()) gTerrain[it.key()] = std::move(r);
          }
    }
    if (readRel("resource_packs/" + p + "/blocks.json", txt)) {
      const json j = json::parse(txt, nullptr, false, true);
      if (j.is_object())
        for (auto it = j.begin(); it != j.end(); ++it) {
          const json &v = it.value();
          if (!v.is_object()) continue;
          const json *tex = nullptr;
          if (v.contains("carried_textures")) tex = &v["carried_textures"];
          else if (v.contains("textures")) tex = &v["textures"];
          if (!tex) continue;
          Faces f;
          f.up = faceName(*tex, "up", "side", "north");
          f.side = faceName(*tex, "side", "south", "north");
          f.east = faceName(*tex, "east", "side", "west");
          if (f.side.empty()) f.side = f.up;
          if (f.up.empty()) f.up = f.side;
          if (f.east.empty()) f.east = f.side;
          if (!f.up.empty()) gBlocks[it.key()] = f;
        }
    }
  }
  gPacks.assign(ord.rbegin(), ord.rend());
}


struct Img {
  int w = 0;  
  std::vector<uint8_t> px;
  float clear = 0.f;  
};
std::map<std::string, std::shared_ptr<Img>> gTexCache;

std::shared_ptr<Img> loadTex(const TexRef &t) {
  const std::string key = t.path + "|" + std::to_string(t.tint) + "|" + std::to_string(t.overlay);
  if (auto it = gTexCache.find(key); it != gTexCache.end()) return it->second;
  std::shared_ptr<Img> out;
  for (const auto &p : gPacks) {
    std::string bytes;
    if (!readRel("resource_packs/" + p + "/" + t.path + ".png", bytes) &&
        !readRel("resource_packs/" + p + "/" + t.path + ".tga", bytes))
      continue;
    int w = 0, h = 0, n = 0;
    stbi_uc *d = stbi_load_from_memory(reinterpret_cast<const stbi_uc *>(bytes.data()), int(bytes.size()), &w, &h, &n, 4);
    if (!d) continue;
    if (w > 0 && h >= w && w <= 512) {
      auto im = std::make_shared<Img>();
      im->w = w;
      im->px.assign(d, d + size_t(w) * w * 4);  
      int clear = 0;
      for (int i = 0; i < w * w; ++i) {
        uint8_t *q = &im->px[size_t(i) * 4];
        if (t.overlay) {  
          const float k = q[3] / 255.f;
          const uint32_t c = t.overlay;
          q[0] = uint8_t(q[0] * (1 - k) + q[0] * ((c >> 16) & 255) / 255.f * k);
          q[1] = uint8_t(q[1] * (1 - k) + q[1] * ((c >> 8) & 255) / 255.f * k);
          q[2] = uint8_t(q[2] * (1 - k) + q[2] * (c & 255) / 255.f * k);
          q[3] = 255;
        } else if (t.tint) {
          q[0] = uint8_t(q[0] * ((t.tint >> 16) & 255) / 255);
          q[1] = uint8_t(q[1] * ((t.tint >> 8) & 255) / 255);
          q[2] = uint8_t(q[2] * (t.tint & 255) / 255);
        }
        if (q[3] < 128) ++clear;
      }
      im->clear = float(clear) / float(w * w);
      out = im;
    }
    stbi_image_free(d);
    if (out) break;
  }
  gTexCache[key] = out;
  return out;
}


uint32_t biomeTint(const std::string &n) {
  static const char *kGreen[] = {"leaves", "vine", "tallgrass", "short_grass", "tall_grass", "fern", "waterlily", "lily_pad"};
  for (const char *k : kGreen)
    if (n.find(k) != std::string::npos) return 0x0177AB2F;
  
  if (n == "water" || n == "flowing_water") return 0x013F76E4;
  if (n == "redstone_wire") return 0x01E01010;
  return 0;
}

std::string alias(std::string n) {
  static const std::map<std::string, std::string> kAlias = {
      {"grass_block", "grass"}, {"sea_lantern", "seaLantern"}, {"iron_chain", "chain"}, {"trip_wire", "tripWire"},
      {"underwater_torch", "torch"}, {"underwater_tnt", "tnt"}};
  if (auto it = kAlias.find(n); it != kAlias.end()) return it->second;
  if (n.compare(0, 5, "hard_") == 0) return n.substr(5);
  if (n.compare(0, 13, "colored_torch") == 0) return "torch";
  return n;
}

std::vector<std::string> tokens(const std::string &s) {
  std::vector<std::string> t;
  std::string cur;
  for (char c : s) {
    if (c == '_' || c == '/' || c == '.') {
      if (!cur.empty()) t.push_back(cur), cur.clear();
    } else {
      cur += char(std::tolower(uint8_t(c)));
    }
  }
  if (!cur.empty()) t.push_back(cur);
  return t;
}
bool tokenMatch(const std::string &a, const std::string &b) {
  if (a == b) return true;
  if ((a == "silver" && b == "gray") || (a == "gray" && b == "silver")) return true;  
  const size_t n = std::min(a.size(), b.size());
  return n >= 4 && a.compare(0, n, b, 0, n) == 0;  
}

const TexRef &pickVariant(const std::vector<TexRef> &v, const std::string &block) {
  if (v.size() == 1) return v[0];
  std::vector<std::string> bt = tokens(block);
  for (size_t i = 0; i + 1 < bt.size(); ++i)
    if (bt[i] == "light" && bt[i + 1] == "gray") bt[i + 1] = "silver";
  size_t best = 0;
  int bestScore = -1000000;
  for (size_t i = 0; i < v.size(); ++i) {
    std::string stem = v[i].path;
    if (const auto k = stem.rfind('/'); k != std::string::npos) stem = stem.substr(k + 1);
    const std::vector<std::string> vt = tokens(stem);
    int matched = 0, extra = 0;
    for (const auto &a : bt)
      for (const auto &b : vt)
        if (tokenMatch(a, b)) { ++matched; break; }
    for (const auto &b : vt) {
      bool used = false;
      for (const auto &a : bt)
        if (tokenMatch(a, b)) { used = true; break; }
      extra += !used;
    }
    const int score = matched * 10 - extra;
    
    const bool stage = stem.find("stage") != std::string::npos;
    if (score > bestScore || (score == bestScore && stage)) bestScore = score, best = i;
  }
  return v[best];
}

bool resolveFaces(const std::string &shortName, TexRef &up, TexRef &side, TexRef &east) {
  const std::string n = alias(shortName);
  auto ref = [&](const std::string &tn, TexRef &out) {
    auto it = gTerrain.find(tn);
    if (it == gTerrain.end() || it->second.empty()) return false;
    out = pickVariant(it->second, n);
    return true;
  };
  if (auto it = gBlocks.find(n); it != gBlocks.end()) {
    if (!ref(it->second.up, up)) return false;
    if (!ref(it->second.side, side)) side = up;
    if (!ref(it->second.east, east)) east = side;
  } else if (ref(n, up)) {
    side = east = up;
  } else {
    up.path = "textures/blocks/" + n;
    side = east = up;
  }
  if (const uint32_t g = biomeTint(n)) {
    for (TexRef *t : {&up, &side, &east})
      if (!t->tint && !t->overlay && t->path.find("carried") == std::string::npos) t->tint = g;
  }
  return true;
}

void sample(const Img &im, float u, float v, float shade, float acc[4]) {
  const int x = std::clamp(int(u * im.w), 0, im.w - 1), y = std::clamp(int(v * im.w), 0, im.w - 1);
  const uint8_t *q = &im.px[(size_t(y) * im.w + x) * 4];
  if (q[3] < 100) return;
  acc[0] += q[0] * shade;
  acc[1] += q[1] * shade;
  acc[2] += q[2] * shade;
  acc[3] += 255.f;
}

bool renderIcon(const std::string &fullName, std::vector<uint8_t> &out) {
  std::string n = fullName;
  if (const auto k = n.find(':'); k != std::string::npos) n = n.substr(k + 1);
  TexRef tu, ts, te;
  if (!resolveFaces(n, tu, ts, te)) return false;
  const auto up = loadTex(tu);
  if (!up) return false;
  auto side = loadTex(ts), east = loadTex(te);
  if (!side) side = up;
  if (!east) east = side;
  const int N = kSize;
  out.assign(size_t(N) * N * 4, 0);
  
  const bool door = n.size() >= 4 && n.compare(n.size() - 4, 4, "door") == 0 && n.find("trapdoor") == std::string::npos;
  constexpr int SS = 3;  
  if (door) {
    const Img &lower = *up, &upper = *side;  
    const float m = 3.f, hgt = N - 2 * m, wid = hgt * 0.5f, x0 = (N - wid) * 0.5f;
    for (int y = 0; y < N; ++y)
      for (int x = 0; x < N; ++x) {
        float acc[4] = {0, 0, 0, 0};
        for (int sy = 0; sy < SS; ++sy)
          for (int sx = 0; sx < SS; ++sx) {
            const float u = (x + (sx + 0.5f) / SS - x0) / wid, v = (y + (sy + 0.5f) / SS - m) / hgt;
            if (u < 0 || u >= 1 || v < 0 || v >= 1) continue;
            if (v < 0.5f) sample(upper, u, v * 2.f, 1.f, acc);
            else sample(lower, u, v * 2.f - 1.f, 1.f, acc);
          }
        uint8_t *o = &out[(size_t(y) * N + x) * 4];
        if (acc[3] > 0) {
          const float k = 255.f / acc[3];
          o[0] = uint8_t(std::min(255.f, acc[0] * k));
          o[1] = uint8_t(std::min(255.f, acc[1] * k));
          o[2] = uint8_t(std::min(255.f, acc[2] * k));
          o[3] = uint8_t(acc[3] / (SS * SS));
        }
      }
    return true;
  }
  const bool cube = side->clear < 0.25f || n.find("glass") != std::string::npos || n.find("leaves") != std::string::npos;
  if (!cube) {  
    const float m = 4.f, s = N - 2 * m;
    for (int y = 0; y < N; ++y)
      for (int x = 0; x < N; ++x) {
        float acc[4] = {0, 0, 0, 0};
        for (int sy = 0; sy < SS; ++sy)
          for (int sx = 0; sx < SS; ++sx) {
            const float u = (x + (sx + 0.5f) / SS - m) / s, v = (y + (sy + 0.5f) / SS - m) / s;
            if (u >= 0 && u < 1 && v >= 0 && v < 1) sample(*side, u, v, 1.f, acc);
          }
        uint8_t *o = &out[(size_t(y) * N + x) * 4];
        if (acc[3] > 0) {
          const float k = 255.f / acc[3];
          o[0] = uint8_t(std::min(255.f, acc[0] * k));
          o[1] = uint8_t(std::min(255.f, acc[1] * k));
          o[2] = uint8_t(std::min(255.f, acc[2] * k));
          o[3] = uint8_t(acc[3] / (SS * SS));
        }
      }
    return true;
  }
  
  float h = 1.f;
  if (n.find("slab") != std::string::npos && n.find("double") == std::string::npos) h = 0.5f;
  else if (n.find("carpet") != std::string::npos || n.find("pressure_plate") != std::string::npos) h = 0.0625f;
  else if (n == "snow_layer") h = 0.125f;
  else if (n.find("trapdoor") != std::string::npos) h = 0.1875f;
  const float hw = 19.f, hh = hw * 0.57735f, vh = hw * 1.1547f;
  const float cx = N * 0.5f, oy = (N - (vh + 2 * hh)) * 0.5f + vh;  
  for (int y = 0; y < N; ++y)
    for (int x = 0; x < N; ++x) {
      float acc[4] = {0, 0, 0, 0};
      for (int sy = 0; sy < SS; ++sy)
        for (int sx = 0; sx < SS; ++sx) {
          const float X = x + (sx + 0.5f) / SS - cx, Y = y + (sy + 0.5f) / SS - oy;
          
          const float a = X / hw, b = (Y + h * vh) / hh;
          const float bx = (a + b) * 0.5f, bz = (b - a) * 0.5f;
          if (bx >= 0 && bx <= 1 && bz >= 0 && bz <= 1) { sample(*up, bx, bz, 1.f, acc); continue; }
          if (X >= 0) {  
            const float z = 1 - X / hw, yy = ((1 + z) * hh - Y) / vh;
            if (z >= 0 && z <= 1 && yy >= 0 && yy <= h) sample(*east, 1 - z, 1 - yy, 0.62f, acc);
          } else {  
            const float xx = 1 + X / hw, yy = ((xx + 1) * hh - Y) / vh;
            if (xx >= 0 && xx <= 1 && yy >= 0 && yy <= h) sample(*side, xx, 1 - yy, 0.82f, acc);
          }
        }
      uint8_t *o = &out[(size_t(y) * N + x) * 4];
      if (acc[3] > 0) {
        const float k = 255.f / acc[3];
        o[0] = uint8_t(std::min(255.f, acc[0] * k));
        o[1] = uint8_t(std::min(255.f, acc[1] * k));
        o[2] = uint8_t(std::min(255.f, acc[2] * k));
        o[3] = uint8_t(acc[3] / (SS * SS));
      }
    }
  return true;
}

std::mutex gMu;
std::unordered_map<std::string, std::string> gIds;  

}  

void setSourceForTest(const std::string &path) { gTestSource = path; }

void start() {
  int expected = 0;
  if (!gState.compare_exchange_strong(expected, 1)) return;
  std::thread([] {
    try {
      buildIndex();
      gState.store(gBlocks.empty() && gTerrain.empty() ? 3 : 2);
    } catch (...) {
      gState.store(3);
    }
  }).detach();
}

bool renderForTest(const std::string &blockName, std::string &rgba) {
  if (gState.load() == 0) { gState.store(1); buildIndex(); gState.store(2); }
  std::vector<uint8_t> px;
  if (!renderIcon(blockName, px)) return false;
  rgba.assign(px.begin(), px.end());
  return true;
}

std::string iconFor(const std::string &blockName) {
  if (gState.load(std::memory_order_acquire) != 2) {
    start();
    return {};
  }
  std::lock_guard<std::mutex> lk(gMu);
  if (auto it = gIds.find(blockName); it != gIds.end()) return it->second;
  
  static int built = 0;
  static auto windowStart = std::chrono::steady_clock::now();
  const auto now = std::chrono::steady_clock::now();
  if (now - windowStart > std::chrono::milliseconds(30)) { windowStart = now; built = 0; }
  if (built >= 4) return {};
  ++built;
  std::string id;
  try {
    std::vector<uint8_t> px;
    if (renderIcon(blockName, px)) {
      
      for (size_t i = 0; i + 3 < px.size(); i += 4) {
        const unsigned a = px[i + 3];
        if (a == 255) continue;
        px[i] = uint8_t(px[i] * a / 255);
        px[i + 1] = uint8_t(px[i + 1] * a / 255);
        px[i + 2] = uint8_t(px[i + 2] * a / 255);
      }
      id = "st.ic." + blockName;
      if (!pl::modmenu::registerImage(id, px, kSize, kSize)) id.clear();
    }
  } catch (...) {
    id.clear();
  }
  gIds[blockName] = id;
  return id;
}

}  
