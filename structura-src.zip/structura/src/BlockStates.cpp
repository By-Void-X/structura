#include "BlockStates.hpp"

#include <cctype>
#include <cstring>
#include <string_view>

#include "Nbt.hpp"

namespace lm::states {
namespace {

const char *const kCard[4] = {"north", "east", "south", "west"};
int cardOf(const std::string &v) {
  for (int k = 0; k < 4; ++k)
    if (v == kCard[k]) return k;
  return -1;
}
bool has(const std::string &s, const char *part) { return s.find(part) != std::string::npos; }
bool startsWith(const std::string &s, const char *p) { return s.rfind(p, 0) == 0; }
bool endsWith(const std::string &s, const char *p) {
  const size_t n = std::strlen(p);
  return s.size() >= n && std::string_view(s).substr(s.size() - n) == std::string_view(p, n);
}

// Integer direction tables: value -> cardinal index.
struct IntDir {
  int n;
  int toC[6];
};
constexpr IntDir kDoorDir{4, {1, 2, 3, 0}};      // 0 east 1 south 2 west 3 north
constexpr IntDir kTrapdoorDir{4, {1, 3, 2, 0}};  // 0 east 1 west 2 south 3 north
constexpr IntDir kGenericDir{4, {2, 3, 0, 1}};   // 0 south 1 west 2 north 3 east
constexpr IntDir kStairDir{4, {1, 3, 2, 0}};     // 0 east 1 west 2 south 3 north
constexpr IntDir kCoralDir{4, {3, 1, 0, 2}};     // 0 west 1 east 2 north 3 south

int fromCard(const IntDir &t, int c) {
  for (int i = 0; i < t.n; ++i)
    if (t.toC[i] == c) return i;
  return -1;
}
int turnIntDir(const IntDir &t, int v, int rot, bool mirror) {
  if (v < 0 || v >= t.n) return v;
  const int r = fromCard(t, transformFacing(t.toC[v], rot, mirror));
  return r >= 0 ? r : v;
}
const IntDir &directionTable(const std::string &name) {
  if (has(name, "trapdoor")) return kTrapdoorDir;
  if (isDoorName(name)) return kDoorDir;
  return kGenericDir;
}
int turnBits(int v, const int bitOf[4], int rot, bool mirror) {
  int keep = v, out = 0;
  for (int c = 0; c < 4; ++c) keep &= ~bitOf[c];
  for (int c = 0; c < 4; ++c)
    if (v & bitOf[c]) out |= bitOf[transformFacing(c, rot, mirror)];
  return keep | out;
}

struct KeyRule {
  const char *key;
  Cls cls;
  Tf tf;
};
// Bedrock block state keys (1.21-1.26). Keys missing here are Unknown: compared, never transformed.
constexpr KeyRule kRules[] = {
    // orientation set by the placement
    {"minecraft:cardinal_direction", Cls::Placement, Tf::Cardinal},
    {"minecraft:facing_direction", Cls::Placement, Tf::Facing6Str},
    {"minecraft:block_face", Cls::Placement, Tf::Facing6Str},
    {"facing_direction", Cls::Placement, Tf::Facing6Int},
    {"facing", Cls::Placement, Tf::Facing6Str},
    {"direction", Cls::Placement, Tf::DirByName},
    {"weirdo_direction", Cls::Placement, Tf::DirStair},
    {"coral_direction", Cls::Placement, Tf::DirCoral},
    {"pillar_axis", Cls::Placement, Tf::Axis},
    {"portal_axis", Cls::Placement, Tf::Axis},
    {"ground_sign_direction", Cls::Placement, Tf::Sign16},
    {"torch_facing_direction", Cls::Placement, Tf::Torch},
    {"lever_direction", Cls::Placement, Tf::Lever},
    {"orientation", Cls::Placement, Tf::Orientation},
    {"vine_direction_bits", Cls::Placement, Tf::VineBits},
    {"multi_face_direction_bits", Cls::Placement, Tf::FaceBits},
    {"upside_down_bit", Cls::Placement, Tf::None},
    {"top_slot_bit", Cls::Placement, Tf::None},
    {"minecraft:vertical_half", Cls::Placement, Tf::None},
    {"hanging", Cls::Placement, Tf::None},
    {"attachment", Cls::Placement, Tf::None},
    {"coral_hang_type_bit", Cls::Placement, Tf::None},
    // decided by the game while placing
    {"door_hinge_bit", Cls::GameDecided, Tf::Hinge},
    {"rail_direction", Cls::GameDecided, Tf::Rail},
    {"huge_mushroom_bits", Cls::GameDecided, Tf::Mushroom},
    // multi-block parts
    {"upper_block_bit", Cls::Part, Tf::None},
    {"head_piece_bit", Cls::Part, Tf::None},
    // changed by tapping the placed block
    {"repeater_delay", Cls::Interaction, Tf::None},
    {"output_subtract_bit", Cls::Interaction, Tf::None},
    // needs more items / tools
    {"candles", Cls::ItemUse, Tf::None},
    {"cluster_count", Cls::ItemUse, Tf::None},
    {"turtle_egg_count", Cls::ItemUse, Tf::None},
    {"height", Cls::ItemUse, Tf::None},
    {"extinguished", Cls::ItemUse, Tf::None},
    {"end_portal_eye_bit", Cls::ItemUse, Tf::None},
    {"respawn_anchor_charge", Cls::ItemUse, Tf::None},
    {"composter_fill_level", Cls::ItemUse, Tf::None},
    {"fill_level", Cls::ItemUse, Tf::None},
    {"cauldron_liquid", Cls::ItemUse, Tf::None},
    {"bite_counter", Cls::ItemUse, Tf::None},
    // computed by the game
    {"wall_post_bit", Cls::Generated, Tf::None},
    {"in_wall_bit", Cls::Generated, Tf::None},
    {"redstone_signal", Cls::Generated, Tf::None},
    {"powered_bit", Cls::Generated, Tf::None},
    {"button_pressed_bit", Cls::Generated, Tf::None},
    {"output_lit_bit", Cls::Generated, Tf::None},
    {"triggered_bit", Cls::Generated, Tf::None},
    {"toggle_bit", Cls::Generated, Tf::None},
    {"rail_data_bit", Cls::Generated, Tf::None},
    {"age", Cls::Generated, Tf::None},
    {"age_bit", Cls::Generated, Tf::None},
    {"growth", Cls::Generated, Tf::None},
    {"kelp_age", Cls::Generated, Tf::None},
    {"twisting_vines_age", Cls::Generated, Tf::None},
    {"weeping_vines_age", Cls::Generated, Tf::None},
    {"growing_plant_age", Cls::Generated, Tf::None},
    {"propagule_stage", Cls::Generated, Tf::None},
    {"persistent_bit", Cls::Generated, Tf::None},
    {"update_bit", Cls::Generated, Tf::None},
    {"occupied_bit", Cls::Generated, Tf::None},
    {"dripstone_thickness", Cls::Generated, Tf::None},
    {"big_dripleaf_tilt", Cls::Generated, Tf::None},
    {"big_dripleaf_head", Cls::Generated, Tf::None},
    {"stability", Cls::Generated, Tf::None},
    {"stability_check", Cls::Generated, Tf::None},
    {"liquid_depth", Cls::Generated, Tf::None},
    {"moisturized_amount", Cls::Generated, Tf::None},
    {"books_stored", Cls::Generated, Tf::None},
    {"cracked_state", Cls::Generated, Tf::None},
    {"sculk_sensor_phase", Cls::Generated, Tf::None},
    {"active", Cls::Generated, Tf::None},
    {"can_summon", Cls::Generated, Tf::None},
    {"bloom", Cls::Generated, Tf::None},
    {"honey_level", Cls::Generated, Tf::None},
    {"dead_bit", Cls::Generated, Tf::None},
    {"explode_bit", Cls::Generated, Tf::None},
    {"allow_underwater_bit", Cls::Generated, Tf::None},
    {"infiniburn_bit", Cls::Generated, Tf::None},
    {"item_frame_map_bit", Cls::Generated, Tf::None},
    {"item_frame_photo_bit", Cls::Generated, Tf::None},
    {"crafting", Cls::Generated, Tf::None},
    {"trial_spawner_state", Cls::Generated, Tf::None},
    {"vault_state", Cls::Generated, Tf::None},
    {"ominous", Cls::Generated, Tf::None},
    {"creaking_heart_state", Cls::Generated, Tf::None},
    {"natural", Cls::Generated, Tf::None},
    {"brushed_progress", Cls::Generated, Tf::None},
    {"bamboo_leaf_size", Cls::Generated, Tf::None},
    {"bamboo_stalk_thickness", Cls::Generated, Tf::None},
    {"deprecated", Cls::Generated, Tf::None},
    {"tip", Cls::Generated, Tf::None},
    {"rehydration_level", Cls::Generated, Tf::None},
    // block identity (old palettes): must match, no transform
    {"stripped_bit", Cls::Placement, Tf::None},
    {"wood_type", Cls::Placement, Tf::None},
    {"stone_type", Cls::Placement, Tf::None},
    {"color", Cls::Placement, Tf::None},
    {"chisel_type", Cls::Placement, Tf::None},
    {"sapling_type", Cls::Placement, Tf::None},
    {"structure_block_type", Cls::Placement, Tf::None},
    {"structure_void_type", Cls::Placement, Tf::None},
};

const char *const kSidePrefixes[] = {"wall_connection_type_", "pale_moss_carpet_side_"};

int sideOf(const std::string &key, const char *prefix) {
  const size_t n = std::strlen(prefix);
  if (key.size() <= n || std::string_view(key).substr(0, n) != std::string_view(prefix, n)) return -1;
  return cardOf(key.substr(n));
}

}  // namespace

const char *clsName(Cls c) {
  static const char *k[] = {"placement", "game-decided", "interaction", "item-use", "part", "generated", "unknown"};
  const int i = int(c);
  return i >= 0 && i < int(Cls::Count) ? k[i] : "?";
}

Rule ruleFor(const std::string &key, const std::string &name, bool *known) {
  if (known) *known = true;
  for (const char *p : kSidePrefixes)
    if (sideOf(key, p) >= 0) return {Cls::Generated, Tf::SideKeys};
  if (startsWith(key, "brewing_stand_slot_")) return {Cls::Generated, Tf::None};
  // keys whose meaning depends on the block
  if (key == "open_bit") return {interactable(name) ? Cls::Interaction : Cls::Generated, Tf::None};
  if (key == "attached_bit") return {has(name, "hanging_sign") ? Cls::Placement : Cls::Generated, Tf::None};
  if (key == "lit") return {has(name, "candle") ? Cls::ItemUse : Cls::Generated, Tf::None};
  for (const auto &r : kRules)
    if (key == r.key) return {r.cls, r.tf};
  if (known) *known = false;
  return {Cls::Unknown, Tf::None};
}

bool looksDirectional(const std::string &key) {
  std::string k = key;
  for (char &c : k) c = char(std::tolower(static_cast<unsigned char>(c)));
  static const char *kHints[] = {"direction", "facing", "axis", "rotation", "orientation", "hinge", "attach",
                                 "north",     "south",  "east", "west",     "side",        "face"};
  for (const char *h : kHints)
    if (k.find(h) != std::string::npos) return true;
  return false;
}

// ---------------------------------------------------------------- primitives
int transformFacing(int c, int rot, bool mirror) {
  if (c < 0 || c > 3) return c;
  if (mirror && (c == 1 || c == 3)) c ^= 2;
  return (c + rot) & 3;
}
int turnCardinal(int c, int rot, bool mirror) { return transformFacing(c, rot, mirror); }

const char *transformFacingName(const std::string &v, int rot, bool mirror) {
  if (v == "up") return "up";
  if (v == "down") return "down";
  const int c = cardOf(v);
  return c >= 0 ? kCard[transformFacing(c, rot & 3, mirror)] : nullptr;
}

int transformFacing6(int v, int rot, bool mirror) {
  static const int toC[6] = {-1, -1, 0, 2, 3, 1}, fromC[4] = {2, 5, 3, 4};
  if (v < 2 || v > 5) return v;
  return fromC[transformFacing(toC[v], rot & 3, mirror)];
}

std::string transformAxis(const std::string &a, int rot, bool) {
  if (!(rot & 1)) return a;
  if (a == "x") return "z";
  if (a == "z") return "x";
  return a;
}

int transformRailShape(int v, int rot, bool mirror) {
  rot &= 3;
  static const int kAsc[4] = {4, 2, 5, 3};  // ascending north, east, south, west
  static const int kCurve[10][2] = {{-1, -1}, {-1, -1}, {-1, -1}, {-1, -1}, {-1, -1},
                                    {-1, -1}, {2, 1},   {2, 3},   {0, 3},   {0, 1}};
  if (v == 0 || v == 1) {
    const int c = transformFacing(v == 0 ? 0 : 1, rot, mirror);
    return (c == 0 || c == 2) ? 0 : 1;
  }
  if (v >= 2 && v <= 5) {
    for (int c = 0; c < 4; ++c)
      if (kAsc[c] == v) return kAsc[transformFacing(c, rot, mirror)];
    return v;
  }
  if (v >= 6 && v <= 9) {
    const int a = transformFacing(kCurve[v][0], rot, mirror), b = transformFacing(kCurve[v][1], rot, mirror);
    for (int k = 6; k <= 9; ++k)
      if ((kCurve[k][0] == a && kCurve[k][1] == b) || (kCurve[k][0] == b && kCurve[k][1] == a)) return k;
  }
  return v;
}

int transformSignRotation(int r, int rot, bool mirror) {
  int v = r & 15;
  if (mirror) v = (16 - v) & 15;
  return (v + 4 * (rot & 3)) & 15;
}

int transformDirection(const std::string &name, int v, int rot, bool mirror) {
  return turnIntDir(directionTable(name), v, rot & 3, mirror);
}
int transformStairDirection(int v, int rot, bool mirror) { return turnIntDir(kStairDir, v, rot & 3, mirror); }
int transformCoralDirection(int v, int rot, bool mirror) { return turnIntDir(kCoralDir, v, rot & 3, mirror); }
int transformVineBits(int v, int rot, bool mirror) {
  static const int bitOf[4] = {4, 8, 1, 2};
  return turnBits(v, bitOf, rot & 3, mirror);
}
int transformFaceBits(int v, int rot, bool mirror) {
  static const int bitOf[4] = {4, 32, 8, 16};
  return turnBits(v, bitOf, rot & 3, mirror);
}

std::string transformTorch(const std::string &v, int rot, bool mirror) {
  const int c = cardOf(v);
  return c >= 0 ? std::string(kCard[transformFacing(c, rot & 3, mirror)]) : v;
}

std::string transformLever(const std::string &v, int rot, bool mirror) {
  const int c = cardOf(v);
  if (c >= 0) return kCard[transformFacing(c, rot & 3, mirror)];
  if (!(rot & 1)) return v;  // floor/ceiling levers only know the axis; mirroring keeps it
  if (v == "up_east_west") return "up_north_south";
  if (v == "up_north_south") return "up_east_west";
  if (v == "down_east_west") return "down_north_south";
  if (v == "down_north_south") return "down_east_west";
  return v;
}

std::string transformOrientation(const std::string &v, int rot, bool mirror) {
  const size_t u = v.find('_');
  if (u == std::string::npos) return v;
  const char *a = transformFacingName(v.substr(0, u), rot, mirror);
  const char *b = transformFacingName(v.substr(u + 1), rot, mirror);
  if (!a || !b) return v;
  return std::string(a) + "_" + b;
}

int transformMushroomBits(int v, int rot, bool mirror) {
  if (v < 1 || v > 9) return v;  // 0 pores, 10 stem, 14 all cap, 15 all stem: symmetric
  int dx = (v - 1) % 3 - 1, dz = (v - 1) / 3 - 1;
  if (mirror) dx = -dx;
  for (int i = 0; i < (rot & 3); ++i) {  // quarter turn clockwise: local +x -> +z, +z -> -x
    const int nx = -dz, nz = dx;
    dx = nx;
    dz = nz;
  }
  return 1 + (dz + 1) * 3 + (dx + 1);
}

int transformHinge(int bit, int, bool mirror) { return mirror ? (bit ^ 1) : bit; }

// ---------------------------------------------------------------- the transformation
int transformConnections(std::vector<BlockStateValue> &st, int rot, bool mirror) {
  int changed = 0;
  rot &= 3;
  if (rot == 0 && !mirror) return 0;
  // one key per side (walls, pale moss carpet): permute the values with the sides
  for (const char *prefix : kSidePrefixes) {
    BlockStateValue *side[4] = {nullptr, nullptr, nullptr, nullptr};
    for (auto &sv : st) {
      const int c = sideOf(sv.key, prefix);
      if (c >= 0) side[c] = &sv;
    }
    if (!side[0] && !side[1] && !side[2] && !side[3]) continue;
    BlockStateValue old[4];
    bool had[4];
    for (int c = 0; c < 4; ++c) {
      had[c] = side[c] != nullptr;
      if (had[c]) old[c] = *side[c];
    }
    for (int c = 0; c < 4; ++c) {
      if (!had[c]) continue;
      const int to = transformFacing(c, rot, mirror);
      if (side[to]) {
        if (side[to]->s != old[c].s || side[to]->i != old[c].i) ++changed;
        side[to]->type = old[c].type;
        side[to]->i = old[c].i;
        side[to]->s = old[c].s;
      }
    }
  }
  return changed;
}

std::string transformStairShape(const std::string &shape, int rot, bool mirror) {
  (void)rot;  // left/right are relative to the stair's own facing: rotation keeps them
  if (!mirror) return shape;
  auto swap = [](std::string s, const char *a, const char *b) {
    const size_t p = s.rfind(a);
    if (p != std::string::npos && p + std::strlen(a) == s.size()) s.replace(p, std::strlen(a), b);
    return s;
  };
  if (endsWith(shape, "_left")) return swap(shape, "_left", "_right");
  if (endsWith(shape, "_right")) return swap(shape, "_right", "_left");
  return shape;
}

std::string transformAttachment(const std::string &face, int rot, bool mirror) {
  const char *t = transformFacingName(face, rot, mirror);
  return t ? std::string(t) : face;  // standing / hanging / side / multiple / up / down keep their value
}
int transformAttachment(int facing6, int rot, bool mirror) { return transformFacing6(facing6, rot, mirror); }

TransformOutcome transformBlockState(std::vector<BlockStateValue> &st, int rot, bool mirror, const std::string &name) {
  TransformOutcome out;
  rot &= 3;
  if (rot == 0 && !mirror) return out;
  out.changed += transformConnections(st, rot, mirror);
  for (auto &sv : st) {
    if (!plainType(sv)) continue;  // raw NBT state: preserved untouched (the variant is unsupported)
    bool known = false;
    const Rule r = ruleFor(sv.key, name, &known);
    if (!known) {
      if (looksDirectional(sv.key)) out.unknownDirectional.push_back(sv.key);
      continue;
    }
    const bool str = sv.type == nbt::String;
    const std::string beforeS = sv.s;
    const int32_t beforeI = sv.i;
    switch (r.tf) {
      case Tf::Cardinal:
      case Tf::Facing6Str:
        if (str) {
          if (const char *n = transformFacingName(sv.s, rot, mirror)) sv.s = n;
        }
        break;
      case Tf::Torch:
        if (str) sv.s = transformTorch(sv.s, rot, mirror);
        break;
      case Tf::Lever:
        if (str) sv.s = transformLever(sv.s, rot, mirror);
        break;
      case Tf::Orientation:
        if (str) sv.s = transformOrientation(sv.s, rot, mirror);
        break;
      case Tf::Axis:
        if (str) sv.s = transformAxis(sv.s, rot, mirror);
        break;
      case Tf::Facing6Int:
        if (!str) sv.i = transformFacing6(sv.i, rot, mirror);
        break;
      case Tf::DirByName:
        if (!str) sv.i = transformDirection(name, sv.i, rot, mirror);
        break;
      case Tf::DirStair:
        if (!str) sv.i = transformStairDirection(sv.i, rot, mirror);
        break;
      case Tf::DirCoral:
        if (!str) sv.i = transformCoralDirection(sv.i, rot, mirror);
        break;
      case Tf::Rail:
        if (!str) sv.i = transformRailShape(sv.i, rot, mirror);
        break;
      case Tf::Sign16:
        if (!str) sv.i = transformSignRotation(sv.i, rot, mirror);
        break;
      case Tf::VineBits:
        if (!str) sv.i = transformVineBits(sv.i, rot, mirror);
        break;
      case Tf::FaceBits:
        if (!str) sv.i = transformFaceBits(sv.i, rot, mirror);
        break;
      case Tf::Hinge:
        if (!str) sv.i = transformHinge(sv.i, rot, mirror);
        break;
      case Tf::Mushroom:
        if (!str) sv.i = transformMushroomBits(sv.i, rot, mirror);
        break;
      case Tf::SideKeys:  // handled above
      case Tf::None:
      case Tf::Count:
        break;
    }
    if (sv.s != beforeS || sv.i != beforeI) ++out.changed;
  }
  return out;
}

void transformStates(std::vector<BlockStateValue> &st, int rot, bool mirror, const std::string &name) {
  (void)transformBlockState(st, rot, mirror, name);
}

bool isDoorName(const std::string &n) {
  return n.size() >= 4 && std::string_view(n).substr(n.size() - 4) == "door" && !has(n, "trapdoor");
}

int legacyAliases(const std::string &name, const BlockStateValue &sv, BlockStateValue out[2]) {
  int n = 0;
  auto putStr = [&](const char *key, const char *val) {
    out[n].key = key;
    out[n].type = nbt::String;
    out[n].i = 0;
    out[n].s = val;
    ++n;
  };
  if (sv.type != nbt::String && sv.key == "direction") {
    const IntDir &t = directionTable(name);
    if (sv.i >= 0 && sv.i < t.n) putStr("minecraft:cardinal_direction", kCard[t.toC[sv.i]]);
  } else if (sv.type != nbt::String && sv.key == "facing_direction") {
    static const char *k6[6] = {"down", "up", "north", "south", "west", "east"};
    if (sv.i >= 0 && sv.i <= 5) {
      putStr("minecraft:facing_direction", k6[sv.i]);
      if (sv.i >= 2) putStr("minecraft:cardinal_direction", k6[sv.i]);
    }
  } else if (sv.type != nbt::String && sv.key == "top_slot_bit") {
    putStr("minecraft:vertical_half", sv.i ? "top" : "bottom");
  } else if (sv.type == nbt::String && sv.key == "minecraft:cardinal_direction" && isDoorName(name)) {
    const int c = cardOf(sv.s);
    if (c >= 0) {
      out[n].key = "direction";
      out[n].type = nbt::Int;
      out[n].i = fromCard(kDoorDir, c);
      out[n].s.clear();
      ++n;
    }
  }
  return n;
}

std::string valueText(const BlockStateValue &sv) { return sv.type == nbt::String ? sv.s : std::to_string(sv.i); }

std::string describe(const std::vector<BlockStateValue> &st, const std::string &name, bool all) {
  std::string out;
  for (const auto &sv : st) {
    if (!all && ruleFor(sv.key, name).cls == Cls::Generated) continue;
    if (!out.empty()) out += ' ';
    out += startsWith(sv.key, "minecraft:") ? sv.key.substr(10) : sv.key;
    out += '=';
    out += valueText(sv);
  }
  return out.empty() ? std::string("(no states)") : out;
}

int doorInfo(const std::vector<BlockStateValue> &st) {
  int info = 0;
  for (const auto &sv : st) {
    if (sv.type != nbt::String && sv.key == "direction") {
      info = (info & ~3) | (sv.i & 3) | 32;
    } else if (sv.type == nbt::String && sv.key == "minecraft:cardinal_direction") {
      const int d = sv.s == "east" ? 0 : sv.s == "south" ? 1 : sv.s == "west" ? 2 : sv.s == "north" ? 3 : -1;
      if (d >= 0) info = (info & ~3) | d | 32;
    } else if (sv.type != nbt::String && sv.key == "open_bit" && sv.i) {
      info |= 4;
    } else if (sv.type != nbt::String && sv.key == "door_hinge_bit" && sv.i) {
      info |= 8;
    } else if (sv.type != nbt::String && sv.key == "upper_block_bit" && sv.i) {
      info |= 16;
    }
  }
  return info;
}

// ---------------------------------------------------------------- block type equivalence
std::string placeableName(const std::string &n) {
  static const char *const kPairs[][2] = {
      {"powered_repeater", "unpowered_repeater"},
      {"powered_comparator", "unpowered_comparator"},
      {"lit_furnace", "furnace"},
      {"lit_blast_furnace", "blast_furnace"},
      {"lit_smoker", "smoker"},
      {"lit_redstone_lamp", "redstone_lamp"},
      {"unlit_redstone_torch", "redstone_torch"},
      {"lit_redstone_ore", "redstone_ore"},
      {"lit_deepslate_redstone_ore", "deepslate_redstone_ore"},
  };
  for (const auto &p : kPairs)
    if (n == p[0]) return p[1];
  return n;
}
bool sameBlockType(const std::string &a, const std::string &b) { return a == b || placeableName(a) == placeableName(b); }

// ---------------------------------------------------------------- multi-block companions
namespace {
const BlockStateValue *findKey(const std::vector<BlockStateValue> &st, const char *key) {
  for (const auto &sv : st)
    if (sv.key == key) return &sv;
  return nullptr;
}
bool upperIsCompanion(const std::string &name) {
  return name.find("pale_moss_carpet") == std::string::npos;  // there it marks a stacked carpet, not a part
}
}  // namespace

Companion companionOf(const std::vector<BlockStateValue> &st, const std::string &name) {
  Companion c;
  if (const auto *u = findKey(st, "upper_block_bit"); u && u->type != nbt::String && u->i == 0 && upperIsCompanion(name)) {
    c.has = true;
    c.dy = 1;
    c.what = "upper half";
    return c;
  }
  if (const auto *h = findKey(st, "head_piece_bit"); h && h->type != nbt::String && h->i == 0) {
    int card = -1;
    if (const auto *d = findKey(st, "direction"); d && d->type != nbt::String && d->i >= 0 && d->i < 4)
      card = kGenericDir.toC[d->i];
    else if (const auto *cd = findKey(st, "minecraft:cardinal_direction"); cd && cd->type == nbt::String)
      card = cardOf(cd->s);
    if (card < 0) return c;
    static const int kdx[4] = {0, 1, 0, -1}, kdz[4] = {-1, 0, 1, 0};
    c.has = true;
    c.dx = kdx[card];
    c.dz = kdz[card];
    c.what = "bed head";
  }
  return c;
}

bool isSecondaryPart(const std::vector<BlockStateValue> &st, const std::string &name) {
  if (const auto *h = findKey(st, "head_piece_bit"); h && h->type != nbt::String && h->i == 1) return true;
  if (const auto *u = findKey(st, "upper_block_bit"); u && u->type != nbt::String && u->i == 1) return upperIsCompanion(name);
  return false;
}

// ---------------------------------------------------------------- verification
const char *matchName(Match m) {
  static const char *k[] = {"exact", "equivalent", "state mismatch", "wrong block", "missing"};
  const int i = int(m);
  return i >= 0 && i < int(Match::Count) ? k[i] : "?";
}

Compared compareStates(const std::vector<BlockStateValue> &expected, const std::string &name, ValueFn value, void *ctx) {
  Compared c;
  for (const auto &sv : expected) {
    if (!plainType(sv)) continue;  // raw NBT data: reported as unsupported, not comparable
    const Rule r = ruleFor(sv.key, name);
    if (r.cls == Cls::Generated) continue;
    const int64_t a = value(ctx, 0, sv), b = value(ctx, 1, sv);
    if (a < 0 || b < 0) continue;  // one side has no such state: not comparable
    if (a == b) continue;
    c.clsMask |= bit(r.cls);
    c.diffs.push_back(StateDiff{sv.key, r.cls, a, b});
  }
  c.match = c.clsMask ? Match::StateMismatch : Match::Equivalent;
  return c;
}

// ---------------------------------------------------------------- Easy Place policy
const char *modeName(Mode m) {
  static const char *k[] = {"missing-only", "place-and-verify", "safe", "correct-states", "strict"};
  const int i = int(m);
  return i >= 0 && i < int(Mode::Count) ? k[i] : "?";
}

int planScore(const Compared &s) {
  if (s.match == Match::Exact || s.match == Match::Equivalent) return 3;
  if (s.match == Match::StateMismatch && s.only(bit(Cls::GameDecided) | bit(Cls::Interaction) | bit(Cls::ItemUse)))
    return 2;
  return 0;
}

bool acceptPlan(Mode m, int score, bool directional) {
  switch (m) {
    case Mode::MissingOnly:
    case Mode::PlaceVerify:
      return score >= 1;
    case Mode::Safe:
    case Mode::Correct:
      return score >= 2 || (score == 1 && !directional);
    case Mode::Strict:
      return score == 3 || (score == 1 && !directional);
    case Mode::Count:
      break;
  }
  return false;
}
bool verifies(Mode m) { return m != Mode::MissingOnly; }
bool correctsOwn(Mode m) { return m == Mode::Safe || m == Mode::Correct || m == Mode::Strict; }
bool correctsExisting(Mode m) { return m == Mode::Correct; }

bool interactable(const std::string &n) {
  if (n == "iron_door" || n == "iron_trapdoor") return false;  // redstone only
  if (isDoorName(n) || endsWith(n, "trapdoor") || endsWith(n, "fence_gate")) return true;
  return n == "lever" || n == "unpowered_repeater" || n == "powered_repeater" || n == "unpowered_comparator" ||
         n == "powered_comparator";
}

int correctionPresses(const std::string &name, const std::string &key, int64_t expected, int64_t actual) {
  if (!interactable(name) || expected < 0 || actual < 0) return -1;
  if (expected == actual) return 0;
  if (key == "open_bit") return 1;
  if (key == "repeater_delay" && has(name, "repeater")) return int(((expected - actual) % 4 + 4) % 4);
  if (key == "output_subtract_bit" && has(name, "comparator")) return 1;
  return -1;
}

}  // namespace lm::states
