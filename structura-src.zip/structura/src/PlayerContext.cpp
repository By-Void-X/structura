#include "PlayerContext.hpp"

#include <time.h>

#include <cmath>
#include <cstring>
#include <mutex>

#include "Game.hpp"
#include "State.hpp"

namespace lm::ctx {
namespace {

struct Slot {
  std::atomic_bool inst{false};
  std::atomic<int64_t> seenAt{0};  // last time this source delivered the local player (or ran, for update)
  std::atomic<uint64_t> acc{0}, obs{0}, rej{0};
  std::atomic<int> lastRej{0};
};
Slot gSlot[kSources];
std::mutex gTextMu;  // cold data only (strings)
std::string gDetail[kSources];
std::string gLastDrop;
std::atomic<uint64_t> gDrops{0};

std::atomic<int> gActive{0};
std::atomic<int64_t> gAt{0};
std::atomic<int64_t> gUpdPlayerAt{0};  // update hook delivered a non-null player
std::atomic<int64_t> gTickAt{0};       // a tick source delivered the local player
std::atomic<uintptr_t> gCi{0}, gDim{0};
std::atomic<float> gPitch{0};
std::atomic<uint64_t> gGen{1};
std::atomic<uintptr_t> gLpVt{0}, gGmVt{0}, gSmVt{0};

Slot &slot(Source s) { return gSlot[int(s) > 0 && int(s) < kSources ? int(s) : 0]; }

void reject(Source s, Reject r) {
  Slot &k = slot(s);
  k.rej.fetch_add(1, std::memory_order_relaxed);
  k.lastRej.store(int(r), std::memory_order_relaxed);
}

// Reads of a player object that the game itself just handed us (validated by vtable): direct loads.
void commit(Source s, uintptr_t ci, uintptr_t player, int64_t now) {
  auto &st = status();
  uintptr_t dim = 0;
  if (player) {
    const uintptr_t p = game::untag(player);
    const uintptr_t sv = *reinterpret_cast<const uintptr_t *>(p + off::Actor_mStateVector);
    if (game::plausiblePtr(sv)) {
      const float *pos = reinterpret_cast<const float *>(game::untag(sv));
      if (std::isfinite(pos[0]) && std::isfinite(pos[1]) && std::isfinite(pos[2]) && std::fabs(pos[0]) < 3.0e7f &&
          std::fabs(pos[2]) < 3.0e7f && std::fabs(pos[1]) < 1.0e5f) {
        st.feetX.store(pos[0], std::memory_order_relaxed);
        st.feetY.store(pos[1] - 1.62f, std::memory_order_relaxed);  // eye -> feet
        st.feetZ.store(pos[2], std::memory_order_relaxed);
      } else {
        reject(s, Reject::BadPosition);  // keep the context, position just not refreshed this tick
      }
    }
    const uintptr_t rc = *reinterpret_cast<const uintptr_t *>(p + off::Actor_mRotation);
    if (game::plausiblePtr(rc)) {
      const float *rot = reinterpret_cast<const float *>(game::untag(rc));
      if (std::isfinite(rot[0])) gPitch.store(rot[0], std::memory_order_relaxed);
      if (std::isfinite(rot[1])) st.yaw.store(rot[1], std::memory_order_relaxed);
    }
    const uintptr_t d = *reinterpret_cast<const uintptr_t *>(p + off::Actor_mDimension);
    dim = game::plausiblePtr(d) ? d : 0;
  }
  const uintptr_t prevP = st.player.load(std::memory_order_relaxed);
  if (player != prevP || dim != gDim.load(std::memory_order_relaxed)) gGen.fetch_add(1, std::memory_order_relaxed);
  gDim.store(dim, std::memory_order_relaxed);
  gCi.store(ci, std::memory_order_relaxed);
  st.player.store(player, std::memory_order_relaxed);
  gActive.store(int(s), std::memory_order_relaxed);
  gAt.store(now, std::memory_order_release);
  slot(s).acc.fetch_add(1, std::memory_order_relaxed);
}

}  // namespace

namespace {
int64_t realClock() {
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return int64_t(ts.tv_sec) * 1000 + ts.tv_nsec / 1000000;
}
std::atomic<int64_t (*)()> gClock{&realClock};
}  // namespace

int64_t monoMs() { return gClock.load(std::memory_order_relaxed)(); }
void setClockForTest(int64_t (*clock)()) { gClock.store(clock ? clock : &realClock); }

RenderUse renderUse(const View &v, bool anySource, uintptr_t lr, uintptr_t lrp, RenderMemo &m) {
  if (!anySource || !v.player) return RenderUse::None;
  if (v.fresh) {
    m = RenderMemo{lr, lrp, v.player, v.generation};
    return RenderUse::Fresh;
  }
  if (m.lr == lr && m.lrp == lrp && m.player == v.player && m.generation == v.generation) return RenderUse::Stale;
  return RenderUse::Drop;
}

const char *sourceName(Source s) {
  switch (s) {
    case Source::UpdateHook: return "ClientInstance::update";
    case Source::GameModeTick: return "GameModeTick";
    case Source::LocalPlayerTick: return "LocalPlayer tick";
    default: return "none";
  }
}
const char *sourceKey(Source s) {
  switch (s) {
    case Source::UpdateHook: return "diag.src_update";
    case Source::GameModeTick: return "diag.src_gamemode";
    case Source::LocalPlayerTick: return "diag.src_localplayer";
    default: return "diag.src_none";
  }
}
const char *rejectName(Reject r) {
  switch (r) {
    case Reject::NullObject: return "null object";
    case Reject::BadPointer: return "not a GameMode object";
    case Reject::NotLocalPlayer: return "not the local player (server-side or other player)";
    case Reject::NoLocalPlayerVtable: return "LocalPlayer vtable unknown";
    case Reject::BadPosition: return "invalid position";
    default: return "-";
  }
}

void setInstalled(Source s, bool on, const std::string &d) {
  slot(s).inst.store(on, std::memory_order_release);
  std::lock_guard<std::mutex> lk(gTextMu);
  gDetail[int(s) > 0 && int(s) < kSources ? int(s) : 0] = d;
}
bool installed(Source s) { return slot(s).inst.load(std::memory_order_acquire); }
bool anySource() {
  return installed(Source::UpdateHook) || installed(Source::GameModeTick) || installed(Source::LocalPlayerTick);
}
std::string detail(Source s) {
  std::lock_guard<std::mutex> lk(gTextMu);
  return gDetail[int(s) > 0 && int(s) < kSources ? int(s) : 0];
}
void setLocalPlayerVtable(uintptr_t vt) { gLpVt.store(vt, std::memory_order_release); }
uintptr_t localPlayerVtable() { return gLpVt.load(std::memory_order_acquire); }
void setGameModeVtables(uintptr_t gm, uintptr_t sm) {
  gGmVt.store(gm, std::memory_order_release);
  gSmVt.store(sm, std::memory_order_release);
}

bool isLocalPlayer(uintptr_t player) {
  const uintptr_t lp = gLpVt.load(std::memory_order_acquire);
  if (!lp || !game::plausiblePtr(player)) return false;
  uintptr_t vt = 0;
  if (!game::safeReadPtr(player, vt)) return false;
  return game::untag(vt) == lp;
}

bool updateAlive(int64_t now) {
  return installed(Source::UpdateHook) && now - gUpdPlayerAt.load(std::memory_order_relaxed) <= kFreshMs;
}

void publishUpdate(uintptr_t ci, uintptr_t player) {
  const int64_t now = monoMs();
  slot(Source::UpdateHook).seenAt.store(now, std::memory_order_relaxed);
  if (player) {
    gUpdPlayerAt.store(now, std::memory_order_relaxed);
    commit(Source::UpdateHook, ci, player, now);
    return;
  }
  // "No player" from the update hook only wins when no tick source is delivering the local player
  // (a getLocalPlayer slot that misbehaves must not hide a player proven by its vtable).
  if (now - gTickAt.load(std::memory_order_relaxed) > kFreshMs) commit(Source::UpdateHook, ci, 0, now);
  else slot(Source::UpdateHook).obs.fetch_add(1, std::memory_order_relaxed);
}

namespace {
bool publishTick(Source s, uintptr_t player) {
  const int64_t now = monoMs();
  if (!gLpVt.load(std::memory_order_acquire)) { reject(s, Reject::NoLocalPlayerVtable); return false; }
  if (!isLocalPlayer(player)) { reject(s, player ? Reject::NotLocalPlayer : Reject::NullObject); return false; }
  slot(s).seenAt.store(now, std::memory_order_relaxed);
  gTickAt.store(now, std::memory_order_relaxed);
  if (updateAlive(now)) {  // the per-frame source is alive: only observe
    slot(s).obs.fetch_add(1, std::memory_order_relaxed);
    return false;
  }
  commit(s, 0, player, now);
  return true;
}
}  // namespace

bool publishGameMode(uintptr_t gm, uintptr_t playerOffset) {
  if (!game::plausiblePtr(gm)) { reject(Source::GameModeTick, Reject::NullObject); return false; }
  uintptr_t vt = 0, player = 0;
  if (!game::safeReadPtr(gm, vt)) { reject(Source::GameModeTick, Reject::BadPointer); return false; }
  vt = game::untag(vt);
  const uintptr_t a = gGmVt.load(std::memory_order_acquire), b = gSmVt.load(std::memory_order_acquire);
  if (!vt || (vt != a && vt != b)) { reject(Source::GameModeTick, Reject::BadPointer); return false; }
  if (!game::safeReadPtr(gm + playerOffset, player)) { reject(Source::GameModeTick, Reject::BadPointer); return false; }
  return publishTick(Source::GameModeTick, player);
}

bool publishLocalPlayer(uintptr_t player) { return publishTick(Source::LocalPlayerTick, player); }

View view(int64_t now) {
  View v;
  v.at = gAt.load(std::memory_order_acquire);
  v.source = Source(gActive.load(std::memory_order_relaxed));
  auto &st = status();
  v.player = st.player.load(std::memory_order_relaxed);
  v.ci = gCi.load(std::memory_order_relaxed);
  v.dim = gDim.load(std::memory_order_relaxed);
  v.pos[0] = st.feetX.load(std::memory_order_relaxed);
  v.pos[1] = st.feetY.load(std::memory_order_relaxed) + 1.62f;
  v.pos[2] = st.feetZ.load(std::memory_order_relaxed);
  v.pitch = gPitch.load(std::memory_order_relaxed);
  v.yaw = st.yaw.load(std::memory_order_relaxed);
  v.generation = gGen.load(std::memory_order_relaxed);
  v.fresh = v.at > 0 && now - v.at <= kFreshMs;
  return v;
}
bool fresh(int64_t now) {
  const int64_t at = gAt.load(std::memory_order_acquire);
  return at > 0 && now - at <= kFreshMs;
}
uint64_t generation() { return gGen.load(std::memory_order_relaxed); }

void dropStale(uintptr_t expected, const char *why) {
  uintptr_t e = expected;
  if (!expected || !status().player.compare_exchange_strong(e, 0, std::memory_order_relaxed)) return;
  gDim.store(0, std::memory_order_relaxed);
  gGen.fetch_add(1, std::memory_order_relaxed);
  gDrops.fetch_add(1, std::memory_order_relaxed);
  std::lock_guard<std::mutex> lk(gTextMu);
  gLastDrop = why ? why : "";
}

void invalidate(const char *why) {
  status().player.store(0, std::memory_order_relaxed);
  gDim.store(0, std::memory_order_relaxed);
  gAt.store(0, std::memory_order_release);
  gGen.fetch_add(1, std::memory_order_relaxed);
  gDrops.fetch_add(1, std::memory_order_relaxed);
  std::lock_guard<std::mutex> lk(gTextMu);
  gLastDrop = why ? why : "";
}

Stats stats() {
  Stats s;
  for (int i = 0; i < kSources; ++i) {
    s.accepted[i] = gSlot[i].acc.load(std::memory_order_relaxed);
    s.observed[i] = gSlot[i].obs.load(std::memory_order_relaxed);
    s.rejected[i] = gSlot[i].rej.load(std::memory_order_relaxed);
    s.seenAt[i] = gSlot[i].seenAt.load(std::memory_order_relaxed);
    s.lastReject[i] = Reject(gSlot[i].lastRej.load(std::memory_order_relaxed));
  }
  s.drops = gDrops.load(std::memory_order_relaxed);
  std::lock_guard<std::mutex> lk(gTextMu);
  s.lastDrop = gLastDrop;
  return s;
}

void resetForTest() {
  for (auto &k : gSlot) {
    k.inst.store(false);
    k.seenAt.store(0);
    k.acc.store(0);
    k.obs.store(0);
    k.rej.store(0);
    k.lastRej.store(0);
  }
  {
    std::lock_guard<std::mutex> lk(gTextMu);
    for (auto &d : gDetail) d.clear();
    gLastDrop.clear();
  }
  gDrops.store(0);
  gActive.store(0);
  gAt.store(0);
  gUpdPlayerAt.store(0);
  gTickAt.store(0);
  gCi.store(0);
  gDim.store(0);
  gGen.store(1);
  gLpVt.store(0);
  gGmVt.store(0);
  gSmVt.store(0);
  status().player.store(0);
  gClock.store(&realClock);
}

}  // namespace lm::ctx
