#pragma once

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "Preview.hpp"
#include "Structure.hpp"
#include "Theme.hpp"

namespace lm {

enum class Phase : int { WaitingGame = 0, Settling, Installing, Active, Failed };

enum class FailReason : int {
  None = 0,
  GameLibraryNotFound,
  RenderSignatureMissing,
  UpdateSignatureMissing,
  RenderHookFailed,
  UpdateHookFailed,
  EasyPlaceHookFailed,
  NoPlayerContext  // neither ClientInstance::update nor any validated fallback provides the local player
};
const char *failReasonText(FailReason r);
constexpr int kInitAttempts = 3;

enum class LayerMode : int { All = 0, Only = 1, UpTo = 2, Above = 3, Range = 4 };


enum Cmp : uint8_t {
  CmpUnknown = 0, CmpCorrect = 1, CmpWrong = 2, CmpMissing = 3, CmpExtra = 4, CmpAirOk = 5, CmpWrongState = 6
};


enum BlockColor : int { ColMissing = 0, ColWrong, ColWrongState, ColExtra, ColCorrect, ColCount };
inline constexpr uint32_t kDefaultBlockColor[ColCount] = {
    0xFF9EDBFF,  
    0xFFFF2020,  
    0xFFFF9010,  
    0xFFFF4CE6,  
    0xFF40FF60,  
};

struct Settings {  
  std::atomic_bool hologram{true};
  std::atomic_bool showFaces{true};
  std::atomic_bool showLines{true};
  std::atomic_bool twoSided{true};
  std::atomic_int blockLook{1};      
  std::atomic_int faceMaterial{0};   
  std::atomic<float> alpha{1.0f};  
  std::atomic_int radius{20};
  std::atomic<int> layerMode{0};
  std::atomic<int> layerAxis{1};  
  std::atomic_bool compare{false};
  std::atomic_bool hideCorrect{true};
  std::atomic<float> uiScale{0.9f};     
  std::atomic<float> panelSize{0.7f};   
  std::atomic_int theme{0};             
  std::atomic_bool scanDownloads{true};
  std::atomic_bool scanPacks{false};  
  std::atomic_bool panelRight{true};      
  std::atomic<float> panelFX{0.5f}, panelFY{0.5f};  
  std::atomic_bool testDraw{false};  
  std::atomic_bool animations{true};  
  std::atomic<uint32_t> blockColor[ColCount] = {kDefaultBlockColor[0], kDefaultBlockColor[1], kDefaultBlockColor[2],
                                                kDefaultBlockColor[3], kDefaultBlockColor[4]};
  
  std::atomic_int controlSize{theme::style::DefaultSize};      
  std::atomic_int opacityMode{theme::style::DefaultOpacityMode};  
  std::atomic_int opacityPct[theme::style::InkCount] = {
      theme::style::DefaultOpacity[0], theme::style::DefaultOpacity[1], theme::style::DefaultOpacity[2],
      theme::style::DefaultOpacity[3], theme::style::DefaultOpacity[4]};  
  std::atomic_int uiLayout{theme::style::DefaultLayout};  
  std::atomic_int uiLabels{theme::style::DefaultLabels};  
  
  
  std::atomic<float> stX{-1.f}, stY{-1.f}, epX{-1.f}, epY{-1.f};
  std::atomic_bool perfLog{false};  
  std::atomic_int epMode{2};
  // hologram display filter: 0 all, 1 missing only, 2 incorrect only, 3 unverified only (display only)
  std::atomic_int holoFilter{0};
  // progress / layer overlay (separate touch panel); position = fraction of the free screen space
  std::atomic_bool ovVisible{true};
  std::atomic<float> ovX{-1.f}, ovY{-1.f};
  std::atomic<float> ovScale{1.f};   // 0.7 .. 1.6
  std::atomic<float> ovWidth{1.f};   // 0.8 .. 1.6 (resize handle)
  std::atomic<float> ovAlpha{0.92f}; // 0.3 .. 1
  std::atomic_bool ovExpanded{false};
  std::atomic_int ovDisplay{0};      // 0 percent + blocks, 1 blocks only, 2 layer focus
  std::atomic_int ovLayer{-1};       // last selected layer (restored when the same structure is reopened)
  // Easy Place run controls
  std::atomic_bool epLayerOnly{true};   // place only blocks of the visible layers (existing behaviour)
  std::atomic_int epRate{20};           // max blocks per second (1..20; 20 = previous fixed step)
  std::atomic_int epBatch{1};           // max blocks per placement step (1..4)
  std::atomic_bool epBottomUp{true};    // prefer the lowest missing block
  std::atomic_bool epSafeOnly{false};   // only blocks with an exact, verified-safe placement plan  // Easy Place mode (states::Mode): 0 missing only, 1 place+verify, 2 safe, 3 correct, 4 strict
};

void resetAppearance();

// Progress record states (the verification state of one structure block).
enum PState : uint8_t {
  PNotChecked = 0, PMissing, PPlacing, PCorrect, PIncorrect, PSkipped, PUnsupported, PFailed, PCount,
  PNone = 255  // air position of the structure: not a block to build
};
// Easy Place outcome stored next to the world comparison (bits 4..6 of the record byte).
enum EpFlag : uint8_t { EpNone = 0, EpPlacing = 1, EpSkipped = 2, EpUnsupported = 3, EpFailed = 4 };
// Last Easy Place error of a block (progress model; texts in Progress.cpp).
enum EpErr : uint8_t {
  ErrNone = 0, ErrUnsupported, ErrNoItem, ErrNeedsSupport, ErrCompanion, ErrNoExactPlan, ErrRefused, ErrMismatch,
  ErrTimeout, ErrValidation, ErrReplaceDenied, ErrCount
};

// Central progress model of the placed structure: one record per structure position, keyed by the
// structure-local index, holding the world comparison against the SHARED transformed state (low 3 bits,
// Cmp) and the Easy Place outcome (bits 4..6, EpFlag). Counters (global + per local slice on each axis) are
// maintained on every change, so overall and layer progress are O(1) and never need a scan.
// Updated only through progress::setCmp / progress::setEp (Progress.hpp). A new instance is created for
// every structure / move / rotation / mirror / world change (gen + epoch), so stale work can't touch it.
struct CompareData {
  uint64_t gen = 0;
  uint64_t epoch = 0;  // world epoch the states were checked in
  size_t n = 0;
  int sx = 0, sy = 0, sz = 0;
  std::shared_ptr<const Structure> S;
  std::unique_ptr<std::atomic<uint8_t>[]> st;     // record byte: Cmp | EpFlag << 4
  std::unique_ptr<std::atomic<uint8_t>[]> tries;  // Easy Place attempts (saturating)
  std::unique_ptr<std::atomic<uint8_t>[]> err;    // EpErr
  std::atomic<uint32_t> cnt[PCount];
  std::unique_ptr<std::atomic<uint32_t>[]> slice;  // (sx + sy + sz) * PCount
  std::atomic<uint32_t> extra{0};                  // air positions occupied in the world
  std::atomic<uint64_t> rev{0};                    // bumps on every change (UI refresh key)
  uint32_t total = 0;                              // blocks to build (non-air)
  explicit CompareData(uint64_t g, size_t count) : gen(g), n(count), st(new std::atomic<uint8_t>[count]) {
    for (size_t i = 0; i < n; ++i) st[i].store(CmpUnknown, std::memory_order_relaxed);
    for (auto &c : cnt) c.store(0, std::memory_order_relaxed);
  }
  uint8_t cmp(size_t i) const { return st[i].load(std::memory_order_relaxed) & 7; }
};
struct Model {
  std::mutex mu;
  std::shared_ptr<const Structure> structure;
  std::shared_ptr<const std::vector<PreviewFace>> previewFaces;
  Placement placement;
  bool placed = false;
  int layer = 0;   
  int layer2 = 0;  
  uint64_t gen = 1;  
  std::shared_ptr<CompareData> compare;

  
  bool cornerA = false, cornerB = false;
  int ax = 0, ay = 0, az = 0, bx = 0, by = 0, bz = 0;

  
  std::atomic_bool live{false};     
  std::atomic_bool corners{false};  
  std::atomic<uint64_t> genSeen{1};  
  // lifecycle flags (read lock-free by the render thread / diagnostics)
  bool wantPlace = false;                 // loaded without a player: place when the player is valid
  std::atomic_bool hasStructure{false};
  std::atomic_bool pendingPlace{false};
  void syncFlags() {  
    genSeen.store(gen, std::memory_order_release);
    if (!structure || placed) wantPlace = false;
    hasStructure.store(structure != nullptr, std::memory_order_release);
    pendingPlace.store(wantPlace, std::memory_order_release);
    live.store(structure != nullptr && placed, std::memory_order_release);
    corners.store(cornerA || cornerB, std::memory_order_release);
  }
};

struct Status {
  std::atomic<Phase> phase{Phase::WaitingGame};
  std::atomic<FailReason> failReason{FailReason::None};
  std::atomic_int initAttempt{0};          
  std::atomic_bool hkEasyPlace{false};     
  std::atomic_bool hkRender{false}, hkUpdate{false}, hasGetBlock{false}, hasLineMat{false};
  std::atomic_int faceMatMask{0};
  std::atomic_int renderMeshAbi{0};  
  std::atomic_int renderStage{0};    
  std::atomic<int> namesState{0};  
  std::atomic<uint64_t> renderCalls{0}, drawnQuads{0}, drawnLines{0}, cmpChecks{0}, meshCalls{0};

  
  
  std::atomic<int> texStage{-1}, texSigMissing{0};
  std::atomic<uint32_t> texVarOk{0}, texVarTotal{0}, texBlocks{0}, texZero{0}, texVerts{0}, texChunks{0};

  
  std::atomic<uintptr_t> player{0};
  std::atomic<float> feetX{0}, feetY{0}, feetZ{0}, yaw{0};
  std::atomic<float> camX{0}, camY{0}, camZ{0};  

  
  std::atomic_bool captureRequest{false};
  std::atomic<int> captureProgress{-1};  

  
  std::atomic<uint32_t> cmpCorrect{0}, cmpWrong{0}, cmpMissing{0}, cmpExtra{0}, cmpWrongState{0}, cmpUnknown{0};

  
  std::atomic_bool oldModsLoaded{false};
};

Settings &settings();

void setGameLabel(const std::string &label);
std::string gameLabel();
Status &status();
Model &model();
int64_t nowMs();



enum class Tone : int { Info = 0, Success, Warning, Error };
void notify(const char *key, Tone tone = Tone::Info, int ms = 3000, const std::string &arg = {});
struct Notice {
  std::string key, arg;  
  Tone tone = Tone::Info;
  int64_t start = 0, until = 0;
};
bool currentNotice(Notice &out);

void toast(const std::string &msg, int ms = 3000);

std::string currentToast();


void requestLibraryRescan(const std::string &selectPath = {});

}  
