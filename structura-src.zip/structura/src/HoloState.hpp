#pragma once
// Hologram lifecycle + load pipeline state (lock-free for the render thread).
//
// Writers:
//   - job thread  -> load pipeline (Open..Transform) and LoadShared strings (under mutex)
//   - render thread -> runtime atomics (WaitWorld..Visible), never strings, never locks
// Readers:
//   - UI thread (uiLoop) builds the diagnostics snapshot from these values.

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <mutex>
#include <string>

namespace lm::hs {

enum class HState : int {
  NoStructureLoaded = 0,
  StructureLoading,
  StructureLoaded,
  WaitingForWorld,
  WaitingForPlayer,
  WaitingForRender,
  PreparingHologram,
  HologramReady,
  HologramVisible,
  HologramFailed,
  HologramCancelled,
  Count
};

// Pipeline stages, in order.
enum class Stage : int {
  Open = 0,
  Nbt,
  Dimensions,
  Palette,
  Indices,
  CountSolid,
  Transform,
  WaitWorld,
  RenderData,
  Materials,
  RenderCache,
  Visible,
  Done,
  Count
};
constexpr int kStageCount = int(Stage::Count);

enum class SSt : int { Pending = 0, Running, Ok, Warning, Failed, Skipped, Cancelled };

// Reason codes (render path uses codes only; the UI maps them to text).
enum class Why : int {
  None = 0,
  HologramOff,
  NoStructure,
  NotPlaced,
  NoPlayer,
  NoWorld,
  WorldChanged,
  DimensionChanged,
  NoRenderFrame,
  RenderDataInvalid,
  RenderContextChanged,
  Resumed,
  MaterialsMissing,
  TexturesUnavailable,
  BuildStalled,
  MemoryLimit,
  Cancelled,
  OutOfRange,
  RetryLimit,
  Settling,
  HookMissing,
  StructureChanged,
  NoContextSource,  // no validated player context source is hooked
  Count
};

// Load-side error codes (map parser error strings to the stage that failed).
enum class LoadErr : int {
  None = 0,
  CantRead,
  Empty,
  TooLargeFile,
  Corrupt,
  Zip,
  NotNbt,
  JavaNbt,
  NotStructure,
  BadSize,
  NoIndices,
  BadIndicesType,
  NoPalette,
  IndicesCount,
  NoBlocks,
  MemoryLimit,
  Cancelled,
  Other,
  Count
};

struct Runtime {
  // overall state written by render thread (render-side part of the lifecycle)
  std::atomic<int> renderState{int(HState::WaitingForRender)};
  std::atomic<int> why{int(Why::None)};
  std::atomic<int64_t> stateSinceMs{0};
  std::atomic<int64_t> lastFrameMs{0};     // last frame that passed render-data validation
  std::atomic<int64_t> lastHookMs{0};      // last renderLevel call at all
  std::atomic<uint32_t> texResolved{0}, texTotal{0};
  std::atomic<int64_t> lastVisibleMs{0};
  // epochs / generations
  std::atomic<uint64_t> worldEpoch{0};
  std::atomic<uint64_t> dimEpoch{0};
  std::atomic<uint64_t> renderEpoch{0};
  std::atomic<uint64_t> buildGen{0};      // generation the mesh cache was built for
  std::atomic<uint64_t> cancelled{0};     // number of cancelled preparations
  std::atomic<int> lastCancelWhy{0};
  // validation
  std::atomic<bool> worldValid{false}, playerValid{false}, dimValid{false}, renderValid{false};
  // Player context went quiet (singleplayer pause, loading) while the render context stayed the same:
  // the hologram keeps drawing from the last context, world reads (verification) pause.
  std::atomic<bool> ctxStale{false};
  std::atomic<int> stableFrames{0};
  // materials
  std::atomic<int> matTex{0};         // 0 not checked, 1 ok, 2 retrying, 3 failed(fallback)
  std::atomic<int> matLine{0};        // same
  std::atomic<int> matFace{0};        // 0 not checked, 1 ok, 2 missing
  std::atomic<int> matAttempts{0};
  // preparation progress (in-range chunks)
  std::atomic<uint32_t> prepDone{0}, prepTotal{0}, prepBatches{0}, prepPerFrame{0};
  std::atomic<uint32_t> meshCount{0};
  std::atomic<bool> meshCapped{false};
  // recovery
  std::atomic<bool> retryRequest{false};
  std::atomic<uint32_t> failures{0};
  std::atomic<uint32_t> invalidations{0};
  std::atomic<int> lastInvalidateWhy{0};
  std::atomic<int64_t> lastInvalidateMs{0};
  std::atomic<bool> eglAbandoned{false};
  // stage table for render-side stages
  std::atomic<int> st[kStageCount]{};
  std::atomic<int64_t> at[kStageCount]{};
};

struct LoadShared {
  std::mutex mu;
  uint64_t seq = 0;                 // request sequence of the load being shown
  bool busy = false;
  std::string path, title, error, detail;
  LoadErr err = LoadErr::None;
  int failedStage = -1;
  int64_t startedMs = 0, endedMs = 0;
  uint64_t fileBytes = 0, rawBytes = 0, memEstimate = 0, memAvail = 0;
  int sx = 0, sy = 0, sz = 0;
  size_t palette = 0, indices = 0, solid = 0, air = 0, voids = 0, variants = 0;
  std::string indicesType;
  size_t stOk = 0, stDirectional = 0, stMulti = 0, stUnknown = 0, stDiscarded = 0, stDiscardedVariants = 0;
  size_t stPreserved = 0, stRaw = 0;
  size_t stWaterlogged = 0, stBlockEntities = 0;
  std::string stUnknownKeys, stDiscardedKeys;
  int st[kStageCount]{};            // SSt for load stages
  int64_t at[kStageCount]{};
};

Runtime &rt();
LoadShared &load();
std::atomic<uint64_t> &loadSeq();   // bumped on each new request/unload (cancels older async results)
std::atomic<int> &loadBusy();       // 1 while a load job runs

int64_t monoMs();
void setRenderState(HState s, Why w);
void setStage(Stage s, SSt v);      // render-side stages (atomics)
void resetRenderStages();

// Overall state: combines load side + render side + freshness (UI thread).
HState overall(Why *why = nullptr);

const char *stateName(HState s);
const char *whyName(Why w);
const char *stageName(Stage s);
const char *loadErrName(LoadErr e);
LoadErr classifyLoadError(const std::string &err, Stage &stage);

// /proc/meminfo MemAvailable in bytes (0 = unknown). Not for the render thread.
uint64_t memAvailable();

}  // namespace lm::hs
