#pragma once
// Shared transformed structure data: ONE place where palette block states are turned by rotation/mirror.
// The hologram (textures + comparison), Easy Place (targets, plans, verification), the progress model and
// the layer UI all read the same table, so they can never disagree about the state a block must have.
//
//   original variant states --states::transformBlockState(rot, mirror)--> Table::states[v]
//
// A table is built once per (structure, rotation, mirror); world positions are transformed by
// localToWorld/worldToLocal (Structure.hpp) with the same Placement.

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "Structure.hpp"

namespace lm::xf {

struct Table {
  std::shared_ptr<const Structure> keep;  // keeps the structure alive while the table exists
  int rot = 0;
  bool mirror = false;
  uint64_t id = 0;  // unique per built table (generation)
  std::vector<std::vector<BlockStateValue>> states;  // per variant: transformed states
  std::vector<std::string> unsupported;  // per variant: why the exact state can't be reproduced ("" = fine)
  std::vector<uint8_t> verified;         // per variant: has states verification compares (not game-generated)
  std::vector<uint8_t> directional;      // per variant: has placement-decided states (facing, half, axis...)
  size_t variants = 0, changed = 0, nUnsupported = 0, nDirectional = 0, nRaw = 0;
};

// The table for (S, rot, mirror); built on first use (O(variants)), then cached. Thread-safe.
std::shared_ptr<const Table> get(const std::shared_ptr<const Structure> &S, int rot, bool mirror);
// Cached table only, never builds and never blocks (render thread). nullptr = not built yet.
std::shared_ptr<const Table> peek(const Structure *S, int rot, bool mirror);
void clear();

struct Stats {
  bool ready = false;
  int rot = 0;
  bool mirror = false;
  uint64_t builds = 0;
  size_t variants = 0, changed = 0, unsupported = 0, directional = 0, raw = 0;
  std::string firstUnsupported;  // example reason, for the diagnostics
};
Stats stats();  // of the most recently built table

}  // namespace lm::xf
