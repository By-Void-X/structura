#include "Progress.hpp"

#include <algorithm>
#include <mutex>

#include "Transformed.hpp"

namespace lm::progress {
namespace {
inline void bump(CompareData &C, size_t li, uint8_t ps, int d) {
  if (ps >= PCount) return;
  C.cnt[ps].fetch_add(uint32_t(d), std::memory_order_relaxed);
  if (!C.slice) return;
  const size_t syz = size_t(C.sy) * size_t(C.sz);
  const size_t x = li / syz, y = (li / size_t(C.sz)) % size_t(C.sy), z = li % size_t(C.sz);
  C.slice[x * PCount + ps].fetch_add(uint32_t(d), std::memory_order_relaxed);
  C.slice[(size_t(C.sx) + y) * PCount + ps].fetch_add(uint32_t(d), std::memory_order_relaxed);
  C.slice[(size_t(C.sx) + size_t(C.sy) + z) * PCount + ps].fetch_add(uint32_t(d), std::memory_order_relaxed);
}
inline bool airAt(const CompareData &C, size_t li) {
  if (!C.S || li >= C.S->idx.size()) return true;
  const uint16_t p = C.S->idx[li];
  return p == kVoid || p >= C.S->palette.size() || C.S->palette[p].air;
}
template <class F>
void update(CompareData &C, size_t li, F &&f) {
  if (li >= C.n) return;
  const bool air = airAt(C, li);
  uint8_t old = C.st[li].load(std::memory_order_relaxed), now;
  do {
    now = f(old);
    if (now == old) return;
  } while (!C.st[li].compare_exchange_weak(old, now, std::memory_order_relaxed));
  if (air) {
    const bool wasExtra = (old & 7) == CmpExtra, isExtra = (now & 7) == CmpExtra;
    if (wasExtra != isExtra) C.extra.fetch_add(isExtra ? 1u : uint32_t(-1), std::memory_order_relaxed);
  } else {
    const uint8_t a = stateOf(old, false), b = stateOf(now, false);
    if (a != b) {
      bump(C, li, a, -1);
      bump(C, li, b, +1);
    }
  }
  C.rev.fetch_add(1, std::memory_order_relaxed);
}
}  // namespace

uint8_t stateOf(uint8_t r, bool air) {
  if (air) return PNone;
  const uint8_t cmp = r & 7, ep = (r >> 4) & 7;
  if (ep == EpPlacing) return PPlacing;
  if (cmp == CmpCorrect) return PCorrect;
  if (cmp == CmpWrong || cmp == CmpWrongState) return PIncorrect;
  if (ep == EpUnsupported) return PUnsupported;
  if (ep == EpFailed) return PFailed;
  if (ep == EpSkipped) return PSkipped;
  if (cmp == CmpMissing) return PMissing;
  return PNotChecked;
}

std::shared_ptr<CompareData> create(uint64_t gen, uint64_t epoch, const std::shared_ptr<const Structure> &S,
                                    const xf::Table *X) {
  const size_t n = S ? S->volume() : 0;
  auto C = std::make_shared<CompareData>(gen, n);
  C->epoch = epoch;
  C->S = S;
  if (!S) return C;
  C->sx = S->sx;
  C->sy = S->sy;
  C->sz = S->sz;
  C->tries.reset(new std::atomic<uint8_t>[n]);
  C->err.reset(new std::atomic<uint8_t>[n]);
  const size_t ns = (size_t(S->sx) + size_t(S->sy) + size_t(S->sz)) * PCount;
  C->slice.reset(new std::atomic<uint32_t>[ns]);
  for (size_t i = 0; i < ns; ++i) C->slice[i].store(0, std::memory_order_relaxed);
  const bool useX = X && X->states.size() == S->variants.size() && S->vidx.size() == n;
  for (size_t li = 0; li < n; ++li) {
    C->tries[li].store(0, std::memory_order_relaxed);
    C->err[li].store(ErrNone, std::memory_order_relaxed);
    if (airAt(*C, li)) continue;
    ++C->total;
    uint8_t r = CmpUnknown;
    if (useX) {
      const uint16_t v = S->vidx[li];
      if (v < X->unsupported.size() && !X->unsupported[v].empty()) {
        r = uint8_t(EpUnsupported << 4);
        C->err[li].store(ErrUnsupported, std::memory_order_relaxed);
      }
    }
    C->st[li].store(r, std::memory_order_relaxed);
    bump(*C, li, stateOf(r, false), +1);
  }
  return C;
}

uint8_t setCmp(CompareData &C, size_t li, uint8_t cmp) {
  uint8_t prev = CmpUnknown;
  update(C, li, [&](uint8_t old) -> uint8_t {
    prev = old & 7;
    if (prev == cmp) return old;
    uint8_t ep = (old >> 4) & 7;
    if (ep != EpUnsupported) ep = EpNone;  // the world changed: an old Easy Place outcome is stale
    return uint8_t(cmp | ep << 4);
  });
  return prev;
}

void setEp(CompareData &C, size_t li, EpFlag f, EpErr e, bool attempt) {
  if (li >= C.n) return;
  update(C, li, [&](uint8_t old) -> uint8_t {
    const uint8_t ep = (old >> 4) & 7;
    if (ep == EpUnsupported && f != EpUnsupported) return old;  // static: no exact transformation exists
    return uint8_t((old & 7) | uint8_t(f) << 4);
  });
  if (C.err) C.err[li].store(e, std::memory_order_relaxed);
  if (attempt && C.tries) {
    uint8_t t = C.tries[li].load(std::memory_order_relaxed);
    if (t < 255) C.tries[li].store(uint8_t(t + 1), std::memory_order_relaxed);
  }
  C.rev.fetch_add(1, std::memory_order_relaxed);
}

Counts overall(const CompareData &C) {
  Counts c;
  c.total = C.total;
  for (int i = 0; i < PCount; ++i) c.s[i] = C.cnt[i].load(std::memory_order_relaxed);
  c.extra = C.extra.load(std::memory_order_relaxed);
  return c;
}

int layerCount(const Structure &S, const Placement &P, int axis) {
  int dx, dz;
  rotatedSize(S, P.rot, dx, dz);
  return axis == 0 ? dx : axis == 1 ? S.sy : dz;
}
int layerWorld(const Structure &S, const Placement &P, int axis, int index) {
  return (axis == 0 ? P.ox : axis == 1 ? P.oy : P.oz) + index;
}

bool layerCounts(const CompareData &C, const Structure &S, const Placement &P, int axis, int index, Counts &out) {
  out = Counts{};
  if (!C.slice || S.sx != C.sx || S.sy != C.sy || S.sz != C.sz) return false;
  const int size = layerCount(S, P, axis);
  if (index < 0 || index >= size) return false;
  // Rotation is about Y only: world Y is local Y; world X/Z are local X/Z (even rotation) or Z/X (odd).
  // worldToLocal (the same transform as the hologram) gives the local coordinate, mirroring included.
  const int la = axis == 1 ? 1 : ((axis == 0) == !(P.rot & 1) ? 0 : 2);
  int w[3] = {P.ox, P.oy, P.oz};
  w[axis] += index;
  int l[3];
  if (!worldToLocal(S, P, w[0], w[1], w[2], l[0], l[1], l[2])) return false;
  const size_t base = (la == 0 ? 0 : la == 1 ? size_t(C.sx) : size_t(C.sx) + size_t(C.sy)) + size_t(l[la]);
  for (int ps = 0; ps < PCount; ++ps) {
    out.s[ps] = C.slice[base * PCount + ps].load(std::memory_order_relaxed);
    out.total += out.s[ps];
  }
  return true;
}

namespace {
template <class F>
bool withWorld(int x, int y, int z, F &&f) {
  auto &m = model();
  std::shared_ptr<CompareData> C;
  std::shared_ptr<const Structure> S;
  Placement P;
  {
    std::lock_guard<std::mutex> lk(m.mu);
    if (!m.structure || !m.placed || !m.compare || m.compare->gen != m.gen) return false;
    C = m.compare;
    S = m.structure;
    P = m.placement;
  }
  int lx, ly, lz;
  if (!worldToLocal(*S, P, x, y, z, lx, ly, lz)) return false;
  const size_t li = S->index(lx, ly, lz);
  if (li >= C->n) return false;
  f(*C, li);
  return true;
}
}  // namespace

bool noteWorld(int x, int y, int z, EpFlag f, EpErr e, bool attempt) {
  return withWorld(x, y, z, [&](CompareData &C, size_t li) { setEp(C, li, f, e, attempt); });
}
bool verifiedWorld(int x, int y, int z, uint8_t cmp) {
  return withWorld(x, y, z, [&](CompareData &C, size_t li) {
    setCmp(C, li, cmp);
    // a verified result ends "placing"
    const uint8_t ep = (C.st[li].load(std::memory_order_relaxed) >> 4) & 7;
    if (ep == EpPlacing) setEp(C, li, EpNone, ErrNone, false);
  });
}

const char *stateName(uint8_t ps) {
  static const char *k[PCount] = {"not checked", "missing", "placing", "correct", "incorrect",
                                  "skipped",     "unsupported", "failed"};
  return ps < PCount ? k[ps] : "air";
}
const char *errName(uint8_t e) {
  static const char *k[ErrCount] = {"-",          "unsupported state", "no matching item", "needs support",
                                    "companion blocked", "no exact placement", "game refused", "state mismatch",
                                    "timeout",    "validation",        "replace not allowed"};
  return e < ErrCount ? k[e] : "?";
}
const char *stateKey(uint8_t ps) {
  static const char *k[PCount] = {"prog.not_checked", "prog.missing", "prog.placing",  "prog.correct",
                                  "prog.incorrect",   "prog.skipped", "prog.unsupported", "prog.failed"};
  return ps < PCount ? k[ps] : "prog.missing";
}

}  // namespace lm::progress
