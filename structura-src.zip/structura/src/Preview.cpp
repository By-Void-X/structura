#include "Preview.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace lm {

std::vector<PreviewFace> buildPreviewFaces(const Structure &s, size_t maxFaces) {
  static const int d[6][3] = {{0, 1, 0}, {0, -1, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, 0}, {1, 0, 0}};
  std::vector<PreviewFace> out;
  out.reserve(std::min<size_t>(maxFaces, s.solidCount * 2 + 16));
  for (int x = 0; x < s.sx; ++x)
    for (int y = 0; y < s.sy; ++y)
      for (int z = 0; z < s.sz; ++z) {
        const uint16_t p = s.idx[s.index(x, y, z)];
        if (p == kVoid || s.palette[p].air) continue;
        for (int f = 0; f < 6; ++f) {
          if (s.solidAt(x + d[f][0], y + d[f][1], z + d[f][2])) continue;
          if (out.size() >= maxFaces) return out;
          out.push_back({int16_t(x), int16_t(y), int16_t(z), uint8_t(f), s.palette[p].color});
        }
      }
  return out;
}

namespace {
struct V2 {
  float x, y, z;
};

inline float edge(const V2 &a, const V2 &b, float px, float py) {
  return (b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x);
}

void triangle(const V2 &a, const V2 &b, const V2 &c, uint32_t rgb, int w, int h, std::vector<float> &zb,
              std::vector<uint8_t> &px) {
  const float area = edge(a, b, c.x, c.y);
  if (std::fabs(area) < 1e-6f) return;
  int x0 = std::max(0, int(std::floor(std::min({a.x, b.x, c.x}))));
  int x1 = std::min(w - 1, int(std::ceil(std::max({a.x, b.x, c.x}))));
  int y0 = std::max(0, int(std::floor(std::min({a.y, b.y, c.y}))));
  int y1 = std::min(h - 1, int(std::ceil(std::max({a.y, b.y, c.y}))));
  const float inv = 1.f / area;
  for (int y = y0; y <= y1; ++y)
    for (int x = x0; x <= x1; ++x) {
      const float fx = x + 0.5f, fy = y + 0.5f;
      float w0 = edge(b, c, fx, fy) * inv, w1 = edge(c, a, fx, fy) * inv, w2 = edge(a, b, fx, fy) * inv;
      if (w0 < -1e-4f || w1 < -1e-4f || w2 < -1e-4f) continue;
      const float z = w0 * a.z + w1 * b.z + w2 * c.z;
      const size_t i = size_t(y) * w + x;
      if (z >= zb[i]) continue;
      zb[i] = z;
      px[i * 4 + 0] = uint8_t(rgb >> 16);
      px[i * 4 + 1] = uint8_t(rgb >> 8);
      px[i * 4 + 2] = uint8_t(rgb);
      px[i * 4 + 3] = 255;
    }
}
}  

void renderPreview(const Structure &s, const std::vector<PreviewFace> &faces, float yawDeg, float pitchDeg, int w,
                   int h, std::vector<uint8_t> &rgba) {
  rgba.assign(size_t(w) * h * 4, 0);
  
  for (int y = 0; y < h; ++y)
    for (int x = 0; x < w; ++x) {
      uint8_t *p = &rgba[(size_t(y) * w + x) * 4];
      const uint8_t g = uint8_t(24 + 18 * y / std::max(1, h));
      p[0] = g; p[1] = uint8_t(g + 4); p[2] = uint8_t(g + 10); p[3] = 215;
    }
  std::vector<float> zb(size_t(w) * h, std::numeric_limits<float>::max());

  const float cx = s.sx * 0.5f, cy = s.sy * 0.5f, cz = s.sz * 0.5f;
  const float radius = 0.5f * std::sqrt(float(s.sx * s.sx + s.sy * s.sy + s.sz * s.sz));
  const float scale = (std::min(w, h) * 0.46f) / std::max(radius, 0.5f);
  const float yaw = yawDeg * 3.14159265f / 180.f, pitch = pitchDeg * 3.14159265f / 180.f;
  const float cyw = std::cos(yaw), syw = std::sin(yaw), cp = std::cos(pitch), sp = std::sin(pitch);

  auto project = [&](float x, float y, float z) {
    x -= cx; y -= cy; z -= cz;
    const float rx = x * cyw - z * syw;    
    const float rz = x * syw + z * cyw;
    const float ry2 = y * cp - rz * sp;    
    const float rz2 = y * sp + rz * cp;
    return V2{w * 0.5f + rx * scale, h * 0.5f - ry2 * scale, -rz2};  
  };
  
  const float vx = syw * cp, vy = sp, vz = cyw * cp;  
  static const float nrm[6][3] = {{0, 1, 0}, {0, -1, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, 0}, {1, 0, 0}};
  static const float shade[6] = {1.0f, 0.5f, 0.8f, 0.8f, 0.65f, 0.65f};
  const float pxPerBlock = scale;

  for (const auto &f : faces) {
    const float *n = nrm[f.dir];
    if (n[0] * vx + n[1] * vy + n[2] * vz <= 0.f) continue;
    const float k = shade[f.dir];
    const uint32_t c = f.color;
    const uint32_t rgb = (uint32_t(((c >> 16) & 0xFF) * k) << 16) | (uint32_t(((c >> 8) & 0xFF) * k) << 8) |
                         uint32_t((c & 0xFF) * k);
    const float x0 = f.x, y0 = f.y, z0 = f.z, x1 = x0 + 1, y1 = y0 + 1, z1 = z0 + 1;
    V2 q[4];
    switch (f.dir) {
      case 0: q[0] = project(x0, y1, z0); q[1] = project(x1, y1, z0); q[2] = project(x1, y1, z1); q[3] = project(x0, y1, z1); break;
      case 1: q[0] = project(x0, y0, z0); q[1] = project(x1, y0, z0); q[2] = project(x1, y0, z1); q[3] = project(x0, y0, z1); break;
      case 2: q[0] = project(x0, y0, z0); q[1] = project(x1, y0, z0); q[2] = project(x1, y1, z0); q[3] = project(x0, y1, z0); break;
      case 3: q[0] = project(x0, y0, z1); q[1] = project(x1, y0, z1); q[2] = project(x1, y1, z1); q[3] = project(x0, y1, z1); break;
      case 4: q[0] = project(x0, y0, z0); q[1] = project(x0, y0, z1); q[2] = project(x0, y1, z1); q[3] = project(x0, y1, z0); break;
      default: q[0] = project(x1, y0, z0); q[1] = project(x1, y0, z1); q[2] = project(x1, y1, z1); q[3] = project(x1, y1, z0); break;
    }
    if (pxPerBlock < 1.2f) {  
      const float mx = (q[0].x + q[2].x) * 0.5f, my = (q[0].y + q[2].y) * 0.5f, mz = (q[0].z + q[2].z) * 0.5f;
      const int ix = int(mx), iy = int(my);
      if (ix < 0 || iy < 0 || ix >= w || iy >= h) continue;
      const size_t i = size_t(iy) * w + ix;
      if (mz >= zb[i]) continue;
      zb[i] = mz;
      rgba[i * 4] = uint8_t(rgb >> 16); rgba[i * 4 + 1] = uint8_t(rgb >> 8); rgba[i * 4 + 2] = uint8_t(rgb); rgba[i * 4 + 3] = 255;
      continue;
    }
    triangle(q[0], q[1], q[2], rgb, w, h, zb, rgba);
    triangle(q[0], q[2], q[3], rgb, w, h, zb, rgba);
  }
}

}  
