#pragma once
// Placement plan search (pure, header-only so it can be tested on the host).
// For one target position it tries clicked faces x hit positions x player rotations and asks a simulator
// (the game's own BlockType::getPlacementBlock on device) which block that click would produce, scored
// by states::planScore(). The first exact result wins; otherwise the best partial result is returned.

#include <cstdint>
#include <initializer_list>

namespace lm::plan {

struct V3 {
  float x, y, z;
};

struct Candidate {
  bool ok = false;
  int face = 1;          // clicked face of the neighbour: 0 down 1 up 2 north 3 south 4 west 5 east
  V3 click{0.5f, 0.5f, 0.5f};
  bool rotate = false;   // player rotation must be changed for the click
  float pitch = 0, yaw = 0;
  int score = 0;         // 3 exact, 2 placement states match, 1 fallback (no simulated match)
  bool inAir = false;    // no solid neighbour: click the target position itself
  int simulations = 0;
};

// Hit positions on face f (block-local, 0..1). Phase 0: centre column (2 heights on sides);
// phase 1: side quadrants / top-bottom quadrants (hinge or half decided by the hit position).
inline int clicksFor(int f, int phase, V3 *out) {
  int n = 0;
  if (phase == 0) {
    if (f == 0) { out[n++] = {0.5f, 0.f, 0.5f}; return n; }
    if (f == 1) { out[n++] = {0.5f, 1.f, 0.5f}; return n; }
    for (float yy : {0.25f, 0.75f}) {
      V3 c{0.5f, yy, 0.5f};
      if (f == 2) c.z = 0.f;
      else if (f == 3) c.z = 1.f;
      else if (f == 4) c.x = 0.f;
      else c.x = 1.f;
      out[n++] = c;
    }
    return n;
  }
  for (float a : {0.25f, 0.75f})
    for (float b : {0.25f, 0.75f}) {
      V3 c{a, b, 0.5f};
      if (f == 0) c = {a, 0.f, b};
      else if (f == 1) c = {a, 1.f, b};
      else if (f == 2) c = {a, b, 0.f};
      else if (f == 3) c = {a, b, 1.f};
      else if (f == 4) c = {0.f, b, a};
      else c = {1.f, b, a};
      out[n++] = c;
    }
  return n;
}

// solid[f]: the neighbour on face f of the target (target - normal(f)) can be clicked.
// sim(face, click, rotate, pitch, yaw) -> score 0..3 for the block that click would place.
// extraYaw: additional player yaws worth trying (e.g. 16-step sign rotation), may be null.
template <class Sim>
Candidate search(const bool solid[6], bool canRotate, float origPitch, float origYaw, const float *extraYaw, int nExtra,
                 Sim &&sim) {
  Candidate best;
  bool anySolid = false;
  for (int f = 0; f < 6; ++f) anySolid |= solid[f];
  struct R {
    float pitch, yaw;
    bool rotate;
  };
  R rots[13 + 8];
  int nr = 0;
  rots[nr++] = {origPitch, origYaw, false};
  if (canRotate) {
    for (float p : {0.f, 80.f, -80.f})
      for (float y : {0.f, 90.f, 180.f, -90.f}) rots[nr++] = {p, y, true};
    for (int i = 0; i < nExtra && i < 8 && extraYaw; ++i) rots[nr++] = {0.f, extraYaw[i], true};
  }
  auto consider = [&](int f, const V3 &c, const R &r, int sc, bool air) {
    if (sc <= best.score) return;
    best.ok = true;
    best.face = f;
    best.click = air ? V3{0.5f, 0.5f, 0.5f} : c;
    best.rotate = r.rotate;
    best.pitch = r.pitch;
    best.yaw = r.yaw;
    best.score = sc;
    best.inAir = air;
  };
  for (int phase = 0; phase < 2 && best.score < 3; ++phase) {
    for (int ri = 0; ri < nr && best.score < 3; ++ri) {
      for (int pass = 0; pass < 2 && best.score < 3; ++pass) {
        for (int f = 0; f < 6 && best.score < 3; ++f) {
          if (pass == 0 && !solid[f]) continue;
          // Place in the air as well (as the last pass, and also when some neighbour is solid): every face is tried,
          // not only 'up'. The game's own placement function decides the facing from (face, look), so a facing can be
          // reachable through a face that has no solid neighbour (hopper, piston, observer). The simulated state must
          // still match exactly to be used.
          V3 cs[4];
          const int nc = clicksFor(f, phase, cs);
          for (int ci = 0; ci < nc && best.score < 3; ++ci) {
            ++best.simulations;
            const int sc = sim(f, cs[ci], rots[ri].rotate, rots[ri].pitch, rots[ri].yaw);
            if (sc >= 2) consider(f, cs[ci], rots[ri], sc, pass == 1);
          }
        }
      }
    }
  }
  if (!best.ok) {  // no simulated match: plain click on the first solid neighbour (score 1)
    for (int f = 0; f < 6; ++f) {
      if (!solid[f]) continue;
      V3 cs[4];
      clicksFor(f, 0, cs);
      consider(f, cs[0], rots[0], 1, false);
      break;
    }
  }
  if (!best.ok) consider(1, V3{0.5f, 0.5f, 0.5f}, rots[0], 1, true);
  return best;
}

}  // namespace lm::plan
