#pragma once
#include <algorithm>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace lm {

constexpr uint16_t kVoid = 0xFFFF;  

struct PaletteEntry {
  std::string name;   
  std::string label;  
  uint32_t color = 0xFFFF00FF;  
  bool air = false;   
  uint32_t count = 0; 
};


struct BlockStateValue {
  std::string key;
  uint8_t type = 0;  
  int32_t i = 0;
  std::string s;
};


struct BlockVariant {
  uint16_t palette = kVoid;
  std::string fullName;    
  std::vector<BlockStateValue> states;
};

struct Structure {
  std::string title;  
  std::string path;
  int sx = 0, sy = 0, sz = 0;
  std::vector<uint16_t> idx;  
  std::vector<PaletteEntry> palette;
  uint32_t solidCount = 0;    
  std::vector<BlockVariant> variants;
  std::vector<uint16_t> vidx;  
  std::vector<uint32_t> water;  // sorted linear indices with water in layer 2 (waterlogged)
  bool waterAt(size_t li) const { return std::binary_search(water.begin(), water.end(), uint32_t(li)); }

  size_t volume() const { return size_t(sx) * sy * sz; }
  size_t index(int x, int y, int z) const { return (size_t(x) * sy + y) * sz + z; }
  bool inside(int x, int y, int z) const { return x >= 0 && y >= 0 && z >= 0 && x < sx && y < sy && z < sz; }
  
  uint16_t at(int x, int y, int z) const { return inside(x, y, z) ? idx[index(x, y, z)] : kVoid; }
  bool solidAt(int x, int y, int z) const {
    const uint16_t p = at(x, y, z);
    return p != kVoid && !palette[p].air;
  }
};


struct LoadInfo {
  int sx = 0, sy = 0, sz = 0;
  std::string indicesType;    
  size_t indexCount = 0;      
  size_t paletteSize = 0;     
  size_t airCount = 0;        
  size_t solidCount = 0;      
  size_t voidCount = 0;       
  // block states (every palette state kept; classified with states::ruleFor)
  size_t variantsOk = 0;          // variants whose states are all known
  size_t variantsDirectional = 0; // with placement-decided states (facing, half, axis, ...)
  size_t variantsMulti = 0;       // multi-block parts (doors, beds, tall plants)
  size_t variantsUnknown = 0;     // with a state key without a rule (kept + compared, not rotated)
  size_t discardedStates = 0;     // palette states dropped by the parser (always 0: nothing is dropped)
  size_t preservedStates = 0;     // palette state values kept (all of them)
  size_t rawStates = 0;           // kept as raw data (non byte/int/string NBT type): block unsupported
  size_t discardedVariants = 0;   // palette entries beyond the 65520 limit (blocks left empty)
  size_t waterlogged = 0;         // positions with water in layer 2
  size_t blockEntities = 0;       // block_position_data entries (not placeable by Easy Place)
  std::string unknownKeys, discardedKeys, rawKeys;
  // source format: "mcstructure" or a Java format converted on load ("litematic", "sponge-v2", "mcedit", "java-nbt")
  std::string format;
  int javaDataVersion = 0;
  size_t javaStates = 0, javaApprox = 0, javaUnmapped = 0;  // Java palette states / closest-match / no Bedrock block
  std::string javaUnmappedNames;  // first few keys, for the diagnostics
  std::string describe() const;
  std::string statesLine() const;
};

bool loadStructure(const std::string &path, Structure &out, std::string &err, LoadInfo *info = nullptr);


bool saveStructure(const std::string &path, int sx, int sy, int sz, const std::vector<std::string> &names,
                   const std::vector<int32_t> &indices, int ox, int oy, int oz, std::string &err);


std::string normalizeName(const std::string &fullName);
uint32_t blockColor(const std::string &shortName);
std::string prettyName(const std::string &shortName);


struct Placement {
  int ox = 0, oy = 0, oz = 0;  
  int rot = 0;                 
  bool mirror = false;         
};


inline void rotatedSize(const Structure &s, int rot, int &wx, int &wz) {
  if (rot & 1) { wx = s.sz; wz = s.sx; } else { wx = s.sx; wz = s.sz; }
}

inline bool worldToLocal(const Structure &s, const Placement &p, int wx, int wy, int wz, int &x, int &y, int &z) {
  int X = wx - p.ox, Y = wy - p.oy, Z = wz - p.oz;
  int dx, dz;
  rotatedSize(s, p.rot, dx, dz);
  if (X < 0 || Y < 0 || Z < 0 || X >= dx || Y >= s.sy || Z >= dz) return false;
  switch (p.rot & 3) {
    case 0: x = X; z = Z; break;
    case 1: x = Z; z = s.sz - 1 - X; break;
    case 2: x = s.sx - 1 - X; z = s.sz - 1 - Z; break;
    default: x = s.sx - 1 - Z; z = X; break;
  }
  if (p.mirror) x = s.sx - 1 - x;
  y = Y;
  return true;
}

inline void localToWorld(const Structure &s, const Placement &p, int x, int y, int z, int &wx, int &wy, int &wz) {
  const int x0 = p.mirror ? s.sx - 1 - x : x;
  int X, Z;
  switch (p.rot & 3) {
    case 0: X = x0; Z = z; break;
    case 1: X = s.sz - 1 - z; Z = x0; break;
    case 2: X = s.sx - 1 - x0; Z = s.sz - 1 - z; break;
    default: X = z; Z = s.sx - 1 - x0; break;
  }
  wx = p.ox + X; wy = p.oy + y; wz = p.oz + Z;
}

}  
