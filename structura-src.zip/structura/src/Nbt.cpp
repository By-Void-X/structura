#include "Nbt.hpp"

#include <cstring>

namespace lm::nbt {
namespace {

struct Reader {
  const uint8_t *p, *end;
  std::string err;
  size_t budget = 64u * 1024 * 1024;  
  bool be = false;  // Java Edition files are big-endian; Bedrock files are little-endian

  bool need(size_t n) {
    if (size_t(end - p) < n) {
      err = "truncated file";
      return false;
    }
    return true;
  }
  bool u8(uint8_t &v) { if (!need(1)) return false; v = *p++; return true; }
  bool i16(int64_t &v) {
    if (!need(2)) return false;
    uint16_t x; std::memcpy(&x, p, 2); p += 2;
    if (be) x = __builtin_bswap16(x);
    v = int16_t(x); return true;
  }
  bool i32(int64_t &v) {
    if (!need(4)) return false;
    uint32_t x; std::memcpy(&x, p, 4); p += 4;
    if (be) x = __builtin_bswap32(x);
    v = int32_t(x); return true;
  }
  bool i64(int64_t &v) {
    if (!need(8)) return false;
    uint64_t x; std::memcpy(&x, p, 8); p += 8;
    if (be) x = __builtin_bswap64(x);
    v = int64_t(x); return true;
  }
  bool f32(double &v) {
    int64_t r; if (!i32(r)) return false;
    const uint32_t u = uint32_t(r); float x; std::memcpy(&x, &u, 4); v = x; return true;
  }
  bool f64(double &v) {
    int64_t r; if (!i64(r)) return false;
    double x; std::memcpy(&x, &r, 8); v = x; return true;
  }
  bool str(std::string &s) {
    if (!need(2)) return false;
    const uint16_t n = be ? uint16_t((p[0] << 8) | p[1]) : uint16_t(p[0] | (p[1] << 8));
    p += 2;
    if (!need(n)) return false;
    s.assign(reinterpret_cast<const char *>(p), n);
    p += n;
    return true;
  }
  bool count(int64_t &n) {
    if (!i32(n)) return false;
    if (n < 0 || size_t(n) > budget) {
      err = "bad list size";
      return false;
    }
    budget -= size_t(n);
    return true;
  }

  bool payload(Type t, Tag &tag, int depth) {
    if (depth > 64) { err = "aninhamento demais"; return false; }
    tag.type = t;
    switch (t) {
      case Byte: { uint8_t b; if (!u8(b)) return false; tag.i = int8_t(b); return true; }
      case Short: return i16(tag.i);
      case Int: return i32(tag.i);
      case Long: return i64(tag.i);
      case Float: return f32(tag.d);
      case Double: return f64(tag.d);
      case String: return str(tag.s);
      case ByteArray: {
        int64_t n; if (!count(n) || !need(size_t(n))) return false;
        tag.nums.resize(size_t(n));
        for (int64_t k = 0; k < n; ++k) tag.nums[size_t(k)] = int8_t(*p++);
        return true;
      }
      case IntArray: case LongArray: {
        int64_t n; if (!count(n) || !need(size_t(n) * (t == IntArray ? 4 : 8))) return false;
        tag.nums.resize(size_t(n));  
        for (int64_t k = 0; k < n; ++k)
          if (!(t == IntArray ? i32(tag.nums[size_t(k)]) : i64(tag.nums[size_t(k)]))) return false;
        return true;
      }
      case List: {
        uint8_t et; if (!u8(et)) return false;
        int64_t n; if (!count(n)) return false;
        if (et > LongArray) { err = "bad list type"; return false; }
        // every element takes at least one byte: a count larger than the rest of the file is garbage
        // (wrong endianness or a corrupt file) and must not reach resize()
        if (et != End && size_t(n) > size_t(end - p)) { err = "truncated file"; return false; }
        tag.listType = Type(et);
        if (et == Byte || et == Short || et == Int || et == Long) {
          tag.nums.resize(size_t(n));
          for (int64_t k = 0; k < n; ++k) {
            Tag tmp;
            if (!payload(Type(et), tmp, depth + 1)) return false;
            tag.nums[size_t(k)] = tmp.i;
          }
        } else if (et != End) {
          tag.items.resize(size_t(n));
          for (int64_t k = 0; k < n; ++k)
            if (!payload(Type(et), tag.items[size_t(k)], depth + 1)) return false;
        }
        return true;
      }
      case Compound: {
        for (;;) {
          uint8_t ct; if (!u8(ct)) return false;
          if (ct == End) return true;
          if (ct > LongArray) { err = "tipo invalido no compound"; return false; }
          std::string name; if (!str(name)) return false;
          tag.fields.emplace_back(std::move(name), Tag{});
          if (!payload(Type(ct), tag.fields.back().second, depth + 1)) return false;
        }
      }
      default: err = "tipo desconhecido"; return false;
    }
  }
};

}  

static const char *baseName(Type t) {
  switch (t) {
    case End: return "END"; case Byte: return "BYTE"; case Short: return "SHORT"; case Int: return "INT";
    case Long: return "LONG"; case Float: return "FLOAT"; case Double: return "DOUBLE";
    case ByteArray: return "BYTE_ARRAY"; case String: return "STRING"; case List: return "LIST";
    case Compound: return "COMPOUND"; case IntArray: return "INT_ARRAY"; case LongArray: return "LONG_ARRAY";
  }
  return "?";
}

std::string typeName(const Tag &t) {
  if (t.type != List) return baseName(t.type);
  if (t.listType == List && !t.items.empty()) return "LIST<" + typeName(t.items[0]) + ">";
  return std::string("LIST<") + baseName(t.listType) + ">";
}

bool parse(const uint8_t *data, size_t size, Tag &root, std::string &err, bool bigEndian) {
  Reader r{data, data + size, {}};
  r.be = bigEndian;
  uint8_t t;
  std::string name;
  if (!r.u8(t) || t != Compound) { err = "not an NBT structure file"; return false; }
  if (!r.str(name) || !r.payload(Compound, root, 0)) { err = r.err.empty() ? "NBT invalido" : r.err; return false; }
  return true;
}

}  
