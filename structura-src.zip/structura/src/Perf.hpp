#pragma once



#include <atomic>
#include <cstdint>

namespace lm::perf {

enum Counter : int {
  RenderHook,     
  PlayerUpdate,   
  GuiSubmit,      
  GuiCommands,    
  LayoutRebuild,  
  TextureRebuild, 
  MeshRebuild,    
  WorldQuery,     
  BlockingWait,   
  Alloc,          
  CounterCount
};

extern std::atomic_bool gOn;
extern std::atomic<uint64_t> gCnt[CounterCount];

inline bool on() { return gOn.load(std::memory_order_relaxed); }
inline void count(Counter c, uint64_t n = 1) {
  if (gOn.load(std::memory_order_relaxed)) gCnt[c].fetch_add(n, std::memory_order_relaxed);
}



void setEnabled(bool on);
bool takeLine(char *out, unsigned outSize);

}  
