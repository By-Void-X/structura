#pragma once








#include <cstddef>
#include <initializer_list>
#include <string>
#include <string_view>
#include <vector>

namespace lm::i18n {

struct Entry {
  const char *key;
  const char *text;
};


void init(const std::string &configDir);


void setChoice(std::string_view code);
std::string choice();


std::string activeCode();
std::string activeName();   
std::string detectedCode(); 


struct Language {
  std::string code, name;
};
std::vector<Language> languages();


unsigned generation();


const char *tr(std::string_view key);

std::string fmt(std::string_view key, std::initializer_list<std::string_view> args);


void setDevMode(bool on);
void setLogger(void (*log)(const std::string &));
std::vector<std::string> missingKeys();  
std::vector<std::string> keysMissingIn(std::string_view code);  


std::string matchCode(std::string_view tag);


void setDetectOverride(std::string_view launcherTag, std::string_view systemTag);

}  
