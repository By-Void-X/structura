#pragma once
// Progress / layer overlay: a small touch panel drawn on the game HUD while the main panel is closed,
// independent of it (own position, size, scale, opacity, visibility). Reads the central progress model
// (Progress.hpp) only; never places blocks itself (place actions start an Easy Place run after a confirm).
#include <pl/Input.hpp>
#include "UiKit.hpp"

namespace lm::overlay {
void setActions(void (*openUi)(), void (*wake)());
// Something to draw now: overlay enabled, structure placed, game HUD visible.
bool wanted();
// Look changed since the last draw (positions, settings, progress in 200 ms buckets, pressed button).
bool changed(float W, float H);
void draw(ui::kit::Canvas &cv, float W, float H);
// Not drawn this frame (main panel open, nothing to show): touches pass through, gesture cancelled.
void hidden();
// Consumes only touches that start inside the overlay (and the rest of that gesture).
bool onTouch(const pl::input::TouchEvent &ev);
// diagnostics
const char *uiStatus();      // "Active" / "Hidden" / "Waiting" / "Off"
const char *touchStatus();   // "OK" / "Not checked" / "Active (dragging)"
uint32_t touchesConsumed();
}  // namespace lm::overlay
