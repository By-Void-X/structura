#pragma once




#include <cstdint>
#include <string>
#include <string_view>

namespace lm::ver {

enum class Channel : int { Unknown = 0, Stable, ReleaseCandidate, Preview, Beta };

struct GameVersion {
  
  int major = -1, minor = 0, patch = 0, build = 0;
  int parts = 0;          
  Channel channel = Channel::Unknown;
  int channelNumber = 0;  
  bool is_preview = false;            
  bool is_release_candidate = false;  
  bool channelFromBuild = false;      
  std::string abi;        
  std::string raw;        
  bool valid() const { return major >= 0; }
};


bool parse(std::string_view text, GameVersion &out);

std::string normalized(const GameVersion &v);

int compare(const GameVersion &a, const GameVersion &b);

bool sameRelease(const GameVersion &a, const GameVersion &b);
const char *channelName(Channel c);  

}  
