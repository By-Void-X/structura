#pragma once
#include <atomic>
#include <cstdint>
#include <string>
#include <vector>

namespace pl::log {
class Logger;
}

namespace ep {

int64_t nowMs();

struct State {
  std::atomic_bool enabled{false};  
  std::atomic_bool installed{false};
};
State &state();


void toast(const std::string &text, uint32_t color = 0xFFFFFFFF, int ms = 2000);


void setLogPath(const std::string &path);
void logf(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
void flushLog();
// Last step the mod was in (set at key points). Written to the log by the terminate handler when the game aborts.
void setStep(const char *s);
const char *currentStep();


bool install(pl::log::Logger &log);

// ---- placement verification (diagnostics) ----
struct Stats {
  uint32_t placed = 0, exact = 0, mismatch = 0, corrected = 0, failed = 0, unsupported = 0, skipped = 0;
};
Stats stats();
struct Record {  // "Placement: PARTIAL / Block / Position / Expected / Actual / Correction / Result"
  int x = 0, y = 0, z = 0;
  std::string status, block, expected, actual, correction, result;
  int64_t at = 0;
};
std::vector<Record> recent();  // newest first, at most 16
const char *modeText();

const char *disabledReason();


void onClientUpdate(void *ci);
// Same per-client step, driven by the local player's tick when ClientInstance::update is unavailable.
void onLocalPlayerTick();
// ---- run controls (UI thread; the game thread acts on its next tick) ----
// Drops the queue, a pending turn (rotation restored), corrections and rechecks; never places anything.
void invalidate(const char *why);
void pause();   // no new placement; a turn that has not placed yet is cancelled
void resume();
bool paused();
void cancel();  // stops the run, disables Easy Place, invalidates the queue
// 0 = stop the run (crosshair Easy Place unchanged), 1 = place the selected layer, 2 = all visible missing
void startRun(int scope);
int runScope();
enum Op : int { OpIdle = 0, OpTurning, OpPlacing, OpVerifying, OpCorrecting, OpNeedItem, OpPaused, OpNoTarget, OpCount };
int currentOp();
// GameMode/SurvivalMode tick hooks used as a player context source (independent of placement validation).
bool installContextTicks(pl::log::Logger &log, std::string &detail);

}  
