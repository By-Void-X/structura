#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include <pl/Logger.hpp>

#include "BlockStates.hpp"

struct StructuraApiV1;

namespace lm::holo {


enum class InstallResult : int { Ok = 0, SignatureMissing, HookFailed };
InstallResult install(pl::log::Logger &log);

const StructuraApiV1 *api();

int faceMaterialCount();
int blockLookCount();
const char *blockLookName(int i);
bool blockLookUsesAlpha(int i);
const char *faceMaterialName(int i);


struct CaptureResult {
  int sx = 0, sy = 0, sz = 0, ox = 0, oy = 0, oz = 0;
  std::vector<std::string> names;  
  std::vector<int32_t> indices;
};
bool takeCapture(CaptureResult &out);

// ---- shared transformed pipeline (hologram = Easy Place = verification) ----
// Everything a placement needs about one world position of the placed structure.
struct Expect {
  bool ok = false;
  uint16_t variant = 0xFFFF;
  int x = 0, y = 0, z = 0;        // world position
  int lx = 0, ly = 0, lz = 0;     // original (structure-local) position
  std::string name;               // palette short name
  uintptr_t block = 0;            // expected game Block* (transformed states applied), 0 = not resolved
  std::vector<BlockStateValue> original;  // palette states as stored in the file
  std::vector<BlockStateValue> states;    // after rotation/mirror
  std::string unsupported;        // non-empty: exact transform impossible (reason), Easy Place skips it
  bool directional = false;       // has placement-decided states (facing, half, axis, ...)
  bool companion = false;         // multi-block: the game creates a second part
  int cx = 0, cy = 0, cz = 0;
  std::string companionWhat;
  bool companionInStructure = false;
  uintptr_t companionBlock = 0;
};
bool expectAt(int x, int y, int z, Expect &out);
// Visible-layer gate (same box the hologram draws): 0 = outside the placed structure (or no structure),
// 1 = a cell Easy Place may touch (visible layers; whole structure when "only visible layer" is off),
// 2 = inside the structure but in a hidden layer.
int layerGate(int x, int y, int z);
// Exact / Equivalent / StateMismatch (+diffs) / WrongBlock / Missing for a world (or simulated) block.
states::Compared compareWorld(const Expect &e, uintptr_t world);
// "facing=north half=top" of a world block (expectedSide: of e.block) for the verified keys of e.
std::string describeWorld(const Expect &e, uintptr_t world, bool expectedSide = false);
// value index of one palette state on a game block (legacy aliases tried), -1 if absent.
int64_t blockStateValue(uintptr_t block, const Expect &e, const BlockStateValue &sv);
std::string captureError();

}  
