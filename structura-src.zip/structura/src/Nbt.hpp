#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include <utility>
#include <vector>

namespace lm::nbt {

enum Type : uint8_t {
  End = 0, Byte = 1, Short = 2, Int = 3, Long = 4, Float = 5, Double = 6, ByteArray = 7,
  String = 8, List = 9, Compound = 10, IntArray = 11, LongArray = 12,
};

struct Tag {
  Type type = End;
  int64_t i = 0;                  
  double d = 0;                   
  std::string s;                  
  Type listType = End;            
  std::vector<int64_t> nums;      
  std::vector<Tag> items;         
  std::vector<std::pair<std::string, Tag>> fields;  

  const Tag *get(const std::string &key) const {
    for (auto &f : fields)
      if (f.first == key) return &f.second;
    return nullptr;
  }
  
  
  bool isIntList() const {
    if (type == ByteArray || type == IntArray || type == LongArray) return true;
    return type == List && (listType == Byte || listType == Short || listType == Int || listType == Long ||
                            listType == End              );
  }
  
  bool isListOfIntLists() const {
    return type == List && (listType == List || listType == ByteArray || listType == IntArray || listType == LongArray);
  }
};


// bigEndian: Java Edition NBT (structure .nbt, .litematic, .schem, .schematic)
bool parse(const uint8_t *data, size_t size, Tag &root, std::string &err, bool bigEndian = false);


std::string typeName(const Tag &t);


class Writer {
public:
  std::vector<uint8_t> out;
  void beginCompound(const std::string &name) { head(Compound, name); }
  void endCompound() { u8(End); }
  void beginList(const std::string &name, Type elem, int32_t count) {
    head(List, name);
    u8(elem);
    i32(count);
  }
  
  void listCompoundBegin() {}
  void listCompoundEnd() { u8(End); }
  void listInt(int32_t v) { i32(v); }
  void listListBegin(Type elem, int32_t count) { u8(elem); i32(count); }
  void putInt(const std::string &name, int32_t v) { head(Int, name); i32(v); }
  void putByte(const std::string &name, int8_t v) { head(Byte, name); u8(uint8_t(v)); }
  void putString(const std::string &name, const std::string &v) { head(String, name); str(v); }

private:
  void head(Type t, const std::string &name) { u8(t); str(name); }
  void u8(uint8_t v) { out.push_back(v); }
  void i32(int32_t v) { for (int k = 0; k < 4; ++k) out.push_back(uint8_t(uint32_t(v) >> (8 * k))); }
  void str(const std::string &v) {
    const uint16_t n = uint16_t(v.size() > 0xFFFF ? 0xFFFF : v.size());
    out.push_back(uint8_t(n));
    out.push_back(uint8_t(n >> 8));
    out.insert(out.end(), v.begin(), v.begin() + n);
  }
};

}  
