#include "Perf.hpp"

#include <chrono>
#include <cstdio>

namespace lm::perf {

std::atomic_bool gOn{false};
std::atomic<uint64_t> gCnt[CounterCount];

namespace {
uint64_t gLast[CounterCount] = {};
int64_t gLastAt = 0;
int64_t nowMs() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch())
      .count();
}
}  

void setEnabled(bool v) {
  if (v == gOn.load(std::memory_order_relaxed)) return;
  if (v) {
    for (int i = 0; i < CounterCount; ++i) gLast[i] = gCnt[i].load(std::memory_order_relaxed);
    gLastAt = nowMs();
  }
  gOn.store(v, std::memory_order_relaxed);
}

bool takeLine(char *out, unsigned outSize) {
  if (!gOn.load(std::memory_order_relaxed) || outSize == 0) return false;
  const int64_t now = nowMs();
  if (now - gLastAt < 1000) return false;
  uint64_t d[CounterCount];
  for (int i = 0; i < CounterCount; ++i) {
    const uint64_t v = gCnt[i].load(std::memory_order_relaxed);
    d[i] = v - gLast[i];
    gLast[i] = v;
  }
  const double secs = double(now - gLastAt) / 1000.0;
  gLastAt = now;
  const double frames = d[RenderHook] ? double(d[RenderHook]) : 1.0;
  auto pf = [&](Counter c) { return double(d[c]) / frames; };
  
  
  std::snprintf(out, outSize,
                "[perf] frame_id=%llu fps=%.1f frame_time_ms=%.2f render_hook_calls=%.2f player_update_calls=%.2f "
                "gui_draw_calls=%.3f gui_commands=%.2f allocations_this_frame=%.3f layout_rebuilds=%.3f "
                "texture_rebuilds=%.3f mesh_rebuilds=%.3f world_queries=%.3f gpu_flushes=0 swap_calls=0 "
                "blocking_waits=%llu",
                static_cast<unsigned long long>(gCnt[RenderHook].load(std::memory_order_relaxed)),
                double(d[RenderHook]) / secs, d[RenderHook] ? secs * 1000.0 / double(d[RenderHook]) : 0.0,
                pf(RenderHook), pf(PlayerUpdate), pf(GuiSubmit), pf(GuiCommands), pf(Alloc), pf(LayoutRebuild),
                pf(TextureRebuild), pf(MeshRebuild), pf(WorldQuery), static_cast<unsigned long long>(d[BlockingWait]));
  return true;
}

}  
