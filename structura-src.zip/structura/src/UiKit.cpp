#include "UiKit.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <unordered_map>

#if defined(__ANDROID__)
#include <sys/system_properties.h>
#endif

namespace lm::ui::kit {

namespace col = theme::color;
using pl::modmenu::DrawCommand;
using pl::modmenu::DrawCommandType;


Rect Rect::intersect(const Rect &o) const {
  const float nx = std::max(x, o.x), ny = std::max(y, o.y);
  const float nr = std::min(r(), o.r()), nb = std::min(b(), o.b());
  return {nx, ny, std::max(0.f, nr - nx), std::max(0.f, nb - ny)};
}
Rect Rect::takeLeft(float v, float gap) {
  Rect o{x, y, std::min(v, w), h};
  x += o.w + gap;
  w = std::max(0.f, w - o.w - gap);
  return o;
}
Rect Rect::takeRight(float v, float gap) {
  Rect o{r() - std::min(v, w), y, std::min(v, w), h};
  w = std::max(0.f, w - o.w - gap);
  return o;
}
Rect Rect::takeTop(float v, float gap) {
  Rect o{x, y, w, std::min(v, h)};
  y += o.h + gap;
  h = std::max(0.f, h - o.h - gap);
  return o;
}
Rect Rect::takeBottom(float v, float gap) {
  Rect o{x, b() - std::min(v, h), w, std::min(v, h)};
  h = std::max(0.f, h - o.h - gap);
  return o;
}

uint32_t toneColor(Tone t) {
  switch (t) {
    case Tone::Success: return col::Success;
    case Tone::Warning: return col::Warning;
    case Tone::Error: return col::Error;
    case Tone::Neutral: return col::TextSecondary;
    case Tone::Info:
    case Tone::Loading: return col::AccentText;
  }
  return col::TextSecondary;
}
uint32_t toneSoft(Tone t) {
  switch (t) {
    case Tone::Success: return col::SuccessSoft;
    case Tone::Warning: return col::WarningSoft;
    case Tone::Error: return col::ErrorSoft;
    case Tone::Neutral: return 0x30A6AEBB;
    case Tone::Info:
    case Tone::Loading: return col::AccentSoft;
  }
  return col::AccentSoft;
}


namespace {
float gDensityOverride = 0.f;
int64_t nowMs() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch())
      .count();
}
}  

void setDensityOverride(float pxPerDp) { gDensityOverride = pxPerDp; }

float deviceDensity(float surfW, float surfH) {
  if (gDensityOverride > 0.f) return gDensityOverride;
  static float cached = -1.f;
  if (cached < 0.f) {
    cached = 0.f;
#if defined(__ANDROID__)
    char v[PROP_VALUE_MAX] = {};
    for (const char *prop : {"ro.sf.lcd_density", "qemu.sf.lcd_density"})
      if (__system_property_get(prop, v) > 0) {
        const float dpi = std::strtof(v, nullptr);
        if (dpi >= 80.f && dpi <= 1200.f) { cached = dpi / 160.f; break; }
      }
#endif
  }
  if (cached > 0.f) return cached;
  return std::clamp(std::min(surfW, surfH) / 400.f, 1.f, 4.f);  
}

Metrics makeMetrics(float pxPerDp, bool compact, const theme::UiStyle *style, float devDensity) {
  namespace sz = theme::size;
  namespace ty = theme::type;
  namespace spc = theme::space;
  Metrics m;
  m.dp = pxPerDp;
  m.dev = devDensity > 0 ? devDensity : pxPerDp;
  m.compact = compact;
  const theme::UiStyle def{};
  const theme::UiStyle &st = style ? *style : def;
  m.spacing = style ? st.spacing : 1.f;
  m.layout = st.layout;
  m.labels = st.labels;
  for (int i = 0; i < theme::style::InkCount; ++i) m.op[i] = style ? st.op[i] : 1.f;
  m.touch = m.dev * st.touchMinDp;
  m.s1 = m.sp(spc::S1); m.s2 = m.sp(spc::S2); m.s3 = m.sp(spc::S3); m.s4 = m.sp(spc::S4); m.s6 = m.sp(spc::S6);
  m.s8 = m.sp(spc::S8); m.s10 = m.sp(spc::S10); m.s12 = m.sp(spc::S12); m.s14 = m.sp(spc::S14);
  m.s16 = m.sp(spc::S16); m.s20 = m.sp(spc::S20);
  m.row = std::max(m.px(compact ? sz::RowCompact : sz::Row), m.touch);
  m.ctl = std::max(m.px(sz::Control), m.touch);
  m.ctlTall = std::max(m.px(sz::ControlTall), m.touch);
  m.iconS = m.px(sz::IconSmall);
  m.iconM = m.px(sz::NavIcon);
  m.iconLead = m.sp(sz::IconLead);
  m.iconGap = m.sp(sz::IconTextGap);
  m.header = std::max(m.px(compact ? sz::HeaderCompact : sz::Header), m.touch);  
  m.tab = m.px(compact ? sz::TabCompact : sz::Tab);
  m.pad = m.sp(compact ? sz::PadCompact : sz::Pad);
  m.gap = m.sp(compact ? sz::GapCompact : sz::Gap);
  m.section = m.sp(sz::Section);
  m.radius = m.px(sz::Radius);
  m.radiusPanel = m.px(sz::RadiusPanel);
  m.edge = std::max(2.f, m.px(sz::Edge));
  m.border = std::max(1.f, std::round(m.px(sz::Border)));
  m.indicator = std::max(2.f, m.px(sz::Indicator));
  m.icon = m.px(sz::Icon);
  m.scrollBar = std::max(3.f, m.px(sz::ScrollBar));
  m.msgMin = m.px(sz::MessageMin);
  const float fs = compact ? 0.93f : 1.f;
  auto f = [&](float sp) { return std::max(ty::MinPx, m.px(sp) * fs); };
  m.fTitle = f(ty::Title);
  m.fBody = f(ty::Body);
  m.fLabel = f(ty::Label);
  m.fSmall = f(ty::Small);
  m.fCaption = f(ty::Caption);
  return m;
}


namespace {
#include "FontWidths.inc"

uint32_t nextCp(std::string_view s, size_t &i) {
  const auto c = static_cast<unsigned char>(s[i]);
  int n = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 1;
  if (i + n > s.size()) n = 1;
  uint32_t cp = n == 1 ? c : n == 2 ? (c & 0x1F) : n == 3 ? (c & 0x0F) : (c & 0x07);
  for (int k = 1; k < n; ++k) cp = (cp << 6) | (static_cast<unsigned char>(s[i + k]) & 0x3F);
  i += n;
  return cp;
}


float advance(uint32_t cp) {
  for (const auto &r : kWidthRanges)
    if (cp >= r.first && cp <= r.last) {
      if (const uint16_t w = r.w[cp - r.first]; w != 0xFFFF) return w;
      break;
    }
  if (cp >= 0x0300 && cp <= 0x036F) return 0;  
  if (cp == 0x200B || cp == 0x200C || cp == 0x200D || cp == 0xFEFF) return 0;  
  switch (cp) {
    case 0x2026: return 669;  
    case 0x2013: return 656;
    case 0x2014: return 781;
    case 0x2022: return 337;
    case 0x2018: case 0x2019: return 196;
    case 0x201C: case 0x201D: return 340;
    default: break;
  }
  
  if ((cp >= 0x2E80 && cp <= 0x9FFF) || (cp >= 0xAC00 && cp <= 0xD7AF) || (cp >= 0xF900 && cp <= 0xFAFF) ||
      (cp >= 0xFF00 && cp <= 0xFF60) || (cp >= 0x20000 && cp <= 0x2FFFF))
    return 1000;
  return 640;  
}

struct SvHash {
  using is_transparent = void;
  size_t operator()(std::string_view v) const noexcept { return std::hash<std::string_view>{}(v); }
};

std::unordered_map<std::string, float, SvHash, std::equal_to<>> gWidthCache;

float emWidth(std::string_view s) {
  if (s.size() <= 48) {
    if (auto it = gWidthCache.find(s); it != gWidthCache.end()) return it->second;
  }
  float sum = 0;
  for (size_t i = 0; i < s.size();) sum += advance(nextCp(s, i));
  sum /= 1000.f;
  if (s.size() <= 48) {
    if (gWidthCache.size() > 2048) gWidthCache.clear();
    gWidthCache.emplace(std::string(s), sum);
  }
  return sum;
}

size_t prevBoundary(std::string_view s, size_t n) {
  if (n == 0) return 0;
  --n;
  while (n > 0 && (static_cast<unsigned char>(s[n]) & 0xC0) == 0x80) --n;
  return n;
}
}  

void resetTextCache() { gWidthCache.clear(); }
float minTextPx() { return theme::type::MinPx; }

float textWidth(std::string_view s, float size) {
  if (s.empty()) return 0.f;
  return emWidth(s) * size * 1.04f + 1.f;  
}

std::string ellipsize(std::string_view s, float maxW, float size) {
  if (textWidth(s, size) <= maxW) return std::string(s);
  static const std::string kDots = "\xE2\x80\xA6";
  const float dotsW = textWidth(kDots, size);
  size_t n = s.size();
  while (n > 0) {
    n = prevBoundary(s, n);
    std::string_view head = s.substr(0, n);
    while (!head.empty() && head.back() == ' ') head.remove_suffix(1);
    if (textWidth(head, size) + dotsW <= maxW) return std::string(head) + kDots;
  }
  return dotsW <= maxW ? kDots : std::string();
}

float fitSize(std::string_view s, float maxW, float size) {
  const float w = textWidth(s, size);
  if (w <= maxW || w <= 0) return size;
  const float floor = std::max(minTextPx(), size * theme::type::ShrinkMin);
  return std::max(floor, size * maxW / w);
}

std::vector<std::string> wrap(std::string_view s, float maxW, float size, int maxLines) {
  std::vector<std::string> lines;
  if (maxLines <= 0) return lines;
  std::string cur;
  auto push = [&](std::string l) { lines.push_back(std::move(l)); };
  size_t i = 0;
  bool truncated = false;
  while (i < s.size() && !truncated) {
    if (s[i] == '\n') {
      push(cur);
      cur.clear();
      ++i;
      if (int(lines.size()) >= maxLines) truncated = i < s.size();
      continue;
    }
    if (s[i] == ' ') { ++i; continue; }
    size_t j = i;
    while (j < s.size() && s[j] != ' ' && s[j] != '\n') ++j;
    std::string_view word = s.substr(i, j - i);
    const std::string trial = cur.empty() ? std::string(word) : cur + " " + std::string(word);
    if (textWidth(trial, size) <= maxW) {
      cur = trial;
      i = j;
      continue;
    }
    if (!cur.empty()) {  
      push(cur);
      cur.clear();
      if (int(lines.size()) >= maxLines) { truncated = true; break; }
      continue;
    }
    
    size_t k = 0, lastFit = 0;
    while (k < word.size()) {
      size_t nk = k;
      nextCp(word, nk);
      if (textWidth(word.substr(0, nk), size) > maxW) break;
      lastFit = k = nk;
    }
    if (lastFit == 0) nextCp(word, lastFit);  
    push(std::string(word.substr(0, lastFit)));
    i += lastFit;
    if (int(lines.size()) >= maxLines) { truncated = i < s.size(); break; }
  }
  if (!truncated && !cur.empty()) push(cur);
  if (int(lines.size()) > maxLines) lines.resize(maxLines);
  if (truncated && !lines.empty()) {
    std::string rest(s.substr(std::min(i, s.size())));
    while (!rest.empty() && (rest[0] == ' ' || rest[0] == '\n')) rest.erase(0, 1);
    std::string last = lines.back() + (rest.empty() ? "" : " " + rest);
    for (auto &c : last)
      if (c == '\n') c = ' ';
    lines.back() = ellipsize(last + (textWidth(last, size) <= maxW ? "\xE2\x80\xA6" : ""), maxW, size);
  }
  if (lines.empty()) lines.emplace_back();
  return lines;
}


void Canvas::begin(const Metrics &metrics) {
  count = 0;  
  hits.clear();
  m = metrics;
  alpha = 1.f;
  noClip();
}

pl::modmenu::DrawCommand &Canvas::next() {
  if (count == cmds.size()) cmds.emplace_back();
  DrawCommand &d = cmds[count++];
  d.type = DrawCommandType::Text;
  d.x = d.y = d.w = d.h = d.x3 = d.y3 = d.size = 0.f;
  d.color = 0;
  d.text.clear();
  d.fontId.clear();
  d.imageId.clear();
  return d;
}

uint32_t Canvas::fade(uint32_t c) const {
  if (alpha >= 0.999f) return c;
  const uint32_t a = static_cast<uint32_t>(std::lround(((c >> 24) & 0xFF) * std::clamp(alpha, 0.f, 1.f)));
  return (a << 24) | (c & 0x00FFFFFF);
}

namespace {
bool isStrip(uint32_t c) {
  const uint32_t rgb = c & 0x00FFFFFF;
  return rgb == (col::Header & 0x00FFFFFF) || rgb == (col::HeaderBorder & 0x00FFFFFF) ||
         rgb == (col::HeaderPressed & 0x00FFFFFF);
}
}  


int Canvas::cutInk(uint32_t c) const { return isStrip(c) ? theme::style::InkStrip : theme::style::InkBg; }

uint32_t Canvas::fadeInk(uint32_t c, int k) const {
  using namespace theme::style;
  const float o = k == InkStrip ? std::max(m.op[InkBg], StripFloor) : (k >= 0 && k < InkCount) ? m.op[k] : 1.f;
  const float f = std::clamp(alpha, 0.f, 1.f) * o;
  if (f >= 0.999f) return c;
  const uint32_t a = static_cast<uint32_t>(std::lround(((c >> 24) & 0xFF) * f));
  return (a << 24) | (c & 0x00FFFFFF);
}

int Canvas::rectInk(uint32_t c, const Rect &r) const {
  using namespace theme::style;
  if (ink >= 0) return (ink == InkIcon && cutout && c == cutout) ? cutInk(c) : ink;
  if (isStrip(c)) return InkStrip;
  const uint32_t rgb = c & 0x00FFFFFF;
  if (rgb == (col::Accent & 0x00FFFFFF) || rgb == (col::AccentPressed & 0x00FFFFFF) ||
      rgb == (col::AccentEdge & 0x00FFFFFF) || rgb == (col::AccentSoft & 0x00FFFFFF))
    return InkSelected;
  if (std::min(r.w, r.h) <= std::max(2.5f * m.border, 3.f)) return InkBorder;  
  return InkBg;
}

bool Canvas::visible(const Rect &r) const {
  return r.x >= clip.x - 0.5f && r.y >= clip.y - 0.5f && r.r() <= clip.r() + 0.5f && r.b() <= clip.b() + 0.5f;
}

bool Canvas::isPressed(const Rect &r) const {
  return !pressed.empty() && std::fabs(pressed.x - r.x) < 1.f && std::fabs(pressed.y - r.y) < 1.f &&
         std::fabs(pressed.w - r.w) < 1.f && std::fabs(pressed.h - r.h) < 1.f;
}

void Canvas::fill(const Rect &r0, uint32_t c, float radius) {
  const Rect r = r0.intersect(clip);
  if (r.empty() || (c >> 24) == 0) return;
  DrawCommand &d = next();
  d.type = DrawCommandType::RectFilled;
  d.x = r.x; d.y = r.y; d.w = r.w; d.h = r.h;
  d.color = fadeInk(c, rectInk(c, r0));
  
  const float rad = std::min(radius, std::min(r.w, r.h) * 0.5f);
  d.x3 = (r.w == r0.w && r.h == r0.h) ? rad : 0.f;
}

void Canvas::frame(const Rect &r, uint32_t fillC, uint32_t borderC, float radius, float bw) {
  
  
  const Rect in = r.inset(bw);
  if (m.op[theme::style::InkBg] >= 0.999f && m.op[theme::style::InkBorder] >= 0.999f && alpha >= 0.999f) {
    fill(r, borderC, radius);  
    fill(in, fillC, std::max(0.f, radius - bw));
    return;
  }
  int bk = ink;
  if (bk < 0) bk = rectInk(borderC, r) == theme::style::InkSelected ? theme::style::InkSelected : theme::style::InkBorder;
  {
    InkScope k(*this, bk);
    fill({r.x, r.y, r.w, bw}, borderC);
    fill({r.x, r.b() - bw, r.w, bw}, borderC);
    fill({r.x, r.y + bw, bw, r.h - 2 * bw}, borderC);
    fill({r.r() - bw, r.y + bw, bw, r.h - 2 * bw}, borderC);
  }
  fill(in, fillC, std::max(0.f, radius - bw));
}

void Canvas::line(float x1, float y1, float x2, float y2, uint32_t c, float width) {
  const Rect bb{std::min(x1, x2) - width, std::min(y1, y2) - width, std::fabs(x2 - x1) + 2 * width,
                std::fabs(y2 - y1) + 2 * width};
  if (!visible(bb)) return;
  DrawCommand &d = next();
  d.type = DrawCommandType::Line;
  d.x = x1; d.y = y1; d.w = x2 - x1; d.h = y2 - y1;
  d.size = width;
  d.color = fadeInk(c, ink >= 0 ? ink : theme::style::InkIcon);
}

void Canvas::circle(float cx, float cy, float radius, uint32_t c) {
  if (!visible({cx - radius, cy - radius, 2 * radius, 2 * radius})) return;
  DrawCommand &d = next();
  d.type = DrawCommandType::CircleFilled;
  d.x = cx; d.y = cy; d.size = radius;
  d.color = fadeInk(c, ink >= 0 ? ((ink == theme::style::InkIcon && cutout && c == cutout) ? cutInk(c) : ink)
                                : theme::style::InkIcon);
}

void Canvas::triangle(float x1, float y1, float x2, float y2, float x3, float y3, uint32_t c) {
  const float minx = std::min({x1, x2, x3}), miny = std::min({y1, y2, y3});
  if (!visible({minx, miny, std::max({x1, x2, x3}) - minx, std::max({y1, y2, y3}) - miny})) return;
  DrawCommand &d = next();
  d.type = DrawCommandType::TriangleFilled;
  d.x = x1; d.y = y1; d.w = x2; d.h = y2; d.x3 = x3; d.y3 = y3;
  d.color = fadeInk(c, ink >= 0 ? ((ink == theme::style::InkIcon && cutout && c == cutout) ? cutInk(c) : ink)
                                : theme::style::InkIcon);
}

void Canvas::image(const Rect &r, const std::string &id) {
  if (!visible(r)) return;
  DrawCommand &d = next();
  d.type = DrawCommandType::Image;
  d.x = r.x; d.y = r.y; d.w = r.w; d.h = r.h;
  d.color = fadeInk(0xFFFFFFFF, theme::style::InkIcon);
  d.imageId = id;
}

void Canvas::text(const Rect &box, std::string_view s, uint32_t c, float size, Align a, bool shrink) {
  if (s.empty() || box.w <= 0) return;
  
  if (box.cy() - size * 0.62f < clip.y - 0.5f || box.cy() + size * 0.62f > clip.b() + 0.5f) return;
  const float sz = shrink ? fitSize(s, box.w, size) : size;
  DrawCommand &d = next();
  d.type = DrawCommandType::Text;
  d.size = sz;
  d.color = fadeInk(c, theme::style::InkText);
  if (textWidth(s, sz) <= box.w) d.text.assign(s.data(), s.size());
  else d.text = ellipsize(s, box.w, sz);
  d.y = box.cy() + sz * 0.35f;  
  switch (a) {
    case Align::Left: d.x = box.x; d.w = 0.f; break;
    case Align::Center: d.x = box.cx(); d.w = -2.f; break;
    case Align::Right: d.x = box.r(); d.w = -1.f; break;
  }
}

float Canvas::paragraph(float x, float y, float w, std::string_view s, uint32_t c, float size, int maxLines,
                        Align a) {
  const auto lines = wrap(s, w, size, maxLines);
  const float lh = lineHeight(size);
  float yy = y;
  for (const auto &l : lines) {
    text({x, yy, w, lh}, l, c, size, a, false);
    yy += lh;
  }
  return yy - y;
}

void Canvas::label(const Rect &box, std::string_view s, uint32_t c, float size, Align a) {
  if (s.empty() || box.w <= 0) return;
  if (textWidth(s, fitSize(s, box.w, size)) <= box.w) {
    text(box, s, c, size, a, true);
    return;
  }
  const float sz = std::max(minTextPx(), std::min(size, m.fSmall));
  const auto lines = wrap(s, box.w, sz, 2);
  const float lh = sz * 1.2f;
  float y = box.cy() - lines.size() * lh * 0.5f;
  for (const auto &l : lines) {
    text({box.x, y, box.w, lh}, l, c, sz, a, false);
    y += lh;
  }
}

float Canvas::switchWidth(std::string_view label, std::string_view stateText) const {
  return m.s4 + textWidth(label, m.fBody) + m.s16 + textWidth(stateText, m.fSmall) + m.s8 +
         m.px(theme::size::Switch) + m.s4;
}

void Canvas::hit(const Rect &r, std::function<void()> action, bool repeat) {
  const Rect v = r.intersect(clip);
  
  
  
  const bool whole = v.w >= r.w - 0.5f && v.h >= r.h - 0.5f;
  
  const float minVis = std::max(m.px(theme::size::HitMinVisible), m.touch);
  if (!whole && (v.w < std::max(r.w * 0.5f, std::min(r.w, minVis)) - 0.5f ||
                 v.h < std::max(r.h * 0.6f, std::min(r.h, minVis)) - 0.5f))
    return;
  hits.push_back({v, std::move(action), repeat});
}


namespace {
struct Skin {
  uint32_t face, edge, pressed, text;
};
Skin skinFor(Canvas::Style s) {
  switch (s) {
    case Canvas::Style::Primary: return {col::Accent, col::AccentEdge, col::AccentPressed, col::TextOnAccent};
    case Canvas::Style::Danger: return {col::Danger, col::DangerEdge, 0xFF7A2E2E, col::Text};
    case Canvas::Style::DangerArmed: return {col::DangerArmed, 0xFF7E2A2A, 0xFFA83A3A, col::TextOnAccent};
    case Canvas::Style::Success: return {0xFF3B8A54, 0xFF27613A, 0xFF34784A, col::TextOnAccent};
    case Canvas::Style::Secondary: break;
  }
  return {col::Control, col::ControlEdge, col::ControlPressed, col::Text};
}
}  

void Canvas::button(const Rect &r, std::string_view label, std::function<void()> action, ButtonOpts o) {
  if (!visible(r)) return;
  const Skin sk = skinFor(o.style);
  const bool down = o.enabled && isPressed(r);
  const float e = m.edge;
  Rect face{r.x, r.y + (down ? e : 0.f), r.w, r.h - e};
  if (!o.enabled) {
    fill(face, col::ControlDisabled, m.radius);
  } else {
    if (!down) fill(r, sk.edge, m.radius);
    fill(face, down ? sk.pressed : sk.face, m.radius);
  }
  const float fs = o.fontSize > 0 ? o.fontSize : m.fLabel;
  text(face.inset(m.s6, 0), label, o.enabled ? sk.text : col::TextDisabled, fs, Align::Center);
  if (action && (o.enabled || o.callWhenDisabled)) hit(r, std::move(action), o.repeat && o.enabled);
}

void Canvas::iconButton(const Rect &r, Glyph g, std::function<void()> action, bool repeat, bool enabled) {
  if (!visible(r)) return;
  const bool down = enabled && isPressed(r);
  const float e = m.edge;
  Rect face{r.x, r.y + (down ? e : 0.f), r.w, r.h - e};
  if (!enabled) fill(face, col::ControlDisabled, m.radius);
  else {
    if (!down) fill(r, col::ControlEdge, m.radius);
    fill(face, down ? col::ControlPressed : col::Control, m.radius);
  }
  const uint32_t c = enabled ? col::Text : col::TextDisabled;
  const float s = std::min(face.w, face.h) * 0.17f, t = std::max(2.f, m.s2);
  const float cx = face.cx(), cy = face.cy();
  switch (g) {
    case Glyph::Minus: line(cx - s, cy, cx + s, cy, c, t); break;
    case Glyph::Plus:
      line(cx - s, cy, cx + s, cy, c, t);
      line(cx, cy - s, cx, cy + s, c, t);
      break;
    case Glyph::Back:
      line(cx + s * 0.4f, cy - s, cx - s * 0.6f, cy, c, t);
      line(cx - s * 0.6f, cy, cx + s * 0.4f, cy + s, c, t);
      break;
  }
  if (action && enabled) hit(r, std::move(action), repeat);
}

void Canvas::segmented(const Rect &r, std::span<const char *const> labels, int selected,
                       const std::function<void(int)> &onSelect, bool enabled) {
  if (!visible(r) || labels.empty()) return;
  frame(r, col::Surface, col::Divider, m.radius, m.border);
  const int n = int(labels.size());
  const float inset = m.s2;
  const float sw = (r.w - 2 * inset) / n;
  for (int i = 0; i < n; ++i) {
    const Rect seg{r.x + inset + i * sw, r.y + inset, sw, r.h - 2 * inset};
    
    const Rect hr{i == 0 ? r.x : seg.x, r.y, seg.w + (i == 0 ? inset : 0.f) + (i == n - 1 ? inset : 0.f), r.h};
    const bool sel = i == selected;
    if (sel) {
      fill(seg, enabled ? col::Accent : col::ControlDisabled, m.radius - 1);
      
      fill({seg.x + seg.w * 0.3f, seg.b() - m.s3, seg.w * 0.4f, m.s2}, 0xCCF4F7FB, m.px(1));
    } else if (enabled && isPressed(hr)) {
      fill(seg, col::ControlPressed, m.radius - 1);
    }
    if (i > 0 && !sel && i - 1 != selected)
      fill({seg.x - 0.5f, seg.y + seg.h * 0.25f, std::max(1.f, m.border), seg.h * 0.5f}, col::Divider);
    const uint32_t tc = !enabled ? col::TextDisabled : sel ? col::TextOnAccent : col::TextSecondary;
    text(seg.inset(m.s3, 0), labels[size_t(i)] ? labels[size_t(i)] : "", tc, m.fSmall, Align::Center);
    if (enabled && onSelect) hit(hr, [onSelect, i] { onSelect(i); });
  }
}

void Canvas::switchRow(const Rect &r, std::string_view label, std::string_view stateText, bool on,
                       std::function<void()> toggle) {
  if (!visible(r)) return;
  if (isPressed(r)) fill(r, col::ControlPressed, m.radius);
  const float tw = m.px(theme::size::Switch), th = tw * 0.56f;
  const Rect track{r.r() - tw - m.s4, r.cy() - th * 0.5f, tw, th};
  if (on) fill(track, col::Accent, th * 0.5f);
  else frame(track, col::Control, col::PanelBorder, th * 0.5f, m.border);
  const float kr = th * 0.5f - m.s3;
  circle(on ? track.r() - th * 0.5f : track.x + th * 0.5f, track.cy(), kr, on ? col::TextOnAccent : col::TextSecondary);
  
  const float sw = textWidth(stateText, m.fSmall);
  text({track.x - m.s8 - sw, r.y, sw, r.h}, stateText, on ? col::AccentText : col::TextSecondary, m.fSmall,
       Align::Right, false);
  const float lx = r.x + m.s4;
  this->label({lx, r.y, track.x - m.s16 - sw - lx, r.h}, label, col::Text, m.fBody);
  if (toggle) hit(r, std::move(toggle));
}

void Canvas::stepperRow(const Rect &r0, std::string_view label, std::string_view value, std::function<void()> dec,
                        std::function<void()> inc, std::function<void()> tapValue, StepperOpts so) {
  if (!visible(r0)) return;
  Rect r = r0;
  const float b = std::min(r.h, m.row);
  const float vw = std::max(m.px(64), textWidth(value, m.fLabel) + m.s16);
  const float g = m.s4;
  const Rect plus = r.takeRight(b, g);
  const Rect val = r.takeRight(vw, g);
  const Rect minus = r.takeRight(b, m.s10);
  iconButton({minus.x, minus.cy() - b * 0.5f, b, b}, Glyph::Minus, std::move(dec), so.repeat, so.decEnabled);
  const Rect vbox{val.x, val.cy() - b * 0.5f, val.w, b - m.edge};
  if (tapValue) {
    ButtonOpts o;
    o.fontSize = m.fLabel;
    button({val.x, val.cy() - b * 0.5f, val.w, b}, value, std::move(tapValue), o);
  } else {
    valueBox(vbox, value);
  }
  iconButton({plus.x, plus.cy() - b * 0.5f, b, b}, Glyph::Plus, std::move(inc), so.repeat, so.incEnabled);
  this->label({r.x + m.s4, r.y, r.w - m.s4, r.h}, label, col::Text, m.fBody);
}

void Canvas::swatch(const Rect &r, uint32_t color, bool selected) {
  if (!visible(r)) return;
  const float ring = std::max(2.f, m.s2);
  if (selected) {  
    fill(r, col::Text, m.radius + ring);
    fill(r.inset(ring), col::Panel, m.radius + ring * 0.5f);
  } else {
    fill(r.inset(ring), col::PanelBorder, m.radius + ring * 0.5f);
  }
  fill(r.inset(ring * 2), color | 0xFF000000u, m.radius);
}

void Canvas::valueBox(const Rect &r, std::string_view value, uint32_t color) {
  if (!visible(r)) return;
  fill(r, col::SurfaceRaised, m.radius);
  text(r.inset(m.s4, 0), value, color, m.fLabel, Align::Center);
}

void Canvas::statusIcon(float cx, float cy, float size, Tone t) {
  const float h = size * 0.5f;
  const float lw = std::max(1.5f, size * 0.13f);
  const uint32_t ink = col::TextOnStatus;
  switch (t) {
    case Tone::Success:
      circle(cx, cy, h, col::Success);
      line(cx - size * 0.24f, cy + size * 0.01f, cx - size * 0.06f, cy + size * 0.18f, ink, lw);
      line(cx - size * 0.06f, cy + size * 0.18f, cx + size * 0.25f, cy - size * 0.16f, ink, lw);
      break;
    case Tone::Warning:
      triangle(cx, cy - h, cx - h * 1.05f, cy + h * 0.85f, cx + h * 1.05f, cy + h * 0.85f, col::Warning);
      line(cx, cy - size * 0.15f, cx, cy + size * 0.13f, ink, lw);
      circle(cx, cy + size * 0.27f, lw * 0.6f, ink);
      break;
    case Tone::Error:
      circle(cx, cy, h, col::Error);
      line(cx - size * 0.17f, cy - size * 0.17f, cx + size * 0.17f, cy + size * 0.17f, ink, lw);
      line(cx + size * 0.17f, cy - size * 0.17f, cx - size * 0.17f, cy + size * 0.17f, ink, lw);
      break;
    case Tone::Info:
      circle(cx, cy, h, col::AccentText);
      circle(cx, cy - size * 0.2f, lw * 0.6f, ink);
      line(cx, cy - size * 0.04f, cx, cy + size * 0.25f, ink, lw);
      break;
    case Tone::Neutral:
      circle(cx, cy, h, col::TextDisabled);
      line(cx - size * 0.2f, cy, cx + size * 0.2f, cy, ink, lw);
      break;
    case Tone::Loading:
      circle(cx, cy, h, col::AccentSoft);
      for (int i = -1; i <= 1; ++i) circle(cx + i * size * 0.22f, cy, lw * 0.6f, col::AccentText);
      break;
  }
}

void Canvas::loadingDots(float x, float cy, float size, uint32_t c, bool animate) {
  const int active = animate ? int((nowMs() / theme::motion::LoadingStep) % 3) : -1;
  for (int i = 0; i < 3; ++i) {
    const uint32_t a = active < 0 ? 0xB0 : i == active ? 0xFF : 0x55;
    circle(x + size * 0.15f + i * size * 0.38f, cy, size * 0.11f, (a << 24) | (c & 0x00FFFFFF));
  }
}

float Canvas::chipWidth(std::string_view label) const {
  return m.s8 + m.icon + m.s6 + textWidth(label, m.fSmall) + m.s10;
}

void Canvas::chip(const Rect &r, Tone t, std::string_view label) {
  if (!visible(r)) return;
  fill(r, toneSoft(t), r.h * 0.5f);
  statusIcon(r.x + m.s8 + m.icon * 0.5f, r.cy(), m.icon, t);
  const float tx = r.x + m.s8 + m.icon + m.s6;
  text({tx, r.y, r.r() - tx - m.s8, r.h}, label, col::Text, m.fSmall, Align::Left);
}

void Canvas::divider(float x, float y, float w) { fill({x, y, w, m.border}, col::Divider); }

void Canvas::scrollBar(const Rect &track, float contentH, float scroll) {
  if (contentH <= track.h + 0.5f || track.h <= 0) return;
  const float th = std::max(m.px(24), track.h * track.h / contentH);
  const float maxS = contentH - track.h;
  const float y = track.y + (track.h - th) * std::clamp(scroll / maxS, 0.f, 1.f);
  const Rect saved = clip;
  noClip();
  fill({track.r() - m.scrollBar, y, m.scrollBar, th}, col::ScrollThumb, m.scrollBar * 0.5f);
  clip = saved;
}

float Canvas::sectionTitle(float x, float y, float w, std::string_view label) {
  const float h = lineHeight(m.fSmall) + m.s2;
  text({x, y, w, h}, label, col::TextSecondary, m.fSmall, Align::Left);
  return h;
}

}  
