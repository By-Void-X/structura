#pragma once
#include <string>
#include <vector>

namespace lm::lib {

struct Entry {
  std::string title;   
  std::string path;
  std::string source;  
};


std::vector<Entry> scan(const std::string &myDir, bool includeDownloads, bool includePacks,
                        std::vector<std::string> *rootsFound);


std::string importFile(const std::string &src, const std::string &displayName, const std::string &myDir,
                       std::string &err);


std::string scanNotes();

std::string uniquePath(const std::string &dir, const std::string &base, const std::string &ext);

}  
