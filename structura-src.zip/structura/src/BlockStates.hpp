#pragma once
// Block state rules: one place that knows, for every Bedrock block state key,
//  - how it changes under rotation / mirroring (transform kind), and
//  - how Easy Place and verification must treat it (class).
// The hologram, Easy Place and verification all transform states through transformBlockState(), so
// the preview, the placement and the check always see the same transformed state.
//
// Conventions: cardinal index N=0 E=1 S=2 W=3. A rotation step turns clockwise seen from above
// (N->E->S->W), matching localToWorld(). Mirroring flips the structure's local X axis (east <-> west)
// before rotating, exactly like localToWorld(); a Z mirror equals an X mirror plus a 180 degree turn.

#include <cstdint>
#include <string>
#include <vector>

#include "Structure.hpp"

namespace lm::states {

// ---- classes: how a state is placed / verified
enum class Cls : uint8_t {
  Placement,    // set by the placement itself (clicked face, hit position, player rotation): must match
  GameDecided,  // chosen by the game when placing (neighbours, defaults), cannot be forced: must match, reported
  Interaction,  // changed by a normal interaction on the placed block (open, delay, mode): correctable
  ItemUse,      // needs extra items or tools (candle count, lit, filled): must match, not automated
  Part,         // which part of a multi-block structure (door upper half, bed head): must match
  Generated,    // computed by the game at runtime (power, connections, age): ignored by verification
  Unknown,      // key not in the rules table: compared, never transformed
  Count
};
const char *clsName(Cls c);

// ---- transform kinds
enum class Tf : uint8_t {
  None,
  Cardinal,      // "north"/"east"/"south"/"west" strings
  Facing6Str,    // "down"/"up"/cardinals (minecraft:facing_direction, minecraft:block_face)
  Facing6Int,    // facing_direction int: 0 down 1 up 2 north 3 south 4 west 5 east
  DirByName,     // legacy "direction" int, table depends on the block (door / trapdoor / generic)
  DirStair,      // weirdo_direction: 0 east 1 west 2 south 3 north
  DirCoral,      // coral_direction: 0 west 1 east 2 north 3 south
  Axis,          // pillar_axis / portal_axis: x <-> z on quarter turns
  Rail,          // rail_direction 0..9
  Sign16,        // ground_sign_direction 0..15 (0 south, clockwise)
  VineBits,      // vine_direction_bits: 1 south 2 west 4 north 8 east
  FaceBits,      // multi_face_direction_bits: 4 north 8 south 16 west 32 east (1 down, 2 up kept)
  SideKeys,      // one key per side (wall_connection_type_<side>, pale_moss_carpet_side_<side>)
  Torch,         // torch_facing_direction: cardinals, "top", "unknown"
  Lever,         // lever_direction
  Hinge,         // door_hinge_bit: flips on mirror
  Orientation,   // crafter orientation "down_east" ... "north_up"
  Mushroom,      // huge_mushroom_bits (3x3 cap grid)
  Count
};

struct Rule {
  Cls cls;
  Tf tf;
};
// Rule for a key on a block (short name, e.g. "oak_door"). known=false for keys not in the table.
Rule ruleFor(const std::string &key, const std::string &shortName, bool *known = nullptr);
// Heuristic for unknown keys that look directional: such keys are never guessed under a transform.
bool looksDirectional(const std::string &key);

// ---- transform primitives (all pure; rot = quarter turns clockwise, mirror = X mirror first)
int transformFacing(int card, int rot, bool mirror);
// Direction name ("north", "up", ...) -> transformed name; up/down unchanged; nullptr if not a direction.
const char *transformFacingName(const std::string &v, int rot, bool mirror);
int transformFacing6(int v, int rot, bool mirror);  // facing_direction int
std::string transformAxis(const std::string &axis, int rot, bool mirror);
int transformRailShape(int shape, int rot, bool mirror);
int transformSignRotation(int r16, int rot, bool mirror);
int transformDirection(const std::string &shortName, int v, int rot, bool mirror);  // legacy "direction"
int transformStairDirection(int v, int rot, bool mirror);
int transformCoralDirection(int v, int rot, bool mirror);
int transformVineBits(int v, int rot, bool mirror);
int transformFaceBits(int v, int rot, bool mirror);
std::string transformTorch(const std::string &v, int rot, bool mirror);
std::string transformLever(const std::string &v, int rot, bool mirror);
std::string transformOrientation(const std::string &v, int rot, bool mirror);
int transformMushroomBits(int v, int rot, bool mirror);
int transformHinge(int bit, int rot, bool mirror);
// Side-keyed connection states (wall_connection_type_<side>, ...): values move with their side. Returns changes.
int transformConnections(std::vector<BlockStateValue> &st, int rot, bool mirror);
// Java-style stair shape (straight / inner_left / outer_right ...). Bedrock stores no shape state (the game
// derives it from neighbours); used for reports and tests: rotation keeps it, mirroring swaps left/right.
std::string transformStairShape(const std::string &shape, int rot, bool mirror);
// Attachment face: direction names / facing_direction ints turn; standing/hanging/side/multiple are kept.
std::string transformAttachment(const std::string &face, int rot, bool mirror);
int transformAttachment(int facing6, int rot, bool mirror);

// Result of transforming one block's states.
struct TransformOutcome {
  int changed = 0;                              // states whose value changed
  std::vector<std::string> unknownDirectional;  // keys that look directional but have no rule
  bool safe() const { return unknownDirectional.empty(); }
};
// THE state transformation used by hologram, Easy Place and verification.
// Byte/int/string: the only block-state types Bedrock uses. Other NBT types are kept as raw data.
inline bool plainType(const BlockStateValue &sv) { return sv.type == 1 || sv.type == 3 || sv.type == 8; }
TransformOutcome transformBlockState(std::vector<BlockStateValue> &st, int rot, bool mirror, const std::string &shortName);

// Compatibility wrapper (older call sites).
int turnCardinal(int c, int rot, bool mirror);
void transformStates(std::vector<BlockStateValue> &st, int rot, bool mirror, const std::string &name);

// Older equivalents of a state key the game may use instead (e.g. direction <-> cardinal_direction).
int legacyAliases(const std::string &name, const BlockStateValue &sv, BlockStateValue out[2]);

std::string valueText(const BlockStateValue &sv);
// "facing=east half=top" style text of the states that matter for placement (skips Generated).
std::string describe(const std::vector<BlockStateValue> &st, const std::string &shortName, bool all = false);

bool isDoorName(const std::string &shortName);
int doorInfo(const std::vector<BlockStateValue> &transformed);

// ---- block type equivalence
// Blocks the game swaps at runtime (powered/lit variants) count as the same block type: the item places
// the base form ("powered_repeater" -> "unpowered_repeater", "lit_furnace" -> "furnace").
std::string placeableName(const std::string &shortName);
bool sameBlockType(const std::string &a, const std::string &b);

// ---- multi-block companions
struct Companion {
  bool has = false;
  int dx = 0, dy = 0, dz = 0;  // offset from this part to the other part (world axes, after transform)
  const char *what = "";       // "upper half", "bed head"
};
// For the base part (door lower half, bed foot, tall plant lower half) of a transformed state.
Companion companionOf(const std::vector<BlockStateValue> &transformed, const std::string &shortName);
// True when this transformed state is the secondary part (placed by the game together with the base).
bool isSecondaryPart(const std::vector<BlockStateValue> &transformed, const std::string &shortName);

// ---- verification
enum class Match : uint8_t {
  Exact,          // same game block (every state identical)
  Equivalent,     // same block type, only Generated states differ
  StateMismatch,  // same block type, some compared state differs
  WrongBlock,     // a different block
  Missing,        // nothing placed (air / replaceable)
  Count
};
const char *matchName(Match m);

struct StateDiff {
  std::string key;
  Cls cls = Cls::Unknown;
  int64_t expected = -1, actual = -1;
};
struct Compared {
  Match match = Match::Missing;
  uint32_t clsMask = 0;  // bit (1 << Cls) for every differing compared class
  std::vector<StateDiff> diffs;
  bool only(uint32_t allowedMask) const { return (clsMask & ~allowedMask) == 0; }
};
constexpr uint32_t bit(Cls c) { return 1u << unsigned(c); }

// Value reader: side 0 = expected block, 1 = actual block. Returns -1 when the block has no such state.
using ValueFn = int64_t (*)(void *ctx, int side, const BlockStateValue &sv);
// Compares two blocks of the same (or equivalent) type state by state, using the expected transformed
// states as the list of keys.
Compared compareStates(const std::vector<BlockStateValue> &expected, const std::string &shortName, ValueFn value,
                       void *ctx);

// ---- Easy Place policy
enum class Mode : int { MissingOnly = 0, PlaceVerify, Safe, Correct, Strict, Count };
const char *modeName(Mode m);
constexpr Mode kDefaultMode = Mode::Safe;

// Plan quality from the placement simulation:
//  3 = simulated result matches (exact or equivalent)
//  2 = every Placement/Part state matches; only GameDecided / Interaction / ItemUse may differ
//  1 = no simulation available or no simulated result matched
int planScore(const Compared &simulated);
// Whether a plan of this score may be used. directional = the expected state has Placement states.
bool acceptPlan(Mode m, int score, bool directional);
bool verifies(Mode m);                       // verify and report after placement
bool correctsOwn(Mode m);                    // correct Interaction states of blocks Easy Place placed
bool correctsExisting(Mode m);               // also correct existing blocks of the right type
// Interactions needed to turn `actual` into `expected` for one Interaction state, -1 if not correctable.
int correctionPresses(const std::string &shortName, const std::string &key, int64_t expected, int64_t actual);
// Blocks a normal tap toggles/cycles without opening a screen (and that a hand can operate).
bool interactable(const std::string &shortName);

}  // namespace lm::states
