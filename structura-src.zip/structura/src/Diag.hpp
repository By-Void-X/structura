#pragma once
// Structured diagnostics: one row per subsystem, rebuilt on the UI thread from lock-free state.
// Hooks and worker threads never touch this; they only publish atomics (State.hpp / HoloState.hpp).

#include <cstdint>
#include <string>
#include <vector>

#include "HoloState.hpp"

namespace lm::diag {

enum class DSt : int { Waiting = 0, Loading, Ok, Ready, Active, Warning, Failed, Cancelled, NotAvailable, NotChecked, Count };

enum class Row : int {
  File = 0,
  Parser,
  Palette,
  Indices,
  States,  // block states kept by the parser
  Structure,
  Update,  // ClientInstance::update (optional player context source)
  Player,  // player context (source, freshness)
  World,
  Dimension,
  RenderHook,
  RenderContext,
  Materials,
  Textures,
  Hologram,
  EasyPlace,
  Transform,   // shared rotation/mirror state table (hologram, Easy Place, verification, progress)
  Verify,      // Easy Place read-back verification
  Progress,    // central progress model
  Layers,      // layer model (transformed box)
  ProgressUi,  // progress / layer overlay
  Touch,       // overlay touch input
  Ui,
  Memory,
  Operation,
  Count
};
constexpr int kRows = int(Row::Count);

struct RowData {
  DSt st = DSt::NotChecked;
  std::string msgKey = "diag.m_not_checked";  // i18n key of the short message
  std::vector<std::string> args;              // message arguments
  std::string detail;                         // technical detail (English, may be empty)
  std::string error;                          // error text (English, empty when none)
  int64_t changedMs = 0;                      // monotonic time of the last status/message change
  uint64_t gen = 0;                           // generation / epoch the row refers to
};

struct Snapshot {
  RowData rows[kRows];
  hs::HState state = hs::HState::NoStructureLoaded;
  hs::Why why = hs::Why::None;
  int progress = -1;                 // 0..100 while preparing/loading, -1 otherwise
  uint32_t processed = 0, remaining = 0, batches = 0;
  bool canRetryHologram = false, canRetryLoad = false;
  std::string loadPath;
  uint64_t revision = 0;
  int64_t builtMs = 0;
};

// UI thread. Throttled to 4 Hz unless forced or a refresh was requested.
void refresh(bool force = false);
void requestRefresh();
Snapshot snapshot();
uint64_t revision();

const char *statusKey(DSt s);
const char *rowKey(Row r);
const char *statusName(DSt s);
const char *rowName(Row r);
// Short state text for the Details page.
const char *stateKey(hs::HState s);

// Localized short message with arguments (never empty).
std::string message(const RowData &r);

// Plain-text block appended to "Copy diagnostic".
std::string text();
// Init/runtime state flags: ParserReady, PlacementReady, RenderHookReady, PlayerContext*, Hologram*, PartialMode.
std::string states();

}  // namespace lm::diag
