#include "Overlay.hpp"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>

#include "App.hpp"
#include "EasyPlace.hpp"
#include "HudButtons.hpp"
#include "I18n.hpp"
#include "Progress.hpp"
#include "State.hpp"
#include "Theme.hpp"

namespace lm::overlay {
namespace {
using ui::kit::Align;
using ui::kit::Canvas;
using ui::kit::Metrics;
using ui::kit::Rect;
namespace col = theme::color;
namespace sty = theme::style;
using i18n::tr;

// Buttons / touch zones. Index = draw order; hit testing goes the other way.
enum Zone : int {
  ZNone = -1, ZHeader = 0, ZExpand, ZHide, ZPrev, ZLabel, ZNext,
  ZMode0, ZMode1, ZMode2, ZMode3, ZHolo, ZFilter, ZPlaceLayer, ZPlaceVisible, ZPause, ZCancel, ZOpenUi, ZResize,
  ZCount
};

constexpr float kBaseWDp = 236.f;   // panel width at scale 1, width 1
constexpr float kRowDp = 34.f;      // touch row (>= theme TouchMin)
constexpr float kPadDp = 6.f;
constexpr float kGapDp = 4.f;
constexpr float kSlopDp = 10.f;
constexpr float kScrubDp = 22.f;    // horizontal drag on the layer label: one layer per 22 dp
constexpr int kLongPressMs = 500;
constexpr int kArmMs = 3000;        // confirm window of Place layer / Place visible / Cancel
constexpr int kBucketMs = 200;      // progress numbers refresh at most every 200 ms

int64_t nowMs() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch())
      .count();
}

std::atomic<void (*)()> gOpenUi{nullptr}, gWake{nullptr};
std::mutex gMu;  // geometry + gesture (UI thread draws, touch thread reads)
struct Geo {
  float W = 0, H = 0, k = 1;  // k = px per dp * overlay scale
  Rect panel, z[ZCount];
  bool valid = false;
} gGeo;
bool gShown = false;  // drawn in the last UI frame (else touches pass through)
int gPtr = -1, gZone = ZNone;
bool gDrag = false;
int gDragKind = 0;  // 0 none / cancelled press, 1 move, 2 resize, 3 scrub
float gDownX = 0, gDownY = 0, gStartX = 0, gStartY = 0, gStartW = 1;
int gStartLayer = 0, gScrubApplied = 0;
int64_t gDownAt = 0;
std::atomic<int> gPressed{ZNone};
std::atomic<int> gArmed{ZNone};
std::atomic<int64_t> gArmedAt{0};
std::atomic<uint32_t> gMoveRev{0};
std::atomic<uint32_t> gTouches{0};
std::atomic<int> gUi{0};  // 0 off, 1 waiting, 2 active, 3 hidden

struct Snap {
  bool live = false, cmpReady = false, layOk = false;
  progress::Counts all, lay;
  int axis = 1, layer = 0, nLayers = 1, coord = 0, mode = 0;
};

bool snapshot(Snap &s) {
  std::shared_ptr<CompareData> C;
  std::shared_ptr<const Structure> S;
  Placement P;
  {
    auto &m = model();
    std::lock_guard<std::mutex> lk(m.mu);
    if (!m.structure || !m.placed) return false;
    C = m.compare;
    S = m.structure;
    P = m.placement;
    s.layer = m.layer;
  }
  s.live = true;
  s.axis = std::clamp(settings().layerAxis.load(std::memory_order_relaxed), 0, 2);
  s.mode = std::clamp(settings().layerMode.load(std::memory_order_relaxed), 0, 4);
  s.nLayers = std::max(1, progress::layerCount(*S, P, s.axis));
  s.layer = std::clamp(s.layer, 0, s.nLayers - 1);
  s.coord = progress::layerWorld(*S, P, s.axis, s.layer);
  if (C && C->S == S) {
    s.cmpReady = true;
    s.all = progress::overall(*C);
    s.layOk = progress::layerCounts(*C, *S, P, s.axis, s.layer, s.lay);
  }
  return true;
}

std::string grp(uint32_t v) {  // 1248 -> "1,248"
  char b[16];
  std::snprintf(b, sizeof(b), "%u", v);
  std::string s(b), out;
  const int n = int(s.size());
  for (int i = 0; i < n; ++i) {
    out += s[size_t(i)];
    if ((n - 1 - i) % 3 == 0 && i != n - 1) out += ',';
  }
  return out;
}
std::string pct(double p) {
  char b[16];
  std::snprintf(b, sizeof(b), "%.1f%%", p);
  return b;
}

// Default spot: top-left under the game's top bar, clear of the joystick (bottom-left), jump/sneak
// (bottom-right), hotbar (bottom) and the pause/chat buttons (top centre/right). Margins scale with the
// screen so notches/cut-outs (landscape left/right, portrait top) stay clear.
void layoutLocked(float W, float H, float dev, bool expanded) {
  auto &s = settings();
  const float k = dev * std::clamp(s.ovScale.load(), 0.7f, 1.6f);
  const bool land = W >= H;
  const float edgeX = std::max(16.f * dev, land ? W * 0.045f : W * 0.03f);
  const float edgeY = std::max(12.f * dev, land ? H * 0.12f : H * 0.06f);
  const float row = std::round(kRowDp * k), pad = std::round(kPadDp * k), gap = std::round(kGapDp * k);
  const float small = std::round(16.f * k), bar = std::max(2.f, std::round(3.f * k)), grip = std::round(12.f * k);
  float w = std::round(kBaseWDp * std::clamp(s.ovWidth.load(), 0.8f, 1.6f) * k);
  w = std::clamp(w, std::min(W - 2 * pad, 150.f * k), std::max(150.f * k, W - 2 * pad));
  // content height
  float h = pad + row + bar + gap + row + small + bar;  // header, bar, layer row, layer progress, bar
  if (expanded) h += gap + small * 2 + gap + row + gap + row + gap + row + gap + row;
  h += grip;
  h = std::min(h, H);
  const float freeW = std::max(0.f, W - w), freeH = std::max(0.f, H - h);
  const float fx = s.ovX.load(), fy = s.ovY.load();
  const float x = fx >= 0.f ? fx * freeW : std::min(edgeX, freeW);
  const float y = fy >= 0.f ? fy * freeH : std::min(edgeY, freeH);
  Geo &G = gGeo;
  G.W = W;
  G.H = H;
  G.k = k;
  G.panel = {std::round(std::clamp(x, 0.f, freeW)), std::round(std::clamp(y, 0.f, freeH)), w, h};
  for (auto &r : G.z) r = {};
  Rect c = G.panel.inset(pad, 0);
  c.y += pad;
  c.h -= pad;
  Rect hdr = c.takeTop(row);
  G.z[ZHide] = hdr.takeRight(row, gap);
  G.z[ZExpand] = hdr.takeRight(row, gap);
  G.z[ZHeader] = hdr;
  c.takeTop(bar + gap);
  Rect lr = c.takeTop(row);
  G.z[ZPrev] = lr.takeLeft(row, gap);
  G.z[ZNext] = lr.takeRight(row, gap);
  G.z[ZLabel] = lr;
  c.takeTop(small + bar);
  if (expanded) {
    c.takeTop(gap + small * 2 + gap);
    Rect m = c.takeTop(row);
    const float mw = (m.w - 3 * gap) / 4;
    for (int i = 0; i < 4; ++i) G.z[ZMode0 + i] = {std::round(m.x + i * (mw + gap)), m.y, std::round(mw), m.h};
    c.takeTop(gap);
    Rect hf = c.takeTop(row);
    G.z[ZHolo] = hf.takeLeft(std::round((hf.w - gap) / 2), gap);
    G.z[ZFilter] = hf;
    c.takeTop(gap);
    Rect pl = c.takeTop(row);
    G.z[ZPlaceLayer] = pl.takeLeft(std::round((pl.w - gap) / 2), gap);
    G.z[ZPlaceVisible] = pl;
    c.takeTop(gap);
    Rect ct = c.takeTop(row);
    const float cw = std::round((ct.w - 2 * gap) / 3);
    G.z[ZPause] = ct.takeLeft(cw, gap);
    G.z[ZCancel] = ct.takeLeft(cw, gap);
    G.z[ZOpenUi] = ct;
  }
  const float rs = std::round(22.f * k);  // resize grip touch area (bottom-right corner)
  G.z[ZResize] = {G.panel.r() - rs, G.panel.b() - rs, rs, rs};
  G.valid = W > 0 && H > 0;
}

int hitLocked(float x, float y) {
  if (!gGeo.panel.contains(x, y)) return ZNone;
  for (int i = ZCount - 1; i >= 0; --i)
    if (gGeo.z[i].contains(x, y)) return i;
  return ZHeader;  // panel body drags like the header
}

void resetGestureLocked() {
  gPtr = -1;
  gZone = ZNone;
  gDrag = false;
  gDragKind = 0;
  gPressed.store(ZNone);
}

void wake() {
  if (auto w = gWake.load()) w();
}

bool placeAvailable() { return ep::state().installed.load(std::memory_order_relaxed); }

bool armOrConfirm(int z) {
  const int64_t now = nowMs();
  if (gArmed.load() == z && now - gArmedAt.load() < kArmMs) {
    gArmed.store(ZNone);
    return true;
  }
  gArmed.store(z);
  gArmedAt.store(now);
  return false;
}

void fire(int z) {
  auto &s = settings();
  if (z != ZPlaceLayer && z != ZPlaceVisible && z != ZCancel) gArmed.store(ZNone);
  switch (z) {
    case ZExpand: s.ovExpanded.store(!s.ovExpanded.load()); break;
    case ZHide:
      s.ovVisible.store(false);
      notify("prog.ov_hidden", Tone::Info, 3500);
      break;
    case ZPrev: app::layerDelta(-1); break;
    case ZNext: app::layerDelta(+1); break;
    case ZLabel: app::setLayerToFeet(); break;
    case ZMode0: case ZMode1: case ZMode2: case ZMode3: app::setLayerMode(z - ZMode0); break;
    case ZHolo: s.hologram.store(!s.hologram.load()); break;
    case ZFilter: s.holoFilter.store((std::clamp(s.holoFilter.load(), 0, 3) + 1) % 4); break;
    case ZPlaceLayer:
    case ZPlaceVisible: {
      if (!placeAvailable()) break;
      const int scope = z == ZPlaceLayer ? 1 : 2;
      if (ep::runScope() == scope) {  // running: tap stops it (stopping never needs a confirm)
        gArmed.store(ZNone);
        ep::startRun(0);
      } else if (armOrConfirm(z)) {
        ep::startRun(scope);
      }
      break;
    }
    case ZPause:
      if (ep::paused()) ep::resume();
      else ep::pause();
      break;
    case ZCancel:
      if (armOrConfirm(z)) ep::cancel();
      break;
    case ZOpenUi:
      if (auto f = gOpenUi.load()) f();
      break;
    default: break;
  }
}

// ---- glyphs (no font dependency) ----
void chevron(Canvas &cv, const Rect &r, int dir, uint32_t c) {  // dir 0 left, 1 right, 2 down, 3 up
  const float s = std::min(r.w, r.h) * 0.2f, cx = r.cx(), cy = r.cy();
  switch (dir) {
    case 0: cv.triangle(cx + s * 0.6f, cy - s, cx + s * 0.6f, cy + s, cx - s * 0.7f, cy, c); break;
    case 1: cv.triangle(cx - s * 0.6f, cy - s, cx - s * 0.6f, cy + s, cx + s * 0.7f, cy, c); break;
    case 2: cv.triangle(cx - s, cy - s * 0.5f, cx + s, cy - s * 0.5f, cx, cy + s * 0.7f, c); break;
    default: cv.triangle(cx - s, cy + s * 0.5f, cx + s, cy + s * 0.5f, cx, cy - s * 0.7f, c); break;
  }
}
void cross(Canvas &cv, const Rect &r, uint32_t c, float t) {
  const float s = std::min(r.w, r.h) * 0.18f;
  cv.line(r.cx() - s, r.cy() - s, r.cx() + s, r.cy() + s, c, t);
  cv.line(r.cx() - s, r.cy() + s, r.cx() + s, r.cy() - s, c, t);
}

const char *opKey(int op) {
  static const char *k[] = {"prog.op_idle",       "prog.op_turning",  "prog.op_placing", "prog.op_verifying",
                            "prog.op_correcting", "prog.op_need_item", "prog.op_paused", "prog.op_no_target"};
  return k[std::clamp(op, 0, int(sizeof(k) / sizeof(k[0])) - 1)];
}

struct Key {
  float W, H, pos[2], scale, width, alpha;
  int vis, expanded, display, pressed, armed, filter, holo, op, run, paused, epOn, layer, mode, axis, nLayers;
  uint32_t total, s[PCount], lt, ls[PCount], moveRev, lang;
  bool operator==(const Key &o) const { return std::memcmp(this, &o, sizeof(Key)) == 0; }
};
Key gLast{};
bool gHaveLast = false;
int64_t gLastCountsAt = 0;

void button(Canvas &cv, const Rect &r, bool pressed, bool on, bool enabled, float rad) {
  const uint32_t f = !enabled ? col::ControlDisabled
                     : on     ? (pressed ? col::AccentPressed : col::Accent)
                              : (pressed ? col::ControlPressed : col::Control);
  cv.fill(r, f, rad);
}

}  // namespace

void setActions(void (*openUi)(), void (*w)()) {
  gOpenUi.store(openUi);
  gWake.store(w);
}

bool wanted() {
  if (!settings().ovVisible.load(std::memory_order_relaxed)) {
    gUi.store(0);
    return false;
  }
  if (!model().live.load(std::memory_order_acquire)) {
    gUi.store(1);
    return false;
  }
  if (!hudbtn::gameHudVisible()) {
    gUi.store(3);
    return false;
  }
  return true;
}

void hidden() {
  std::lock_guard<std::mutex> lk(gMu);
  gShown = false;
  if (gPtr >= 0) resetGestureLocked();
}

bool changed(float W, float H) {
  auto &s = settings();
  Snap sn;
  snapshot(sn);
  Key k{};
  k.W = W;
  k.H = H;
  k.pos[0] = s.ovX.load();
  k.pos[1] = s.ovY.load();
  k.scale = s.ovScale.load();
  k.width = s.ovWidth.load();
  k.alpha = s.ovAlpha.load();
  k.vis = s.ovVisible.load();
  k.expanded = s.ovExpanded.load();
  k.display = s.ovDisplay.load();
  k.pressed = gPressed.load();
  const int64_t now = nowMs();
  k.armed = now - gArmedAt.load() < kArmMs ? gArmed.load() : ZNone;
  k.filter = s.holoFilter.load();
  k.holo = s.hologram.load();
  k.op = ep::currentOp();
  k.run = ep::runScope();
  k.paused = ep::paused();
  k.epOn = ep::state().enabled.load();
  k.layer = sn.layer;
  k.mode = sn.mode;
  k.axis = sn.axis;
  k.nLayers = sn.nLayers;
  k.moveRev = gMoveRev.load();
  k.lang = i18n::generation();
  // progress numbers: at most one refresh per 200 ms bucket
  Key cnt = gLast;
  k.total = sn.all.total;
  std::memcpy(k.s, sn.all.s, sizeof(k.s));
  k.lt = sn.lay.total;
  std::memcpy(k.ls, sn.lay.s, sizeof(k.ls));
  if (gHaveLast && now - gLastCountsAt < kBucketMs) {
    k.total = cnt.total;
    std::memcpy(k.s, cnt.s, sizeof(k.s));
    k.lt = cnt.lt;
    std::memcpy(k.ls, cnt.ls, sizeof(k.ls));
  }
  if (gHaveLast && k == gLast) return false;
  if (!gHaveLast || k.total != gLast.total || std::memcmp(k.s, gLast.s, sizeof(k.s)) || k.lt != gLast.lt ||
      std::memcmp(k.ls, gLast.ls, sizeof(k.ls)))
    gLastCountsAt = now;
  gLast = k;
  gHaveLast = true;
  return true;
}

void draw(Canvas &cv, float W, float H) {
  auto &s = settings();
  Snap sn;
  if (!snapshot(sn)) {
    hidden();
    return;
  }
  const float dev = ui::kit::deviceDensity(W, H);
  const bool expanded = s.ovExpanded.load();
  Geo G;
  {
    std::lock_guard<std::mutex> lk(gMu);
    if (gPtr < 0 || !gDrag || gDragKind == 2 || gGeo.W != W || gGeo.H != H) layoutLocked(W, H, dev, expanded);
    G = gGeo;
    gShown = true;
  }
  gUi.store(2);
  theme::UiStyle style;
  style.scale = 1.f;
  style.spacing = 1.f;
  int pcts[sty::InkCount];
  for (int i = 0; i < sty::InkCount; ++i) pcts[i] = s.opacityPct[i].load();
  theme::resolveOpacity(std::clamp(s.opacityMode.load(), 0, sty::OpacityModeCount - 1), pcts, style.op);
  const Metrics saved = cv.m;
  const Rect savedClip = cv.clip, savedPressed = cv.pressed;
  const float savedAlpha = cv.alpha;
  cv.m = ui::kit::makeMetrics(G.k, false, &style, dev);
  cv.noClip();
  cv.pressed = {};
  cv.alpha = std::clamp(s.ovAlpha.load(), 0.3f, 1.f);
  const float k = G.k, rad = 6.f * k, small = std::round(16.f * k), bar = std::max(2.f, std::round(3.f * k));
  const float fBody = 13.f * k, fSmall = 11.f * k;
  const int pressed = gPressed.load();
  const int64_t now = nowMs();
  const int armed = now - gArmedAt.load() < kArmMs ? gArmed.load() : ZNone;

  cv.frame(G.panel, col::Panel, col::PanelBorder, rad, std::max(1.f, k));
  // header: progress
  const auto &A = sn.all;
  std::string head;
  const int disp = std::clamp(s.ovDisplay.load(), 0, 2);
  if (!sn.cmpReady) head = tr("prog.waiting");
  else if (A.total == 0) head = tr("prog.no_blocks");
  else if (disp == 1) head = grp(A.done()) + " / " + grp(A.total);
  else if (disp == 2 && sn.layOk && sn.lay.total)
    head = grp(sn.lay.done()) + " / " + grp(sn.lay.total) + "  " + pct(sn.lay.percent());
  else head = pct(A.percent()) + "  " + grp(A.done()) + " / " + grp(A.total);
  cv.text(G.z[ZHeader], head, col::Text, fBody, Align::Left, true);
  button(cv, G.z[ZExpand], pressed == ZExpand, false, true, rad);
  chevron(cv, G.z[ZExpand], expanded ? 3 : 2, col::Text);
  button(cv, G.z[ZHide], pressed == ZHide, false, true, rad);
  cross(cv, G.z[ZHide], col::Text, std::max(1.5f, 1.8f * k));
  // overall bar
  const Rect hb{G.z[ZHeader].x, G.z[ZHeader].b(), G.panel.r() - std::round(kPadDp * k) - G.z[ZHeader].x, bar};
  cv.fill(hb, col::Control, bar * 0.5f);
  if (A.total) {
    const float f = float(A.done()) / float(A.total);
    cv.fill({hb.x, hb.y, std::round(hb.w * f), hb.h}, col::Success, bar * 0.5f);
  }
  // layer row
  static const char kAxis[3] = {'X', 'Y', 'Z'};
  char lab[64];
  std::snprintf(lab, sizeof(lab), "%c=%d  %d/%d", kAxis[sn.axis], sn.coord, sn.layer + 1, sn.nLayers);
  button(cv, G.z[ZPrev], pressed == ZPrev, false, sn.layer > 0, rad);
  chevron(cv, G.z[ZPrev], 0, sn.layer > 0 ? col::Text : col::TextDisabled);
  button(cv, G.z[ZNext], pressed == ZNext, false, sn.layer + 1 < sn.nLayers, rad);
  chevron(cv, G.z[ZNext], 1, sn.layer + 1 < sn.nLayers ? col::Text : col::TextDisabled);
  if (pressed == ZLabel) cv.fill(G.z[ZLabel], col::ControlPressed, rad);
  const char *modeShort[5] = {tr("ui.layer_all"), tr("ui.layer_single"), tr("ui.layer_below"), tr("ui.layer_above"),
                              tr("ui.layer_range")};
  const Rect lt = G.z[ZLabel];
  cv.text({lt.x, lt.y, lt.w, lt.h * 0.62f}, lab, col::Text, fBody, Align::Center, true);
  cv.text({lt.x, lt.y + lt.h * 0.55f, lt.w, lt.h * 0.45f}, modeShort[sn.mode], col::TextSecondary, fSmall * 0.9f,
          Align::Center, true);
  // layer progress + bar
  const Rect lp{G.panel.x + std::round(kPadDp * k), G.z[ZLabel].b(), G.panel.w - 2 * std::round(kPadDp * k), small};
  std::string lpt;
  if (sn.layOk && sn.lay.total)
    lpt = std::string(tr("ui.layer")) + ": " + grp(sn.lay.done()) + " / " + grp(sn.lay.total) + "  " +
          pct(sn.lay.percent());
  else if (sn.layOk)
    lpt = std::string(tr("ui.layer")) + ": " + tr("prog.no_blocks");
  else
    lpt = std::string(tr("ui.layer")) + ": " + tr("prog.waiting");
  cv.text(lp, lpt, col::TextSecondary, fSmall, Align::Left, true);
  const Rect lb{lp.x, lp.b(), lp.w, bar};
  cv.fill(lb, col::Control, bar * 0.5f);
  if (sn.layOk && sn.lay.total)
    cv.fill({lb.x, lb.y, std::round(lb.w * float(sn.lay.done()) / float(sn.lay.total)), lb.h}, col::Success,
            bar * 0.5f);

  if (expanded) {
    // status: current operation + counts
    const int op = ep::currentOp();
    std::string st = tr(opKey(op));
    const int run = ep::runScope();
    if (run) st += std::string("  -  ") + tr(run == 1 ? "prog.place_layer" : "prog.place_visible");
    const Rect s1{lp.x, lb.b() + std::round(kGapDp * k), lp.w, small};
    cv.text(s1, st, op == ep::OpPaused ? col::Warning : col::Text, fSmall, Align::Left, true);
    std::string cnt = std::string(tr("prog.missing")) + " " + grp(A.s[PMissing] + A.s[PNotChecked]) + "  " +
                      tr("prog.incorrect") + " " + grp(A.s[PIncorrect]) + "  " + tr("prog.skipped") + " " +
                      grp(A.s[PSkipped] + A.s[PFailed]) + "  " + tr("prog.unsupported") + " " +
                      grp(A.s[PUnsupported]);
    cv.text({s1.x, s1.b(), s1.w, small}, cnt, col::TextSecondary, fSmall, Align::Left, true);
    // layer modes
    for (int i = 0; i < 4; ++i) {
      const bool on = sn.mode == i;
      button(cv, G.z[ZMode0 + i], pressed == ZMode0 + i, on, true, rad);
      cv.text(G.z[ZMode0 + i], modeShort[i], on ? col::TextOnAccent : col::Text, fSmall, Align::Center, true);
    }
    // hologram + filter
    const bool holo = s.hologram.load();
    button(cv, G.z[ZHolo], pressed == ZHolo, holo, true, rad);
    cv.text(G.z[ZHolo], tr("ui.hologram"), holo ? col::TextOnAccent : col::Text, fSmall, Align::Center, true);
    static const char *kFilter[4] = {"prog.filter_all", "prog.filter_missing", "prog.filter_incorrect",
                                     "prog.filter_unverified"};
    const int f = std::clamp(s.holoFilter.load(), 0, 3);
    button(cv, G.z[ZFilter], pressed == ZFilter, f != 0, true, rad);
    cv.text(G.z[ZFilter], tr(kFilter[f]), f ? col::TextOnAccent : col::Text, fSmall, Align::Center, true);
    // place runs (confirm with a second tap)
    const bool can = placeAvailable();
    for (int z : {int(ZPlaceLayer), int(ZPlaceVisible)}) {
      const int scope = z == ZPlaceLayer ? 1 : 2;
      const bool running = run == scope, arm = armed == z;
      const uint32_t fill = !can ? col::ControlDisabled : arm ? col::DangerArmed : running ? col::Accent
                            : pressed == z ? col::ControlPressed : col::Control;
      cv.fill(G.z[z], fill, rad);
      const char *t = arm ? tr("prog.confirm") : running ? tr("prog.stop")
                      : tr(z == ZPlaceLayer ? "prog.place_layer" : "prog.place_visible");
      cv.text(G.z[z], t, !can ? col::TextDisabled : (arm || running) ? col::TextOnAccent : col::Text, fSmall,
              Align::Center, true);
    }
    // pause / cancel / open UI
    const bool paused = ep::paused();
    button(cv, G.z[ZPause], pressed == ZPause, paused, can, rad);
    cv.text(G.z[ZPause], tr(paused ? "prog.resume" : "prog.pause"), paused ? col::TextOnAccent : col::Text, fSmall,
            Align::Center, true);
    cv.fill(G.z[ZCancel], armed == ZCancel ? col::DangerArmed : pressed == ZCancel ? col::ControlPressed : col::Danger,
            rad);
    cv.text(G.z[ZCancel], armed == ZCancel ? tr("prog.confirm") : tr("ui.cancel"), col::TextOnAccent, fSmall,
            Align::Center, true);
    button(cv, G.z[ZOpenUi], pressed == ZOpenUi, false, true, rad);
    cv.text(G.z[ZOpenUi], tr("prog.open_ui"), col::Text, fSmall, Align::Center, true);
  }
  // resize grip
  const Rect g = G.z[ZResize];
  const float gs = g.w * 0.45f;
  cv.triangle(g.r() - std::round(3 * k), g.b() - gs - std::round(3 * k), g.r() - std::round(3 * k),
              g.b() - std::round(3 * k), g.r() - gs - std::round(3 * k), g.b() - std::round(3 * k),
              pressed == ZResize ? col::AccentText : col::TextDisabled);
  cv.m = saved;
  cv.clip = savedClip;
  cv.pressed = savedPressed;
  cv.alpha = savedAlpha;
}

bool onTouch(const pl::input::TouchEvent &ev) {
  int doFire = ZNone, scrubTo = -1;
  bool consumed = false, look = false, toggleExpand = false, cycleDisplay = false;
  {
    std::lock_guard<std::mutex> lk(gMu);
    if (!gShown || !gGeo.valid || !settings().ovVisible.load(std::memory_order_relaxed)) {
      if (gPtr >= 0) resetGestureLocked();
      return false;
    }
    const float slop = kSlopDp * gGeo.k;
    switch (ev.action) {
      case 0:
      case 5: {
        if (ev.action == 0 && gPtr >= 0) {  // stale gesture (lost up event)
          resetGestureLocked();
          look = true;
        }
        const int z = hitLocked(ev.x, ev.y);
        if (z == ZNone) break;  // starts outside: the game gets it
        consumed = true;        // inside: never reaches the game, even as a second finger
        if (gPtr >= 0) break;   // one gesture at a time
        gPtr = ev.pointerId;
        gZone = z;
        gDrag = false;
        gDragKind = 0;
        gDownX = ev.x;
        gDownY = ev.y;
        gStartX = gGeo.panel.x;
        gStartY = gGeo.panel.y;
        gStartW = settings().ovWidth.load();
        gDownAt = nowMs();
        gScrubApplied = 0;
        gStartLayer = app::currentLayer();
        gPressed.store(z);
        look = true;
        break;
      }
      case 2: {
        if (gPtr < 0 || ev.pointerId != gPtr) break;
        consumed = true;
        const float dx = ev.x - gDownX, dy = ev.y - gDownY;
        if (!gDrag && std::hypot(dx, dy) > slop) {
          gDrag = true;
          gDragKind = gZone == ZHeader ? 1 : gZone == ZResize ? 2 : gZone == ZLabel ? 3 : 0;
          gPressed.store(gDragKind == 2 ? ZResize : ZNone);
          look = true;
        }
        if (!gDrag) break;
        if (gDragKind == 1) {
          Rect &p = gGeo.panel;
          const float freeW = std::max(0.f, gGeo.W - p.w), freeH = std::max(0.f, gGeo.H - p.h);
          const float nx = std::round(std::clamp(gStartX + dx, 0.f, freeW));
          const float ny = std::round(std::clamp(gStartY + dy, 0.f, freeH));
          for (auto &r : gGeo.z) {  // move the zones with the panel (layout is kept while dragging)
            r.x += nx - p.x;
            r.y += ny - p.y;
          }
          p.x = nx;
          p.y = ny;
          settings().ovX.store(freeW > 0 ? p.x / freeW : 0.f);
          settings().ovY.store(freeH > 0 ? p.y / freeH : 0.f);
          gMoveRev.fetch_add(1);
          look = true;
        } else if (gDragKind == 2) {
          const float base = kBaseWDp * gGeo.k;
          settings().ovWidth.store(std::clamp(gStartW + dx / base, 0.8f, 1.6f));
          gMoveRev.fetch_add(1);
          look = true;
        } else if (gDragKind == 3) {
          const int steps = int(dx / (kScrubDp * gGeo.k));
          if (steps != gScrubApplied) {
            gScrubApplied = steps;
            scrubTo = gStartLayer + steps;
          }
        }
        break;
      }
      case 1:
      case 6: {
        if (gPtr < 0 || ev.pointerId != gPtr) {
          // a second finger lifted inside the panel: keep it from the game too
          consumed = gGeo.panel.contains(ev.x, ev.y) && gPtr >= 0;
          break;
        }
        consumed = true;
        if (!gDrag) {
          const bool inside = gZone >= 0 && (gZone == ZHeader ? gGeo.panel.contains(ev.x, ev.y)
                                                              : gGeo.z[gZone].contains(ev.x, ev.y));
          if (inside) {
            if (gZone == ZHeader) {
              if (nowMs() - gDownAt >= kLongPressMs) toggleExpand = true;  // long press: compact/expanded
              else cycleDisplay = true;                                    // tap: what the header shows
            } else if (gZone != ZResize) {
              doFire = gZone;
            }
          }
        }
        resetGestureLocked();
        look = true;
        break;
      }
      case 3:
        if (gPtr < 0) break;
        consumed = true;
        resetGestureLocked();
        look = true;
        break;
      default: break;
    }
  }
  if (consumed) gTouches.fetch_add(1, std::memory_order_relaxed);
  if (scrubTo >= 0) app::setLayer(scrubTo);
  if (toggleExpand) settings().ovExpanded.store(!settings().ovExpanded.load());
  if (cycleDisplay) settings().ovDisplay.store((std::clamp(settings().ovDisplay.load(), 0, 2) + 1) % 3);
  if (doFire != ZNone) fire(doFire);
  if (look || doFire != ZNone || scrubTo >= 0 || toggleExpand || cycleDisplay) wake();
  return consumed;
}

const char *uiStatus() {
  switch (gUi.load()) {
    case 2: return "Active";
    case 3: return "Hidden";
    case 1: return "Waiting";
    default: return "Off";
  }
}
const char *touchStatus() {
  std::lock_guard<std::mutex> lk(gMu);
  if (gPtr >= 0 && gDrag) return "Active";
  return gTouches.load() ? "OK" : "Not checked";
}
uint32_t touchesConsumed() { return gTouches.load(); }

}  // namespace lm::overlay
