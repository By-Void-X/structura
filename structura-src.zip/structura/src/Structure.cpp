#include "Structure.hpp"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <climits>
#include <cstring>
#include <fstream>

#include <zlib.h>
#include <unordered_map>

#include "BlockStates.hpp"
#include "JavaFormats.hpp"
#include "Nbt.hpp"

namespace lm {
namespace {

struct ColorRow {
  const char *name;
  uint32_t argb;
};
const ColorRow kColors[] = {
#include "BlockColors.inc"
};
constexpr size_t kColorCount = sizeof(kColors) / sizeof(kColors[0]);

const ColorRow *findColor(const std::string &n) {
  size_t lo = 0, hi = kColorCount;
  while (lo < hi) {
    const size_t mid = (lo + hi) / 2;
    const int c = std::strcmp(kColors[mid].name, n.c_str());
    if (c == 0) return &kColors[mid];
    if (c < 0) lo = mid + 1; else hi = mid;
  }
  return nullptr;
}

const char *const kDyes[] = {"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
                             "light_gray", "silver", "cyan", "purple", "blue", "brown", "green", "red", "black"};

std::string stateString(const nbt::Tag *states, const char *key) {
  if (!states) return {};
  const nbt::Tag *t = states->get(key);
  return (t && t->type == nbt::String) ? t->s : std::string();
}


std::string modernize(const std::string &shortName, const nbt::Tag *states) {
  const std::string color = stateString(states, "color");
  auto dye = [&](const std::string &c) { return c == "silver" ? std::string("light_gray") : c; };
  if (!color.empty()) {
    static const char *const bases[] = {"wool", "carpet", "concrete", "concrete_powder", "stained_glass",
                                        "stained_glass_pane", "shulker_box"};
    for (const char *b : bases)
      if (shortName == b) return dye(color) + "_" + b;
    if (shortName == "stained_hardened_clay") return dye(color) + "_terracotta";
  }
  if (shortName == "hardened_clay") return "terracotta";
  if (shortName == "planks" || shortName == "wooden_slab" || shortName == "double_wooden_slab") {
    const std::string w = stateString(states, "wood_type");
    if (!w.empty()) return w + (shortName == "planks" ? "_planks" : "_slab");
  }
  if (shortName == "log" || shortName == "log2") {
    std::string w = stateString(states, shortName == "log" ? "old_log_type" : "new_log_type");
    if (!w.empty()) return w + "_log";
  }
  if (shortName == "leaves" || shortName == "leaves2") {
    std::string w = stateString(states, shortName == "leaves" ? "old_leaf_type" : "new_leaf_type");
    if (!w.empty()) return w + "_leaves";
  }
  if (shortName == "stone") {
    const std::string t = stateString(states, "stone_type");
    if (t == "granite" || t == "diorite" || t == "andesite") return t;
    if (t == "granite_smooth") return "polished_granite";
    if (t == "diorite_smooth") return "polished_diorite";
    if (t == "andesite_smooth") return "polished_andesite";
  }
  if (shortName == "grass") return "grass_block";
  return shortName;
}

uint32_t hashColor(const std::string &s) {
  uint32_t h = 2166136261u;
  for (char c : s) h = (h ^ uint8_t(c)) * 16777619u;
  return 0xFF000000u | (0x40 + (h & 0x7F)) << 16 | (0x40 + ((h >> 8) & 0x7F)) << 8 | (0x40 + ((h >> 16) & 0x7F));
}

}  

std::string normalizeName(const std::string &fullName) {
  const auto c = fullName.find(':');
  return c == std::string::npos ? fullName : fullName.substr(c + 1);
}

uint32_t blockColor(const std::string &n) {
  if (const ColorRow *r = findColor(n)) return r->argb | 0xFF000000u;  
  
  static const char *const suffixes[] = {"_double_slab", "_slab", "_stairs", "_wall", "_fence_gate", "_fence",
                                         "_trapdoor", "_door", "_button", "_pressure_plate", "_pane", "_carpet",
                                         "_sign", "_hanging_sign", "_block"};
  for (const char *suf : suffixes) {
    const size_t L = std::strlen(suf);
    if (n.size() > L && n.compare(n.size() - L, L, suf) == 0) {
      std::string base = n.substr(0, n.size() - L);
      for (const std::string &cand : {base, base + "_planks", base + "s", base + "_block"})
        if (const ColorRow *r = findColor(cand)) return r->argb | 0xFF000000u;
    }
  }
  for (const char *d : kDyes) {
    const size_t L = std::strlen(d);
    if (n.compare(0, L, d) == 0 && n.size() > L && n[L] == '_')
      if (const ColorRow *r = findColor(std::string(d) + "_wool")) return r->argb | 0xFF000000u;
  }
  return hashColor(n);
}

std::string prettyName(const std::string &n) {
  std::string out;
  bool up = true;
  for (char c : n) {
    if (c == '_') { out.push_back(' '); up = true; continue; }
    out.push_back(up ? char(std::toupper(uint8_t(c))) : c);
    up = false;
  }
  return out;
}

static bool gunzip(const std::vector<uint8_t> &in, std::vector<uint8_t> &out) {
  z_stream zs{};
  if (inflateInit2(&zs, 16 + MAX_WBITS) != Z_OK) return false;
  zs.next_in = const_cast<Bytef *>(in.data());
  zs.avail_in = uInt(in.size());
  out.resize(in.size() * 4 + 1024);
  int rc;
  do {
    if (zs.total_out >= out.size()) {
      if (out.size() > 300u * 1024 * 1024) { inflateEnd(&zs); return false; }
      out.resize(out.size() * 2);
    }
    zs.next_out = out.data() + zs.total_out;
    zs.avail_out = uInt(out.size() - zs.total_out);
    rc = inflate(&zs, Z_NO_FLUSH);
  } while (rc == Z_OK);
  out.resize(zs.total_out);
  inflateEnd(&zs);
  return rc == Z_STREAM_END;
}

std::string LoadInfo::describe() const {
  char b[256];
  std::snprintf(b, sizeof b, "dimensions=%dx%dx%d block_indices=%s indices=%zu palette=%zu air=%zu solid=%zu void=%zu",
                sx, sy, sz, indicesType.empty() ? "-" : indicesType.c_str(), indexCount, paletteSize, airCount,
                solidCount, voidCount);
  return b;
}

std::string LoadInfo::statesLine() const {
  char b[256];
  std::snprintf(b, sizeof b, "states: preserved=%zu ok=%zu directional=%zu multiblock=%zu unknown=%zu raw=%zu "
                "discarded_states=%zu discarded_variants=%zu waterlogged=%zu block_entities=%zu",
                preservedStates, variantsOk, variantsDirectional, variantsMulti, variantsUnknown, rawStates,
                discardedStates, discardedVariants, waterlogged, blockEntities);
  std::string out = b;
  if (!format.empty()) out += " format=" + format;
  if (format != "mcstructure" && !format.empty()) {
    std::snprintf(b, sizeof b, " java_states=%zu approx=%zu unmapped=%zu data_version=%d", javaStates, javaApprox,
                  javaUnmapped, javaDataVersion);
    out += b;
    if (!javaUnmappedNames.empty()) out += " unmapped_blocks=" + javaUnmappedNames;
  }
  if (!rawKeys.empty()) out += " raw_keys=" + rawKeys;
  if (!unknownKeys.empty()) out += " unknown_keys=" + unknownKeys;
  if (!discardedKeys.empty()) out += " discarded_keys=" + discardedKeys;
  return out;
}

bool loadStructure(const std::string &path, Structure &out, std::string &err, LoadInfo *info) {
  LoadInfo localInfo;
  LoadInfo &li = info ? *info : localInfo;
  li = LoadInfo{};
  std::ifstream f(path, std::ios::binary);
  if (!f) { err = "can't read file"; return false; }
  std::vector<uint8_t> data((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  if (data.size() < 16) { err = "empty file"; return false; }
  if (data.size() > 200u * 1024 * 1024) { err = "file too large"; return false; }
  if (data[0] == 0x1F && data[1] == 0x8B) {  
    std::vector<uint8_t> raw;
    if (!gunzip(data, raw)) { err = "corrupt file"; return false; }
    data.swap(raw);
  }
  if (data[0] == 'P' && data[1] == 'K') { err = "zip/mcpack, extract it first"; return false; }
  if (data[0] != 0x0A) { err = "not an NBT structure file"; return false; }
  // Bedrock .mcstructure is little-endian NBT; Java .nbt/.litematic/.schem/.schematic are big-endian.
  // The extension only decides which byte order is tried first: the content decides the format.
  std::string ext;
  {
    const auto sl = path.find_last_of('/');
    const auto dot = path.rfind('.');
    if (dot != std::string::npos && (sl == std::string::npos || dot > sl))
      for (char c : path.substr(dot)) ext.push_back(char(std::tolower(uint8_t(c))));
  }
  const bool javaFirst = ext == ".nbt" || ext == ".litematic" || ext == ".schem" || ext == ".schematic";
  nbt::Tag root;
  bool isJava = false, recognised = false, parsedAny = false;
  for (int pass = 0; pass < 2 && !recognised; ++pass) {
    const bool be = (pass == 0) == javaFirst;
    nbt::Tag r;
    std::string e;
    if (!nbt::parse(data.data(), data.size(), r, e, be)) {
      if (!parsedAny && err.empty()) err = e;
      continue;
    }
    const bool bedrockTree = !be && r.get("structure") && r.get("size");
    const bool javaTree = be && java::isJavaFormat(r);
    if (bedrockTree || javaTree || !parsedAny) {
      root = std::move(r);
      parsedAny = true;
      isJava = javaTree;
      recognised = bedrockTree || javaTree;
    }
  }
  if (!parsedAny) return false;  // err: NBT reader message
  err.clear();
  java::Stats js;
  if (isJava) {
    nbt::Tag conv;
    if (!java::toBedrock(root, conv, js, err)) return false;
    root = std::move(conv);
    li.format = js.format;
    li.javaDataVersion = js.dataVersion;
    li.javaStates = js.paletteEntries;
    li.javaApprox = js.approx;
    li.javaUnmapped = js.unmapped;
    li.javaUnmappedNames = js.unmappedNames;
  } else {
    li.format = "mcstructure";
  }

  const nbt::Tag *size = root.get("size");
  const nbt::Tag *st = root.get("structure");
  if (!size || !size->isIntList() || size->nums.size() != 3 || !st || st->type != nbt::Compound) {
    err = "not a structure file (.mcstructure, .nbt, .litematic, .schem, .schematic)";
    return false;
  }
  const int64_t sx = size->nums[0], sy = size->nums[1], sz = size->nums[2];
  if (sx <= 0 || sy <= 0 || sz <= 0 || sx * sy * sz > 16LL * 1024 * 1024) {
    err = "invalid or too large (max 16M blocks)";
    return false;
  }
  li.sx = int(sx); li.sy = int(sy); li.sz = int(sz);
  const nbt::Tag *bi = st->get("block_indices");
  const nbt::Tag *pal = st->get("palette");
  const nbt::Tag *def = pal ? pal->get("default") : nullptr;
  if (!def && pal && pal->type == nbt::Compound)  
    for (auto &f : pal->fields)
      if (f.second.type == nbt::Compound && f.second.get("block_palette")) { def = &f.second; break; }
  const nbt::Tag *bp = def ? def->get("block_palette") : nullptr;
  if (bi) li.indicesType = nbt::typeName(*bi);
  if (!bi) { err = "missing block_indices"; return false; }
  
  
  if (!bi->isListOfIntLists() || bi->items.empty() || !bi->items[0].isIntList()) {
    err = "unsupported block_indices type (" + li.indicesType + ")";
    return false;
  }
  if (!bp || bp->type != nbt::List || (bp->listType != nbt::Compound && !bp->items.empty())) {
    err = "missing block_palette";
    return false;
  }
  li.paletteSize = bp->items.size();
  const auto &layer0 = bi->items[0].nums;
  li.indexCount = layer0.size();
  const size_t vol = size_t(sx * sy * sz);
  if (layer0.size() != vol) {
    err = "bad block_indices size (" + std::to_string(layer0.size()) + " != " + std::to_string(vol) + ")";
    return false;
  }

  out = Structure{};
  out.path = path;
  {
    std::string t = path.substr(path.find_last_of('/') + 1);
    const auto dot = t.rfind('.');
    out.title = dot == std::string::npos ? t : t.substr(0, dot);
  }
  out.sx = int(sx); out.sy = int(sy); out.sz = int(sz);

  
  std::vector<uint16_t> remap(bp->items.size(), kVoid);
  std::unordered_map<std::string, uint16_t> byName;
  std::vector<uint16_t> vremap(bp->items.size(), kVoid);
  std::unordered_map<std::string, uint16_t> byVariant;
  for (size_t k = 0; k < bp->items.size(); ++k) {
    const nbt::Tag &e = bp->items[k];
    const nbt::Tag *nm = e.get("name");
    if (!nm || nm->type != nbt::String) continue;
    const std::string shortName = modernize(normalizeName(nm->s), e.get("states"));
    if (shortName == "structure_void") continue;  
    auto it = byName.find(shortName);
    if (it == byName.end()) {
      if (out.palette.size() >= 0xFFF0) continue;
      PaletteEntry pe;
      pe.name = shortName;
      pe.label = prettyName(shortName);
      pe.air = shortName == "air";
      pe.color = pe.air ? 0x00000000u : blockColor(shortName);
      it = byName.emplace(shortName, uint16_t(out.palette.size())).first;
      out.palette.push_back(std::move(pe));
    }
    remap[k] = it->second;
    
    BlockVariant bv;
    bv.palette = it->second;
    bv.fullName = nm->s;
    if (const nbt::Tag *stt = e.get("states"); stt && stt->type == nbt::Compound) {
      for (auto &f : stt->fields) {
        const nbt::Tag &v = f.second;
        BlockStateValue sv;
        sv.key = f.first;
        if (v.type == nbt::Byte || v.type == nbt::Short || v.type == nbt::Int) {
          sv.type = v.type == nbt::Int ? nbt::Int : nbt::Byte;
          sv.i = int32_t(v.i);
        } else if (v.type == nbt::Long && v.i >= INT32_MIN && v.i <= INT32_MAX) {
          sv.type = nbt::Int;
          sv.i = int32_t(v.i);
        } else if (v.type == nbt::String) {
          sv.type = nbt::String;
          sv.s = v.s;
        } else {
          // Bedrock block states are byte/int/string. Anything else (long out of range, float, list, ...)
          // is preserved as raw data (original NBT type + text) and reported; the block is marked
          // unsupported for Easy Place instead of being replaced by a default state.
          sv.type = uint8_t(v.type);
          if (v.type == nbt::Float || v.type == nbt::Double) {
            char b[32];  // snprintf: no new libc++ import (std::to_string(double))
            std::snprintf(b, sizeof b, "%g", v.d);
            sv.s = b;
          }
          else if (v.type == nbt::Long) sv.s = std::to_string(v.i);
          else sv.s = "nbt-type-" + std::to_string(int(v.type));
          ++li.rawStates;
          if (li.rawKeys.size() < 120) li.rawKeys += (li.rawKeys.empty() ? "" : ",") + f.first;
        }
        ++li.preservedStates;
        bv.states.push_back(std::move(sv));
      }
    }
    std::string vkey = bv.fullName;
    for (auto &sv : bv.states) {
      vkey += '\x1f';
      vkey += sv.key;
      vkey += '=';
      vkey += sv.type == nbt::String ? sv.s : std::to_string(sv.i);
    }
    auto vit = byVariant.find(vkey);
    if (vit == byVariant.end() && out.variants.size() >= 0xFFF0) {
      ++li.discardedVariants;
      remap[k] = kVoid;  // no default-state fallback: the position stays empty and is reported
      continue;
    }
    if (vit == byVariant.end()) {
      bool unknown = false, dir = false, multi = false;
      for (const auto &sv : bv.states) {
        bool known = true;
        const states::Rule r = states::ruleFor(sv.key, shortName, &known);
        if (!states::plainType(sv)) known = false;  // raw NBT data: kept, reported, never guessed
        if (!known) {
          unknown = true;
          if (li.unknownKeys.size() < 120 && li.unknownKeys.find(sv.key) == std::string::npos)
            li.unknownKeys += (li.unknownKeys.empty() ? "" : ",") + sv.key;
        }
        if (r.cls == states::Cls::Placement) dir = true;
        if (r.cls == states::Cls::Part) multi = true;
      }
      if (unknown) ++li.variantsUnknown;
      else ++li.variantsOk;
      if (dir) ++li.variantsDirectional;
      if (multi) ++li.variantsMulti;
      vit = byVariant.emplace(std::move(vkey), uint16_t(out.variants.size())).first;
      out.variants.push_back(std::move(bv));
    }
    vremap[k] = vit->second;
  }
  out.idx.resize(vol);
  out.vidx.resize(vol);
  for (size_t k = 0; k < vol; ++k) {
    const int64_t v = layer0[k];
    const uint16_t p = (v >= 0 && size_t(v) < remap.size()) ? remap[size_t(v)] : kVoid;
    out.idx[k] = p;
    out.vidx[k] = (p != kVoid) ? vremap[size_t(v)] : kVoid;
    if (p == kVoid) {
      ++li.voidCount;
    } else if (out.palette[p].air) {
      ++li.airCount;
    } else {
      ++out.palette[p].count;
      ++out.solidCount;
    }
  }
  li.solidCount = out.solidCount;
  // layer 2: water of waterlogged blocks (shown in the diagnostics; Easy Place can't add water)
  if (bi->items.size() > 1 && bi->items[1].isIntList() && bi->items[1].nums.size() == vol) {
    std::vector<uint8_t> isWater(bp->items.size(), 0);
    for (size_t k = 0; k < bp->items.size(); ++k) {
      const nbt::Tag *nm = bp->items[k].get("name");
      if (nm && nm->type == nbt::String) {
        const std::string n = normalizeName(nm->s);
        isWater[k] = n == "water" || n == "flowing_water";
      }
    }
    const auto &layer1 = bi->items[1].nums;
    for (size_t k = 0; k < vol; ++k) {
      const int64_t v = layer1[k];
      if (v >= 0 && size_t(v) < isWater.size() && isWater[size_t(v)]) out.water.push_back(uint32_t(k));
    }
    li.waterlogged = out.water.size();
  }
  if (const nbt::Tag *pd = def->get("block_position_data"); pd && pd->type == nbt::Compound)
    li.blockEntities = pd->fields.size();
  if (isJava) li.blockEntities = js.blockEntities;
  
  if (out.solidCount == 0) {
    err = "no blocks";  
    return false;
  }
  return true;
}

bool saveStructure(const std::string &path, int sx, int sy, int sz, const std::vector<std::string> &names,
                   const std::vector<int32_t> &indices, int ox, int oy, int oz, std::string &err) {
  const size_t vol = size_t(sx) * sy * sz;
  if (indices.size() != vol) { err = "bad data"; return false; }
  nbt::Writer w;
  w.beginCompound("");
  w.putInt("format_version", 1);
  w.beginList("size", nbt::Int, 3);
  w.listInt(sx); w.listInt(sy); w.listInt(sz);
  w.beginCompound("structure");
  w.beginList("block_indices", nbt::List, 2);
  w.listListBegin(nbt::Int, int32_t(vol));
  for (int32_t v : indices) w.listInt(v);
  w.listListBegin(nbt::Int, int32_t(vol));
  for (size_t k = 0; k < vol; ++k) w.listInt(-1);
  w.beginList("entities", nbt::Compound, 0);
  w.beginCompound("palette");
  w.beginCompound("default");
  w.beginList("block_palette", nbt::Compound, int32_t(names.size()));
  for (const auto &n : names) {
    w.putString("name", n);
    w.beginCompound("states");
    w.endCompound();
    w.putInt("version", 18168865);  
    w.listCompoundEnd();
  }
  w.beginCompound("block_position_data");
  w.endCompound();
  w.endCompound();  
  w.endCompound();  
  w.endCompound();  
  w.beginList("structure_world_origin", nbt::Int, 3);
  w.listInt(ox); w.listInt(oy); w.listInt(oz);
  w.endCompound();  

  const std::string tmp = path + ".tmp";
  {
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) { err = "can't create file"; return false; }
    f.write(reinterpret_cast<const char *>(w.out.data()), std::streamsize(w.out.size()));
    if (!f) { err = "write failed"; return false; }
  }
  if (std::rename(tmp.c_str(), path.c_str()) != 0) { err = "rename failed"; return false; }
  return true;
}

}  
