#include "App.hpp"
#include "EasyPlace.hpp"
#include "Progress.hpp"
#include "Transformed.hpp"

#include <sys/stat.h>
#include <unistd.h>

#include <chrono>
#include <cmath>
#include <condition_variable>
#include <ctime>
#include <deque>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fstream>

#include "Catalog.hpp"
#include "Compat.hpp"
#include "ExampleData.hpp"
#include <mutex>
#include <thread>

#include <pl/Input.hpp>

#include "Hologram.hpp"
#include "HoloState.hpp"
#include "I18n.hpp"
#include "PlayerContext.hpp"
#include "State.hpp"
#include "Structure.hpp"

namespace lm {


Settings &settings() { static Settings s; return s; }
Status &status() { static Status s; return s; }
Model &model() { static Model m; return m; }
int64_t nowMs() {
  return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch())
      .count();
}
void resetAppearance() {
  auto &s = settings();
  s.controlSize.store(theme::style::DefaultSize);
  s.opacityMode.store(theme::style::DefaultOpacityMode);
  for (int i = 0; i < theme::style::InkCount; ++i) s.opacityPct[i].store(theme::style::DefaultOpacity[i]);
  s.uiLayout.store(theme::style::DefaultLayout);
  s.uiLabels.store(theme::style::DefaultLabels);
  s.uiScale.store(theme::style::SizeScale[theme::style::SizeMedium]);
  s.panelSize.store(0.7f);
  s.panelFX.store(0.5f);
  s.panelFY.store(0.5f);
}

const char *failReasonText(FailReason r) {
  switch (r) {
    case FailReason::None: return "none";
    case FailReason::GameLibraryNotFound: return "game library not found";
    case FailReason::RenderSignatureMissing: return "render signature missing";
    case FailReason::UpdateSignatureMissing: return "update signature missing";
    case FailReason::RenderHookFailed: return "render hook failed";
    case FailReason::UpdateHookFailed: return "update hook failed";
    case FailReason::EasyPlaceHookFailed: return "Easy Place hook failed";
    case FailReason::NoPlayerContext: return "no validated player context source";
  }
  return "unknown";
}
namespace {
std::mutex gGameLabelMu;
std::string gGameLabel;
}  
void setGameLabel(const std::string &label) {
  std::lock_guard<std::mutex> lk(gGameLabelMu);
  gGameLabel = label;
}
std::string gameLabel() {
  std::lock_guard<std::mutex> lk(gGameLabelMu);
  return gGameLabel.empty() ? std::string("version unknown") : gGameLabel;
}
namespace {
std::mutex gToastMu;
Notice gNotice;
}  
std::mutex gImpMu;
std::string gLastImport = "none";
void setLastImport(const std::string &m) {
  std::lock_guard<std::mutex> lk(gImpMu);
  gLastImport = m;
}
void notify(const char *key, Tone tone, int ms, const std::string &arg) {
  std::lock_guard<std::mutex> lk(gToastMu);
  gNotice.key = key ? key : "";
  gNotice.arg = arg;
  gNotice.tone = tone;
  gNotice.start = nowMs();
  gNotice.until = gNotice.start + ms;
}
void toast(const std::string &msg, int ms) { notify("", Tone::Info, ms, msg); }
bool currentNotice(Notice &out) {
  std::lock_guard<std::mutex> lk(gToastMu);
  if (nowMs() >= gNotice.until) return false;
  out = gNotice;
  return true;
}
std::string currentToast() {
  Notice n;
  if (!currentNotice(n)) return {};
  return n.key.empty() ? n.arg : i18n::fmt(n.key, {n.arg});
}
void requestLibraryRescan(const std::string &selectPath) { app::rescan(selectPath); }

namespace app {
int layerSizeLocked(const Model &m);
namespace {

pl::log::Logger *gLog = nullptr;
std::string gMyDir;

std::mutex gJobMu;
std::condition_variable gJobCv;
std::deque<std::function<void()>> gJobs;
bool gJobStop = false;
std::thread gJobThread;

std::mutex gLibMu;
std::vector<lib::Entry> gLib;
uint64_t gLibRev = 0;
std::string gRoots;
std::string gSelected;
std::string gExportDir = "/storage/emulated/0/Download/Structura";

std::string titleOf(const std::string &path) {
  auto sl = path.rfind('/');
  std::string nm = path.substr(sl == std::string::npos ? 0 : sl + 1);
  if (auto d = nm.rfind('.'); d != std::string::npos) nm.resize(d);
  return nm;
}

// ".mcstructure", ".litematic", ... (lower case) of a library file; ".mcstructure" when it has none
std::string extOf(const std::string &path) {
  const auto sl = path.rfind('/');
  const auto d = path.rfind('.');
  if (d == std::string::npos || (sl != std::string::npos && d < sl)) return ".mcstructure";
  std::string e;
  for (char c : path.substr(d)) e.push_back(char(std::tolower(uint8_t(c))));
  return e;
}

bool copyFile(const std::string &from, const std::string &to) {
  std::ifstream in(from, std::ios::binary);
  std::ofstream out(to, std::ios::binary | std::ios::trunc);
  if (!in || !out) return false;
  out << in.rdbuf();
  return bool(out);
}

void mkdirs(const std::string &dir) {
  for (size_t i = 1; i <= dir.size(); ++i)
    if (i == dir.size() || dir[i] == '/') mkdir(dir.substr(0, i).c_str(), 0775);
}


bool feet(int &x, int &y, int &z) {
  auto &st = status();
  if (st.player.load()) {
    x = int(std::floor(st.feetX.load()));
    y = int(std::floor(st.feetY.load() + 0.01f));
    z = int(std::floor(st.feetZ.load()));
    return true;
  }
  // Camera fallback only without any player context source and only with a fresh render frame (no stale
  // menu camera). With a source, placement waits for the real player position.
  if (ctx::anySource()) return false;
  const int64_t lf = hs::rt().lastFrameMs.load(std::memory_order_relaxed);
  if (!lf || hs::monoMs() - lf > 1000) return false;
  const float cx = st.camX.load(), cy = st.camY.load(), cz = st.camZ.load();
  if (!st.hkRender.load() || (cx == 0.f && cy == 0.f && cz == 0.f)) return false;
  x = int(std::floor(cx));
  y = int(std::floor(cy - 1.62f + 0.01f));  
  z = int(std::floor(cz));
  return true;
}


const char *loadErrorKey(const std::string &err) {
  if (err == "no blocks") return "msg.structure_empty";
  if (err.find("too large") != std::string::npos) return "ui.structure_too_large";
  if (err.find("zip/mcpack") != std::string::npos) return "msg.extract_first";
  if (err.find("not a structure file") != std::string::npos || err.find("not an NBT") != std::string::npos)
    return "msg.not_structure";
  if (err.find("can't read") != std::string::npos || err.find("copy failed") != std::string::npos)
    return "msg.file_unreadable";
  return "ui.invalid_structure";
}

void changed(Model &m) {
  ++m.gen;
  m.syncFlags();
}


void placeInFrontLocked(Model &m, int x, int y, int z) {
  int fx, fz;
  facing(fx, fz);
  int dx, dz;
  rotatedSize(*m.structure, m.placement.rot, dx, dz);
  Placement &p = m.placement;
  p.oy = y;
  if (fz == 1) { p.oz = z + 2; p.ox = x - dx / 2; }
  else if (fz == -1) { p.oz = z - 1 - dz; p.ox = x - dx / 2; }
  else if (fx == 1) { p.ox = x + 2; p.oz = z - dz / 2; }
  else { p.ox = x - 1 - dx; p.oz = z - dz / 2; }
  m.placed = true;
  changed(m);
}

}  

void init(const std::string &myDir, pl::log::Logger *log) {
  gLog = log;
  gMyDir = myDir;
  mkdir(myDir.c_str(), 0775);
  cat::init(myDir);
  
  {
    const std::string flag = myDir + "/.example_created";
    if (access(flag.c_str(), F_OK) != 0) {
      std::ofstream ex(myDir + "/Example.mcstructure", std::ios::binary | std::ios::trunc);
      ex.write(reinterpret_cast<const char *>(kExampleStructure), std::streamsize(kExampleStructureSize));
      std::ofstream(flag) << "1";
      if (gLog) gLog->info("example created in {}", myDir);
    }
  }
  
  if (access(myDir.c_str(), W_OK) == 0) compat::set(compat::Comp::Loading, compat::State::Ok);
  else compat::set(compat::Comp::Loading, compat::State::Failed, compat::Reason::StorageUnavailable);
  std::lock_guard<std::mutex> lk(gJobMu);
  if (gJobThread.joinable()) return;
  gJobStop = false;
  gJobThread = std::thread([] {
    for (;;) {
      std::function<void()> job;
      {
        std::unique_lock<std::mutex> l(gJobMu);
        gJobCv.wait(l, [] { return gJobStop || !gJobs.empty(); });
        if (gJobStop) return;
        job = std::move(gJobs.front());
        gJobs.pop_front();
      }
      try {
        job();
      } catch (...) {
        notify("msg.internal_error", Tone::Error);
      }
    }
  });
  
  gJobs.push_back([] {
    const std::string tmp = gMyDir + "/.parser_check.tmp";
    {
      std::ofstream ex(tmp, std::ios::binary | std::ios::trunc);
      ex.write(reinterpret_cast<const char *>(kExampleStructure), std::streamsize(kExampleStructureSize));
    }
    Structure s;
    std::string err;
    const bool ok = loadStructure(tmp, s, err) && s.sx > 0 && s.sy > 0 && s.sz > 0;
    std::remove(tmp.c_str());
    if (ok) compat::set(compat::Comp::Parser, compat::State::Ok);
    else compat::set(compat::Comp::Parser, compat::State::Failed, compat::Reason::ParseFailed, err);
  });
  gJobCv.notify_one();
}

void shutdown() {
  cat::shutdown();
  {
    std::lock_guard<std::mutex> lk(gJobMu);
    gJobStop = true;
    gJobs.clear();
  }
  gJobCv.notify_all();
  if (gJobThread.joinable()) gJobThread.detach();  
}

void postJob(std::function<void()> job) {
  {
    std::lock_guard<std::mutex> lk(gJobMu);
    if (gJobs.size() > 32) return;
    gJobs.push_back(std::move(job));
  }
  gJobCv.notify_one();
}

std::string myDir() { return gMyDir; }
std::string lastImport() {
  std::lock_guard<std::mutex> lk(gImpMu);
  return gLastImport;
}

void rescan(const std::string &selectPath) {
  postJob([selectPath] {
    std::vector<std::string> roots;
    auto list = lib::scan(gMyDir, settings().scanDownloads.load(), settings().scanPacks.load(), &roots);
    std::string info;
    for (auto &r : roots) info += (info.empty() ? "" : " | ") + r;
    const std::string notes = lib::scanNotes();
    if (!notes.empty()) info += (info.empty() ? "" : " | ") + std::string("no access: ") + notes;
    if (gLog) gLog->info("library: {} structures; com.mojang: {}", list.size(), info.empty() ? "not found" : info);
    
    if (!selectPath.empty()) {
      bool found = false;
      for (auto &e : list) found |= e.path == selectPath;
      if (!found) {
        auto sl = selectPath.rfind('/');
        std::string nm = selectPath.substr(sl == std::string::npos ? 0 : sl + 1);
        if (auto d = nm.rfind('.'); d != std::string::npos) nm.resize(d);
        list.insert(list.begin(), {nm, selectPath, "Mine"});
      }
    }
    {
      std::lock_guard<std::mutex> lk(gLibMu);
      gLib = std::move(list);
      gRoots = info;
      ++gLibRev;
    }
    if (!selectPath.empty()) select(selectPath);
  });
}

std::vector<lib::Entry> library() {
  std::lock_guard<std::mutex> lk(gLibMu);
  return gLib;
}
uint64_t libraryRevision() {
  std::lock_guard<std::mutex> lk(gLibMu);
  return gLibRev;
}
std::string rootsInfo() {
  std::lock_guard<std::mutex> lk(gLibMu);
  return gRoots;
}
std::string selectedPath() {
  std::lock_guard<std::mutex> lk(gLibMu);
  return gSelected;
}

void importFile() {
  
  
  
  const bool ok = pl::input::openDocument("*/*", [](const pl::input::DocumentResult &r) {
    if (!r.success) {
      if (!r.error.empty() && r.error != "Import cancelled") notify("msg.import_rejected", Tone::Error, 5000, r.error);
      setLastImport("cancelled/launcher error: " + (r.error.empty() ? std::string("?") : r.error));
      return;
    }
    // runs on the Android UI thread; the launcher deletes r.path as soon as this returns, so the copy is
    // synchronous. Parsing/conversion happens on the job thread.
    const std::string name = r.displayName.empty() ? "imported" : r.displayName;
    std::string ext;  // keeps the extension so the loader tries the right byte order first
    if (const auto d = name.rfind('.'); d != std::string::npos && name.size() - d <= 12)
      for (char c : name.substr(d)) ext.push_back((c == '/' || c == '\\') ? '_' : char(std::tolower(uint8_t(c))));
    mkdirs(gMyDir);
    const std::string tmp = gMyDir + "/.importing_" + std::to_string(nowMs()) + ext;
    bool writeOk = false;
    {
      std::ifstream in(r.path, std::ios::binary);
      std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
      if (!in || !out) {
        notify("msg.file_unreadable", Tone::Error);
        setLastImport(std::string("copy failed (") + (in ? "dest " + tmp : "source " + r.path) + ")");
        if (gLog) gLog->error("import: copy failed {} -> {}", r.path, tmp);
        return;
      }
      out << in.rdbuf();
      writeOk = bool(out);
    }  // stream closed here
    if (!writeOk) {
      std::remove(tmp.c_str());
      notify("msg.file_unreadable", Tone::Error);
      setLastImport("copy failed (write " + tmp + ")");
      return;
    }
    if (gLog) gLog->info("import: '{}' copied from {}", name, r.path);
    postJob([tmp, name] {
      std::string err;
      const std::string dst = lib::importFile(tmp, name, gMyDir, err);
      std::remove(tmp.c_str());
      if (dst.empty()) {
        const char *key = loadErrorKey(err);
        if (std::strcmp(key, "ui.invalid_structure") == 0) {
          std::string why = err;
          if (why.compare(0, 14, "invalid file: ") == 0) why.erase(0, 14);
          notify("msg.import_rejected", Tone::Error, 5000, why);
        } else {
          notify(key, Tone::Error, 4000);
        }
        setLastImport("'" + name + "' rejected: " + err);
        if (gLog) gLog->warn("import '{}' failed: {}", name, err);
        return;
      }
      notify("msg.imported", Tone::Success);
      setLastImport("'" + name + "' OK -> " + dst);
      rescan(dst);
    });
  });
  if (!ok) notify("msg.picker_unavailable", Tone::Error);
}

void removeSelected() { removeFile(selectedPath()); }

void removeFile(const std::string &path) {
  if (path.empty()) return;
  postJob([path] {
    const std::string nm = titleOf(path);
    if (std::remove(path.c_str()) != 0) {
      notify("msg.cant_delete", Tone::Error, 3000, nm);
      if (gLog) gLog->warn("delete {} failed", path);
      return;
    }
    bool wasOpen;
    {
      std::lock_guard<std::mutex> lk(gLibMu);
      wasOpen = gSelected == path;
      if (wasOpen) gSelected.clear();
    }
    if (wasOpen) {
      auto &m = model();
      std::lock_guard<std::mutex> lk(m.mu);
      m.structure.reset();
      m.previewFaces.reset();
      m.compare.reset();
      m.placed = false;
      m.wantPlace = false;
      changed(m);
    }
    if (wasOpen) {
      ep::startRun(0);  // no structure: stop a run, drop the queue
      xf::clear();      // release the transformed-state tables of the closed structure
    }
    cat::removed(path);
    notify("msg.deleted", Tone::Success);
    if (gLog) gLog->info("deleted {}", path);
    rescan();
  });
}

void renameFile(const std::string &path, const std::string &newTitle) {
  postJob([path, newTitle] {
    std::string clean;
    for (char c : newTitle) {
      if (c == '\n' || c == '\r' || c == '\t') c = ' ';
      clean.push_back((c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' ||
                       c == '>' || c == '|') ? '_' : c);
    }
    while (!clean.empty() && clean.back() == ' ') clean.pop_back();
    while (!clean.empty() && (clean.front() == ' ' || clean.front() == '.')) clean.erase(0, 1);
    if (clean.size() > 120) clean.resize(120);
    if (clean.empty()) {
      notify("msg.name_empty", Tone::Warning);
      return;
    }
    const auto sl = path.rfind('/');
    const std::string dir = sl == std::string::npos ? "." : path.substr(0, sl);
    const std::string dst = dir + "/" + clean + extOf(path);
    if (dst == path) return;
    if (access(dst.c_str(), F_OK) == 0) {
      notify("msg.name_taken", Tone::Warning, 3000);
      return;
    }
    if (std::rename(path.c_str(), dst.c_str()) != 0) {
      notify("msg.rename_failed", Tone::Error);
      if (gLog) gLog->warn("rename {} -> {} failed", path, dst);
      return;
    }
    {
      std::lock_guard<std::mutex> lk(gLibMu);
      if (gSelected == path) gSelected = dst;
    }
    cat::renamed(path, dst);
    notify("msg.renamed", Tone::Success, 2500, clean);
    if (gLog) gLog->info("renamed {} -> {}", path, dst);
    rescan();
  });
}

void setExportDir(const std::string &dir) { gExportDir = dir; }

void exportFile(const std::string &path) {
  postJob([path] {
    mkdirs(gExportDir);
    const std::string dst = lib::uniquePath(gExportDir, titleOf(path), extOf(path));
    if (!copyFile(path, dst)) {
      std::remove(dst.c_str());
      notify("msg.export_failed", Tone::Error);
      if (gLog) gLog->warn("export {} -> {} failed", path, dst);
      return;
    }
    notify("msg.exported", Tone::Success, 3000);
    if (gLog) gLog->info("exported {} -> {}", path, dst);
    rescan();
  });
}

bool canModify(const lib::Entry &e) {
  return e.source == "Mine" || e.source == "Download" || e.source == "Documents";
}

namespace {
// Load pipeline bookkeeping (job thread writes, UI reads under hs::load().mu).
void loadStage(hs::Stage st, hs::SSt v) {
  auto &L = hs::load();
  std::lock_guard<std::mutex> lk(L.mu);
  L.st[int(st)] = int(v);
  L.at[int(st)] = hs::monoMs();
}
void loadFail(uint64_t seq, hs::Stage st, hs::LoadErr e, const std::string &raw) {
  auto &L = hs::load();
  std::lock_guard<std::mutex> lk(L.mu);
  if (L.seq != seq) return;
  L.busy = false;
  L.err = e;
  L.error = raw;
  L.failedStage = int(st);
  L.st[int(st)] = int(e == hs::LoadErr::Cancelled ? hs::SSt::Cancelled : hs::SSt::Failed);
  L.at[int(st)] = hs::monoMs();
  for (int i = int(st) + 1; i <= int(hs::Stage::Transform); ++i) L.st[i] = int(hs::SSt::Skipped);
  L.endedMs = hs::monoMs();
}
// gzip ISIZE trailer = uncompressed size mod 2^32 (enough for the 200 MB file cap).
uint64_t fileSizes(const std::string &path, uint64_t &raw) {
  raw = 0;
  FILE *f = std::fopen(path.c_str(), "rb");
  if (!f) return 0;
  std::fseek(f, 0, SEEK_END);
  const long n = std::ftell(f);
  uint8_t hd[2]{};
  std::fseek(f, 0, SEEK_SET);
  const bool gz = n > 18 && std::fread(hd, 1, 2, f) == 2 && hd[0] == 0x1F && hd[1] == 0x8B;
  raw = n > 0 ? uint64_t(n) : 0;
  if (gz) {
    uint8_t t[4]{};
    std::fseek(f, n - 4, SEEK_SET);
    if (std::fread(t, 1, 4, f) == 4) raw = uint64_t(t[0]) | uint64_t(t[1]) << 8 | uint64_t(t[2]) << 16 | uint64_t(t[3]) << 24;
  }
  std::fclose(f);
  return n > 0 ? uint64_t(n) : 0;
}
}  // namespace

void select(const std::string &path) {
  // Every request gets a sequence number; an older job that finishes later is discarded.
  const uint64_t seq = hs::loadSeq().fetch_add(1) + 1;
  {
    auto &L = hs::load();
    std::lock_guard<std::mutex> lk(L.mu);
    const uint64_t keepSeq = seq;
    L.seq = keepSeq;
    L.busy = true;
    L.path = path;
    L.title = titleOf(path);
    L.error.clear();
    L.detail.clear();
    L.err = hs::LoadErr::None;
    L.failedStage = -1;
    L.startedMs = hs::monoMs();
    L.endedMs = 0;
    L.fileBytes = L.rawBytes = L.memEstimate = L.memAvail = 0;
    L.sx = L.sy = L.sz = 0;
    L.palette = L.indices = L.solid = L.air = L.voids = L.variants = 0;
    L.indicesType.clear();
    for (int i = 0; i < hs::kStageCount; ++i) { L.st[i] = int(hs::SSt::Pending); L.at[i] = 0; }
  }
  hs::loadBusy().fetch_add(1);
  postJob([path, seq] {
    struct BusyGuard {
      ~BusyGuard() { hs::loadBusy().fetch_sub(1); }
    } busyGuard;
    auto stale = [&] { return hs::loadSeq().load() != seq; };
    if (stale()) { loadFail(seq, hs::Stage::Open, hs::LoadErr::Cancelled, "replaced by a newer request"); return; }
    loadStage(hs::Stage::Open, hs::SSt::Running);
    // Memory guard: estimate the parser peak (file + inflated NBT + int64 index lists + structure arrays).
    uint64_t raw = 0;
    const uint64_t fileBytes = fileSizes(path, raw);
    const uint64_t estimate = fileBytes + raw + raw * 2 + raw / 2 + (8u << 20);
    const uint64_t avail = hs::memAvailable();
    {
      auto &L = hs::load();
      std::lock_guard<std::mutex> lk(L.mu);
      if (L.seq == seq) { L.fileBytes = fileBytes; L.rawBytes = raw; L.memEstimate = estimate; L.memAvail = avail; }
    }
    if (avail && estimate > avail / 10 * 7) {
      char d[96];
      std::snprintf(d, sizeof(d), "needs ~%llu MB, available %llu MB", (unsigned long long)(estimate >> 20),
                    (unsigned long long)(avail >> 20));
      loadFail(seq, hs::Stage::Open, hs::LoadErr::MemoryLimit, d);
      notify("msg.structure_memory", Tone::Error, 4500);
      if (gLog) gLog->warn("open refused {}: memory limit ({})", path, d);
      return;
    }
    auto s = std::make_shared<Structure>();
    std::string err;
    LoadInfo info;
    const int64_t t0 = hs::monoMs();
    const bool ok = loadStructure(path, *s, err, &info);
    if (gLog) gLog->info("load {}: {} ({} ms)", path, info.describe(), hs::monoMs() - t0);
    if (gLog) gLog->info("load {}: {}", path, info.statesLine());
    {
      auto &L = hs::load();
      std::lock_guard<std::mutex> lk(L.mu);
      if (L.seq == seq) {
        L.sx = info.sx; L.sy = info.sy; L.sz = info.sz;
        L.palette = info.paletteSize; L.indices = info.indexCount; L.solid = info.solidCount;
        L.air = info.airCount; L.voids = info.voidCount; L.indicesType = info.indicesType;
        L.variants = ok ? s->variants.size() : 0;
        L.stOk = info.variantsOk; L.stDirectional = info.variantsDirectional; L.stMulti = info.variantsMulti;
        L.stUnknown = info.variantsUnknown; L.stDiscarded = info.discardedStates;
        L.stDiscardedVariants = info.discardedVariants; L.stWaterlogged = info.waterlogged;
        L.stBlockEntities = info.blockEntities; L.stUnknownKeys = info.unknownKeys;
        L.stPreserved = info.preservedStates; L.stRaw = info.rawStates;
        L.stDiscardedKeys = info.discardedKeys;
      }
    }
    if (!ok) {
      hs::Stage failed = hs::Stage::Nbt;
      const hs::LoadErr e = hs::classifyLoadError(err, failed);
      {
        auto &L = hs::load();
        std::lock_guard<std::mutex> lk(L.mu);
        if (L.seq == seq)
          for (int i = int(hs::Stage::Open); i < int(failed); ++i) L.st[i] = int(hs::SSt::Ok);
      }
      loadFail(seq, failed, e, err);
      if (!stale()) notify(loadErrorKey(err), Tone::Error, 3500);
      if (gLog) gLog->warn("open failed {}: {} (stage: {})", path, err, hs::stageName(failed));
      return;
    }
    for (hs::Stage st : {hs::Stage::Open, hs::Stage::Nbt, hs::Stage::Dimensions, hs::Stage::Palette,
                         hs::Stage::Indices, hs::Stage::CountSolid})
      loadStage(st, hs::SSt::Ok);
    if (stale()) { loadFail(seq, hs::Stage::Transform, hs::LoadErr::Cancelled, "replaced by a newer request"); return; }
    loadStage(hs::Stage::Transform, hs::SSt::Running);
    ep::setStep("select: preview faces");
    auto faces = std::make_shared<std::vector<PreviewFace>>(buildPreviewFaces(*s));
    if (stale()) { loadFail(seq, hs::Stage::Transform, hs::LoadErr::Cancelled, "replaced by a newer request"); return; }
    {
      std::lock_guard<std::mutex> lk(gLibMu);
      gSelected = path;
    }
    ep::setStep("select: model update");
    cat::touchRecent(path);
    auto &m = model();
    int x, y, z;
    const bool hasFeet = feet(x, y, z);
    {
      std::lock_guard<std::mutex> lk(m.mu);
      m.structure = s;
      m.previewFaces = faces;
      m.layer = 0;
      m.layer2 = 0;
      // last selected layer (overlay) is restored when it fits the new structure
      if (const int ov = settings().ovLayer.load(std::memory_order_relaxed); ov >= 0 && ov < layerSizeLocked(m))
        m.layer = ov;
      m.placement = Placement{};
      m.placed = false;
      m.compare.reset();
      m.wantPlace = !hasFeet;  // placed automatically once the world and player are valid
      if (hasFeet) placeInFrontLocked(m, x, y, z);  
      changed(m);
    }
    ep::setStep("select: run/transform reset");
    ep::startRun(0);
    xf::clear();  // old structure's tables; the new one is built on the next poll
    loadStage(hs::Stage::Transform, hs::SSt::Ok);
    {
      auto &L = hs::load();
      std::lock_guard<std::mutex> lk(L.mu);
      if (L.seq == seq) { L.busy = false; L.endedMs = hs::monoMs(); }
    }
    char buf[160];
    std::snprintf(buf, sizeof(buf), "%s: %dx%dx%d, %u blocks", s->title.c_str(), s->sx, s->sy, s->sz, s->solidCount);
    if (!hasFeet) notify("msg.place_when_ready", Tone::Info, 3500);
    else notify("ui.structure_loaded", Tone::Success, 1800);
    ep::setStep("select: done");
    if (gLog) gLog->info("selected {} ({})", path, buf);
  });
}

void placeHere() {
  int x, y, z;
  if (!feet(x, y, z)) { notify("msg.join_world", Tone::Warning); return; }
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.structure) { notify("ui.no_structure_loaded", Tone::Warning); return; }
  m.placement.ox = x; m.placement.oy = y; m.placement.oz = z;
  m.placed = true;
  changed(m);
}

void facing(int &fx, int &fz) {
  
  const int k = ((int(std::lround(status().yaw.load() / 90.f)) % 4) + 4) % 4;
  static const int f[4][2] = {{0, 1}, {-1, 0}, {0, -1}, {1, 0}};
  fx = f[k][0];
  fz = f[k][1];
}

void placeInFront() {
  int x, y, z;
  if (!feet(x, y, z)) { notify("msg.join_world", Tone::Warning); return; }
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.structure) { notify("ui.no_structure_loaded", Tone::Warning); return; }
  placeInFrontLocked(m, x, y, z);
}

void moveRel(int fwd, int right, int up) {
  int fx, fz;
  facing(fx, fz);
  const int rx = -fz, rz = fx;  
  nudge(fx * fwd + rx * right, up, fz * fwd + rz * right);
}

void nudge(int dx, int dy, int dz) {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.placed) return;
  m.placement.ox += dx; m.placement.oy += dy; m.placement.oz += dz;
  changed(m);
}

void rotate() {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.placed) return;
  m.placement.rot = (m.placement.rot + 1) & 3;
  changed(m);
}

void mirror() {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.placed) return;
  m.placement.mirror = !m.placement.mirror;
  changed(m);
}

void rotateLeft() {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.placed) return;
  m.placement.rot = (m.placement.rot + 3) & 3;
  changed(m);
}


int layerSizeLocked(const Model &m) {
  if (!m.structure) return 1;
  int dx, dz;
  rotatedSize(*m.structure, m.placement.rot, dx, dz);
  const int a = settings().layerAxis.load();
  return std::max(1, a == 0 ? dx : a == 1 ? m.structure->sy : dz);
}

int layerSize() {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  return layerSizeLocked(m);
}

namespace {
// Any change of the visible layers: Easy Place drops its queue / pending turn (never places), a running
// layer/visible run pauses until the player resumes it deliberately. Runs after the model lock is released.
struct LayerChange {
  ~LayerChange() {
    ep::invalidate("layer changed");
    if (ep::runScope() != 0) ep::pause();
    auto &m = model();
    std::lock_guard<std::mutex> lk(m.mu);
    settings().ovLayer.store(m.layer, std::memory_order_relaxed);
  }
};
}  // namespace

void setLayer(int index) {
  LayerChange lc;
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.structure) return;
  m.layer = std::clamp(index, 0, layerSizeLocked(m) - 1);
  if (settings().layerMode.load() == int(LayerMode::All)) settings().layerMode.store(int(LayerMode::Only));
}

void setLayerMode(int mode) {
  LayerChange lc;
  settings().layerMode.store(std::clamp(mode, 0, 4));
}

int currentLayer() {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  return m.structure ? std::clamp(m.layer, 0, std::max(0, layerSizeLocked(m) - 1)) : 0;
}

void layerDelta(int d) {
  LayerChange lc;
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.structure) return;
  m.layer = std::clamp(m.layer + d, 0, layerSizeLocked(m) - 1);
  if (settings().layerMode.load() == int(LayerMode::All)) settings().layerMode.store(int(LayerMode::Only));
}

void layer2Delta(int d) {
  LayerChange lc;
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.structure) return;
  m.layer2 = std::clamp(m.layer2 + d, 0, layerSizeLocked(m) - 1);
}

void cycleLayerMode() {
  LayerChange lc;
  auto &s = settings();
  s.layerMode.store((s.layerMode.load() + 1) % 5);
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (s.layerMode.load() == int(LayerMode::Range) && m.layer2 == m.layer)
    m.layer2 = std::min(m.layer + 4, layerSizeLocked(m) - 1);
}

void cycleLayerAxis() {
  LayerChange lc;
  auto &s = settings();
  s.layerAxis.store((s.layerAxis.load() + 1) % 3);
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  const int n = layerSizeLocked(m);
  m.layer = std::clamp(m.layer, 0, n - 1);
  m.layer2 = std::clamp(m.layer2, 0, n - 1);
}

void setLayerToFeet() {
  int x, y, z;
  if (!feet(x, y, z)) return;
  LayerChange lc;
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.structure || !m.placed) return;
  const int a = settings().layerAxis.load();
  const int v = a == 0 ? x - m.placement.ox : a == 1 ? y - m.placement.oy : z - m.placement.oz;
  m.layer = std::clamp(v, 0, layerSizeLocked(m) - 1);
  if (settings().layerMode.load() == int(LayerMode::All)) settings().layerMode.store(int(LayerMode::Only));
}

void cornerHere(int which) {
  int x, y, z;
  if (!feet(x, y, z)) { notify("msg.join_world", Tone::Warning); return; }
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (which == 0) { m.ax = x; m.ay = y; m.az = z; m.cornerA = true; }
  else { m.bx = x; m.by = y; m.bz = z; m.cornerB = true; }
  m.syncFlags();
}

void cornersY(int d) {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (m.cornerA) m.ay += d;
  if (m.cornerB) m.by += d;
}

void clearCorners() {
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  m.cornerA = m.cornerB = false;
  m.syncFlags();
}

void capture() {
  auto &m = model();
  {
    std::lock_guard<std::mutex> lk(m.mu);
    if (!m.cornerA || !m.cornerB) { notify("msg.set_corners", Tone::Warning); return; }
    const int64_t vol = int64_t(std::abs(m.ax - m.bx) + 1) * (std::abs(m.ay - m.by) + 1) * (std::abs(m.az - m.bz) + 1);
    if (vol > 2000000) { notify("msg.area_too_large", Tone::Error); return; }
  }
  if (status().namesState.load() != 1) {
    notify(status().namesState.load() < 0 ? "msg.capture_unavailable" : "msg.not_ready", Tone::Warning);
    return;
  }
  if (status().captureProgress.load() >= 0) return;
  status().captureRequest.store(true);
}

namespace {
// UI thread: deferred placement + compare buffer allocation (kept off the render thread).
void lifecyclePoll() {
  auto &m = model();
  auto &r = hs::rt();
  if (m.pendingPlace.load(std::memory_order_acquire) && r.worldValid.load(std::memory_order_relaxed) &&
      r.stableFrames.load(std::memory_order_relaxed) >= 10) {
    int x, y, z;
    if (feet(x, y, z)) {
      bool placed = false;
      {
        std::lock_guard<std::mutex> lk(m.mu);
        if (m.wantPlace && m.structure && !m.placed) {
          m.wantPlace = false;
          placeInFrontLocked(m, x, y, z);
          placed = true;
        }
      }
      if (placed) {
        notify("ui.structure_loaded", Tone::Success, 1800);
        if (gLog) gLog->info("structure placed after the world became ready ({} {} {})", x, y, z);
      }
    }
  }
  uint64_t gen = 0, epoch = r.worldEpoch.load(std::memory_order_relaxed);
  std::shared_ptr<const Structure> sp, cur;
  Placement pl;
  {
    std::lock_guard<std::mutex> lk(m.mu);
    cur = m.structure;
    pl = m.placement;
    if (m.structure && m.placed && (!m.compare || m.compare->gen != m.gen || m.compare->epoch != epoch)) {
      gen = m.gen;
      sp = m.structure;
    }
  }
  // Shared transformed states for the current rotation/mirror: built here (UI thread) so the render thread
  // only ever reads a finished table (xf::peek) and Easy Place gets the same one.
  const auto xt = cur ? xf::get(cur, pl.rot & 3, pl.mirror) : nullptr;
  if (!sp) return;
  auto c = progress::create(gen, epoch, sp, xt.get());
  std::lock_guard<std::mutex> lk(m.mu);
  if (m.structure == sp && m.gen == gen) m.compare = std::move(c);
}
}  // namespace

void poll() {
  lifecyclePoll();
  const std::string e = holo::captureError();
  if (!e.empty()) {  
    if (gLog) gLog->warn("capture: {}", e);
    notify(e == "Not ready, try again" ? "msg.not_ready" : "msg.capture_failed", Tone::Warning);
  }
  holo::CaptureResult r;
  if (!holo::takeCapture(r)) return;
  
  {
    size_t solid = 0;
    for (int32_t i : r.indices)
      if (i >= 0 && size_t(i) < r.names.size() && r.names[size_t(i)] != "minecraft:air") { ++solid; break; }
    if (!solid) {
      notify("msg.area_empty", Tone::Warning);
      return;
    }
  }
  postJob([r = std::move(r)]() mutable {
    char name[64];
    const std::time_t t = std::time(nullptr);
    std::tm tm{};
    localtime_r(&t, &tm);
    std::strftime(name, sizeof(name), "capture_%Y%m%d_%H%M%S", &tm);
    const std::string path = lib::uniquePath(gMyDir, name, ".mcstructure");
    std::string err;
    if (!saveStructure(path, r.sx, r.sy, r.sz, r.names, r.indices, r.ox, r.oy, r.oz, err)) {
      if (gLog) gLog->warn("capture save failed: {}", err);
      notify("msg.save_failed", Tone::Error);
      return;
    }
    notify("msg.saved", Tone::Success, 3000, name);
    if (gLog) gLog->info("capture saved to {}", path);
    rescan(path);
  });
}

}  
}  
