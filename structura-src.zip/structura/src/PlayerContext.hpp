#pragma once
// Player context: who/where the local player is, published by whichever validated source is alive.
//
// Sources, in priority order:
//   1. ClientInstance::update  (every client frame, also in menus; may report "no player")
//   2. GameMode::tick / SurvivalMode::tick, only when GameMode::mPlayer is the LOCAL player
//      (vtable == LocalPlayer vtable proven through RTTI; server-side players are rejected)
//   3. LocalPlayer::normalTick (the function is only referenced from the LocalPlayer vtable)
// The render path (renderLevel) consumes the context; it never produces a player.
//
// Hot path rules: publish*() run inside game ticks. They are lock-free, allocate nothing and do a
// handful of reads. Readers (render thread, UI thread, Easy Place) only see atomics.
#include <atomic>
#include <cstdint>
#include <string>

namespace lm::ctx {

enum class Source : int { None = 0, UpdateHook, GameModeTick, LocalPlayerTick, Count };
constexpr int kSources = int(Source::Count);

// A source that ticks at 20 Hz publishes every ~50 ms; allow lag spikes before calling it stale.
constexpr int64_t kFreshMs = 400;

enum class Reject : int { None = 0, NullObject, BadPointer, NotLocalPlayer, NoLocalPlayerVtable, BadPosition, Count };

const char *sourceName(Source s);  // English, for logs/diagnostic text
const char *sourceKey(Source s);   // i18n key
const char *rejectName(Reject r);

int64_t monoMs();

// ---- install time (watcher thread)
void setInstalled(Source s, bool installed, const std::string &detail = {});
bool installed(Source s);
bool anySource();                  // at least one validated source is hooked
std::string detail(Source s);      // why a source is unavailable / how it was validated
void setLocalPlayerVtable(uintptr_t vt);
uintptr_t localPlayerVtable();
// GameMode classes accepted as tick objects (primary vtables proven through RTTI).
void setGameModeVtables(uintptr_t gameMode, uintptr_t survivalMode);

// ---- hot path (game threads)
// ClientInstance::update: `player` comes from ClientInstance::getLocalPlayer (0 in menus).
void publishUpdate(uintptr_t ci, uintptr_t player);
// GameMode tick: `gm` is the tick object. Returns true when it carried the local player and the
// context was refreshed from it.
bool publishGameMode(uintptr_t gm, uintptr_t playerOffset);
// LocalPlayer::normalTick: `player` is `this`.
bool publishLocalPlayer(uintptr_t player);
// True while the ClientInstance::update source is hooked and alive: tick sources then only observe.
bool updateAlive(int64_t now);
bool isLocalPlayer(uintptr_t player);

// ---- readers
struct View {
  Source source = Source::None;   // source of the last accepted publication
  uintptr_t player = 0, ci = 0, dim = 0;
  float pos[3] = {0, 0, 0};       // eye position (state vector)
  float pitch = 0, yaw = 0;
  int64_t at = 0;                 // monotonic ms of the last accepted publication (0 = never)
  uint64_t generation = 0;        // bumps on every player/dimension identity change or invalidation
  bool fresh = false;             // at > 0 and now - at <= kFreshMs
};
View view(int64_t now);
bool fresh(int64_t now);
uint64_t generation();

// Render thread: the context went stale and the render context changed since it was last fresh (world
// left, client reloaded...). Clears the published player unless a tick already replaced it.
void dropStale(uintptr_t expectedPlayer, const char *why);
// Any thread: forget the context (world/dimension change detected elsewhere).
void invalidate(const char *why);

// Render-side use of the context. A fresh context is remembered with the render context that saw it;
// a quiet (stale) context is only trusted in that same render context and generation, otherwise it is
// dropped (world left / client reloaded while the source was silent).
struct RenderMemo {
  uintptr_t lr = 0, lrp = 0, player = 0;
  uint64_t generation = 0;
};
enum class RenderUse : int { None = 0, Fresh, Stale, Drop };
RenderUse renderUse(const View &v, bool anySource, uintptr_t lr, uintptr_t lrp, RenderMemo &memo);

struct Stats {
  uint64_t accepted[kSources] = {};
  uint64_t observed[kSources] = {};  // seen while a higher-priority source was alive
  uint64_t rejected[kSources] = {};
  int64_t seenAt[kSources] = {};
  Reject lastReject[kSources] = {};
  uint64_t drops = 0;
  std::string lastDrop;
};
Stats stats();

void resetForTest();
void setClockForTest(int64_t (*clock)());  // nullptr restores CLOCK_MONOTONIC

}  // namespace lm::ctx
