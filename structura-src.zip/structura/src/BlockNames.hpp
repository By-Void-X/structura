#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace lm::names {



bool discover(uintptr_t air, const std::vector<uintptr_t> &others);
bool ready();

const std::string *nameOf(uintptr_t block);
std::string describe();
// Drops the Block* -> name cache (Block pointers are per world). Thread-safe.
void invalidate();  

}  
