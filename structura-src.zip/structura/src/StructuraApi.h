#pragma once

#include <stdint.h>

#define STRUCTURA_API_VERSION 1u

#ifdef __cplusplus
extern "C" {
#endif

struct StructuraApiV1 {
  uint32_t version;  
  uint32_t size;     

  
  
  int (*expectedAt)(int x, int y, int z, uintptr_t *outBlock);

  
  
  int (*placeTarget)(int *x, int *y, int *z);

  
  
  int (*orientMatch)(int x, int y, int z, uintptr_t candidate);

  
  uintptr_t (*worldBlock)(int x, int y, int z);

  
  int (*blockName)(uintptr_t block, char *buf, int len);

  
  int (*expectedName)(int x, int y, int z, char *buf, int len);

  
  int64_t (*stateValue)(uintptr_t block, const char *key);
};

#ifdef __cplusplus
}
#endif
