#pragma once
#include <cstdint>
#include <vector>

#include "Structure.hpp"

namespace lm {


struct PreviewFace {
  int16_t x, y, z;
  uint8_t dir;      
  uint32_t color;   
};
std::vector<PreviewFace> buildPreviewFaces(const Structure &s, size_t maxFaces = 600000);


void renderPreview(const Structure &s, const std::vector<PreviewFace> &faces, float yawDeg, float pitchDeg, int w,
                   int h, std::vector<uint8_t> &rgba);

}  
