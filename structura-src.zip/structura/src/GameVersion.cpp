#include "GameVersion.hpp"

#include <cctype>
#include <cstdio>

namespace lm::ver {
namespace {

bool isDigit(char c) { return c >= '0' && c <= '9'; }
char lowerAscii(char c) { return (c >= 'A' && c <= 'Z') ? char(c - 'A' + 'a') : c; }

bool startsWithNoCase(std::string_view s, std::string_view p) {
  if (s.size() < p.size()) return false;
  for (size_t i = 0; i < p.size(); ++i)
    if (lowerAscii(s[i]) != p[i]) return false;
  return true;
}


bool parseChannel(std::string_view s, GameVersion &v) {
  struct Word { std::string_view w; Channel c; };
  static constexpr Word kWords[] = {
      {"release candidate", Channel::ReleaseCandidate}, {"rc", Channel::ReleaseCandidate},
      {"preview", Channel::Preview}, {"beta", Channel::Beta}, {"stable", Channel::Stable},
      {"release", Channel::Stable},
  };
  for (const auto &w : kWords) {
    if (!startsWithNoCase(s, w.w)) continue;
    std::string_view rest = s.substr(w.w.size());
    while (!rest.empty() && (rest.front() == ' ' || rest.front() == '_' || rest.front() == '-' || rest.front() == '.'))
      rest.remove_prefix(1);
    int n = 0, digits = 0;
    while (!rest.empty() && isDigit(rest.front()) && digits < 4) {
      n = n * 10 + (rest.front() - '0');
      rest.remove_prefix(1);
      ++digits;
    }
    if (!rest.empty()) return false;  
    v.channel = w.c;
    v.channelNumber = n;
    return true;
  }
  return false;
}

}  

bool parse(std::string_view text, GameVersion &out) {
  out = GameVersion{};
  std::string_view s = text;
  while (!s.empty() && (s.front() == ' ' || s.front() == 'v' || s.front() == 'V')) s.remove_prefix(1);
  while (!s.empty() && (s.back() == ' ' || s.back() == '\0' || s.back() == '\n' || s.back() == '\r')) s.remove_suffix(1);
  if (s.empty()) return false;

  long nums[4] = {0, 0, 0, 0};
  int parts = 0;
  size_t i = 0;
  while (parts < 4) {
    size_t d0 = i;
    long n = 0;
    while (i < s.size() && isDigit(s[i]) && i - d0 < 6) n = n * 10 + (s[i++] - '0');
    if (i == d0) return false;
    if (i < s.size() && isDigit(s[i])) return false;  
    nums[parts++] = n;
    if (i < s.size() && s[i] == '.' && i + 1 < s.size() && isDigit(s[i + 1]) && parts < 4) { ++i; continue; }
    break;
  }
  if (parts < 3) return false;

  GameVersion v;
  v.parts = parts;
  v.raw = std::string(text);
  if (nums[0] == 1 && parts == 4) {
    v.major = 1; v.minor = int(nums[1]); v.patch = int(nums[2]); v.build = int(nums[3]);
  } else if (nums[0] == 1 && parts == 3) {
    v.major = 1; v.minor = int(nums[1]); v.patch = int(nums[2]); v.build = 0;
  } else if (nums[0] >= 20 && nums[0] <= 99 && parts == 3) {  
    v.major = 1; v.minor = int(nums[0]); v.patch = int(nums[1]); v.build = int(nums[2]);
  } else if (nums[0] >= 20 && nums[0] <= 99 && parts == 4) {  
    v.major = 1; v.minor = int(nums[0]); v.patch = int(nums[1]); v.build = int(nums[2]);
  } else {
    return false;
  }

  std::string_view rest = s.substr(i);
  if (!rest.empty()) {
    const char sep = rest.front();
    if (sep != '_' && sep != '-' && sep != ' ') return false;
    while (!rest.empty() && (rest.front() == '_' || rest.front() == '-' || rest.front() == ' ')) rest.remove_prefix(1);
    if (rest.empty() || !parseChannel(rest, v)) return false;
  } else {
    
    v.channel = v.build >= 20 ? Channel::Preview : Channel::Stable;
    v.channelFromBuild = true;
  }
  v.is_release_candidate = v.channel == Channel::ReleaseCandidate;
  v.is_preview = v.channel == Channel::Preview || v.channel == Channel::Beta;
  out = std::move(v);
  return true;
}

std::string normalized(const GameVersion &v) {
  if (!v.valid()) return {};
  char b[64];
  std::snprintf(b, sizeof(b), "%d.%d.%d.%d", v.major, v.minor, v.patch, v.build);
  std::string s = b;
  if (!v.channelFromBuild) {
    switch (v.channel) {
      case Channel::ReleaseCandidate: s += " RC"; break;
      case Channel::Preview: s += " Preview"; break;
      case Channel::Beta: s += " Beta"; break;
      default: return s;
    }
    if (v.channelNumber > 0) s += std::to_string(v.channelNumber);
  }
  return s;
}

int compare(const GameVersion &a, const GameVersion &b) {
  const int x[4] = {a.major, a.minor, a.patch, a.build}, y[4] = {b.major, b.minor, b.patch, b.build};
  for (int i = 0; i < 4; ++i)
    if (x[i] != y[i]) return x[i] < y[i] ? -1 : 1;
  return 0;
}

bool sameRelease(const GameVersion &a, const GameVersion &b) {
  return a.valid() && b.valid() && a.major == b.major && a.minor == b.minor && a.patch == b.patch;
}

const char *channelName(Channel c) {
  switch (c) {
    case Channel::Stable: return "stable";
    case Channel::ReleaseCandidate: return "release candidate";
    case Channel::Preview: return "preview";
    case Channel::Beta: return "beta";
    default: return "unknown";
  }
}

}  
