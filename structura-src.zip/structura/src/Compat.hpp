#pragma once



#include <string>

#include "GameVersion.hpp"

namespace lm::compat {

enum class Comp : int {
  Gui = 0,       
  Parser,        
  Loading,       
  Versions,      
  PlayerUpdate,  
  Rendering,     
  Verification,  
  Placement,     
  PlayerContext,  // which validated source provides the local player (update hook or fallback tick)
  Hologram,       // hologram capability: render hook + a player context source
  Count
};
inline constexpr int kCount = int(Comp::Count);

enum class State : int { Pending = 0, Ok, Limited, Failed, Unavailable };

enum class Reason : int {
  None = 0,
  BuildNotTested,       
  VersionUnknown,       
  LibraryNotFound,      
  AbiIncompatible,      
  SignatureNotFound,    
  SignatureAmbiguous,   
  ValidationFailed,     
  HookRejected,         
  ChainedOtherMod,      
  NeedsPlayerUpdate,    
  TexturesMissing,      
  PlacementNotValidated,
  StorageUnavailable,
  ParseFailed,
  MenuRejected,
  NotRequired,      // optional source unavailable, another validated source covers it
  NoContextSource,  // no validated player context source at all
  Count
};

struct Entry {
  State state = State::Pending;
  Reason reason = Reason::None;
  std::string detail;  
};

void set(Comp c, State s, Reason r = Reason::None, const std::string &detail = {});
Entry get(Comp c);
unsigned revision();  
void resetGame();  

enum class Level : int { Starting = 0, Full, Partial, Unavailable };
Level level();

struct Env {
  ver::GameVersion mc;      
  std::string buildId;      
  bool tested = false;      
  std::string launcher;     
  std::string abi;          
  std::string deviceAbi;    
  int androidApi = 0;
  std::string rule;         
};
void setEnv(const Env &e);
Env env();


const char *compKey(Comp c);
const char *stateKey(State s);
const char *levelKey(Level l);
const char *reasonKey(Reason r);
const char *actionKey(Reason r);  

const char *compName(Comp c);
const char *stateName(State s);
const char *reasonName(Reason r);
const char *levelName(Level l);


std::string diagnosticText(const std::string &modVersion, const std::string &signatureLines);

}  
