#pragma once



#include <cstdint>
#include <functional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

#include <pl/ModMenu.hpp>

#include "Theme.hpp"

namespace lm::ui::kit {

struct Rect {
  float x = 0, y = 0, w = 0, h = 0;
  float r() const { return x + w; }
  float b() const { return y + h; }
  float cx() const { return x + w * 0.5f; }
  float cy() const { return y + h * 0.5f; }
  bool empty() const { return w <= 0 || h <= 0; }
  bool contains(float px, float py) const { return !empty() && px >= x && py >= y && px < x + w && py < y + h; }
  Rect inset(float d) const { return {x + d, y + d, w - 2 * d, h - 2 * d}; }
  Rect inset(float dx, float dy) const { return {x + dx, y + dy, w - 2 * dx, h - 2 * dy}; }
  Rect intersect(const Rect &o) const;
  
  Rect takeLeft(float v, float gap = 0);
  Rect takeRight(float v, float gap = 0);
  Rect takeTop(float v, float gap = 0);
  Rect takeBottom(float v, float gap = 0);
};

enum class Tone : int { Info = 0, Success, Warning, Error, Neutral, Loading };
uint32_t toneColor(Tone t);
uint32_t toneSoft(Tone t);


struct Metrics {
  float dp = 1;        
  float dev = 1;       
  bool compact = false;
  float row, header, tab, pad, gap, section, radius, radiusPanel, edge, border, indicator, icon, scrollBar, msgMin;
  float fTitle, fBody, fLabel, fSmall, fCaption;
  
  float touch = 0;              
  float ctl = 0, ctlTall = 0;   
  float iconS = 0, iconM = 0;   
  float iconLead = 0, iconGap = 0;
  float spacing = 1;            
  
  float s1 = 1, s2 = 2, s3 = 3, s4 = 4, s6 = 6, s8 = 8, s10 = 10, s12 = 12, s14 = 14, s16 = 16, s20 = 20;
  float op[theme::style::InkCount] = {1, 1, 1, 1, 1};  
  int layout = theme::style::LayoutAuto;
  int labels = theme::style::LabelsIconText;
  float px(float dpValue) const { return dpValue * dp; }
  float sp(float dpValue) const { return dpValue * dp * spacing; }
  bool showIcons() const { return labels != theme::style::LabelsText; }
  bool showText() const { return labels != theme::style::LabelsIcons; }
};

float deviceDensity(float surfW, float surfH);
void setDensityOverride(float pxPerDp);  

Metrics makeMetrics(float pxPerDp, bool compact, const theme::UiStyle *style = nullptr, float devDensity = 0);


float textWidth(std::string_view s, float size);  
std::string ellipsize(std::string_view s, float maxW, float size);

float fitSize(std::string_view s, float maxW, float size);

std::vector<std::string> wrap(std::string_view s, float maxW, float size, int maxLines);
float minTextPx();
void resetTextCache();  

enum class Align { Left, Center, Right };

struct StepperOpts {  
  bool repeat = true;  
  bool decEnabled = true, incEnabled = true;
};

struct Hit {
  Rect r;
  std::function<void()> action;
  bool repeat = false;
};

class Canvas {
public:
  std::vector<pl::modmenu::DrawCommand> cmds;  
  size_t count = 0;
  std::span<const pl::modmenu::DrawCommand> commands() const { return {cmds.data(), count}; }
  std::vector<Hit> hits;
  Metrics m;
  Rect clip{-1e9f, -1e9f, 2e9f, 2e9f};  
  Rect pressed;                          
  float alpha = 1.f;                     
  
  
  int ink = -1;
  uint32_t cutout = 0;  
  struct InkScope {  
    Canvas &c;
    int prevInk;
    uint32_t prevCut;
    InkScope(Canvas &cv, int k, uint32_t cut = 0) : c(cv), prevInk(cv.ink), prevCut(cv.cutout) { c.ink = k; c.cutout = cut; }
    ~InkScope() { c.ink = prevInk; c.cutout = prevCut; }
  };

  void begin(const Metrics &metrics);
  void setClip(const Rect &r) { clip = r; }
  void noClip() { clip = {-1e9f, -1e9f, 2e9f, 2e9f}; }
  bool visible(const Rect &r) const;      
  bool isPressed(const Rect &r) const;

  
  void fill(const Rect &r, uint32_t c, float radius = 0);
  void frame(const Rect &r, uint32_t fillC, uint32_t borderC, float radius, float bw);  
  void line(float x1, float y1, float x2, float y2, uint32_t c, float width);
  void circle(float cx, float cy, float radius, uint32_t c);
  void triangle(float x1, float y1, float x2, float y2, float x3, float y3, uint32_t c);
  void image(const Rect &r, const std::string &id);

  
  void text(const Rect &box, std::string_view s, uint32_t c, float size, Align a = Align::Left, bool shrink = true);
  
  float paragraph(float x, float y, float w, std::string_view s, uint32_t c, float size, int maxLines,
                  Align a = Align::Left);
  float lineHeight(float size) const { return size * 1.35f; }
  
  void label(const Rect &box, std::string_view s, uint32_t c, float size, Align a = Align::Left);
  float switchWidth(std::string_view label, std::string_view stateText) const;  

  void hit(const Rect &r, std::function<void()> action, bool repeat = false);

  
  enum class Style { Secondary, Primary, Danger, DangerArmed, Success };
  struct ButtonOpts {
    Style style = Style::Secondary;
    bool enabled = true;
    bool repeat = false;       
    bool callWhenDisabled = false;  
    float fontSize = 0;        
  };
  void button(const Rect &r, std::string_view label, std::function<void()> action, ButtonOpts o);
  void button(const Rect &r, std::string_view label, std::function<void()> action) {
    button(r, label, std::move(action), ButtonOpts{});
  }
  
  enum class Glyph { Minus, Plus, Back };
  void iconButton(const Rect &r, Glyph g, std::function<void()> action, bool repeat, bool enabled = true);
  
  void segmented(const Rect &r, std::span<const char *const> labels, int selected,
                 const std::function<void(int)> &onSelect, bool enabled = true);
  
  void switchRow(const Rect &r, std::string_view label, std::string_view stateText, bool on,
                 std::function<void()> toggle);
  
  using StepperOpts = kit::StepperOpts;
  void stepperRow(const Rect &r, std::string_view label, std::string_view value, std::function<void()> dec,
                  std::function<void()> inc, std::function<void()> tapValue = nullptr, StepperOpts o = {});
  
  void swatch(const Rect &r, uint32_t color, bool selected);
  
  void valueBox(const Rect &r, std::string_view value, uint32_t color = theme::color::Text);
  void statusIcon(float cx, float cy, float size, Tone t);
  void loadingDots(float x, float cy, float size, uint32_t c, bool animate);
  void chip(const Rect &r, Tone t, std::string_view label);  
  float chipWidth(std::string_view label) const;
  void divider(float x, float y, float w);
  void scrollBar(const Rect &track, float contentH, float scroll);
  float sectionTitle(float x, float y, float w, std::string_view label);  

  uint32_t fade(uint32_t c) const;               
  uint32_t fadeInk(uint32_t c, int ink) const;
  int cutInk(uint32_t c) const;  

private:
  pl::modmenu::DrawCommand &next();  
  int rectInk(uint32_t c, const Rect &r) const;
};

}  
