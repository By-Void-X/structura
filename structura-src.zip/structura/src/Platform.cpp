#include "Platform.hpp"

#include <cstdlib>
#include <mutex>

#if defined(__ANDROID__)
#include <dlfcn.h>
#include <jni.h>
#include <sys/system_properties.h>
#endif

namespace lm::platform {
namespace {
std::mutex gMu;
bool gTest = false;
int gTestApi = 0;
std::string gTestAbi, gTestLauncher;
std::string gLauncher;  

#if defined(__ANDROID__)
std::string prop(const char *name) {
  char v[PROP_VALUE_MAX] = {};
  const int n = __system_property_get(name, v);
  return n > 0 ? std::string(v, size_t(n)) : std::string();
}

using GetVMsFn = jint (*)(JavaVM **, jsize, jsize *);
JavaVM *javaVm() {
  static JavaVM *vm = nullptr;
  if (vm) return vm;
  auto fn = reinterpret_cast<GetVMsFn>(dlsym(RTLD_DEFAULT, "JNI_GetCreatedJavaVMs"));
  for (const char *lib : {"libart.so", "libnativehelper.so"}) {
    if (fn) break;
    if (void *h = dlopen(lib, RTLD_NOW | RTLD_NOLOAD)) fn = reinterpret_cast<GetVMsFn>(dlsym(h, "JNI_GetCreatedJavaVMs"));
  }
  if (!fn) return nullptr;
  JavaVM *v = nullptr;
  jsize n = 0;
  if (fn(&v, 1, &n) != JNI_OK || n < 1) return nullptr;
  vm = v;
  return vm;
}


template <class F>
bool withApp(F &&f) {
  JavaVM *vm = javaVm();
  if (!vm) return false;
  JNIEnv *env = nullptr;
  bool attached = false;
  const jint st = vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
  if (st == JNI_EDETACHED) {
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return false;
    attached = true;
  } else if (st != JNI_OK || !env) {
    return false;
  }
  bool ok = false;
  if (env->PushLocalFrame(32) == JNI_OK) {
    jclass at = env->FindClass("android/app/ActivityThread");
    jmethodID cur = at ? env->GetStaticMethodID(at, "currentApplication", "()Landroid/app/Application;") : nullptr;
    jobject app = cur ? env->CallStaticObjectMethod(at, cur) : nullptr;
    if (env->ExceptionCheck()) { env->ExceptionClear(); app = nullptr; }
    if (app) ok = f(env, app);
    if (env->ExceptionCheck()) { env->ExceptionClear(); ok = false; }
    env->PopLocalFrame(nullptr);
  } else if (env->ExceptionCheck()) {
    env->ExceptionClear();
  }
  if (attached) vm->DetachCurrentThread();
  return ok;
}

bool clear(JNIEnv *env) {
  if (!env->ExceptionCheck()) return false;
  env->ExceptionClear();
  return true;
}
#endif
}  

void setTestValues(int api, const std::string &abi, const std::string &launcher) {
  std::lock_guard<std::mutex> lk(gMu);
  gTest = true;
  gTestApi = api;
  gTestAbi = abi;
  gTestLauncher = launcher;
}

int androidApi() {
  {
    std::lock_guard<std::mutex> lk(gMu);
    if (gTest) return gTestApi;
  }
#if defined(__ANDROID__)
  return std::atoi(prop("ro.build.version.sdk").c_str());
#else
  return 0;
#endif
}

std::string deviceAbi() {
  {
    std::lock_guard<std::mutex> lk(gMu);
    if (gTest) return gTestAbi;
  }
#if defined(__ANDROID__)
  return prop("ro.product.cpu.abi");
#else
  return {};
#endif
}

std::string launcherVersion() {
  std::lock_guard<std::mutex> lk(gMu);
  if (gTest) return gTestLauncher;
  if (!gLauncher.empty()) return gLauncher;
#if defined(__ANDROID__)
  std::string out;
  withApp([&](JNIEnv *env, jobject app) {
    jclass ctx = env->GetObjectClass(app);
    jmethodID getPm = env->GetMethodID(ctx, "getPackageManager", "()Landroid/content/pm/PackageManager;");
    jmethodID getPn = env->GetMethodID(ctx, "getPackageName", "()Ljava/lang/String;");
    if (clear(env) || !getPm || !getPn) return false;
    jobject pm = env->CallObjectMethod(app, getPm);
    jobject pn = env->CallObjectMethod(app, getPn);
    if (clear(env) || !pm || !pn) return false;
    jclass pmc = env->GetObjectClass(pm);
    jmethodID getPi = env->GetMethodID(pmc, "getPackageInfo", "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
    if (clear(env) || !getPi) return false;
    jobject pi = env->CallObjectMethod(pm, getPi, pn, 0);
    if (clear(env) || !pi) return false;
    jfieldID vn = env->GetFieldID(env->GetObjectClass(pi), "versionName", "Ljava/lang/String;");
    if (clear(env) || !vn) return false;
    auto s = static_cast<jstring>(env->GetObjectField(pi, vn));
    if (clear(env) || !s) return false;
    const char *c = env->GetStringUTFChars(s, nullptr);
    if (!c) { clear(env); return false; }
    out = c;
    env->ReleaseStringUTFChars(s, c);
    return true;
  });
  if (out.size() > 40) out.resize(40);
  gLauncher = out;
  return out;
#else
  return {};
#endif
}

bool copyText(const std::string &label, const std::string &text) {
#if defined(__ANDROID__)
  {
    std::lock_guard<std::mutex> lk(gMu);
    if (gTest) return true;
  }
  return withApp([&](JNIEnv *env, jobject app) {
    jclass ctx = env->GetObjectClass(app);
    jmethodID getSvc = env->GetMethodID(ctx, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
    if (clear(env) || !getSvc) return false;
    jstring name = env->NewStringUTF("clipboard");
    jobject cm = name ? env->CallObjectMethod(app, getSvc, name) : nullptr;
    if (clear(env) || !cm) return false;
    jclass clipData = env->FindClass("android/content/ClipData");
    if (clear(env) || !clipData) return false;
    jmethodID newPlain = env->GetStaticMethodID(clipData, "newPlainText",
                                                "(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;");
    if (clear(env) || !newPlain) return false;
    jstring jl = env->NewStringUTF(label.c_str());
    jstring jt = env->NewStringUTF(text.c_str());
    if (clear(env) || !jl || !jt) return false;
    jobject clip = env->CallStaticObjectMethod(clipData, newPlain, jl, jt);
    if (clear(env) || !clip) return false;
    jmethodID setClip = env->GetMethodID(env->GetObjectClass(cm), "setPrimaryClip", "(Landroid/content/ClipData;)V");
    if (clear(env) || !setClip) return false;
    env->CallVoidMethod(cm, setClip, clip);
    return !clear(env);
  });
#else
  (void)label;
  (void)text;
  std::lock_guard<std::mutex> lk(gMu);
  return gTest;
#endif
}

}  
