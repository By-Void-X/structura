#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include <pl/Logger.hpp>

#include "Library.hpp"

namespace lm::app {

void init(const std::string &myDir, pl::log::Logger *log);
void shutdown();
void postJob(std::function<void()> job);  


void rescan(const std::string &selectPath = {});
std::vector<lib::Entry> library();
uint64_t libraryRevision();
std::string myDir();
std::string lastImport();  
std::string rootsInfo();
void importFile();  


void select(const std::string &path);
void removeSelected();  
void removeFile(const std::string &path);  
void renameFile(const std::string &path, const std::string &newTitle);
void exportFile(const std::string &path);  
void setExportDir(const std::string &dir);  
bool canModify(const lib::Entry &e);       
std::string selectedPath();
void placeHere();
void placeInFront();                         
void moveRel(int fwd, int right, int up);   
void facing(int &fx, int &fz);               
void nudge(int dx, int dy, int dz);
void rotate();
void mirror();
void rotateLeft();
void layerDelta(int d);
void layer2Delta(int d);
void cycleLayerMode();
void cycleLayerAxis();
int layerSize();       
void setLayerToFeet();
void setLayer(int index);     // select a layer (overlay); never places blocks
void setLayerMode(int mode);  // LayerMode 0..4
int currentLayer();  


void cornerHere(int which);
void cornersY(int d);
void clearCorners();
void capture();
void poll();  

}  
