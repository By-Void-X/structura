#include "I18n.hpp"

#include <algorithm>
#include <iterator>
#include <atomic>
#include <cctype>
#include <cstdlib>
#include <deque>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <set>
#include <unordered_map>

#if defined(__ANDROID__)
#include <sys/system_properties.h>
#endif

namespace lm::i18n {
namespace {

#include "lang/en.inc"
#include "lang/pt_BR.inc"
#include "lang/es.inc"
#include "lang/fr.inc"
#include "lang/de.inc"
#include "lang/it.inc"
#include "lang/ru.inc"
#include "lang/pl.inc"
#include "lang/tr.inc"
#include "lang/id.inc"
#include "lang/vi.inc"
#include "lang/hi.inc"
#include "lang/zh_CN.inc"
#include "lang/ja.inc"
#include "lang/ko.inc"

struct Builtin {
  const char *code;
  const char *name;  
  const Entry *entries;
  size_t count;
};

constexpr size_t kMaxLanguages = 15;  

#define LM_LANG(code, name, arr) {code, name, arr, sizeof(arr) / sizeof(arr[0])}

const Builtin kBuiltin[] = {
    LM_LANG("en", "English", kLangEn),
    LM_LANG("pt-BR", "Português (Brasil)", kLangPtBR),
    LM_LANG("es", "Español", kLangEs),
    LM_LANG("fr", "Français", kLangFr),
    LM_LANG("de", "Deutsch", kLangDe),
    LM_LANG("it", "Italiano", kLangIt),
    LM_LANG("ru", "Русский", kLangRu),
    LM_LANG("pl", "Polski", kLangPl),
    LM_LANG("tr", "Türkçe", kLangTr),
    LM_LANG("id", "Bahasa Indonesia", kLangId),
    LM_LANG("vi", "Tiếng Việt", kLangVi),
    LM_LANG("hi", "हिन्दी", kLangHi),
    LM_LANG("zh-CN", "简体中文", kLangZhCN),
    LM_LANG("ja", "日本語", kLangJa),
    LM_LANG("ko", "한국어", kLangKo),
};
#undef LM_LANG
static_assert(std::size(kBuiltin) <= kMaxLanguages, "at most 15 languages");

struct Catalog {
  std::string code, name;
  std::unordered_map<std::string_view, const char *> map;
};


std::vector<Catalog> gCatalogs;
std::deque<std::string> gExtStore;  
std::once_flag gBuilt;

std::atomic_int gActive{0};
std::atomic_uint gGen{1};
std::mutex gMu;               
std::string gChoice = "auto";
std::string gDetected = "en";
std::string gConfigDir;
std::string gOverrideLauncher, gOverrideSystem;
bool gOverride = false;
std::set<std::string> gMissing;
std::atomic_bool gDev{false};
void (*gLog)(const std::string &) = nullptr;

std::string lower(std::string_view s) {
  std::string o(s);
  for (auto &c : o) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  std::replace(o.begin(), o.end(), '_', '-');
  return o;
}

std::string trim(std::string_view s) {
  size_t a = 0, b = s.size();
  while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
  while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
  return std::string(s.substr(a, b - a));
}


void loadLangFile(const std::filesystem::path &p) {
  std::ifstream in(p);
  if (!in) return;
  Catalog c;
  c.code = p.stem().string();
  c.name = c.code;
  std::string line;
  while (std::getline(in, line)) {
    if (!line.empty() && line.back() == '\r') line.pop_back();
    const std::string t = trim(line);
    if (t.empty() || t[0] == '#') continue;
    const auto eq = t.find('=');
    if (eq == std::string::npos) continue;
    std::string k = trim(std::string_view(t).substr(0, eq)), v = trim(std::string_view(t).substr(eq + 1));
    for (size_t i; (i = v.find("\\n")) != std::string::npos;) v.replace(i, 2, "\n");
    if (k == "@code") { c.code = v; continue; }
    if (k == "@name") { c.name = v; continue; }
    if (k.empty() || v.empty()) continue;
    gExtStore.push_back(std::move(k));
    const std::string &ks = gExtStore.back();
    gExtStore.push_back(std::move(v));
    c.map[ks] = gExtStore.back().c_str();
  }
  if (c.map.empty()) return;
  
  for (auto &b : gCatalogs)
    if (lower(b.code) == lower(c.code)) {
      for (auto &[k, v] : c.map) b.map[k] = v;
      return;
    }
  if (gCatalogs.size() >= kMaxLanguages) return;  
  gCatalogs.push_back(std::move(c));
}

void build() {
  for (const auto &b : kBuiltin) {
    Catalog c;
    c.code = b.code;
    c.name = b.name;
    c.map.reserve(b.count * 2);
    for (size_t i = 0; i < b.count; ++i) c.map.emplace(b.entries[i].key, b.entries[i].text);
    gCatalogs.push_back(std::move(c));
  }
  if (gConfigDir.empty()) return;
  std::error_code ec;
  const auto dir = std::filesystem::path(gConfigDir) / "lang";
  if (!std::filesystem::is_directory(dir, ec)) return;
  std::vector<std::filesystem::path> files;
  for (auto it = std::filesystem::directory_iterator(dir, ec); !ec && it != std::filesystem::directory_iterator();
       it.increment(ec))
    if (it->path().extension() == ".lang") files.push_back(it->path());
  std::sort(files.begin(), files.end());
  for (auto &f : files) loadLangFile(f);
}

int indexOf(std::string_view code) {
  for (size_t i = 0; i < gCatalogs.size(); ++i)
    if (gCatalogs[i].code == code) return static_cast<int>(i);
  return -1;
}

std::string readFile(const std::string &path) {
  std::ifstream in(path, std::ios::binary);
  if (!in) return {};
  return std::string(std::istreambuf_iterator<char>(in), {});
}



std::string launcherLanguage() {
  std::vector<std::string> candidates;
  std::string pkg = readFile("/proc/self/cmdline");
  if (auto z = pkg.find('\0'); z != std::string::npos) pkg.resize(z);
  if (auto c = pkg.find(':'); c != std::string::npos) pkg.resize(c);
  if (!pkg.empty() && pkg.find('/') == std::string::npos) {
    candidates.push_back("/data/data/" + pkg + "/shared_prefs/settings.xml");
    candidates.push_back("/data/user/0/" + pkg + "/shared_prefs/settings.xml");
  }
  if (auto f = gConfigDir.find("/files/"); f != std::string::npos)
    candidates.push_back(gConfigDir.substr(0, f) + "/shared_prefs/settings.xml");
  for (const auto &p : candidates) {
    const std::string xml = readFile(p);
    if (xml.empty()) continue;
    const auto k = xml.find("name=\"language\"");
    if (k == std::string::npos) return {};
    const auto gt = xml.find('>', k), lt = xml.find('<', gt == std::string::npos ? k : gt);
    if (gt == std::string::npos || lt == std::string::npos || lt <= gt) return {};
    return trim(std::string_view(xml).substr(gt + 1, lt - gt - 1));
  }
  return {};
}

std::string systemLanguage() {
#if defined(__ANDROID__)
  char v[PROP_VALUE_MAX] = {};
  for (const char *prop : {"persist.sys.locale", "ro.product.locale", "persist.sys.language"})
    if (__system_property_get(prop, v) > 0 && v[0]) return v;
#endif
  for (const char *env : {"LC_ALL", "LANG"})
    if (const char *v = std::getenv(env); v && *v && std::string_view(v) != "C" && std::string_view(v) != "POSIX")
      return v;
  return {};
}

std::string detect() {
  std::string launcher, system;
  {
    std::lock_guard lk(gMu);
    if (gOverride) {
      launcher = gOverrideLauncher;
      system = gOverrideSystem;
    }
  }
  bool overridden;
  {
    std::lock_guard lk(gMu);
    overridden = gOverride;
  }
  if (!overridden) {
    launcher = launcherLanguage();
    system = systemLanguage();
  }
  if (auto c = matchCode(launcher); !c.empty()) return c;
  if (auto c = matchCode(system); !c.empty()) return c;
  return "en";
}

void apply() {
  std::string want;
  {
    std::lock_guard lk(gMu);
    want = gChoice == "auto" ? gDetected : gChoice;
  }
  int i = indexOf(want);
  if (i < 0) i = indexOf(matchCode(want));
  if (i < 0) i = 0;
  if (gActive.exchange(i) != i) gGen.fetch_add(1);
}

void noteMissing(std::string_view key) {
  std::lock_guard lk(gMu);
  if (!gMissing.insert(std::string(key)).second) return;
  if (gDev.load() && gLog) gLog("i18n: missing key \"" + std::string(key) + "\"");
}

}  

std::string matchCode(std::string_view tag) {
  std::string t = lower(trim(tag));
  if (auto dot = t.find('.'); dot != std::string::npos) t.resize(dot);  
  if (t.empty()) return {};
  std::call_once(gBuilt, build);
  for (const auto &c : gCatalogs)
    if (lower(c.code) == t) return c.code;
  const std::string base = t.substr(0, t.find('-'));
  
  if (base == "pt" && indexOf("pt-BR") >= 0) return "pt-BR";
  if (base == "zh" && indexOf("zh-CN") >= 0) return "zh-CN";
  
  if ((base == "in" || base == "idn") && indexOf("id") >= 0) return "id";
  for (const auto &c : gCatalogs) {
    const std::string lc = lower(c.code);
    if (lc == base || lc.substr(0, lc.find('-')) == base) return c.code;
  }
  return {};
}

void init(const std::string &configDir) {
  {
    std::lock_guard lk(gMu);
    if (gConfigDir.empty()) gConfigDir = configDir;
  }
  std::call_once(gBuilt, build);
  const std::string d = detect();
  {
    std::lock_guard lk(gMu);
    gDetected = d;
  }
  apply();
}

void setChoice(std::string_view code) {
  std::call_once(gBuilt, build);
  std::string c = trim(code);
  if (c.empty() || lower(c) == "auto") c = "auto";
  else if (auto m = matchCode(c); !m.empty()) c = m;
  else c = "auto";  
  {
    std::lock_guard lk(gMu);
    gChoice = c;
  }
  apply();
}

std::string choice() {
  std::lock_guard lk(gMu);
  return gChoice;
}

std::string activeCode() {
  std::call_once(gBuilt, build);
  return gCatalogs[gActive.load()].code;
}

std::string activeName() {
  std::call_once(gBuilt, build);
  return gCatalogs[gActive.load()].name;
}

std::string detectedCode() {
  std::lock_guard lk(gMu);
  return gDetected;
}

std::vector<Language> languages() {
  std::call_once(gBuilt, build);
  std::vector<Language> out;
  for (const auto &c : gCatalogs) out.push_back({c.code, c.name});
  return out;
}

unsigned generation() { return gGen.load(std::memory_order_relaxed); }

const char *tr(std::string_view key) {
  std::call_once(gBuilt, build);
  const auto &act = gCatalogs[gActive.load(std::memory_order_relaxed)].map;
  if (auto it = act.find(key); it != act.end()) return it->second;
  const auto &en = gCatalogs[0].map;
  if (auto it = en.find(key); it != en.end()) return it->second;
  noteMissing(key);
  return "";
}

std::string fmt(std::string_view key, std::initializer_list<std::string_view> args) {
  const std::string_view pat = tr(key);
  std::string out;
  out.reserve(pat.size() + 16);
  for (size_t i = 0; i < pat.size(); ++i) {
    if (pat[i] == '{' && i + 2 < pat.size() && pat[i + 2] == '}' && pat[i + 1] >= '0' && pat[i + 1] <= '9') {
      const size_t n = static_cast<size_t>(pat[i + 1] - '0');
      if (n < args.size()) out += *(args.begin() + n);
      i += 2;
      continue;
    }
    out += pat[i];
  }
  return out;
}

void setDevMode(bool on) { gDev.store(on); }
void setLogger(void (*log)(const std::string &)) { gLog = log; }

std::vector<std::string> missingKeys() {
  std::lock_guard lk(gMu);
  return {gMissing.begin(), gMissing.end()};
}

std::vector<std::string> keysMissingIn(std::string_view code) {
  std::call_once(gBuilt, build);
  std::vector<std::string> out;
  const int i = indexOf(code);
  if (i < 0) return out;
  for (const auto &[k, v] : gCatalogs[0].map)
    if (!gCatalogs[i].map.count(k)) out.emplace_back(k);
  std::sort(out.begin(), out.end());
  return out;
}

void setDetectOverride(std::string_view launcherTag, std::string_view systemTag) {
  {
    std::lock_guard lk(gMu);
    gOverride = true;
    gOverrideLauncher = launcherTag;
    gOverrideSystem = systemTag;
  }
  const std::string d = detect();
  {
    std::lock_guard lk(gMu);
    gDetected = d;
  }
  apply();
}

}  
