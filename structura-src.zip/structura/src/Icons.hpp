#pragma once



#include <string>

namespace icons {

void start();


std::string iconFor(const std::string &blockName);

void setSourceForTest(const std::string &path);

bool renderForTest(const std::string &blockName, std::string &rgba);
constexpr int kSize = 48;
}  
