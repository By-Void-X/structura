#include "Catalog.hpp"

#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

#include <algorithm>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <fstream>
#include <memory>
#include <mutex>
#include <set>
#include <thread>
#include <unordered_map>

#include "Preview.hpp"
#include "Structure.hpp"

namespace lm::cat {
namespace {

struct Slot {
  Info info;
  int64_t mtime = 0;
  long size = 0;
  bool queued = false;
};

std::mutex gMu;
std::condition_variable gCv;
std::unordered_map<std::string, Slot> gSlots;
std::deque<std::string> gQueue;  
std::deque<std::pair<uint64_t, std::vector<uint8_t>>> gThumbs;
uint64_t gNextThumb = 1, gGen = 0, gListsGen = 0, gLibRev = ~0ull;
bool gStop = false, gStarted = false;
std::thread gThread;

std::string gFile;  
std::set<std::string> gFav;
std::vector<std::pair<std::string, int64_t>> gRecent;  

bool statFile(const std::string &path, int64_t &mt, long &size) {
  struct stat st{};
  if (stat(path.c_str(), &st) != 0) return false;
  mt = int64_t(st.st_mtime);
  size = long(st.st_size);
  return true;
}


void saveLists() {
  if (gFile.empty()) return;
  const std::string tmp = gFile + ".tmp";
  {
    std::ofstream out(tmp, std::ios::trunc);
    if (!out) return;
    for (const auto &f : gFav) out << "fav\t" << f << "\n";
    for (const auto &r : gRecent) {
      char when[24];
      std::snprintf(when, sizeof(when), "%lld", static_cast<long long>(r.second));
      out << "rec\t" << when << "\t" << r.first << "\n";
    }
    if (!out) return;
  }
  std::rename(tmp.c_str(), gFile.c_str());
}

void loadLists() {
  std::ifstream in(gFile);
  std::string line;
  while (std::getline(in, line)) {
    if (line.rfind("fav\t", 0) == 0 && line.size() > 4) {
      gFav.insert(line.substr(4));
    } else if (line.rfind("rec\t", 0) == 0) {
      const auto t = line.find('\t', 4);
      if (t == std::string::npos || t + 1 >= line.size()) continue;
      const std::string num = line.substr(4, t - 4);
      char *end = nullptr;
      const int64_t when = std::strtoll(num.c_str(), &end, 10);
      if (num.empty() || end != num.c_str() + num.size()) continue;  
      if (gRecent.size() < kMaxRecent) gRecent.emplace_back(line.substr(t + 1), when);
    }
  }
}

void readOne(const std::string &path) {
  int64_t mt = 0;
  long size = 0;
  Info info;
  std::vector<uint8_t> px;
  if (!statFile(path, mt, size)) {
    info.state = Info::Failed;
  } else if (size > kMaxFileBytes) {
    info.state = Info::TooLarge;
  } else {
    Structure s;
    std::string err;
    if (!loadStructure(path, s, err)) {
      info.state = err.find("too large") != std::string::npos ? Info::TooLarge : Info::Failed;
    } else {
      info.state = Info::Ready;
      info.sx = s.sx; info.sy = s.sy; info.sz = s.sz;
      info.blocks = s.solidCount;
      std::vector<const PaletteEntry *> pal;
      for (const auto &p : s.palette)
        if (!p.air && p.count) pal.push_back(&p);
      info.kinds = uint32_t(pal.size());
      std::stable_sort(pal.begin(), pal.end(), [](const PaletteEntry *a, const PaletteEntry *b) { return a->count > b->count; });
      for (size_t i = 0; i < pal.size() && i < size_t(kTopMaterials); ++i)
        info.top.push_back({pal[i]->name, pal[i]->label, pal[i]->color, pal[i]->count});
      const auto faces = buildPreviewFaces(s, 150000);
      if (!faces.empty()) renderPreview(s, faces, 35.f, 30.f, kThumb, kThumb, px);
    }
  }
  std::lock_guard<std::mutex> lk(gMu);
  auto it = gSlots.find(path);
  if (it == gSlots.end()) return;  
  Slot &sl = it->second;
  sl.queued = false;
  sl.mtime = mt;
  sl.size = size;
  if (px.size() == size_t(kThumb) * kThumb * 4) {
    info.thumbId = gNextThumb++;
    gThumbs.emplace_back(info.thumbId, std::move(px));  
  }
  sl.info = std::move(info);
  ++gGen;
}

void worker() {
#if defined(__linux__)
  setpriority(PRIO_PROCESS, pid_t(syscall(SYS_gettid)), 10);  
#endif
  for (;;) {
    std::string path;
    {
      std::unique_lock<std::mutex> lk(gMu);
      gCv.wait(lk, [] { return gStop || !gQueue.empty(); });
      if (gStop) return;
      path = std::move(gQueue.front());
      gQueue.pop_front();
    }
    try {
      readOne(path);
    } catch (...) {
      std::lock_guard<std::mutex> lk(gMu);
      auto it = gSlots.find(path);
      if (it != gSlots.end()) {
        it->second.queued = false;
        it->second.info = Info{};
        it->second.info.state = Info::Failed;
      }
    }
  }
}

}  

void init(const std::string &dir) {
  std::lock_guard<std::mutex> lk(gMu);
  if (gFile.empty() && !dir.empty()) {
    gFile = dir + "/.catalog";
    loadLists();
  }
  if (gStarted) return;
  gStarted = true;
  gStop = false;
  gThread = std::thread(worker);
}

void shutdown() {
  {
    std::lock_guard<std::mutex> lk(gMu);
    gStop = true;
    gQueue.clear();
    gStarted = false;
  }
  gCv.notify_all();
  if (gThread.joinable()) gThread.detach();  
}

bool get(const std::string &path, Info &out, bool request) {
  std::lock_guard<std::mutex> lk(gMu);
  auto it = gSlots.find(path);
  if (it == gSlots.end()) {
    if (!request) return false;
    it = gSlots.emplace(path, Slot{}).first;
  }
  Slot &sl = it->second;
  if (sl.info.state != Info::Pending) {
    out = sl.info;
    return true;
  }
  if (request) {
    
    if (sl.queued) {
      auto q = std::find(gQueue.begin(), gQueue.end(), path);
      if (q != gQueue.begin() && q != gQueue.end()) {
        gQueue.erase(q);
        gQueue.push_front(path);
      }
    } else {
      sl.queued = true;
      gQueue.push_front(path);
      gCv.notify_one();
    }
  }
  out = sl.info;
  return false;
}

uint64_t generation() {
  std::lock_guard<std::mutex> lk(gMu);
  return gGen;
}

bool takeThumb(uint64_t &id, std::vector<uint8_t> &rgba) {
  std::lock_guard<std::mutex> lk(gMu);
  if (gThumbs.empty()) return false;
  id = gThumbs.front().first;
  rgba = std::move(gThumbs.front().second);
  gThumbs.pop_front();
  return true;
}

void syncLibrary(const std::vector<lib::Entry> &entries, uint64_t revision) {
  {
    std::lock_guard<std::mutex> lk(gMu);
    if (revision == gLibRev) return;
    gLibRev = revision;
  }
  
  std::vector<std::pair<int64_t, long>> st(entries.size(), {0, 0});
  for (size_t i = 0; i < entries.size(); ++i) statFile(entries[i].path, st[i].first, st[i].second);
  std::lock_guard<std::mutex> lk(gMu);
  for (size_t i = 0; i < entries.size(); ++i) {
    Slot &sl = gSlots[entries[i].path];
    if (sl.info.state != Info::Pending && (sl.mtime != st[i].first || sl.size != st[i].second)) {
      sl.info = Info{};  
      ++gGen;
    }
    sl.mtime = st[i].first;
    sl.size = st[i].second;
  }
}

int64_t mtime(const std::string &path) {
  std::lock_guard<std::mutex> lk(gMu);
  auto it = gSlots.find(path);
  return it == gSlots.end() ? 0 : it->second.mtime;
}

bool isFavorite(const std::string &path) {
  std::lock_guard<std::mutex> lk(gMu);
  return gFav.count(path) != 0;
}

void setFavorite(const std::string &path, bool on) {
  std::lock_guard<std::mutex> lk(gMu);
  const bool changed = on ? gFav.insert(path).second : gFav.erase(path) > 0;
  if (!changed) return;
  ++gListsGen;
  saveLists();
}

uint64_t listsGeneration() {
  std::lock_guard<std::mutex> lk(gMu);
  return gListsGen;
}

void touchRecent(const std::string &path) {
  std::lock_guard<std::mutex> lk(gMu);
  gRecent.erase(std::remove_if(gRecent.begin(), gRecent.end(), [&](const auto &r) { return r.first == path; }),
                gRecent.end());
  gRecent.insert(gRecent.begin(), {path, int64_t(std::time(nullptr))});
  if (gRecent.size() > kMaxRecent) gRecent.resize(kMaxRecent);
  ++gListsGen;
  saveLists();
}

std::vector<std::pair<std::string, int64_t>> recents() {
  std::lock_guard<std::mutex> lk(gMu);
  return gRecent;
}

void renamed(const std::string &from, const std::string &to) {
  std::lock_guard<std::mutex> lk(gMu);
  if (gFav.erase(from)) gFav.insert(to);
  for (auto &r : gRecent)
    if (r.first == from) r.first = to;
  auto it = gSlots.find(from);
  if (it != gSlots.end()) {
    Slot sl = std::move(it->second);
    gSlots.erase(it);
    sl.queued = false;
    gQueue.erase(std::remove(gQueue.begin(), gQueue.end(), from), gQueue.end());
    gSlots[to] = std::move(sl);
  }
  ++gListsGen;
  ++gGen;
  saveLists();
}

void removed(const std::string &path) {
  std::lock_guard<std::mutex> lk(gMu);
  gFav.erase(path);
  gRecent.erase(std::remove_if(gRecent.begin(), gRecent.end(), [&](const auto &r) { return r.first == path; }),
                gRecent.end());
  gSlots.erase(path);
  gQueue.erase(std::remove(gQueue.begin(), gQueue.end(), path), gQueue.end());
  ++gListsGen;
  ++gGen;
  saveLists();
}

}  
