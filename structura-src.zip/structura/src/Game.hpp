#pragma once



#include <sys/uio.h>
#include <unistd.h>

#include <cstdint>
#include <cstring>
#include <string>

namespace lm::game {

struct Vec3 {
  float x{}, y{}, z{};
};
struct BlockPos {
  int x, y, z;
};

enum PrimitiveMode : int { QuadList = 1, TriangleList = 2, LineList = 4 };

using TessBeginFn = void (*)(void *tess, void *dbg, int mode, int vertexCount, int noIndices);
using TessColorFn = void (*)(void *tess, float r, float g, float b, float a);
using TessVertexFn = void (*)(void *tess, float x, float y, float z);
using RenderMeshFn = void (*)(void *screenCtx, void *tess, void *material, char *pad);
using RenderLevelFn = void (*)(void *self, void *screenCtx, void *frameRenderObj);
using GetBlockFn = void *(*)(void *region, const BlockPos &pos);
using UpdateFn = void *(*)(void *clientInstance, bool);


struct HashedString {
  uint64_t mStrHash{};
  std::string mStr;
  mutable const HashedString *mLastMatch{};
  explicit HashedString(const char *s) : mStr(s ? s : "") {
    if (mStr.empty()) return;
    uint64_t h = 0xCBF29CE484222325ULL;
    for (char c : mStr) h = static_cast<uint64_t>(static_cast<unsigned char>(c)) ^ (0x100000001B3ULL * h);
    mStrHash = h;
  }
};


struct MaterialPtr {
  void *sharedPtrData[2]{nullptr, nullptr};
  MaterialPtr() = default;
  MaterialPtr(const MaterialPtr &) = delete;
  MaterialPtr &operator=(const MaterialPtr &) = delete;
  MaterialPtr(MaterialPtr &&o) noexcept : sharedPtrData{o.sharedPtrData[0], o.sharedPtrData[1]} {
    o.sharedPtrData[0] = o.sharedPtrData[1] = nullptr;
  }
  MaterialPtr &operator=(MaterialPtr &&o) noexcept {
    if (this != &o) {
      sharedPtrData[0] = o.sharedPtrData[0];
      sharedPtrData[1] = o.sharedPtrData[1];
      o.sharedPtrData[0] = o.sharedPtrData[1] = nullptr;
    }
    return *this;
  }
  ~MaterialPtr() {}
  explicit operator bool() const { return sharedPtrData[0] != nullptr; }
};



inline uintptr_t untag(uintptr_t p) { return p & 0x00FFFFFFFFFFFFFFULL; }
inline bool plausiblePtr(uintptr_t p) {
  p = untag(p);
  return p >= 0x10000 && p < (1ULL << 48) && (p & 0x7) == 0;
}


inline bool safeRead(uintptr_t src, void *dst, size_t n) {
  src = untag(src);  
  if (src < 0x10000) return false;
  iovec local{dst, n}, remote{reinterpret_cast<void *>(src), n};
  return process_vm_readv(getpid(), &local, 1, &remote, 1, 0) == static_cast<ssize_t>(n);
}
inline bool safeReadPtr(uintptr_t src, uintptr_t &out) { return safeRead(src, &out, sizeof(out)); }

}  

namespace lm::sig {
inline constexpr const char *RenderLevel =
    "? ? ? FC ? ? ? 6D ? ? ? 6D ? ? ? 6D ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 "
    "? ? ? A9 ? ? ? A9 ? ? ? 91 ? ? ? D1 57 D0 3B D5 F8 03 00 AA F4 03 02 AA "
    "? ? ? ? F5 03 01 AA";
inline constexpr const char *TessellatorBegin =
    "? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 FD 03 00 91 ? ? ? 39 ? ? ? 39 08 01 09 2A";
inline constexpr const char *TessellatorColor = "? ? ? 52 ? ? ? 39 04 01 27 1E";
inline constexpr const char *TessellatorVertex =
    "? ? ? D1 ? ? ? FD ? ? ? 6D ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 "
    "? ? ? A9 ? ? ? 91 5A D0 3B D5 ? ? ? F9 ? ? ? F9 ? ? ? B9 ? ? ? B9 1F 01 09 6B";
inline constexpr const char *RenderMeshImmediately2 =
    "? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 FD 03 00 91 ? ? ? D1 57 D0 3B D5 F6 03 00 AA "
    "E0 03 01 AA ? ? ? F9 F4 03 03 AA";
inline constexpr const char *RenderMeshImmediately =
    "? ? ? A9 ? ? ? F9 ? ? ? A9 ? ? ? A9 ? ? ? A9 FD 03 00 91 ? ? ? D1 58 D0 3B D5 "
    "F7 03 00 AA E0 03 01 AA ? ? ? F9 F4 03 04 AA";
inline constexpr const char *RenderMaterialGroupCommon = "? ? ? 90 ? ? ? 91 ? ? ? D1 ? ? ? D1 ? ? ? 91 E3 03 14 AA";
inline constexpr const char *BlockSourceGetBlock =
    "? ? ? D1 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? 91 56 D0 3B D5 ? ? ? F9 ? ? ? F9 ? ? ? B9 ? ? ? 79 1F 01 09 6B "
    "? ? ? 54 ? ? ? 79 F3 03 00 AA 1F 01 09 6B ? ? ? 54 E0 03 00 91";
// LocalPlayer::normalTick (1.26.52.3 +0xaac7dd8): unique in the library, also with the first 28 bytes
// ignored; validated at runtime by its presence in the LocalPlayer vtable (RTTI).
inline constexpr const char *LocalPlayerNormalTick =
    "E8 0F 19 FC FD 7B 01 A9 FC 6F 02 A9 FA 67 03 A9 F8 5F 04 A9 F6 57 05 A9 F4 4F 06 A9 FD 43 00 91 FF C3 09 D1 "
    "54 D0 3B D5 F3 03 00 AA 88 16 40 F9 A8 03 1E F8 08 C0 78 39 ? ? ? 34 68 92 4C B9";
inline constexpr const char *ClientInstanceUpdate =
    "? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 ? ? ? A9 FD 03 00 91 ? ? ? D1 59 D0 3B D5 F3 03 00 AA F4 03 01 2A "
    "? ? ? F9 ? ? ? F8 ? ? ? F9 ? ? ? F9";


inline constexpr const char *TessellateInWorld =
    "FF 83 06 D1 FD 7B 14 A9 FC 6F 15 A9 FA 67 16 A9 F8 5F 17 A9 F6 57 18 A9 F4 4F 19 A9 FD 03 05 91 5A D0 3B D5 "
    "F7 03 04 2A";

inline constexpr const char *GetBlockTessellator =
    "FD 7B BD A9 F5 0B 00 F9 F4 4F 02 A9 FD 03 00 91 F3 03 00 AA 00 E4 41 F9";

inline constexpr const char *BTResetCache = "FD 7B BD A9 F5 0B 00 F9 F4 4F 02 A9 FD 03 00 91 29 28 40 29 0B 04 40 F9";
inline constexpr const char *BTSetBlockInCache = "48 00 40 B9 09 80 46 B9 08 01 09 6B ? ? ? 54 49 04 40 B9 0A 84 46 B9";

inline constexpr const char *BlockRenderFlag =
    "FD 7B BE A9 F4 4F 01 A9 FD 03 00 91 F3 03 00 AA ? ? ? ? ? ? ? B4 F4 03 00 AA E0 03 13 AA";

inline constexpr const char *BlockRegistryGetter =
    "? ? ? ? ? ? ? 91 C0 03 5F D6 ? ? ? ? ? ? ? 91 C0 03 5F D6 FD 7B BD A9 F5 0B 00 F9 F4 4F 02 A9 FD 03 00 91 "
    "F3 03 08 AA";
inline constexpr const char *BlockLookupByName = "E2 03 1F 2A E3 03 1F 2A E4 03 1F 2A ? ? ? ? FF 83 06 D1 FD 7B 14 A9";

inline constexpr const char *FindBlockState = "FD 7B BD A9 F6 57 01 A9 F4 4F 02 A9 FD 03 00 91 F4 03 00 AA 00 00 07 91";

inline constexpr const char *ByteTagVtable =
    "? ? ? ? ? ? ? 91 1F 20 00 39 08 00 00 F9 C0 03 5F D6 ? ? ? ? ? ? ? 91 01 20 00 39";
inline constexpr const char *IntTagVtable = "? ? ? ? ? ? ? 91 68 02 00 F9 88 0A 40 B9 68 0A 00 B9 68 00 80 52";
inline constexpr const char *StringTagVtable =
    "? ? ? ? ? ? ? 91 29 00 00 F9 ? ? ? 37 C0 03 5F D6 20 0C 40 F9 ? ? ? ? FD 7B BD A9";

inline constexpr const char *TessellatorClear = "FD 7B BE A9 F3 0B 00 F9 FD 03 00 91 F3 03 00 AA 1F 90 02 B9 1F 54 09 39";

inline constexpr const char *TessellatorEndMesh = "FD 7B BB A9 FC 67 01 A9 F8 5F 02 A9 F6 57 03 A9 F4 4F 04 A9 FD 03 00 91 FF 43 0A D1 58 D0 3B D5 F4 03 08 AA";
inline constexpr const char *MeshRender = "FD 7B BB A9 FC 67 01 A9 F8 5F 02 A9 F6 57 03 A9 F4 4F 04 A9 FD 03 00 91 FF C3 06 D1 54 D0 3B D5";
inline constexpr const char *MeshDestroy = "FD 7B BD A9 F5 0B 00 F9 F4 4F 02 A9 FD 03 00 91 F3 03 00 AA ? ? ? ? 60 32 41 F9";
inline constexpr const char *MatrixStackPush = "FD 7B BE A9 F4 4F 01 A9 FD 03 00 91 F3 03 08 AA 08 14 40 F9 F4 03 00 AA";
inline constexpr const char *MatrixRefPop = "FD 7B BE A9 F4 4F 01 A9 FD 03 00 91 13 00 40 F9 ? ? ? B4 68 E2 40 39 29 00 80 52 69 02 01 39 ? ? ? 36 68 AA 42 A9 09 05 00 D1 3F 01 0A EB ? ? ? 54 7F E2 00 39 ? ? ? ? 68 16 40 F9 09 05 00 D1 6B AA 40 A9 6D 12 40 F9 69 16 00 F9 08 01 0D 8B 4C 01 0B EB 8C F1 7D D3 5F 01 0B EB 8C 05 00 D1 EB 03 8C 9A 68 01 08 CB 08 05 00 91 1F 01 02 F1 ? ? ? 54 48 81 5F F8 F4 03 00 AA E0 03 08 AA ? ? ? ? 68 0A 40 F9 E0 03 14 AA 08 21 00 D1 68 0A 00 F9 1F 7C 00 A9 F4 4F 41 A9 FD 7B C2 A8 C0 03 5F D6";
}  

namespace lm::off {
inline constexpr unsigned LevelRenderer_mLevelRendererPlayer = 0x420;



inline constexpr unsigned LevelRendererPlayer_mCamPos = 0x628;
inline constexpr unsigned LRP_mat_selection_overlay = 0x1030;
inline constexpr unsigned LRP_mat_selection_overlay_opaque = 0x1040;
inline constexpr unsigned LRP_mat_selection_overlay_double_sided = 0x1050;
inline constexpr unsigned LRP_mat_cracks_overlay = 0x1060;
inline constexpr unsigned LRP_mat_selection_box = 0x1090;
inline constexpr unsigned ScreenContext_mColorHolder = 0x30;
inline constexpr unsigned ScreenContext_mTessellator = 0xB8;
inline constexpr unsigned MaterialGroup_mRenderMaterialGroup = 32;
inline constexpr unsigned VT_RenderMaterialGroup_getMaterial = 2;
inline constexpr unsigned VT_ClientInstance_getLocalPlayer = 32;
inline constexpr unsigned Actor_mDimension = 448;
inline constexpr unsigned Actor_mStateVector = 0x208;
inline constexpr unsigned Actor_mRotation = 0x218;
inline constexpr unsigned Dimension_mBlockSource = 208;
}  
