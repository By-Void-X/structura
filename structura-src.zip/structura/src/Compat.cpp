#include "Compat.hpp"

#include <atomic>
#include <mutex>

namespace lm::compat {
namespace {
std::mutex gMu;
std::atomic<unsigned> gRev{1};
Entry gEntries[kCount];
Env gEnv;
}  

void set(Comp c, State s, Reason r, const std::string &detail) {
  if (int(c) < 0 || int(c) >= kCount) return;
  std::lock_guard<std::mutex> lk(gMu);
  gRev.fetch_add(1);
  gEntries[int(c)] = Entry{s, r, detail};
}

unsigned revision() { return gRev.load(); }

Entry get(Comp c) {
  if (int(c) < 0 || int(c) >= kCount) return {};
  std::lock_guard<std::mutex> lk(gMu);
  return gEntries[int(c)];
}

void resetGame() {
  std::lock_guard<std::mutex> lk(gMu);
  gRev.fetch_add(1);
  for (Comp c : {Comp::Versions, Comp::PlayerUpdate, Comp::Rendering, Comp::Verification, Comp::Placement,
                 Comp::PlayerContext, Comp::Hologram})
    gEntries[int(c)] = Entry{};
}

Level level() {
  std::lock_guard<std::mutex> lk(gMu);
  bool pending = false, allOk = true, anyGame = false;
  // ClientInstance::update is optional: unavailable is fine while another validated source provides the
  // player context (it is then reported, but does not make the mode partial).
  const bool updOptional = gEntries[int(Comp::PlayerUpdate)].state == State::Unavailable &&
                           gEntries[int(Comp::PlayerContext)].state == State::Ok;
  for (int i = 0; i < kCount; ++i) {
    const State s = gEntries[i].state;
    pending |= s == State::Pending;
    allOk &= s == State::Ok || (i == int(Comp::PlayerUpdate) && updOptional);
  }
  for (Comp c : {Comp::PlayerContext, Comp::Rendering, Comp::Verification, Comp::Placement}) {
    const State s = gEntries[int(c)].state;
    anyGame |= s == State::Ok || s == State::Limited;
  }
  const State gui = gEntries[int(Comp::Gui)].state;
  if (gui == State::Failed) return Level::Unavailable;
  if (allOk) return Level::Full;
  const State core[2] = {gEntries[int(Comp::PlayerContext)].state, gEntries[int(Comp::Rendering)].state};
  if (core[0] == State::Pending || core[1] == State::Pending) return Level::Starting;
  if (!anyGame) return Level::Unavailable;
  (void)pending;
  return Level::Partial;
}

void setEnv(const Env &e) {
  std::lock_guard<std::mutex> lk(gMu);
  gRev.fetch_add(1);
  gEnv = e;
}
Env env() {
  std::lock_guard<std::mutex> lk(gMu);
  return gEnv;
}

const char *compKey(Comp c) {
  static const char *const k[kCount] = {"compat.c_gui",          "compat.c_parser",    "compat.c_loading",
                                        "compat.c_versions",     "compat.c_player",    "compat.c_rendering",
                                        "compat.c_verification", "compat.c_placement", "compat.c_player_ctx",
                                        "compat.c_hologram"};
  return (int(c) >= 0 && int(c) < kCount) ? k[int(c)] : "compat.c_gui";
}
const char *compName(Comp c) {
  static const char *const k[kCount] = {"GUI",       "Parser",       "Structure loading", "Versions",
                                        "ClientInstance update", "Rendering", "Verification", "Placement",
                                        "Player context",        "Hologram"};
  return (int(c) >= 0 && int(c) < kCount) ? k[int(c)] : "?";
}
const char *stateKey(State s) {
  switch (s) {
    case State::Ok: return "compat.s_ok";
    case State::Limited: return "compat.s_limited";
    case State::Failed: return "compat.s_failed";
    case State::Unavailable: return "compat.s_unavailable";
    default: return "compat.s_pending";
  }
}
const char *stateName(State s) {
  switch (s) {
    case State::Ok: return "OK";
    case State::Limited: return "LIMITED";
    case State::Failed: return "FAILED";
    case State::Unavailable: return "UNAVAILABLE";
    default: return "PENDING";
  }
}
const char *levelKey(Level l) {
  switch (l) {
    case Level::Full: return "compat.l_full";
    case Level::Partial: return "compat.l_partial";
    case Level::Unavailable: return "compat.l_unavailable";
    default: return "compat.l_starting";
  }
}
const char *levelName(Level l) {
  switch (l) {
    case Level::Full: return "full";
    case Level::Partial: return "partial";
    case Level::Unavailable: return "unavailable";
    default: return "starting";
  }
}

namespace {
struct ReasonInfo { const char *key, *action, *name; };
constexpr ReasonInfo kReasons[int(Reason::Count)] = {
    {"", nullptr, "-"},
    {"compat.r_build_not_tested", nullptr, "build not tested: functions checked by signature"},
    {"compat.r_version_unknown", nullptr, "game version not found in the library"},
    {"compat.r_library", "compat.a_restart", "game library not loaded"},
    {"compat.r_abi", "compat.a_abi", "game library is not arm64-v8a"},
    {"compat.r_sig_missing", "compat.a_update", "function not found in this game version"},
    {"compat.r_sig_ambiguous", "compat.a_update", "function found more than once (rejected)"},
    {"compat.r_validation", "compat.a_update", "function failed validation"},
    {"compat.r_hook", "compat.a_other_mods", "hook rejected"},
    {"compat.r_chained", nullptr, "installed on top of another mod's patch"},
    {"compat.r_needs_player", nullptr, "needs the player update"},
    {"compat.r_textures", nullptr, "block textures unavailable: solid colors"},
    {"compat.r_placement", "compat.a_update", "placement not validated for this game version"},
    {"compat.r_storage", "compat.a_storage", "structure folder not writable"},
    {"compat.r_parse", "compat.a_reinstall", "built-in structure could not be read"},
    {"compat.r_menu", "compat.a_restart", "LeviLauncher rejected the panel"},
    {"compat.r_not_required", nullptr, "optional: the player context comes from another validated source"},
    {"compat.r_no_context", nullptr, "no validated player context source"},
};
}  

const char *reasonKey(Reason r) { return (int(r) > 0 && int(r) < int(Reason::Count)) ? kReasons[int(r)].key : ""; }
const char *actionKey(Reason r) {
  return (int(r) > 0 && int(r) < int(Reason::Count)) ? kReasons[int(r)].action : nullptr;
}
const char *reasonName(Reason r) {
  return (int(r) >= 0 && int(r) < int(Reason::Count)) ? kReasons[int(r)].name : "?";
}

std::string diagnosticText(const std::string &modVersion, const std::string &signatureLines) {
  const Env e = env();
  std::string t;
  t += "Structura " + modVersion + "\n";
  t += "Minecraft version: " + (e.mc.raw.empty() ? std::string("unknown") : e.mc.raw) + "\n";
  t += "Normalized version: " + (e.mc.valid() ? ver::normalized(e.mc) : std::string("unknown")) + "\n";
  t += "Channel: " + std::string(e.mc.valid() ? ver::channelName(e.mc.channel) : "unknown") + "\n";
  t += "Build-id: " + (e.buildId.empty() ? std::string("none") : e.buildId) + (e.tested ? " (tested)" : " (not tested)") + "\n";
  t += "LeviLauncher version: " + (e.launcher.empty() ? std::string("unknown") : e.launcher) + "\n";
  t += "Android API: " + (e.androidApi > 0 ? std::to_string(e.androidApi) : std::string("unknown")) + "\n";
  t += "ABI: " + (e.abi.empty() ? std::string("unknown") : e.abi) +
       (e.deviceAbi.empty() ? std::string() : " (device " + e.deviceAbi + ")") + "\n";
  t += "Compatibility rule: " + (e.rule.empty() ? std::string("-") : e.rule) + "\n";
  t += "Compatibility: " + std::string(levelName(level())) + "\n";
  for (int i = 0; i < kCount; ++i) {
    const Entry en = get(Comp(i));
    t += std::string("  ") + compName(Comp(i)) + ": " + stateName(en.state);
    if (en.reason != Reason::None) t += " - " + std::string(reasonName(en.reason));
    if (!en.detail.empty()) t += " (" + en.detail + ")";
    t += "\n";
  }
  if (!signatureLines.empty()) t += "Signatures:\n" + signatureLines;
  return t;
}

}  
