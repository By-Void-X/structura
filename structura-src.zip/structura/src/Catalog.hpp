#pragma once



#include <cstdint>
#include <string>
#include <utility>
#include <vector>

#include "Library.hpp"

namespace lm::cat {

struct Material {
  std::string name, label;  
  uint32_t color = 0;       
  uint32_t count = 0;
};

struct Info {
  enum State : uint8_t { Pending = 0, Ready, Failed, TooLarge };
  State state = Pending;
  int sx = 0, sy = 0, sz = 0;
  uint32_t blocks = 0;          
  uint32_t kinds = 0;           
  std::vector<Material> top;    
  uint64_t thumbId = 0;         
};

inline constexpr int kThumb = 96;          
inline constexpr int kTopMaterials = 6;
inline constexpr long kMaxFileBytes = 8L << 20;  


void init(const std::string &dir);
void shutdown();


bool get(const std::string &path, Info &out, bool request = true);

uint64_t generation();

bool takeThumb(uint64_t &id, std::vector<uint8_t> &rgba);


void syncLibrary(const std::vector<lib::Entry> &entries, uint64_t revision);
int64_t mtime(const std::string &path);


bool isFavorite(const std::string &path);
void setFavorite(const std::string &path, bool on);
uint64_t listsGeneration();  
void touchRecent(const std::string &path);
std::vector<std::pair<std::string, int64_t>> recents();  
inline constexpr size_t kMaxRecent = 20;


void renamed(const std::string &from, const std::string &to);
void removed(const std::string &path);

}  
