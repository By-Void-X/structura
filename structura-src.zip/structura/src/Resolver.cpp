#include "Resolver.hpp"

#include <elf.h>
#include <fcntl.h>
#include <link.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string_view>
#include <unordered_map>
#include <vector>

#include "GameVersion.hpp"
#include "HookPatch.hpp"


namespace lm::rsv {
namespace {

constexpr const char *kGameLib = "libminecraftpe.so";

// Another mod's hook replaces the first bytes of a prologue. The patch length is measured from the live
// instruction words (HookPatch.hpp), never assumed; the rest of the signature must still match exactly.
constexpr size_t kScanSkip = hookpatch::kMaxPatch;  // scan fallback: compare only bytes no known patch touches
constexpr size_t kMinTailExact = 16;  


struct Off { const char *name; uintptr_t off; };

constexpr Off k12652[] = {
    {"RenderLevel", 0xb318478},          {"ClientInstanceUpdate", 0x98036a4},
    {"TessellatorBegin", 0xa76e7f8},     {"TessellatorColor", 0xa76edac},
    {"TessellatorVertex", 0xa76f048},    {"RenderMeshImmediately2", 0xb28402c},
    {"RenderMeshImmediately", 0xb2a37cc}, {"RenderMaterialGroupCommon", 0x997a740},
    {"BlockSourceGetBlock", 0xfb91918},  {"TessellateInWorld", 0xa6787dc},
    {"GetBlockTessellator", 0xb312810},  {"BTResetCache", 0xa6c73c4},
    {"BTSetBlockInCache", 0xa6cc8d0},    {"BlockRenderFlag", 0xb3485c0},
    {"BlockRegistryGetter", 0x103e33a8}, {"BlockLookupByName", 0x103e5c9c},
    {"FindBlockState", 0x1010957c},      {"ByteTagVtable", 0x11200c10},
    {"IntTagVtable", 0x11202470},        {"StringTagVtable", 0xced23e0},
    {"TessellatorClear", 0xa76e750},     {"TessellatorEndMesh", 0xa770d30},
    {"MeshRender", 0x10e4020c},          {"MeshDestroy", 0x10e3ca08},
    {"MatrixStackPush", 0x110afbc0},     {"MatrixRefPop", 0x110b01dc},
    {"BuildBlock", 0xf8a117c},           {"GameModeTick", 0xf8a38f0},
    {"SurvivalModeTick", 0xf8a42d0},     {"ItemBlockType", 0xfc74c70},
    {"HandItem", 0xf57a04c},             {"BaseUseItem", 0xf8a2eb0},
    {"SelectSlot", 0xf9eee98},
    // LocalPlayer::normalTick: the only reference in the binary is slot 25 of the LocalPlayer vtable
    // (+0x12d08f98, located through its RTTI "11LocalPlayer"), so `this` is always the local player.
    {"LocalPlayerNormalTick", 0xaac7dd8},
};
// LocalPlayer primary vtable of the tested build (RTTI: typeinfo +0x12d09fa8 -> "11LocalPlayer").
constexpr uintptr_t kLocalPlayerVt12652 = 0x12d08f98;
struct TestedBuild {
  const char *buildId;
  const char *label;
  const char *version;  
  const Off *offs;
  size_t count;
};
constexpr TestedBuild kTested[] = {
    {"56de9eed077631e03a31f4f58eb2f0e00071d335", "1.26.52 arm64", "1.26.52", k12652, sizeof(k12652) / sizeof(k12652[0])},
};

struct Region { uintptr_t start, end; bool exec; };

std::mutex gMu;
GameInfo gInfo;
std::vector<Region> gRegions;
const TestedBuild *gTested = nullptr;
std::unordered_map<std::string, Hit> gCache;  
std::unordered_map<std::string, int> gMissAt;  
std::unordered_map<std::string, Hit> gMissHit;  
int gAttempt = 0;


struct SigRecord {
  std::string name;
  int matches = 0;
  uintptr_t off = 0;
  Via via = Via::None;
  std::string rule, validation;
  compat::Reason reason = compat::Reason::None;
  int installed = -1;  
};
std::vector<SigRecord> gRecords;
SigRecord &record(const char *name) {
  for (auto &r : gRecords)
    if (r.name == name) return r;
  gRecords.push_back(SigRecord{});
  gRecords.back().name = name;
  return gRecords.back();
}


bool isHookTarget(const char *name) {
  static const char *const kHooks[] = {"RenderLevel",      "ClientInstanceUpdate", "BlockSourceGetBlock",
                                       "GameModeTick",     "SurvivalModeTick",     "BaseUseItem",
                                       "BuildBlock",       "LocalPlayerNormalTick"};
  for (const char *h : kHooks)
    if (std::strcmp(h, name) == 0) return true;
  return false;
}

uint32_t insnAt(uintptr_t a) {
  uint32_t v;
  std::memcpy(&v, reinterpret_cast<const void *>(a), 4);
  return v;
}


// Bytes of the prologue overwritten by a recognised hook patch (0 = not a known patch).
size_t patchLen(uintptr_t a) {
  uint32_t w[hookpatch::kMaxPatch / 4];
  std::memcpy(w, reinterpret_cast<const void *>(a), sizeof(w));
  return hookpatch::patchLength(w, sizeof(w) / 4);
}

// Original bytes of the game library at a live address, read from the mapped file itself (the path and
// file offset come from /proc/self/maps, so an uncompressed lib inside an APK works too). Used to prove
// that a patched prologue really is the function the signature describes.
enum class FileCheck : int { Unavailable = 0, Match, Mismatch };
bool readOriginal(uintptr_t a, uint8_t *out, size_t n) {
  int fd = open("/proc/self/maps", O_RDONLY | O_CLOEXEC);
  if (fd < 0) return false;
  std::string maps;
  char buf[4096];
  for (ssize_t r; (r = read(fd, buf, sizeof(buf))) > 0;) maps.append(buf, size_t(r));
  close(fd);
  size_t pos = 0;
  while (pos < maps.size()) {
    size_t eol = maps.find('\n', pos);
    if (eol == std::string::npos) eol = maps.size();
    const std::string line = maps.substr(pos, eol - pos);
    pos = eol + 1;
    unsigned long lo = 0, hi = 0, off = 0;
    char perms[8] = {};
    int path = 0;
    if (std::sscanf(line.c_str(), "%lx-%lx %7s %lx %*s %*s %n", &lo, &hi, perms, &off, &path) < 4 || !path) continue;
    if (a < lo || a + n > hi) continue;
    const char *file = line.c_str() + path;
    if (*file != '/') return false;
    const int f = open(file, O_RDONLY | O_CLOEXEC);
    if (f < 0) return false;
    const ssize_t got = pread(f, out, n, off_t(off + (a - lo)));
    close(f);
    return got == ssize_t(n);
  }
  return false;
}

struct Pat {
  std::vector<uint8_t> v, m;  
};
Pat parse(const char *s) {
  Pat p;
  std::string_view sv(s);
  size_t i = 0;
  auto hex = [](char c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; };
  while (i < sv.size()) {
    while (i < sv.size() && sv[i] == ' ') ++i;
    if (i >= sv.size()) break;
    size_t j = i;
    while (j < sv.size() && sv[j] != ' ') ++j;
    const std::string_view t = sv.substr(i, j - i);
    if (t == "?" || t == "??") { p.v.push_back(0); p.m.push_back(0); }
    else if (t.size() == 2 && hex(t[0]) >= 0 && hex(t[1]) >= 0) { p.v.push_back(uint8_t(hex(t[0]) * 16 + hex(t[1]))); p.m.push_back(0xFF); }
    else return Pat{};  
    i = j;
  }
  return p;
}

bool inExec(uintptr_t a, size_t n) {
  for (const auto &r : gRegions)
    if (r.exec && a >= r.start && a + n <= r.end) return true;
  return false;
}

bool matchAt(uintptr_t a, const Pat &p, size_t from) {
  if (p.v.empty() || !inExec(a, p.v.size())) return false;
  const auto *d = reinterpret_cast<const uint8_t *>(a);
  for (size_t i = from; i < p.v.size(); ++i)
    if (p.m[i] && d[i] != p.v[i]) return false;
  return true;
}


int scanTail(const Pat &p, size_t from, uintptr_t &first) {
  first = 0;
  
  size_t bs = 0, bl = 0;
  for (size_t i = from; i < p.v.size();) {
    if (!p.m[i]) { ++i; continue; }
    size_t j = i;
    while (j < p.v.size() && p.m[j]) ++j;
    if (j - i > bl) { bl = j - i; bs = i; }
    i = j;
  }
  if (bl < 4) return 0;
  int count = 0;
  for (const auto &r : gRegions) {
    if (!r.exec) continue;
    const auto *lo = reinterpret_cast<const uint8_t *>(r.start);
    const auto *hi = reinterpret_cast<const uint8_t *>(r.end);
    const uint8_t *q = lo + bs;
    while (q + (p.v.size() - bs) <= hi) {
      const void *f = memmem(q, size_t(hi - q), p.v.data() + bs, bl);
      if (!f) break;
      const auto *s = static_cast<const uint8_t *>(f) - bs;
      bool ok = s >= lo && s + p.v.size() <= hi;
      for (size_t i = from; ok && i < p.v.size(); ++i)
        if (p.m[i] && s[i] != p.v[i]) ok = false;
      if (ok) {
        if (!count) first = reinterpret_cast<uintptr_t>(s);
        if (++count >= 2) return count;
      }
      q = static_cast<const uint8_t *>(f) + 1;
    }
  }
  return count;
}

size_t exactCount(const Pat &p, size_t from) {
  size_t n = 0;
  for (size_t i = from; i < p.m.size(); ++i) n += p.m[i] != 0;
  return n;
}

FileCheck originalMatches(uintptr_t a, const Pat &p) {
  std::vector<uint8_t> b(p.v.size());
  if (!readOriginal(a, b.data(), b.size())) return FileCheck::Unavailable;
  for (size_t i = 0; i < p.v.size(); ++i)
    if (p.m[i] && b[i] != p.v[i]) return FileCheck::Mismatch;
  return FileCheck::Match;
}

// A prologue replaced by another mod's hook: the entry must be a recognised patch, every signature byte
// after the patch must still match, and the original bytes in the library file must not contradict the
// signature (when the file can be read they must match it completely).
struct HookedInfo { size_t len = 0; FileCheck file = FileCheck::Unavailable; };
bool hookedMatch(uintptr_t a, const Pat &p, HookedInfo &hi) {
  hi = HookedInfo{};
  if (!inExec(a, hookpatch::kMaxPatch)) return false;
  hi.len = patchLen(a);
  if (!hi.len || exactCount(p, hi.len) < kMinTailExact || !matchAt(a, p, hi.len)) return false;
  hi.file = originalMatches(a, p);
  return hi.file != FileCheck::Mismatch;
}
std::string hookedText(const HookedInfo &hi) {
  return "another mod's " + std::to_string(hi.len) + "-byte hook patch at the entry, " +
         (hi.file == FileCheck::Match ? "original bytes verified from the library file"
                                      : "library file not readable: tail after the patch verified");
}



std::string versionAt(const char *s, const char *hi) {
  size_t n = 0;
  while (s + n < hi && n < 40 && s[n] != '\0') ++n;
  if (s + n >= hi || s[n] != '\0' || n < 5) return {};
  ver::GameVersion v;
  return ver::parse(std::string_view(s, n), v) ? std::string(s, n) : std::string();
}

std::string findVersion() {
  for (const auto &r : gRegions) {
    const auto *lo = reinterpret_cast<const char *>(r.start);
    const auto *hi = reinterpret_cast<const char *>(r.end);
    static const char kKey[] = "Device model: ";  
    const char *q = lo;
    while (q < hi) {
      const void *f = memmem(q, size_t(hi - q), kKey, sizeof(kKey));
      if (!f) break;
      const char *s = static_cast<const char *>(f) + sizeof(kKey);
      if (s < hi) {
        std::string v = versionAt(s, hi);
        if (!v.empty()) return v;
      }
      q = static_cast<const char *>(f) + 1;
    }
  }
  
  for (const auto &r : gRegions) {
    const auto *lo = reinterpret_cast<const char *>(r.start);
    const auto *hi = reinterpret_cast<const char *>(r.end);
    static const char kKey[] = {'\0', '1', '.'};
    const char *q = lo;
    while (q < hi) {
      const void *f = memmem(q, size_t(hi - q), kKey, sizeof(kKey));
      if (!f) break;
      const char *s = static_cast<const char *>(f) + 1;
      std::string v = versionAt(s, hi);
      ver::GameVersion gv;
      if (!v.empty() && ver::parse(v, gv) && gv.parts == 4) return v;
      q = s;
    }
  }
  return {};
}

const char *abiName(unsigned machine) {
  switch (machine) {
    case EM_AARCH64: return "arm64-v8a";
    case EM_ARM: return "armeabi-v7a";
    case EM_X86_64: return "x86_64";
    case EM_386: return "x86";
    default: return "unknown";
  }
}

int phdrCb(dl_phdr_info *info, size_t, void *) {
  if (!info->dlpi_name || !std::strstr(info->dlpi_name, kGameLib)) return 0;
  gInfo.found = true;
  gInfo.base = info->dlpi_addr;
  for (int i = 0; i < info->dlpi_phnum; ++i) {
    const auto &ph = info->dlpi_phdr[i];
    if (ph.p_type == PT_LOAD && ph.p_offset == 0 && ph.p_vaddr == 0 && ph.p_filesz >= sizeof(ElfW(Ehdr)) &&
        gInfo.abi.empty()) {  
      const auto *eh = reinterpret_cast<const ElfW(Ehdr) *>(info->dlpi_addr);
      if (std::memcmp(eh->e_ident, ELFMAG, SELFMAG) == 0) {
        gInfo.abi = abiName(eh->e_machine);
        gInfo.abiOk = eh->e_machine == EM_AARCH64 && eh->e_ident[EI_CLASS] == ELFCLASS64;
      }
    }
    if (ph.p_type == PT_LOAD && (ph.p_flags & PF_R)) {
      const uintptr_t s = info->dlpi_addr + ph.p_vaddr;
      gRegions.push_back({s, s + ph.p_memsz, (ph.p_flags & PF_X) != 0});
    } else if (ph.p_type == PT_NOTE && gInfo.buildId.empty()) {
      auto *p = reinterpret_cast<const uint8_t *>(info->dlpi_addr + ph.p_vaddr);
      const uint8_t *end = p + ph.p_memsz;
      while (p + sizeof(ElfW(Nhdr)) <= end) {
        const auto *nh = reinterpret_cast<const ElfW(Nhdr) *>(p);
        const uint8_t *name = p + sizeof(ElfW(Nhdr));
        const uint8_t *desc = name + ((nh->n_namesz + 3) & ~3u);
        const uint8_t *next = desc + ((nh->n_descsz + 3) & ~3u);
        if (next > end) break;
        if (nh->n_type == NT_GNU_BUILD_ID && nh->n_namesz == 4 && std::memcmp(name, "GNU", 4) == 0) {
          static const char hx[] = "0123456789abcdef";
          for (uint32_t k = 0; k < nh->n_descsz; ++k) {
            gInfo.buildId += hx[desc[k] >> 4];
            gInfo.buildId += hx[desc[k] & 15];
          }
        }
        p = next;
      }
    }
  }
  return 1;
}

}  

bool refresh() {
  std::lock_guard<std::mutex> lk(gMu);
  if (gInfo.found && !gRegions.empty()) return true;  
  gInfo = GameInfo{};
  gRegions.clear();
  dl_iterate_phdr(&phdrCb, nullptr);
  if (!gInfo.found || gRegions.empty()) { gInfo = GameInfo{}; gRegions.clear(); return false; }
  gTested = nullptr;
  for (const auto &t : kTested)
    if (gInfo.buildId == t.buildId) gTested = &t;
  gInfo.tested = gTested ? gTested->label : nullptr;
  gInfo.version = findVersion();
  if (gInfo.version.empty() && gTested) gInfo.version = gTested->version;
  if (!gInfo.version.empty()) ver::parse(gInfo.version, gInfo.parsed);
  if (gInfo.abi.empty()) {  
#if defined(__aarch64__)
    gInfo.abi = "arm64-v8a";
    gInfo.abiOk = true;
#else
    gInfo.abi = "unknown";
#endif
  }
  gInfo.parsed.abi = gInfo.abi;
  return true;
}

const GameInfo &game() { return gInfo; }

void beginAttempt() {
  std::lock_guard<std::mutex> lk(gMu);
  ++gAttempt;
}

namespace {


bool validate(const char *name, uintptr_t a, bool headPatched, std::string &why) {
  if (!inExec(a, 16)) { why = "outside executable code"; return false; }
  if (a & 3) { why = "not aligned to an ARM64 instruction"; return false; }
  std::string v = "code region, aligned";
  if (headPatched) v += ", prologue patched by another mod (hook chained through it)";
  else v += ", prologue intact";
  if (isHookTarget(name) && !headPatched) {
    for (int k = 0; k < 4; ++k) {
      const uint32_t ik = insnAt(a + 4u * k);
      if (ik == 0xD65F03C0u || ik == 0u || (ik & 0xFFFF0000u) == 0u) {  
        why = "function too short for a 16-byte trampoline";
        return false;
      }
    }
    v += ", trampoline 16 bytes ok";
  }
  why = v;
  return true;
}
}  

Hit find(const char *name, const char *pattern) {
  std::lock_guard<std::mutex> lk(gMu);
  if (auto it = gCache.find(name); it != gCache.end()) return it->second;
  if (auto it = gMissAt.find(name); it != gMissAt.end() && it->second == gAttempt) return gMissHit[name];
  if (!gInfo.found) return {};
  SigRecord &rec = record(name);
  rec = SigRecord{};
  rec.name = name;
  const Pat p = parse(pattern);
  Hit h;
  std::string why;
  HookedInfo hooked;
  if (p.v.empty()) {
    h.why = compat::Reason::SignatureNotFound;
    rec.rule = "invalid pattern";
  } else if (!gInfo.abiOk) {
    h.why = compat::Reason::AbiIncompatible;
    rec.rule = "ABI " + gInfo.abi;
  } else if (gTested) {
    
    rec.rule = std::string("tested build-id (") + gTested->label + "): verified offset + signature";
    for (size_t i = 0; i < gTested->count && !h; ++i) {
      if (std::strcmp(gTested->offs[i].name, name) != 0) continue;
      const uintptr_t a = gInfo.base + gTested->offs[i].off;
      if (matchAt(a, p, 0)) h = {a, Via::TestedBuild, 1};
      else if (hookedMatch(a, p, hooked)) h = {a, Via::TestedBuildHooked, 1};
    }
    
  }
  if (!h && h.why == compat::Reason::None) {
    
    rec.rule = gTested ? rec.rule + "; not at the offset -> signature scan, exactly one match required"
                       : std::string("signature scan, exactly one match required");
    uintptr_t first = 0;
    const int n = scanTail(p, 0, first);
    if (n == 1) h = {first, Via::Signature, 1};
    else if (n >= 2) { h.matches = n; h.why = compat::Reason::SignatureAmbiguous; }
    else if (exactCount(p, kScanSkip) >= kMinTailExact) {
      // Maybe another mod hooked it: search with the bytes no known patch can touch, then require a
      // recognised patch at the candidate and the exact tail after that patch.
      const int t = scanTail(p, kScanSkip, first);
      if (t == 1 && hookedMatch(first, p, hooked)) h = {first, Via::SignatureHooked, 1};
      else if (t >= 2) { h.matches = t; h.why = compat::Reason::SignatureAmbiguous; }
      else h.why = compat::Reason::SignatureNotFound;
      if (!h) rec.rule += " (also checked for another mod's hook patch at the entry: none recognised)";
    } else {
      h.why = compat::Reason::SignatureNotFound;
    }
  }
  if (h) {
    const bool headPatched = h.via == Via::TestedBuildHooked || h.via == Via::SignatureHooked;
    if (!validate(name, h.addr, headPatched, why)) {
      h = Hit{0, Via::None, 1, compat::Reason::ValidationFailed};
    } else {
      if (headPatched) why += "; " + hookedText(hooked);
      for (const auto &kv : gCache)  
        if (kv.second.addr == h.addr && kv.first != name) {
          why = "same address as " + kv.first;
          h = Hit{0, Via::None, 1, compat::Reason::ValidationFailed};
          break;
        }
    }
  }
  rec.matches = h ? 1 : h.matches;
  rec.via = h.via;
  rec.off = h ? h.addr - gInfo.base : 0;
  rec.validation = h ? why : (h.why == compat::Reason::ValidationFailed ? why : std::string("-"));
  rec.reason = h ? (h.via == Via::TestedBuildHooked || h.via == Via::SignatureHooked ? compat::Reason::ChainedOtherMod
                                                                                     : compat::Reason::None)
                 : h.why;
  if (h) gCache[name] = h;
  else { gMissAt[name] = gAttempt; gMissHit[name] = h; }
  return h;
}

namespace {
bool readable(uintptr_t a, size_t n) {
  for (const auto &r : gRegions)
    if (a >= r.start && a + n <= r.end) return true;
  return false;
}
bool vtableIsLocked(uintptr_t vt, const char *mangled) {
  const size_t len = std::strlen(mangled) + 1;
  uintptr_t ti = 0, name = 0;
  if (!vt || (vt & 7) || !readable(vt - 8, 8)) return false;
  std::memcpy(&ti, reinterpret_cast<const void *>(vt - 8), 8);
  if (!ti || (ti & 7) || !readable(ti, 16)) return false;
  std::memcpy(&name, reinterpret_cast<const void *>(ti + 8), 8);
  if (!name || !readable(name, len)) return false;
  int64_t top = 0;
  if (!readable(vt - 16, 8)) return false;
  std::memcpy(&top, reinterpret_cast<const void *>(vt - 16), 8);
  return top == 0 && std::memcmp(reinterpret_cast<const void *>(name), mangled, len) == 0;
}
// Every 8-byte aligned word equal to `value` in the non-executable mapped segments of the game library.
template <class F>
void forEachPointerTo(uintptr_t value, F &&f) {
  for (const auto &r : gRegions) {
    if (r.exec) continue;
    for (uintptr_t a = (r.start + 7) & ~uintptr_t(7); a + 8 <= r.end; a += 8) {
      uintptr_t v;
      std::memcpy(&v, reinterpret_cast<const void *>(a), 8);
      if (v == value && !f(a)) return;
    }
  }
}
struct VtCache { uintptr_t vt = 0; int state = 0; std::string how; };  // state: 0 not tried, 1 found, -1 not
std::unordered_map<std::string, VtCache> gVt;
}  // namespace

bool vtableIs(uintptr_t vt, const char *mangled) {
  std::lock_guard<std::mutex> lk(gMu);
  return vtableIsLocked(vt, mangled);
}

uintptr_t classVtable(const char *mangled, uintptr_t testedOff, std::string *how) {
  std::lock_guard<std::mutex> lk(gMu);
  VtCache &c = gVt[mangled];
  if (c.state == 0 && gInfo.found) {
    c.state = -1;
    c.how = std::string("RTTI for ") + mangled + " not found";
    if (gTested && testedOff && vtableIsLocked(gInfo.base + testedOff, mangled)) {
      c.vt = gInfo.base + testedOff;
      c.state = 1;
      c.how = "tested offset, verified through its RTTI";
    } else {
      // name string -> typeinfo (name pointer at +8) -> primary vtable (typeinfo pointer at -8, offset-to-top 0)
      const size_t len = std::strlen(mangled) + 1;
      std::vector<uintptr_t> found;
      for (const auto &r : gRegions) {
        const auto *lo = reinterpret_cast<const char *>(r.start), *hi = reinterpret_cast<const char *>(r.end);
        for (const char *q = lo; q < hi;) {
          const void *f = memmem(q, size_t(hi - q), mangled, len);
          if (!f) break;
          const char *str = static_cast<const char *>(f);
          q = str + 1;
          if (str == lo || str[-1] != '\0') continue;
          forEachPointerTo(reinterpret_cast<uintptr_t>(str), [&](uintptr_t at) {
            forEachPointerTo(at - 8, [&](uintptr_t slot) {
              const uintptr_t vt = slot + 8;
              if (vtableIsLocked(vt, mangled) && std::find(found.begin(), found.end(), vt) == found.end())
                found.push_back(vt);
              return found.size() < 4;
            });
            return found.size() < 4;
          });
        }
      }
      if (found.size() == 1) {
        c.vt = found[0];
        c.state = 1;
        c.how = "found through its RTTI";
      } else if (found.size() > 1) {
        c.how = std::string("RTTI for ") + mangled + " ambiguous (" + std::to_string(found.size()) + " vtables)";
      }
    }
  }
  if (how) *how = c.how;
  return c.state == 1 ? c.vt : 0;
}

uintptr_t localPlayerVtable(std::string *how) { return classVtable("11LocalPlayer", kLocalPlayerVt12652, how); }

bool vtableContains(uintptr_t vt, uintptr_t fn, int maxSlots) {
  std::lock_guard<std::mutex> lk(gMu);
  for (int k = 0; k < maxSlots; ++k) {
    const uintptr_t a = vt + 8u * unsigned(k);
    if (!readable(a, 8)) return false;
    uintptr_t v;
    std::memcpy(&v, reinterpret_cast<const void *>(a), 8);
    if (v == fn) return true;
  }
  return false;
}

void markHook(const char *name, bool installed) {
  std::lock_guard<std::mutex> lk(gMu);
  SigRecord &r = record(name);
  r.installed = installed ? 1 : 0;
  if (!installed && r.reason == compat::Reason::None) r.reason = compat::Reason::HookRejected;
  if (installed && r.reason == compat::Reason::HookRejected) r.reason = compat::Reason::None;
}

compat::Comp componentOf(const char *name) {
  using C = compat::Comp;
  struct M { const char *n; C c; };
  static const M kMap[] = {
      {"ClientInstanceUpdate", C::PlayerUpdate}, {"BlockSourceGetBlock", C::Verification},
      {"BuildBlock", C::Placement},  {"GameModeTick", C::Placement}, {"SurvivalModeTick", C::Placement},
      {"ItemBlockType", C::Placement}, {"HandItem", C::Placement}, {"BaseUseItem", C::Placement},
      {"SelectSlot", C::Placement},   {"LocalPlayerNormalTick", C::PlayerContext},
  };
  for (const auto &m : kMap)
    if (std::strcmp(m.n, name) == 0) return m.c;
  return C::Rendering;  
}

std::string signatureLines() {
  std::lock_guard<std::mutex> lk(gMu);
  std::string out;
  char addr[32];
  for (const auto &r : gRecords) {
    std::snprintf(addr, sizeof(addr), "+%#lx", static_cast<unsigned long>(r.off));
    out += "  " + r.name + ": component=" + compat::compName(componentOf(r.name.c_str())) + ", version rule=" + r.rule +
           ", matches=" + std::to_string(r.matches) + ", address=" + (r.off ? std::string(addr) : std::string("-")) +
           ", validation=" + r.validation + ", installed=" +
           (r.installed < 0 ? "n/a" : r.installed ? "yes" : "no") + ", failure reason=" + compat::reasonName(r.reason) +
           "\n";
  }
  return out;
}

compat::Reason componentFailure(compat::Comp c, std::string *detail) {
  std::lock_guard<std::mutex> lk(gMu);
  for (const auto &r : gRecords) {
    if (componentOf(r.name.c_str()) != c) continue;
    if (r.reason != compat::Reason::None && r.reason != compat::Reason::ChainedOtherMod) {
      if (detail) *detail = r.name + (r.matches > 1 ? ": " + std::to_string(r.matches) + "+ matches" : std::string());
      return r.reason;
    }
  }
  return compat::Reason::None;
}

void injectForTest(uintptr_t base, const std::vector<TestRegion> &regions, const char *buildId) {
  std::lock_guard<std::mutex> lk(gMu);
  gInfo = GameInfo{};
  gInfo.found = true;
  gInfo.base = base;
  gInfo.buildId = buildId ? buildId : "";
  gInfo.abi = "arm64-v8a";
  gInfo.abiOk = true;
  gRegions.clear();
  for (const auto &r : regions) gRegions.push_back({r.start, r.end, r.exec});
  gTested = nullptr;
  for (const auto &t : kTested)
    if (gInfo.buildId == t.buildId) gTested = &t;
  gInfo.tested = gTested ? gTested->label : nullptr;
  gCache.clear();
  gMissAt.clear();
  gMissHit.clear();
  gRecords.clear();
  gVt.clear();
}

void resetForTest() {
  std::lock_guard<std::mutex> lk(gMu);
  gInfo = GameInfo{};
  gRegions.clear();
  gTested = nullptr;
  gCache.clear();
  gMissAt.clear();
  gMissHit.clear();
  gRecords.clear();
  gVt.clear();
}

const char *viaText(Via v) {
  switch (v) {
    case Via::TestedBuild: return "tested build";
    case Via::TestedBuildHooked: return "tested build, already hooked by another mod";
    case Via::Signature: return "signature";
    case Via::SignatureHooked: return "signature, already hooked by another mod";
    default: return "-";
  }
}

}  
