#include "Library.hpp"

#include <dirent.h>
#include <cerrno>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <cctype>
#include <climits>
#include <functional>
#include <set>

#include "JavaFormats.hpp"
#include "Structure.hpp"

namespace lm::lib {
namespace {

bool isDir(const std::string &p) {
  struct stat st{};
  return stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

bool endsWithCi(const std::string &s, const char *suf) {
  const size_t n = std::strlen(suf);
  if (s.size() < n) return false;
  for (size_t i = 0; i < n; ++i)
    if (std::tolower(uint8_t(s[s.size() - n + i])) != suf[i]) return false;
  return true;
}




bool looksLikeStructure(const std::string &path, bool trusted = false) {
  std::ifstream f(path, std::ios::binary | std::ios::ate);
  if (!f) return false;
  const std::streamoff total = f.tellg();
  if (total < 16) return false;
  f.seekg(0);
  std::string head(size_t(std::min<std::streamoff>(total, 65536)), '\0');
  f.read(head.data(), std::streamsize(head.size()));
  const uint8_t b0 = uint8_t(head[0]), b1 = uint8_t(head[1]);
  if (b0 == 0x1F && b1 == 0x8B) return true;  
  if (b0 != 0x0A) return false;
  if (trusted) return true;
  std::string tail;
  if (total > std::streamoff(head.size())) {
    const std::streamoff n = std::min<std::streamoff>(total - std::streamoff(head.size()), 65536);
    tail.resize(size_t(n));
    f.seekg(total - n);
    f.read(tail.data(), std::streamsize(n));
  }
  for (const char *k : {"format_version", "block_indices", "block_palette", "structure_world_origin",
                        // Java formats (uncompressed files; gzip ones were accepted above)
                        "BlockStatePalette", "BlockData", "DataVersion", "palette", "Palette"})
    if (head.find(k) != std::string::npos || tail.find(k) != std::string::npos) return true;
  return false;
}

std::string stem(const std::string &name) {
  const auto d = name.rfind('.');
  return d == std::string::npos ? name : name.substr(0, d);
}

// every format loadStructure() reads (Java formats are converted on load)
bool supportedName(const std::string &n) {
  for (const char *e : {".mcstructure", ".litematic", ".schem", ".schematic", ".nbt"})
    if (endsWithCi(n, e)) return true;
  return false;
}

std::string gNotes;  

std::vector<std::string> listDir(const std::string &dir) {
  std::vector<std::string> out;
  DIR *d = opendir(dir.c_str());
  if (!d) {
    if (errno != ENOENT && gNotes.size() < 600)
      gNotes += (gNotes.empty() ? "" : "; ") + dir + ": " + std::strerror(errno);
    return out;
  }
  while (dirent *e = readdir(d)) {
    if (e->d_name[0] == '.') continue;
    out.emplace_back(e->d_name);
  }
  closedir(d);
  std::sort(out.begin(), out.end());
  return out;
}

void collect(const std::string &dir, int depth, const std::string &source, std::vector<Entry> &out,
             std::set<std::string> &seen) {
  if (depth < 0 || out.size() >= 800) return;
  for (const auto &n : listDir(dir)) {
    const std::string p = dir + "/" + n;
    if (supportedName(n)) {
      if (isDir(p) || !looksLikeStructure(p, source == "Mine")) continue;
      char real[PATH_MAX];
      const std::string key = realpath(p.c_str(), real) ? std::string(real) : p;
      if (seen.insert(key).second) out.push_back({stem(n), p, source});
    } else if (depth > 0 && n != "db" && isDir(p)) {
      collect(p, depth - 1, source, out, seen);
    }
  }
}


std::vector<std::string> findMojangRoots(const std::string &myDir) {
  std::set<std::string> roots;
  auto addIf = [&](const std::string &p) {
    if (isDir(p + "/behavior_packs") || isDir(p + "/minecraftWorlds") || isDir(p + "/development_behavior_packs"))
      roots.insert(p);
  };
  
  for (const auto &fd : listDir("/proc/self/fd")) {
    char buf[PATH_MAX];
    const ssize_t n = readlink(("/proc/self/fd/" + fd).c_str(), buf, sizeof(buf) - 1);
    if (n <= 0) continue;
    std::string t(buf, size_t(n));
    const auto k = t.find("/games/com.mojang");
    if (k != std::string::npos) addIf(t.substr(0, k + 17));
  }
  
  std::string pkg;
  {
    std::ifstream f("/proc/self/cmdline");
    std::getline(f, pkg, '\0');
    const auto c = pkg.find(':');
    if (c != std::string::npos) pkg.resize(c);
  }
  std::vector<std::string> bases = {"/storage/emulated/0/games/com.mojang"};
  if (!pkg.empty()) {
    for (const char *pre : {"/storage/emulated/0/Android/media/", "/storage/emulated/0/Android/data/",
                            "/data/data/", "/data/user/0/"})
      bases.push_back(std::string(pre) + pkg);
  }
  
  if (!myDir.empty()) {
    std::string p = myDir;
    for (int i = 0; i < 6; ++i) {
      const auto s = p.rfind('/');
      if (s == std::string::npos || s == 0) break;
      p.resize(s);
      bases.push_back(p);
    }
  }
  std::function<void(const std::string &, int)> walk = [&](const std::string &d, int depth) {
    if (depth < 0) return;
    if (d.size() > 17 && d.compare(d.size() - 17, 17, "/games/com.mojang") == 0) { addIf(d); return; }
    for (const auto &n : listDir(d)) {
      if (n == "minecraftWorlds" || n == "cache" || n == "code_cache" || n == "lib" || n == "shader_cache") continue;
      const std::string p = d + "/" + n;
      if (isDir(p)) walk(p, depth - 1);
    }
  };
  for (const auto &b : bases) {
    addIf(b);
    if (isDir(b)) walk(b, 5);
  }
  return {roots.begin(), roots.end()};
}

}  

std::vector<Entry> scan(const std::string &myDir, bool includeDownloads, bool includePacks,
                        std::vector<std::string> *rootsFound) {
  std::vector<Entry> out;
  std::set<std::string> seen;
  gNotes.clear();
  collect(myDir, 2, "Mine", out, seen);
  if (includeDownloads) {
    collect("/storage/emulated/0/Download", 2, "Download", out, seen);
    collect("/storage/emulated/0/Documents", 2, "Documents", out, seen);
  }
  if (!includePacks) return out;  
  const auto roots = findMojangRoots(myDir);
  if (rootsFound) *rootsFound = roots;
  for (const auto &r : roots) {
    for (const char *packs : {"/behavior_packs", "/development_behavior_packs"})
      for (const auto &pk : listDir(r + packs)) collect(r + packs + "/" + pk + "/structures", 4, "Pack", out, seen);
    for (const auto &w : listDir(r + "/minecraftWorlds")) {
      const std::string wb = r + "/minecraftWorlds/" + w + "/behavior_packs";
      for (const auto &pk : listDir(wb)) collect(wb + "/" + pk + "/structures", 4, "World", out, seen);
    }
    collect(r + "/structures", 2, "com.mojang", out, seen);
  }
  return out;
}

std::string scanNotes() { return gNotes; }

std::string uniquePath(const std::string &dir, const std::string &base, const std::string &ext) {
  std::string clean;
  for (char c : base) clean.push_back((c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"' ||
                                       c == '<' || c == '>' || c == '|') ? '_' : c);
  if (clean.empty()) clean = "structure";
  std::string p = dir + "/" + clean + ext;
  for (int i = 2; access(p.c_str(), F_OK) == 0 && i < 1000; ++i) p = dir + "/" + clean + " (" + std::to_string(i) + ")" + ext;
  return p;
}

std::string importFile(const std::string &src, const std::string &displayName, const std::string &myDir,
                       std::string &err) {
  Structure test;
  LoadInfo info;
  if (!loadStructure(src, test, err, &info)) {
    err = "invalid file: " + err;
    return {};
  }
  mkdir(myDir.c_str(), 0775);
  // keep the real format: a Java file stays a Java file (converted again on every load)
  const char *ext = java::extensionFor(info.format);
  if (!*ext) ext = ".mcstructure";
  std::string base = displayName.empty() ? std::string("imported") : displayName;
  if (supportedName(base) || base.rfind('.') != std::string::npos) base = stem(base);
  const std::string dst = uniquePath(myDir, base, ext);
  bool opened = false, wrote = false;
  {
    std::ifstream in(src, std::ios::binary);
    std::ofstream out(dst, std::ios::binary | std::ios::trunc);
    opened = in && out;
    if (opened) {
      out << in.rdbuf();
      wrote = bool(out);
    }
  }  // streams closed here
  if (!opened || !wrote) {
    std::remove(dst.c_str());  // never leave a truncated copy in the library
    err = opened ? "write failed" : "copy failed";
    return {};
  }
  return dst;
}

}  
