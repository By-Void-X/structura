#include "Diag.hpp"
#include "Overlay.hpp"
#include "Progress.hpp"
#include "Transformed.hpp"

#include <algorithm>
#include <cstdio>
#include <mutex>

#include "Compat.hpp"
#include "EasyPlace.hpp"
#include "I18n.hpp"
#include "PlayerContext.hpp"
#include "State.hpp"

namespace lm::diag {
namespace {

std::mutex gMu;
Snapshot gSnap;
std::atomic<bool> gRequest{true};
std::atomic<uint64_t> gRev{0};
int64_t gLastBuild = 0;
uint64_t gMemAvail = 0;
int64_t gMemAt = 0;

std::string num(uint64_t v) { return std::to_string(v); }
const char *stageKey(hs::Stage s) {
  static const char *k[] = {"diag.st_open",  "diag.st_nbt",       "diag.st_dims",  "diag.st_palette", "diag.st_indices",
                            "diag.st_count", "diag.st_transform", "diag.st_world", "diag.st_render",  "diag.st_materials",
                            "diag.st_cache", "diag.st_visible",   "diag.st_done"};
  const int i = int(s);
  return i >= 0 && i < hs::kStageCount ? k[i] : "diag.st_open";
}
std::string mb(uint64_t bytes) {
  char b[32];
  std::snprintf(b, sizeof(b), "%llu MB", (unsigned long long)(bytes >> 20));
  return b;
}
std::string kb(uint64_t bytes) {
  char b[32];
  if (bytes >= (1u << 20)) std::snprintf(b, sizeof(b), "%.1f MB", double(bytes) / (1024.0 * 1024.0));
  else std::snprintf(b, sizeof(b), "%llu KB", (unsigned long long)((bytes + 1023) / 1024));
  return b;
}

void put(RowData &r, DSt st, const char *key, std::vector<std::string> args = {}, std::string detail = {},
         std::string error = {}, uint64_t gen = 0) {
  r.st = st;
  r.msgKey = key;
  r.args = std::move(args);
  r.detail = std::move(detail);
  r.error = std::move(error);
  r.gen = gen;
}

struct LoadCopy {
  uint64_t seq = 0;
  bool busy = false;
  std::string path, title, error;
  hs::LoadErr err = hs::LoadErr::None;
  int failedStage = -1;
  uint64_t fileBytes = 0, rawBytes = 0, memEstimate = 0, memAvail = 0;
  int sx = 0, sy = 0, sz = 0;
  size_t palette = 0, indices = 0, solid = 0, air = 0, voids = 0, variants = 0;
  std::string indicesType;
  size_t stOk = 0, stDirectional = 0, stMulti = 0, stUnknown = 0, stDiscarded = 0, stDiscardedVariants = 0;
  size_t stPreserved = 0, stRaw = 0;
  size_t stWaterlogged = 0, stBlockEntities = 0;
  std::string stUnknownKeys, stDiscardedKeys;
  int st[hs::kStageCount]{};
  int64_t startedMs = 0, endedMs = 0;
};

LoadCopy copyLoad() {
  auto &L = hs::load();
  std::lock_guard<std::mutex> lk(L.mu);
  LoadCopy c;
  c.seq = L.seq; c.busy = L.busy; c.path = L.path; c.title = L.title; c.error = L.error; c.err = L.err;
  c.failedStage = L.failedStage; c.fileBytes = L.fileBytes; c.rawBytes = L.rawBytes; c.memEstimate = L.memEstimate;
  c.memAvail = L.memAvail; c.sx = L.sx; c.sy = L.sy; c.sz = L.sz; c.palette = L.palette; c.indices = L.indices;
  c.solid = L.solid; c.air = L.air; c.voids = L.voids; c.variants = L.variants; c.indicesType = L.indicesType;
  c.stOk = L.stOk; c.stDirectional = L.stDirectional; c.stMulti = L.stMulti; c.stUnknown = L.stUnknown;
  c.stDiscarded = L.stDiscarded; c.stDiscardedVariants = L.stDiscardedVariants; c.stWaterlogged = L.stWaterlogged;
  c.stBlockEntities = L.stBlockEntities; c.stUnknownKeys = L.stUnknownKeys; c.stDiscardedKeys = L.stDiscardedKeys;
  c.stPreserved = L.stPreserved; c.stRaw = L.stRaw;
  for (int i = 0; i < hs::kStageCount; ++i) c.st[i] = L.st[i];
  c.startedMs = L.startedMs; c.endedMs = L.endedMs;
  return c;
}

// Generic mapping for one load stage.
void loadStageRow(RowData &r, const LoadCopy &L, hs::Stage s, const char *okKey, std::vector<std::string> okArgs,
                  std::string okDetail) {
  if (L.seq == 0) { put(r, DSt::Waiting, "diag.m_no_file"); return; }
  const hs::SSt v = hs::SSt(L.st[int(s)]);
  switch (v) {
    case hs::SSt::Pending: put(r, L.busy ? DSt::Waiting : DSt::NotChecked, L.busy ? "diag.m_waiting" : "diag.m_not_checked"); break;
    case hs::SSt::Running: put(r, DSt::Loading, "diag.m_loading"); break;
    case hs::SSt::Ok: put(r, DSt::Ok, okKey, std::move(okArgs), std::move(okDetail)); break;
    case hs::SSt::Warning: put(r, DSt::Warning, okKey, std::move(okArgs), std::move(okDetail)); break;
    case hs::SSt::Failed:
      put(r, DSt::Failed, "diag.m_failed_stage", {i18n::tr(stageKey(s))}, hs::loadErrName(L.err), L.error);
      break;
    case hs::SSt::Skipped: put(r, DSt::NotChecked, "diag.m_skipped"); break;
    case hs::SSt::Cancelled: put(r, DSt::Cancelled, "diag.m_cancelled", {}, L.error); break;
  }
}

const char *whyKey(hs::Why w) {
  switch (w) {
    case hs::Why::HologramOff: return "diag.w_hidden";
    case hs::Why::NoStructure: return "diag.w_no_structure";
    case hs::Why::NotPlaced: return "diag.w_not_placed";
    case hs::Why::NoPlayer: return "diag.w_no_player";
    case hs::Why::NoWorld: return "diag.w_no_world";
    case hs::Why::WorldChanged: return "diag.w_world_changed";
    case hs::Why::DimensionChanged: return "diag.w_dim_changed";
    case hs::Why::NoRenderFrame: return "diag.w_no_frame";
    case hs::Why::RenderDataInvalid: return "diag.w_render_invalid";
    case hs::Why::RenderContextChanged: return "diag.w_context";
    case hs::Why::Resumed: return "diag.w_resumed";
    case hs::Why::MaterialsMissing: return "diag.w_materials";
    case hs::Why::TexturesUnavailable: return "diag.w_textures";
    case hs::Why::BuildStalled: return "diag.w_stalled";
    case hs::Why::MemoryLimit: return "diag.w_memory";
    case hs::Why::Cancelled: return "diag.w_cancelled";
    case hs::Why::OutOfRange: return "diag.w_out_of_range";
    case hs::Why::RetryLimit: return "diag.w_retry_limit";
    case hs::Why::Settling: return "diag.w_settling";
    case hs::Why::HookMissing: return "diag.w_hook_missing";
    case hs::Why::StructureChanged: return "diag.w_structure_changed";
    case hs::Why::NoContextSource: return "diag.w_no_context";
    default: return "";
  }
}

DSt holoDSt(hs::HState s) {
  switch (s) {
    case hs::HState::NoStructureLoaded: return DSt::Waiting;
    case hs::HState::StructureLoading: return DSt::Loading;
    case hs::HState::StructureLoaded: return DSt::Ready;
    case hs::HState::WaitingForWorld:
    case hs::HState::WaitingForPlayer:
    case hs::HState::WaitingForRender: return DSt::Waiting;
    case hs::HState::PreparingHologram: return DSt::Loading;
    case hs::HState::HologramReady: return DSt::Ready;
    case hs::HState::HologramVisible: return DSt::Active;
    case hs::HState::HologramFailed: return DSt::Failed;
    case hs::HState::HologramCancelled: return DSt::Cancelled;
    default: return DSt::NotChecked;
  }
}

void build(Snapshot &S) {
  const int64_t now = hs::monoMs();
  auto &st = status();
  auto &R = hs::rt();
  auto &m = model();
  const LoadCopy L = copyLoad();
  const Phase phase = st.phase.load();
  const bool starting = phase == Phase::WaitingGame || phase == Phase::Settling || phase == Phase::Installing;
  if (!gMemAt || now - gMemAt > 2000) {
    gMemAvail = hs::memAvailable();
    gMemAt = now;
  }
  // model snapshot (brief lock, UI thread)
  bool hasS = false, placed = false, pending = false;
  int sx = 0, sy = 0, sz = 0, rot = 0;
  bool mirror = false;
  uint32_t solid = 0;
  uint64_t gen = 0;
  std::string title;
  {
    std::lock_guard<std::mutex> lk(m.mu);
    if (m.structure) {
      hasS = true;
      sx = m.structure->sx; sy = m.structure->sy; sz = m.structure->sz;
      solid = m.structure->solidCount;
      title = m.structure->title;
    }
    placed = m.placed;
    pending = m.wantPlace;
    rot = m.placement.rot;
    mirror = m.placement.mirror;
    gen = m.gen;
  }
  const uint64_t wEp = R.worldEpoch.load(), dEp = R.dimEpoch.load(), rEp = R.renderEpoch.load(), bGen = R.buildGen.load();
  const int64_t lastHook = R.lastHookMs.load();
  const bool frames = lastHook && now - lastHook < 1500;
  hs::Why why = hs::Why::None;
  const hs::HState hsNow = hs::overall(&why);
  S.state = hsNow;
  S.why = why;

  RowData *row = S.rows;
  // ---- File
  {
    RowData &r = row[int(Row::File)];
    if (L.seq == 0 && !hasS) put(r, DSt::Waiting, "diag.m_no_file");
    else if (L.seq == 0 && hasS) put(r, DSt::Ok, "diag.m_file_ok", {title, "-"});
    else loadStageRow(r, L, hs::Stage::Open, "diag.m_file_ok", {L.title, kb(L.fileBytes)},
                      L.rawBytes && L.rawBytes != L.fileBytes ? "gzip, " + kb(L.rawBytes) + " NBT" : "");
  }
  // ---- Parser (NBT + self-check)
  {
    RowData &r = row[int(Row::Parser)];
    const compat::Entry pe = compat::get(compat::Comp::Parser);
    if (pe.state == compat::State::Failed) put(r, DSt::Failed, "diag.m_parser_selfcheck", {}, pe.detail, "self-check failed");
    else if (L.seq == 0) put(r, hasS ? DSt::Ok : DSt::Waiting, hasS ? "diag.m_nbt_ok" : "diag.m_no_file");
    else loadStageRow(r, L, hs::Stage::Nbt, "diag.m_nbt_ok", {}, "");
  }
  // ---- Palette
  loadStageRow(row[int(Row::Palette)], L, hs::Stage::Palette, "diag.m_palette_ok", {num(L.palette), num(L.variants)}, "");
  if (L.seq == 0 && hasS) put(row[int(Row::Palette)], DSt::Ok, "diag.m_ok");
  // ---- Block indices
  loadStageRow(row[int(Row::Indices)], L, hs::Stage::Indices, "diag.m_indices_ok", {num(L.indices)},
               L.indicesType.empty() ? std::string() : "type " + L.indicesType + ", air " + num(L.air) + ", void " + num(L.voids));
  if (L.seq == 0 && hasS) put(row[int(Row::Indices)], DSt::Ok, "diag.m_ok");
  // ---- Block states: "OK / Directional / Multi-block / Unknown / Discarded states"
  {
    RowData &r = row[int(Row::States)];
    std::string d = "states preserved " + num(L.stPreserved) + ", raw (kept, not reproducible) " + num(L.stRaw) +
                    ", waterlogged " + num(L.stWaterlogged) + ", block entities " + num(L.stBlockEntities) +
                    " (not placed by Easy Place)";
    if (L.stDiscardedVariants) d += ", variants over the limit " + num(L.stDiscardedVariants);
    if (!L.stUnknownKeys.empty()) d += ", unknown keys: " + L.stUnknownKeys;
    if (!L.stDiscardedKeys.empty()) d += ", discarded keys: " + L.stDiscardedKeys;
    const std::vector<std::string> a = {num(L.stOk), num(L.stDirectional), num(L.stMulti), num(L.stUnknown),
                                        num(L.stDiscarded)};
    const bool bad = L.stDiscarded || L.stDiscardedVariants;
    loadStageRow(r, L, hs::Stage::Palette, "diag.m_states", a, d);
    if (r.st == DSt::Ok && (bad || L.stUnknown || L.stRaw)) r.st = DSt::Warning;
    if (L.seq == 0 && hasS) put(r, DSt::Ok, "diag.m_ok");
  }
  // ---- Structure
  {
    RowData &r = row[int(Row::Structure)];
    const hs::SSt dimSt = hs::SSt(L.st[int(hs::Stage::Dimensions)]), cntSt = hs::SSt(L.st[int(hs::Stage::CountSolid)]);
    char d[96];
    std::snprintf(d, sizeof(d), "rot %d, mirror %s, gen %llu", rot * 90, mirror ? "on" : "off", (unsigned long long)gen);
    if (L.busy) put(r, DSt::Loading, "diag.m_loading", {}, "", "", gen);
    else if (L.seq && (dimSt == hs::SSt::Failed || cntSt == hs::SSt::Failed))
      put(r, DSt::Failed, "diag.m_failed_stage", {i18n::tr(stageKey(dimSt == hs::SSt::Failed ? hs::Stage::Dimensions : hs::Stage::CountSolid))},
          hs::loadErrName(L.err), L.error, gen);
    else if (!hasS) put(r, DSt::Waiting, "diag.m_no_structure");
    else if (!placed && pending) put(r, DSt::Waiting, "diag.m_place_pending", {title}, d, "", gen);
    else if (!placed) put(r, DSt::Warning, "diag.m_not_placed", {title}, d, "", gen);
    else put(r, DSt::Ok, "diag.m_structure_ok", {title, num(sx) + "x" + num(sy) + "x" + num(sz), num(solid)}, d, "", gen);
  }
  // ---- ClientInstance update (optional source) and player context
  const bool anyCtx = ctx::anySource();
  const ctx::View cv = ctx::view(ctx::monoMs());
  const ctx::Stats cs = ctx::stats();
  const bool ctxStale = cv.player && (!cv.fresh || R.ctxStale.load());
  auto srcTr = [](ctx::Source s) { return std::string(i18n::tr(ctx::sourceKey(s))); };
  std::string sources;
  for (ctx::Source s : {ctx::Source::UpdateHook, ctx::Source::GameModeTick, ctx::Source::LocalPlayerTick}) {
    const int k = int(s);
    if (!sources.empty()) sources += "; ";
    sources += std::string(ctx::sourceName(s)) + ": " + (ctx::installed(s) ? "hooked" : "unavailable");
    const std::string dt = ctx::detail(s);
    if (!dt.empty()) sources += " (" + dt + ")";
    if (ctx::installed(s)) {
      sources += ", accepted " + num(cs.accepted[k]) + ", observed " + num(cs.observed[k]) + ", rejected " + num(cs.rejected[k]);
      if (cs.lastReject[k] != ctx::Reject::None) sources += std::string(" (last: ") + ctx::rejectName(cs.lastReject[k]) + ")";
    }
  }
  {
    RowData &r = row[int(Row::Update)];
    const compat::Entry e = compat::get(compat::Comp::PlayerUpdate);
    const bool hk = ctx::installed(ctx::Source::UpdateHook);
    const std::string d = ctx::detail(ctx::Source::UpdateHook);
    if (!hk && starting) put(r, DSt::Waiting, "diag.m_starting");
    else if (hk && e.reason == compat::Reason::ChainedOtherMod) put(r, DSt::Ok, "diag.m_upd_chained", {}, d);
    else if (hk) put(r, DSt::Ok, "diag.m_upd_ok", {}, d);
    else if (anyCtx) {
      const ctx::Source fb = ctx::installed(ctx::Source::GameModeTick) ? ctx::Source::GameModeTick : ctx::Source::LocalPlayerTick;
      put(r, DSt::NotAvailable, "diag.m_upd_optional", {srcTr(fb)}, d.empty() ? e.detail : d);
    } else put(r, DSt::NotAvailable, "diag.m_upd_unavail", {}, d.empty() ? e.detail : d, compat::reasonName(e.reason));
  }
  {
    RowData &r = row[int(Row::Player)];
    std::string d = "sources: " + sources + "; generation " + num(cv.generation) + ", drops " + num(cs.drops);
    if (!cs.lastDrop.empty()) d += " (last: " + cs.lastDrop + ")";
    if (cv.at) d += ", last update " + num(uint64_t(std::max<int64_t>(0, ctx::monoMs() - cv.at))) + " ms ago";
    if (starting && !anyCtx) put(r, DSt::Waiting, "diag.m_starting");
    else if (!anyCtx) put(r, DSt::NotAvailable, "diag.m_ctx_none", {}, d, compat::reasonName(compat::Reason::NoContextSource));
    else if (cv.player && !ctxStale) {
      char p[64];
      std::snprintf(p, sizeof(p), "%.0f %.0f %.0f", st.feetX.load(), st.feetY.load(), st.feetZ.load());
      put(r, DSt::Ok, "diag.m_ctx_ok", {srcTr(cv.source), p}, d, "", cv.generation);
    } else if (cv.player) put(r, DSt::Ready, "diag.m_ctx_paused", {srcTr(cv.source)}, d, "", cv.generation);
    else put(r, DSt::Waiting, "diag.m_ctx_wait", {}, d, "", cv.generation);
  }
  // ---- World
  {
    RowData &r = row[int(Row::World)];
    const int stable = R.stableFrames.load();
    std::string d = "epoch " + num(wEp) + (st.hasGetBlock.load() ? "" : ", block reads unavailable");
    if (starting) put(r, DSt::Waiting, "diag.m_starting");
    else if (!anyCtx) put(r, DSt::NotAvailable, "diag.m_ctx_none", {}, d, "", wEp);
    else if (!frames) put(r, DSt::Waiting, !cv.player ? "diag.m_world_wait" : "diag.m_no_frames", {}, d, "", wEp);
    else if (!R.worldValid.load()) put(r, DSt::Waiting, "diag.m_world_wait", {}, d, "", wEp);
    else if (ctxStale) put(r, DSt::Ready, "diag.m_world_paused", {}, d, "", wEp);
    else if (stable < 10) put(r, DSt::Loading, "diag.m_world_settling", {}, d, "", wEp);
    else if (!st.hasGetBlock.load()) put(r, DSt::Warning, "diag.m_world_noverify", {}, d, "", wEp);
    else put(r, DSt::Ok, "diag.m_world_ok", {}, d, "", wEp);
  }
  // ---- Dimension
  {
    RowData &r = row[int(Row::Dimension)];
    const std::string d = "changes " + num(dEp);
    if (starting) put(r, DSt::Waiting, "diag.m_starting");
    else if (!anyCtx) put(r, DSt::NotAvailable, "diag.m_ctx_none");
    else if (!frames || !cv.player) put(r, DSt::Waiting, "diag.m_world_wait", {}, d, "", dEp);
    else if (!R.dimValid.load()) put(r, DSt::Warning, "diag.m_dim_unknown", {}, d, "", dEp);
    else put(r, DSt::Ok, "diag.m_dim_ok", {num(dEp)}, d, "", dEp);
  }
  // ---- Render hook
  {
    RowData &r = row[int(Row::RenderHook)];
    const compat::Entry e = compat::get(compat::Comp::Rendering);
    if (st.hkRender.load()) {
      const std::string d = "renderLevel, calls " + num(st.renderCalls.load()) + ", RenderMesh ABI " + num(st.renderMeshAbi.load());
      if (frames) put(r, DSt::Active, "diag.m_hook_active", {}, d);
      else put(r, DSt::Ready, "diag.m_hook_idle", {}, d);
    } else if (starting) put(r, DSt::Waiting, "diag.m_starting");
    else put(r, DSt::Failed, "diag.m_hook_failed", {}, e.detail, compat::reasonName(e.reason));
  }
  // ---- Render context
  {
    RowData &r = row[int(Row::RenderContext)];
    const int lw = R.lastInvalidateWhy.load();
    const int64_t li = R.lastInvalidateMs.load();
    std::string d = "epoch " + num(rEp) + ", rebuilds " + num(R.invalidations.load());
    if (li) d += ", last: " + std::string(hs::whyName(hs::Why(lw))) + " " + num(uint64_t(std::max<int64_t>(0, now - li) / 1000)) + " s ago";
    if (R.eglAbandoned.load()) d += ", GL context replaced";
    if (!st.hkRender.load()) put(r, starting ? DSt::Waiting : DSt::NotAvailable, starting ? "diag.m_starting" : "diag.m_hook_failed");
    else if (!frames) put(r, DSt::Waiting, "diag.m_no_frames", {}, d, "", rEp);
    else if (!R.renderValid.load()) put(r, DSt::Waiting, "diag.m_render_invalid", {}, d, "", rEp);
    else put(r, DSt::Ok, "diag.m_render_ok", {}, d, "", rEp);
  }
  // ---- Materials
  {
    RowData &r = row[int(Row::Materials)];
    const int ln = R.matLine.load(), fc = R.matFace.load();
    const std::string d = std::string("line ") + (ln == 1 ? "ok" : ln == 2 ? "retrying" : ln == 3 ? "missing" : "-") +
                          ", face " + (fc == 1 ? "ok" : fc == 2 ? "missing" : "-") + ", attempts " + num(uint64_t(R.matAttempts.load()));
    const bool failedMat = hsNow == hs::HState::HologramFailed && why == hs::Why::MaterialsMissing;
    if (ln == 0 && fc == 0) put(r, DSt::NotChecked, "diag.m_not_checked");
    else if (failedMat) put(r, DSt::Failed, "diag.m_mat_failed", {}, d, "no usable material", rEp);
    else if (ln == 1 && fc == 1) put(r, DSt::Ok, "diag.m_ok", {}, d, "", rEp);
    else if (ln == 1 || fc == 1) put(r, DSt::Warning, "diag.m_mat_partial", {}, d, "", rEp);
    else put(r, DSt::Loading, "diag.m_mat_retry", {}, d, "", rEp);
  }
  // ---- Textures
  {
    RowData &r = row[int(Row::Textures)];
    const int tx = R.matTex.load();
    const uint32_t ok = st.texVarOk.load(), tot = st.texVarTotal.load();
    const uint32_t res = R.texResolved.load(), all = R.texTotal.load();
    const std::string d = "variants " + num(ok) + "/" + num(tot) + ", stage " + num(uint64_t(std::max(0, st.texStage.load()))) +
                          ", missing functions " + num(uint64_t(st.texSigMissing.load()));
    if (st.texSigMissing.load() > 0 && st.hkRender.load()) put(r, DSt::NotAvailable, "diag.m_tex_unavailable", {}, d);
    else if (tx == 0) put(r, DSt::NotChecked, "diag.m_not_checked");
    else if (hsNow == hs::HState::PreparingHologram && all && res < all)
      put(r, DSt::Loading, "diag.m_tex_resolving", {num(res), num(all)}, d, "", bGen);
    else if (tx == 2) put(r, DSt::Loading, "diag.m_mat_retry", {}, d, "", rEp);
    else if (tx == 3) put(r, DSt::Warning, "diag.m_tex_fallback", {}, d, "", rEp);
    else if (tot && ok < tot) put(r, DSt::Warning, "diag.m_tex_partial", {num(tot - ok)}, d, "", bGen);
    else put(r, DSt::Ok, "diag.m_tex_ok", {num(ok)}, d, "", bGen);
  }
  // ---- Hologram
  {
    RowData &r = row[int(Row::Hologram)];
    const uint32_t done = R.prepDone.load(), total = R.prepTotal.load();
    const uint32_t res = R.texResolved.load(), all = R.texTotal.load();
    std::string d = std::string(hs::stateName(hsNow)) + (why != hs::Why::None ? std::string(" (") + hs::whyName(why) + ")" : "") +
                    ", build gen " + num(bGen) + ", cancelled " + num(R.cancelled.load()) + ", failures " + num(R.failures.load());
    S.progress = -1;
    S.processed = S.remaining = S.batches = 0;
    if (hsNow == hs::HState::PreparingHologram) {
      if (all && res < all) {
        S.progress = int(uint64_t(res) * 50 / all);
        S.processed = res; S.remaining = all - res;
      } else if (total) {
        S.progress = 50 + int(uint64_t(done) * 50 / total);
        S.processed = done; S.remaining = total - done;
      } else S.progress = 0;
      S.batches = R.prepBatches.load();
    }
    const char *wk = whyKey(why);
    std::vector<std::string> a;
    if (hsNow == hs::HState::PreparingHologram) a = {num(uint64_t(std::max(0, S.progress)))};
    const char *key = "diag.m_ok";
    switch (hsNow) {
      case hs::HState::NoStructureLoaded: key = "diag.h_none"; break;
      case hs::HState::StructureLoading: key = "diag.h_loading"; break;
      case hs::HState::StructureLoaded: key = why == hs::Why::HologramOff ? "diag.h_hidden" : "diag.h_loaded"; break;
      case hs::HState::WaitingForWorld: key = "diag.h_wait_world"; break;
      case hs::HState::WaitingForPlayer: key = "diag.h_wait_player"; break;
      case hs::HState::WaitingForRender: key = "diag.h_wait_render"; break;
      case hs::HState::PreparingHologram: key = "diag.h_preparing"; break;
      case hs::HState::HologramReady: key = why == hs::Why::OutOfRange ? "diag.h_out_of_range" : "diag.h_ready"; break;
      case hs::HState::HologramVisible: key = "diag.h_visible"; break;
      case hs::HState::HologramFailed: key = "diag.h_failed"; break;
      case hs::HState::HologramCancelled: key = "diag.h_cancelled"; break;
      default: break;
    }
    DSt ds = holoDSt(hsNow);
    if (hsNow == hs::HState::HologramVisible && (why == hs::Why::MemoryLimit || why == hs::Why::TexturesUnavailable)) ds = DSt::Warning;
    put(r, ds, key, a, d, hsNow == hs::HState::HologramFailed && *wk ? std::string(hs::whyName(why)) : std::string(), bGen);
    if (*wk && hsNow != hs::HState::NoStructureLoaded) r.detail = std::string(i18n::tr(wk)) + " - " + r.detail;
    S.canRetryHologram = hsNow == hs::HState::HologramFailed && st.hkRender.load();
  }
  // ---- Easy Place (independent of the hologram)
  {
    RowData &r = row[int(Row::EasyPlace)];
    const compat::Entry e = compat::get(compat::Comp::Placement);
    const char *dr = ep::disabledReason();
    const ep::Stats es = ep::stats();
    std::string ed = e.detail + (e.detail.empty() ? "" : "; ") + "mode " + ep::modeText() + ", placed " +
                     num(es.placed) + ", exact " + num(es.exact) + ", state mismatch " + num(es.mismatch) +
                     ", corrected " + num(es.corrected) + ", failed " + num(es.failed) + ", unsupported " +
                     num(es.unsupported) + ", skipped " + num(es.skipped);
    if (st.hkEasyPlace.load()) put(r, ep::state().enabled.load() ? DSt::Active : DSt::Ready,
                                   ep::state().enabled.load() ? "diag.m_ep_on" : "diag.m_ep_ready", {}, ed);
    else if (starting) put(r, DSt::Waiting, "diag.m_starting");
    else put(r, DSt::NotAvailable, "diag.m_ep_off", {}, dr ? dr : e.detail, compat::reasonName(e.reason));
  }
  // ---- Transformation (shared rotation/mirror table)
  {
    RowData &r = row[int(Row::Transform)];
    const xf::Stats x = xf::stats();
    std::string d = "rot " + num(uint64_t(x.rot * 90)) + ", mirror " + (x.mirror ? "on" : "off") + ", changed " +
                    num(x.changed) + ", raw " + num(x.raw) + ", builds " + num(x.builds);
    if (!x.firstUnsupported.empty()) d += "; e.g. " + x.firstUnsupported;
    const std::vector<std::string> a = {num(x.variants), num(x.directional), num(x.unsupported)};
    if (!hasS) put(r, DSt::Waiting, "diag.m_no_structure");
    else if (!x.ready) put(r, DSt::Loading, "diag.m_loading");
    else put(r, x.unsupported ? DSt::Warning : DSt::Ok, "diag.m_xf", a, d);
  }
  // ---- Verification (Easy Place read-back)
  {
    RowData &r = row[int(Row::Verify)];
    const ep::Stats es = ep::stats();
    const std::vector<std::string> a = {num(es.exact), num(es.mismatch), num(es.failed)};
    const std::string d = "placed " + num(es.placed) + ", skipped " + num(es.skipped) + ", unsupported " +
                          num(es.unsupported) + ", mode " + ep::modeText();
    if (es.placed == 0) put(r, DSt::NotChecked, "diag.m_not_checked", {}, d);
    else put(r, es.mismatch || es.failed ? DSt::Warning : DSt::Ok, "diag.m_verify", a, d);
  }
  // ---- Progress model + layer model
  {
    RowData &rp = row[int(Row::Progress)];
    RowData &rl = row[int(Row::Layers)];
    std::shared_ptr<CompareData> C;
    std::shared_ptr<const Structure> Sp;
    Placement P;
    int layer = 0;
    {
      std::lock_guard<std::mutex> lk(m.mu);
      C = m.compare;
      Sp = m.structure;
      P = m.placement;
      layer = m.layer;
    }
    if (!Sp) {
      put(rp, DSt::Waiting, "diag.m_no_structure");
      put(rl, DSt::Waiting, "diag.m_no_structure");
    } else if (!placed || !C || C->S != Sp) {
      put(rp, DSt::Waiting, "diag.m_progress_wait");
      put(rl, DSt::Waiting, "diag.m_progress_wait");
    } else {
      const progress::Counts c = progress::overall(*C);
      char pc[16];
      std::snprintf(pc, sizeof pc, "%.1f%%", c.percent());
      std::string d = "missing " + num(c.s[PMissing]) + ", not checked " + num(c.s[PNotChecked]) + ", placing " +
                      num(c.s[PPlacing]) + ", incorrect " + num(c.s[PIncorrect]) + ", skipped " +
                      num(c.s[PSkipped]) + ", unsupported " + num(c.s[PUnsupported]) + ", failed " +
                      num(c.s[PFailed]) + ", extra " + num(c.extra) + ", gen " + num(C->gen);
      put(rp, DSt::Active, "diag.m_progress", {num(c.done()), num(c.total), pc}, d, "", C->gen);
      const int axis = std::clamp(settings().layerAxis.load(), 0, 2);
      const int n = progress::layerCount(*Sp, P, axis);
      static const char *kAx[3] = {"X", "Y", "Z"};
      if (n <= 0) put(rl, DSt::Failed, "diag.m_failed", {}, "empty box");
      else {
        const int L = std::clamp(layer, 0, n - 1);
        progress::Counts lc;
        const bool ok = progress::layerCounts(*C, *Sp, P, axis, L, lc);
        const std::string w = std::string(kAx[axis]) + "=" + std::to_string(progress::layerWorld(*Sp, P, axis, L));
        put(rl, ok ? DSt::Ok : DSt::Warning, "diag.m_layers", {num(uint64_t(n)), kAx[axis], w},
            "layer " + std::to_string(L + 1) + ": " + num(lc.done()) + "/" + num(lc.total) + ", mode " +
                std::to_string(settings().layerMode.load()));
      }
    }
  }
  // ---- Progress UI + touch input
  {
    RowData &r = row[int(Row::ProgressUi)];
    const std::string u = overlay::uiStatus();
    if (u == "Active") put(r, DSt::Active, "diag.m_ov_active");
    else if (u == "Hidden") put(r, DSt::Ready, "diag.m_ov_hidden");
    else if (u == "Waiting") put(r, DSt::Waiting, "diag.m_no_structure");
    else put(r, DSt::Ready, "diag.m_ov_off");
    RowData &t = row[int(Row::Touch)];
    const std::string ts = overlay::touchStatus();
    const std::vector<std::string> a = {num(overlay::touchesConsumed())};
    if (ts == "Active") put(t, DSt::Active, "diag.m_touch", a);
    else if (ts == "OK") put(t, DSt::Ok, "diag.m_touch", a);
    else put(t, DSt::NotChecked, "diag.m_not_checked");
  }
  // ---- UI
  {
    RowData &r = row[int(Row::Ui)];
    const compat::Entry e = compat::get(compat::Comp::Gui);
    if (e.state == compat::State::Ok) put(r, DSt::Ok, "diag.m_ok");
    else if (e.state == compat::State::Pending) put(r, DSt::Waiting, "diag.m_starting");
    else if (e.state == compat::State::Limited) put(r, DSt::Warning, "diag.m_ui_limited", {}, e.detail, compat::reasonName(e.reason));
    else put(r, DSt::Failed, "diag.m_ui_failed", {}, e.detail, compat::reasonName(e.reason));
  }
  // ---- Memory
  {
    RowData &r = row[int(Row::Memory)];
    const uint32_t meshes = R.meshCount.load();
    std::string d = "available " + (gMemAvail ? mb(gMemAvail) : std::string("unknown")) + ", meshes " + num(meshes) + "/6000";
    if (L.memEstimate) d += ", last load needs ~" + mb(L.memEstimate);
    if (L.err == hs::LoadErr::MemoryLimit) put(r, DSt::Failed, "diag.m_mem_load", {}, d, L.error);
    else if (R.meshCapped.load()) put(r, DSt::Warning, "diag.m_mem_capped", {}, d);
    else if (gMemAvail && gMemAvail < (300ull << 20)) put(r, DSt::Warning, "diag.m_mem_low", {mb(gMemAvail)}, d);
    else if (!gMemAvail) put(r, DSt::NotAvailable, "diag.m_mem_unknown", {}, d);
    else put(r, DSt::Ok, "diag.m_mem_ok", {mb(gMemAvail)}, d);
  }
  // ---- Current operation
  {
    RowData &r = row[int(Row::Operation)];
    if (L.busy) put(r, DSt::Loading, "diag.o_loading", {L.title});
    else if (hsNow == hs::HState::PreparingHologram)
      put(r, DSt::Loading, "diag.o_preparing", {num(uint64_t(std::max(0, S.progress))), num(S.processed), num(S.remaining), num(S.batches)});
    else if (hsNow == hs::HState::WaitingForWorld || hsNow == hs::HState::WaitingForPlayer || hsNow == hs::HState::WaitingForRender)
      put(r, DSt::Waiting, "diag.o_waiting", {i18n::tr(*whyKey(why) ? whyKey(why) : "diag.w_settling")});
    else if (starting) put(r, DSt::Waiting, "diag.m_starting");
    else if (hsNow == hs::HState::HologramFailed) put(r, DSt::Failed, "diag.o_failed");
    else put(r, DSt::Ok, "diag.o_idle");
  }
  S.canRetryLoad = !L.busy && L.seq && L.failedStage >= 0 && L.err != hs::LoadErr::Cancelled && !L.path.empty();
  S.loadPath = L.path;
}

}  // namespace

std::string message(const RowData &r) {
  const std::string_view pat = i18n::tr(r.msgKey);
  std::string out;
  out.reserve(pat.size() + 16);
  for (size_t i = 0; i < pat.size(); ++i) {
    if (pat[i] == '{' && i + 2 < pat.size() && pat[i + 2] == '}' && pat[i + 1] >= '0' && pat[i + 1] <= '9') {
      const size_t n = size_t(pat[i + 1] - '0');
      if (n < r.args.size()) out += r.args[n];
      i += 2;
      continue;
    }
    out += pat[i];
  }
  if (out.empty()) out = statusName(r.st);  // never blank
  return out;
}

void requestRefresh() { gRequest.store(true); }
uint64_t revision() { return gRev.load(); }

void refresh(bool force) {
  const int64_t now = hs::monoMs();
  const bool req = gRequest.exchange(false);
  if (!force && !req && now - gLastBuild < 250) return;
  gLastBuild = now;
  Snapshot fresh;
  build(fresh);
  std::lock_guard<std::mutex> lk(gMu);
  // keep the "changed at" time per row unless status or message changed
  for (int i = 0; i < kRows; ++i) {
    const RowData &o = gSnap.rows[i];
    RowData &n = fresh.rows[i];
    n.changedMs = (o.changedMs && o.st == n.st && o.msgKey == n.msgKey && o.args == n.args) ? o.changedMs : now;
  }
  fresh.builtMs = now;
  fresh.revision = gRev.fetch_add(1) + 1;
  gSnap = std::move(fresh);
}

Snapshot snapshot() {
  std::lock_guard<std::mutex> lk(gMu);
  return gSnap;
}

const char *statusKey(DSt s) {
  static const char *k[] = {"diag.s_waiting", "diag.s_loading", "diag.s_ok",        "diag.s_ready",     "diag.s_active",
                            "diag.s_warning", "diag.s_failed",  "diag.s_cancelled", "diag.s_not_avail", "diag.s_not_checked"};
  const int i = int(s);
  return i >= 0 && i < int(DSt::Count) ? k[i] : "diag.s_not_checked";
}
const char *statusName(DSt s) {
  static const char *k[] = {"Waiting", "Loading", "OK", "Ready", "Active", "Warning", "Failed", "Cancelled", "Not available", "Not checked"};
  const int i = int(s);
  return i >= 0 && i < int(DSt::Count) ? k[i] : "Not checked";
}
const char *rowKey(Row r) {
  static const char *k[] = {"diag.r_file",      "diag.r_parser",    "diag.r_palette",  "diag.r_indices",   "diag.r_states",
                            "diag.r_structure",
                            "diag.r_update",    "diag.r_player",    "diag.r_world",     "diag.r_dimension", "diag.r_render_hook", "diag.r_render_ctx",
                            "diag.r_materials", "diag.r_textures",  "diag.r_hologram", "diag.r_easyplace",
                            "diag.r_transform", "diag.r_verify",   "diag.r_progress", "diag.r_layers",
                            "diag.r_progress_ui", "diag.r_touch",  "diag.r_ui",
                            "diag.r_memory",    "diag.r_operation"};
  const int i = int(r);
  return i >= 0 && i < kRows ? k[i] : "diag.r_operation";
}
const char *rowName(Row r) {
  static const char *k[] = {"File",          "Parser",         "Palette",   "Block indices", "Block states", "Structure",
                            "ClientInstance update",          "Player context",
                            "World",         "Dimension",      "Render hook", "Render context", "Materials", "Textures",
                            "Hologram",      "Easy Place",
                            "Transformation", "Verification", "Progress model", "Layer model", "Progress UI",
                            "Touch input",    "UI",        "Memory",        "Current operation"};
  const int i = int(r);
  return i >= 0 && i < kRows ? k[i] : "?";
}
const char *stateKey(hs::HState s) {
  switch (s) {
    case hs::HState::NoStructureLoaded: return "diag.h_none";
    case hs::HState::StructureLoading: return "diag.h_loading";
    case hs::HState::StructureLoaded: return "diag.h_loaded";
    case hs::HState::WaitingForWorld: return "diag.h_wait_world";
    case hs::HState::WaitingForPlayer: return "diag.h_wait_player";
    case hs::HState::WaitingForRender: return "diag.h_wait_render";
    case hs::HState::PreparingHologram: return "diag.h_preparing";
    case hs::HState::HologramReady: return "diag.h_ready";
    case hs::HState::HologramVisible: return "diag.h_visible";
    case hs::HState::HologramFailed: return "diag.h_failed";
    case hs::HState::HologramCancelled: return "diag.h_cancelled";
    default: return "diag.h_none";
  }
}

std::string states() {
  const auto &st = status();
  std::string t;
  auto add = [&](const char *n) { t += (t.empty() ? "" : ", ") + std::string(n); };
  if (compat::get(compat::Comp::Parser).state == compat::State::Ok) add("ParserReady");
  if (st.hkEasyPlace.load() && compat::get(compat::Comp::Placement).state == compat::State::Ok) add("PlacementReady");
  if (st.hkRender.load()) add("RenderHookReady");
  const int64_t now = ctx::monoMs();
  const ctx::View v = ctx::view(now);
  if (!ctx::anySource()) add("PlayerContextUnavailable");
  else if (v.player) add(v.fresh && !hs::rt().ctxStale.load() ? "PlayerContextReady" : "PlayerContextPaused");
  else add("PlayerContextWaiting");
  hs::Why why = hs::Why::None;
  switch (hs::overall(&why)) {
    case hs::HState::WaitingForPlayer: add("HologramWaitingForContext"); break;
    case hs::HState::WaitingForWorld: add("HologramWaitingForWorld"); break;
    case hs::HState::WaitingForRender: add("HologramWaitingForRender"); break;
    case hs::HState::PreparingHologram: add("HologramPreparing"); break;
    case hs::HState::HologramReady: add("HologramReady"); break;
    case hs::HState::HologramVisible: add("HologramVisible"); break;
    case hs::HState::HologramFailed: add("HologramFailed"); break;
    default: break;
  }
  if (compat::level() == compat::Level::Partial) add("PartialMode");
  return t;
}

std::string text() {
  refresh(true);
  const Snapshot s = snapshot();
  std::string t = "States: " + states() + "\n";
  t += "Hologram state: " + std::string(hs::stateName(s.state));
  if (s.why != hs::Why::None) t += " (" + std::string(hs::whyName(s.why)) + ")";
  if (s.progress >= 0) t += " " + std::to_string(s.progress) + "%";
  t += "\nDiagnostics:\n";
  const int64_t now = hs::monoMs();
  for (int i = 0; i < kRows; ++i) {
    const RowData &r = s.rows[i];
    t += "  " + std::string(rowName(Row(i))) + ": " + statusName(r.st) + " - " + message(r);
    if (!r.detail.empty()) t += " | " + r.detail;
    if (!r.error.empty()) t += " | error: " + r.error;
    t += " | " + std::to_string(std::max<int64_t>(0, now - r.changedMs) / 1000) + " s, gen " + std::to_string(r.gen) + "\n";
  }
  // Easy Place: last placements with their verification
  const auto rec = ep::recent();
  if (!rec.empty()) {
    t += "Easy Place (mode " + std::string(ep::modeText()) + "), last placements:\n";
    for (const auto &e : rec)
      t += "  Placement: " + e.status + " | Block: " + e.block + " | Position: " + std::to_string(e.x) + " " +
           std::to_string(e.y) + " " + std::to_string(e.z) + " | Expected state: " + e.expected +
           " | Actual state: " + e.actual + " | Correction attempt: " + e.correction + " | Result: " + e.result +
           "\n";
  }
  return t;
}

}  // namespace lm::diag
