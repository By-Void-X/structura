#pragma once
// Java Edition structure formats -> Bedrock .mcstructure tree.
//
// Supported: structure-block .nbt (Java), Litematica .litematic, Sponge .schem (v1/v2/v3) and MCEdit/Schematica
// .schematic (legacy numeric ids). The file is parsed as big-endian NBT by the caller; toBedrock() converts it
// into the same NBT tree a Bedrock .mcstructure has (size / structure / block_indices / palette), so the regular
// loader (palette, states, waterlogging, transforms, Easy Place) handles it with no second code path.
//
// Block states are mapped with a table generated at build time (tools/gen_java_map.py) from
// PrismarineJS/minecraft-data blocksJ2B (Java state -> Bedrock state) and legacy.json (MCEdit id:meta -> Java).
#include <cstddef>
#include <string>
#include <utility>
#include <vector>

#include "Nbt.hpp"

namespace lm::java {

struct Stats {
  std::string format;          // "litematic", "sponge-v2", "mcedit", "java-nbt", ...
  int dataVersion = 0;         // Java DataVersion of the file (0 = unknown)
  size_t paletteEntries = 0;   // distinct Java block states in the file
  size_t approx = 0;           // states mapped by the closest match (a property the table doesn't know)
  size_t unmapped = 0;         // Java blocks with no Bedrock equivalent (kept by name, never placed blindly)
  size_t blockEntities = 0;    // chest contents, signs text, ... (not converted)
  std::string unmappedNames;   // first few, for the diagnostics
};

// true when the tree looks like one of the Java formats above
bool isJavaFormat(const nbt::Tag &root);

// Converts a Java (big-endian parsed) tree to a Bedrock .mcstructure tree. false + err on invalid data.
bool toBedrock(const nbt::Tag &root, nbt::Tag &out, Stats &st, std::string &err);

// Maps one Java block state ("minecraft:oak_stairs[facing=east,half=bottom]") to a Bedrock palette entry
// compound {name, states}. exact = every property matched a table entry. false = block unknown to the table.
bool mapState(const std::string &javaName, std::vector<std::pair<std::string, std::string>> props,
              nbt::Tag &entry, bool &exact);
bool mapStateString(const std::string &javaState, nbt::Tag &entry, bool &exact);

// MCEdit legacy id:meta -> Java state string ("" when unknown)
std::string legacyState(int id, int meta);

// file extension used when a converted file is stored in the library ("" = unknown)
const char *extensionFor(const std::string &format);

}  // namespace lm::java
