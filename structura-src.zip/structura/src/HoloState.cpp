#include "HoloState.hpp"

#include <cstdio>
#include <cstring>
#include <time.h>

#include "PlayerContext.hpp"
#include "State.hpp"

namespace lm::hs {

namespace {
Runtime gRt;
LoadShared gLoad;
std::atomic<uint64_t> gLoadSeq{0};
std::atomic<int> gLoadBusy{0};
}  // namespace

Runtime &rt() { return gRt; }
LoadShared &load() { return gLoad; }
std::atomic<uint64_t> &loadSeq() { return gLoadSeq; }
std::atomic<int> &loadBusy() { return gLoadBusy; }

int64_t monoMs() {
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return int64_t(ts.tv_sec) * 1000 + ts.tv_nsec / 1000000;
}

void setRenderState(HState s, Why w) {
  auto &r = gRt;
  const int si = int(s), wi = int(w);
  if (r.renderState.load(std::memory_order_relaxed) != si) {
    r.renderState.store(si, std::memory_order_relaxed);
    r.stateSinceMs.store(monoMs(), std::memory_order_relaxed);
  }
  if (r.why.load(std::memory_order_relaxed) != wi) r.why.store(wi, std::memory_order_relaxed);
}

void setStage(Stage s, SSt v) {
  const int i = int(s);
  if (i < 0 || i >= kStageCount) return;
  if (gRt.st[i].load(std::memory_order_relaxed) != int(v)) {
    gRt.st[i].store(int(v), std::memory_order_relaxed);
    gRt.at[i].store(monoMs(), std::memory_order_relaxed);
  }
}

void resetRenderStages() {
  for (int i = int(Stage::WaitWorld); i < kStageCount; ++i) gRt.st[i].store(int(SSt::Pending), std::memory_order_relaxed);
}

HState overall(Why *why) {
  auto set = [&](HState s, Why w) {
    if (why) *why = w;
    return s;
  };
  if (gLoadBusy.load(std::memory_order_acquire)) return set(HState::StructureLoading, Why::None);
  auto &m = model();
  if (gRt.renderState.load(std::memory_order_relaxed) == int(HState::HologramCancelled) &&
      monoMs() - gRt.stateSinceMs.load(std::memory_order_relaxed) < 3000 &&
      (!m.live.load(std::memory_order_acquire) || !settings().hologram.load(std::memory_order_relaxed)))
    return set(HState::HologramCancelled, Why::Cancelled);
  if (!m.hasStructure.load(std::memory_order_acquire)) return set(HState::NoStructureLoaded, Why::NoStructure);
  auto &st = status();
  if (!st.hkRender.load()) return set(HState::HologramFailed, Why::HookMissing);
  if (!settings().hologram.load(std::memory_order_relaxed)) return set(HState::StructureLoaded, Why::HologramOff);
  const bool ctxAny = ctx::anySource();
  const bool player = st.player.load(std::memory_order_relaxed) != 0;
  if (!m.live.load(std::memory_order_acquire)) {
    if (m.pendingPlace.load(std::memory_order_acquire))
      return set(!player ? HState::WaitingForPlayer : HState::WaitingForWorld,
                 !ctxAny ? Why::NoContextSource : Why::NotPlaced);
    return set(HState::StructureLoaded, Why::NotPlaced);
  }
  if (!ctxAny) return set(HState::WaitingForPlayer, Why::NoContextSource);
  const int64_t last = gRt.lastHookMs.load(std::memory_order_relaxed);
  if (!last || monoMs() - last > 1500) {
    if (!player) return set(HState::WaitingForPlayer, Why::NoPlayer);
    return set(HState::WaitingForRender, Why::NoRenderFrame);
  }
  const int rs = gRt.renderState.load(std::memory_order_relaxed);
  const int w = gRt.why.load(std::memory_order_relaxed);
  if (rs < 0 || rs >= int(HState::Count)) return set(HState::WaitingForRender, Why::None);
  return set(HState(rs), Why(w >= 0 && w < int(Why::Count) ? w : 0));
}

const char *stateName(HState s) {
  static const char *k[] = {"NoStructureLoaded", "StructureLoading", "StructureLoaded",  "WaitingForWorld",
                            "HologramWaitingForContext", "WaitingForRender", "HologramPreparing", "HologramReady",
                            "HologramVisible",   "HologramFailed",   "HologramCancelled"};
  const int i = int(s);
  return i >= 0 && i < int(HState::Count) ? k[i] : "?";
}

const char *whyName(Why w) {
  static const char *k[] = {"none",
                            "hologram hidden",
                            "no structure",
                            "not placed",
                            "waiting for player context",
                            "no world",
                            "world changed",
                            "dimension changed",
                            "no render frame",
                            "render data invalid",
                            "render context changed",
                            "resumed",
                            "materials missing",
                            "textures unavailable",
                            "preparation stalled",
                            "memory limit",
                            "cancelled",
                            "out of range",
                            "retry limit",
                            "settling",
                            "render hook missing",
                            "structure changed",
                            "no validated player context source"};
  const int i = int(w);
  return i >= 0 && i < int(Why::Count) ? k[i] : "?";
}

const char *stageName(Stage s) {
  static const char *k[] = {"open file",   "read NBT",     "dimensions",    "palette",          "block indices",
                            "count blocks", "transform",   "world/player",  "render data",      "materials/textures",
                            "render cache", "visible",     "done"};
  const int i = int(s);
  return i >= 0 && i < kStageCount ? k[i] : "?";
}

const char *loadErrName(LoadErr e) {
  static const char *k[] = {"none",          "cannot read file",       "empty file",       "file too large",
                            "corrupt gzip",  "zip/mcpack",             "not NBT",          "Java conversion",
                            "not .mcstructure", "invalid size",        "missing block_indices",
                            "unsupported block_indices type",          "missing block_palette",
                            "block_indices count mismatch",            "no blocks",        "memory limit",
                            "cancelled",     "invalid structure"};
  const int i = int(e);
  return i >= 0 && i < int(LoadErr::Count) ? k[i] : "?";
}

LoadErr classifyLoadError(const std::string &err, Stage &stage) {
  auto has = [&](const char *s) { return err.find(s) != std::string::npos; };
  if (has("can't read")) { stage = Stage::Open; return LoadErr::CantRead; }
  if (has("copy failed")) { stage = Stage::Open; return LoadErr::CantRead; }
  if (has("empty file")) { stage = Stage::Open; return LoadErr::Empty; }
  if (has("file too large")) { stage = Stage::Open; return LoadErr::TooLargeFile; }
  if (has("corrupt")) { stage = Stage::Nbt; return LoadErr::Corrupt; }
  if (has("zip/mcpack")) { stage = Stage::Nbt; return LoadErr::Zip; }
  if (has("Java .nbt")) { stage = Stage::Nbt; return LoadErr::JavaNbt; }
  if (has("not a Bedrock NBT") || has("not an NBT")) { stage = Stage::Nbt; return LoadErr::NotNbt; }
  if (has("not a structure file")) { stage = Stage::Dimensions; return LoadErr::NotStructure; }
  if (has("Java block table") || has("no regions") || has("block data") || has("BlockStates") || has("missing Blocks") ||
      has("Blocks too short") || has("missing blocks")) { stage = Stage::Nbt; return LoadErr::JavaNbt; }
  if (has("not a .mcstructure")) { stage = Stage::Dimensions; return LoadErr::NotStructure; }
  if (has("too large") || has("invalid or")) { stage = Stage::Dimensions; return LoadErr::BadSize; }
  if (has("missing block_indices")) { stage = Stage::Indices; return LoadErr::NoIndices; }
  if (has("unsupported block_indices")) { stage = Stage::Indices; return LoadErr::BadIndicesType; }
  if (has("block_palette")) { stage = Stage::Palette; return LoadErr::NoPalette; }
  if (has("bad block_indices")) { stage = Stage::Indices; return LoadErr::IndicesCount; }
  if (has("palette")) { stage = Stage::Palette; return LoadErr::NoPalette; }
  if (has("no blocks")) { stage = Stage::CountSolid; return LoadErr::NoBlocks; }
  if (has("memory")) { stage = Stage::Open; return LoadErr::MemoryLimit; }
  // anything else comes from the NBT reader
  stage = Stage::Nbt;
  return LoadErr::Other;
}

uint64_t memAvailable() {
  FILE *f = std::fopen("/proc/meminfo", "r");
  if (!f) return 0;
  char line[128];
  uint64_t kb = 0;
  while (std::fgets(line, sizeof(line), f)) {
    unsigned long long v = 0;
    if (std::sscanf(line, "MemAvailable: %llu kB", &v) == 1) { kb = v; break; }
  }
  std::fclose(f);
  return kb * 1024ull;
}

}  // namespace lm::hs
