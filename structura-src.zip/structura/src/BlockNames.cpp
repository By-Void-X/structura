





#include "BlockNames.hpp"

#include <cstring>
#include <mutex>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "Game.hpp"

namespace lm::names {
namespace {

using game::safeRead;
using game::safeReadPtr;

struct Path {
  int depth = 0;      
  unsigned o = 0;     
  unsigned s = 0;     
  bool raw = false;   
};

bool gReady = false;
Path gPath;
std::unordered_map<uintptr_t, const std::string *> gCache;
std::mutex gCacheMu;  // nameOf is used from the render thread and from Easy Place
std::unordered_set<std::string> gIntern;


bool readStdString(uintptr_t addr, std::string &out) {
  uint8_t raw[24];
  if (!safeRead(addr, raw, sizeof(raw))) return false;
  if ((raw[0] & 1) == 0) {  
    const size_t n = raw[0] >> 1;
    if (n > 22) return false;
    out.assign(reinterpret_cast<const char *>(raw + 1), n);
    return true;
  }
  uint64_t size, data;
  std::memcpy(&size, raw + 8, 8);
  std::memcpy(&data, raw + 16, 8);
  if (size == 0 || size > 200 || !game::plausiblePtr(data & ~7ULL)) return false;
  char buf[201];
  if (!safeRead(data, buf, size)) return false;
  out.assign(buf, size);
  return true;
}

bool objectFor(uintptr_t block, const Path &p, uintptr_t &obj) {
  if (p.depth == 0) { obj = block; return true; }
  uintptr_t a;
  if (!safeReadPtr(block + p.o, a) || !game::plausiblePtr(a)) return false;
  if (p.depth == 1) { obj = a; return true; }
  uintptr_t b;
  if (!safeReadPtr(a, b) || !game::plausiblePtr(b)) return false;
  obj = b;
  return true;
}

bool readName(uintptr_t block, const Path &p, std::string &out) {
  uintptr_t obj;
  return objectFor(block, p, obj) && readStdString(obj + p.s, out);
}

bool plausibleName(const std::string &n, bool raw) {
  if (raw) {
    if (n.size() < 2 || n.size() > 60) return false;
  } else if (n.size() < 11 || n.size() > 80 || n.compare(0, 10, "minecraft:") != 0) {
    return false;
  }
  for (char c : n)
    if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || (!raw && (c == ':' || c == '.'))))
      return false;
  return true;
}


void findAirStrings(uintptr_t obj, size_t len, std::vector<unsigned> &out, bool raw) {
  std::vector<uint8_t> buf(len);
  
  size_t got = 0;
  for (; got < len; got += 256)
    if (!safeRead(obj + got, buf.data() + got, 256)) break;
  if (got < 32) return;
  const char *kAir = raw ? "air" : "minecraft:air";
  const size_t L = std::strlen(kAir);
  
  for (size_t i = 0; i + 1 + L + 1 <= got; i += 8) {
    if (buf[i] == L * 2 && std::memcmp(&buf[i + 1], kAir, L) == 0 && buf[i + 1 + L] == 0) out.push_back(unsigned(i));
  }
  if (raw) return;
  for (size_t k = 0; k + 24 <= got; k += 8) {  
    uint64_t cap, size, data;
    std::memcpy(&cap, &buf[k], 8);
    std::memcpy(&size, &buf[k + 8], 8);
    std::memcpy(&data, &buf[k + 16], 8);
    if ((cap & 1) && size == 13 && game::plausiblePtr(data & ~7ULL)) {
      char t[14];
      if (safeRead(data, t, 14) && std::memcmp(t, kAir, 14) == 0) out.push_back(unsigned(k));
    }
  }
}

}  

bool discover(uintptr_t air, const std::vector<uintptr_t> &others) {
  if (gReady) return true;
  if (!game::plausiblePtr(air) || others.empty()) return false;
  for (int mode = 0; mode < 2 && !gReady; ++mode) {
    const bool raw = mode == 1;
    std::vector<Path> cands;
    {
      std::vector<unsigned> hits;
      findAirStrings(air, 0x400, hits, raw);
      for (unsigned s : hits) cands.push_back({0, 0, s, raw});
    }
    for (unsigned o = 0; o < 0x200; o += 8) {
      uintptr_t a;
      if (!safeReadPtr(air + o, a) || !game::plausiblePtr(a)) continue;
      std::vector<unsigned> hits;
      findAirStrings(a, 0x800, hits, raw);
      for (unsigned s : hits) cands.push_back({1, o, s, raw});
      uintptr_t b;
      if (safeReadPtr(a, b) && game::plausiblePtr(b)) {
        hits.clear();
        findAirStrings(b, 0x800, hits, raw);
        for (unsigned s : hits) cands.push_back({2, o, s, raw});
      }
    }
    const std::string airName = raw ? "air" : "minecraft:air";
    for (const Path &p : cands) {
      std::string a;
      if (!readName(air, p, a) || a != airName) continue;
      bool ok = true;
      for (uintptr_t other : others) {  
        std::string b;
        if (other == air || !readName(other, p, b) || !plausibleName(b, raw) || b == airName) { ok = false; break; }
      }
      if (!ok) continue;
      gPath = p;
      gReady = true;
      break;
    }
  }
  return gReady;
}

bool ready() { return gReady; }

const std::string *nameOf(uintptr_t block) {
  if (!gReady || !block) return nullptr;
  std::lock_guard<std::mutex> lk(gCacheMu);
  auto it = gCache.find(block);
  if (it != gCache.end()) return it->second;
  std::string n;
  const std::string *res = nullptr;
  if (readName(block, gPath, n) && plausibleName(n, gPath.raw))
    res = &*gIntern.insert(gPath.raw ? n : n.substr(10)).first;
  if (gCache.size() < 200000) gCache.emplace(block, res);  
  return res;
}

void invalidate() {
  std::lock_guard<std::mutex> lk(gCacheMu);
  gCache.clear();  // interned strings stay valid (pointers handed out earlier remain usable)
}

std::string describe() {
  if (!gReady) return "not found";
  return std::string(gPath.raw ? "short " : "full ") + "level " + std::to_string(gPath.depth) + " ptr+" + std::to_string(gPath.o) + " str+" + std::to_string(gPath.s);
}

}  
