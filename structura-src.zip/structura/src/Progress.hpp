#pragma once
// Central structure progress model (see CompareData in State.hpp). Pure functions over CompareData so the
// whole model is testable on the host; world-position helpers lock the shared Model.

#include <cstddef>
#include <cstdint>
#include <memory>

#include "State.hpp"
#include "Structure.hpp"

namespace lm::xf { struct Table; }

namespace lm::progress {

// New model for a placed structure (O(volume), UI thread). X marks variants without an exact
// transformation as Unsupported up front (may be null).
std::shared_ptr<CompareData> create(uint64_t gen, uint64_t epoch, const std::shared_ptr<const Structure> &S,
                                    const xf::Table *X);

// Record byte -> PState (air positions -> PNone).
uint8_t stateOf(uint8_t record, bool air);

// World comparison of one block changed (hologram scan / Easy Place verification). Clears a stale Easy
// Place outcome (except Unsupported) when the comparison changes. Returns the previous Cmp.
uint8_t setCmp(CompareData &C, size_t li, uint8_t cmp);
// Easy Place outcome of one block. attempt=true counts a placement attempt.
void setEp(CompareData &C, size_t li, EpFlag f, EpErr e = ErrNone, bool attempt = false);

struct Counts {
  uint32_t total = 0;      // blocks to build
  uint32_t s[PCount] = {};  // per PState
  uint32_t extra = 0;      // air positions occupied in the world
  uint32_t done() const { return s[PCorrect]; }
  double percent() const { return total ? 100.0 * double(s[PCorrect]) / double(total) : 0.0; }
};
Counts overall(const CompareData &C);

// Layers are slices of the TRANSFORMED (rotated/mirrored) structure box along a world axis
// (0 = X, 1 = Y, 2 = Z); index 0 is the lowest world coordinate.
int layerCount(const Structure &S, const Placement &P, int axis);
int layerWorld(const Structure &S, const Placement &P, int axis, int index);  // world coordinate of a layer
// Counts of one layer (O(1): mapped to the matching local slice).
bool layerCounts(const CompareData &C, const Structure &S, const Placement &P, int axis, int index, Counts &out);

// Placement-time helpers by world position (lock the shared Model; game thread, a few calls per second).
bool noteWorld(int x, int y, int z, EpFlag f, EpErr e = ErrNone, bool attempt = false);
bool verifiedWorld(int x, int y, int z, uint8_t cmp);

const char *stateName(uint8_t ps);  // English, logs/diagnostics
const char *errName(uint8_t e);
const char *stateKey(uint8_t ps);   // i18n key

}  // namespace lm::progress
