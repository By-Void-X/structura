#include "JavaFormats.hpp"

#include <zlib.h>

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <unordered_map>

extern "C" const unsigned char structura_java_map[];
extern "C" const unsigned char structura_java_map_end[];

namespace lm::java {
namespace {

constexpr int64_t kMaxVolume = 16LL * 1024 * 1024;  // same limit as the .mcstructure loader

// ---------------------------------------------------------------------------------------------------------------
// table (see tools/gen_java_map.py for the layout)

struct BProp { uint16_t key; uint8_t type; int32_t v; };  // type 1 byte, 3 int, 8 string (v = string id)
struct BState { uint16_t name; uint8_t n; uint32_t first; };
struct JBlock { uint16_t name; uint32_t first; uint16_t count; };
struct JState { uint32_t first; uint8_t n; uint32_t bed; };

struct Table {
  bool ok = false;
  std::vector<std::string> str;
  std::unordered_map<std::string, uint16_t> strId;
  std::vector<BProp> bprops;
  std::vector<BState> bed;
  std::vector<JBlock> blocks;
  std::vector<std::pair<uint16_t, uint16_t>> jprops;
  std::vector<JState> jst;
  std::unordered_map<uint32_t, uint16_t> legacy;  // id << 8 | meta -> string id of the Java state
  std::unordered_map<std::string, std::string> alias;
};

std::mutex gTableMu;
Table *gTable = nullptr;  // built once, never freed (about 2 MB)

bool inflateAll(const uint8_t *in, size_t n, std::vector<uint8_t> &out) {
  z_stream zs{};
  if (inflateInit2(&zs, MAX_WBITS) != Z_OK) return false;  // zlib header (inflateInit2_ is already imported)
  zs.next_in = const_cast<Bytef *>(in);
  zs.avail_in = uInt(n);
  out.resize(n * 8 + 4096);
  int rc;
  do {
    if (zs.total_out >= out.size()) {
      if (out.size() > 32u * 1024 * 1024) { inflateEnd(&zs); return false; }
      out.resize(out.size() * 2);
    }
    zs.next_out = out.data() + zs.total_out;
    zs.avail_out = uInt(out.size() - zs.total_out);
    rc = inflate(&zs, Z_NO_FLUSH);
  } while (rc == Z_OK);
  out.resize(zs.total_out);
  inflateEnd(&zs);
  return rc == Z_STREAM_END;
}

struct Cursor {
  const uint8_t *p, *e;
  bool bad = false;
  bool need(size_t n) { if (size_t(e - p) < n) { bad = true; return false; } return true; }
  uint8_t u8() { if (!need(1)) return 0; return *p++; }
  uint16_t u16() { if (!need(2)) return 0; uint16_t v = uint16_t(p[0] | p[1] << 8); p += 2; return v; }
  uint32_t u32() { if (!need(4)) return 0; uint32_t v; std::memcpy(&v, p, 4); p += 4; return v; }
};

bool buildTable(Table &t) {
  std::vector<uint8_t> raw;
  const size_t n = size_t(structura_java_map_end - structura_java_map);
  if (n < 8 || !inflateAll(structura_java_map, n, raw) || raw.size() < 28 || std::memcmp(raw.data(), "SJM1", 4) != 0)
    return false;
  Cursor c{raw.data() + 4, raw.data() + raw.size()};
  const uint32_t nStr = c.u32(), nBed = c.u32(), nBlk = c.u32(), nSt = c.u32(), nLeg = c.u32(), nAl = c.u32();
  if (nStr > 65536 || nBed > 1000000 || nBlk > 65536 || nSt > 1000000 || nLeg > 100000 || nAl > 1000) return false;
  t.str.resize(nStr);
  t.strId.reserve(nStr * 2);
  for (uint32_t i = 0; i < nStr && !c.bad; ++i) {
    const uint8_t L = c.u8();
    if (!c.need(L)) break;
    t.str[i].assign(reinterpret_cast<const char *>(c.p), L);
    c.p += L;
    t.strId.emplace(t.str[i], uint16_t(i));
  }
  t.bed.resize(nBed);
  for (uint32_t i = 0; i < nBed && !c.bad; ++i) {
    BState &b = t.bed[i];
    b.name = c.u16();
    b.n = c.u8();
    b.first = uint32_t(t.bprops.size());
    for (int k = 0; k < b.n && !c.bad; ++k) {
      BProp p{};
      p.key = c.u16();
      p.type = c.u8();
      p.v = p.type == 8 ? int32_t(c.u16()) : int32_t(c.u32());
      t.bprops.push_back(p);
    }
  }
  t.blocks.resize(nBlk);
  for (uint32_t i = 0; i < nBlk && !c.bad; ++i) {
    t.blocks[i].name = c.u16();
    t.blocks[i].first = c.u32();
    t.blocks[i].count = c.u16();
  }
  t.jst.resize(nSt);
  for (uint32_t i = 0; i < nSt && !c.bad; ++i) {
    JState &s = t.jst[i];
    s.n = c.u8();
    s.first = uint32_t(t.jprops.size());
    for (int k = 0; k < s.n && !c.bad; ++k) {
      const uint16_t a = c.u16(), b = c.u16();
      t.jprops.emplace_back(a, b);
    }
    s.bed = c.u32();
  }
  for (uint32_t i = 0; i < nLeg && !c.bad; ++i) {
    const uint16_t id = c.u16();
    const uint8_t meta = c.u8();
    const uint16_t s = c.u16();
    t.legacy.emplace(uint32_t(id) << 8 | meta, s);
  }
  for (uint32_t i = 0; i < nAl && !c.bad; ++i) {
    const uint16_t a = c.u16(), b = c.u16();
    if (a < nStr && b < nStr) t.alias.emplace(t.str[a], t.str[b]);
  }
  if (c.bad) return false;
  // validate every reference once, so lookups never index out of range
  for (auto &b : t.bed)
    if (b.name >= nStr) return false;
  for (auto &p : t.bprops)
    if (p.key >= nStr || (p.type == 8 && uint32_t(p.v) >= nStr)) return false;
  for (auto &b : t.blocks)
    if (b.name >= nStr || uint64_t(b.first) + b.count > nSt) return false;
  for (auto &s : t.jst)
    if (s.bed >= nBed) return false;
  for (auto &p : t.jprops)
    if (p.first >= nStr || p.second >= nStr) return false;
  for (auto &l : t.legacy)
    if (l.second >= nStr) return false;
  return true;
}

const Table *table() {
  std::lock_guard<std::mutex> lk(gTableMu);
  if (!gTable) {
    Table *t = new Table;
    t->ok = buildTable(*t);
    gTable = t;
  }
  return gTable->ok ? gTable : nullptr;
}

std::string stripNs(const std::string &n) {
  if (n.compare(0, 10, "minecraft:") == 0) return n.substr(10);
  return n;
}

const JBlock *findBlock(const Table &t, const std::string &shortName) {
  size_t lo = 0, hi = t.blocks.size();
  while (lo < hi) {
    const size_t mid = (lo + hi) / 2;
    const int c = t.str[t.blocks[mid].name].compare(shortName);
    if (c == 0) return &t.blocks[mid];
    if (c < 0) lo = mid + 1; else hi = mid;
  }
  return nullptr;
}

nbt::Tag makeString(const std::string &s) { nbt::Tag t; t.type = nbt::String; t.s = s; return t; }
nbt::Tag makeInt(int64_t v, nbt::Type ty = nbt::Int) { nbt::Tag t; t.type = ty; t.i = v; return t; }

void bedrockEntry(const Table &t, uint32_t bi, nbt::Tag &entry) {
  const BState &b = t.bed[bi];
  entry = nbt::Tag{};
  entry.type = nbt::Compound;
  entry.fields.emplace_back("name", makeString("minecraft:" + t.str[b.name]));
  nbt::Tag states;
  states.type = nbt::Compound;
  for (uint32_t k = 0; k < b.n; ++k) {
    const BProp &p = t.bprops[b.first + k];
    if (p.type == 8) states.fields.emplace_back(t.str[p.key], makeString(t.str[uint32_t(p.v)]));
    else states.fields.emplace_back(t.str[p.key], makeInt(p.v, p.type == 1 ? nbt::Byte : nbt::Int));
  }
  entry.fields.emplace_back("states", std::move(states));
}

void parseStateString(const std::string &s, std::string &name, std::vector<std::pair<std::string, std::string>> &props) {
  const auto b = s.find('[');
  name = s.substr(0, b);
  props.clear();
  if (b == std::string::npos) return;
  size_t i = b + 1;
  while (i < s.size() && s[i] != ']') {
    size_t j = i;
    while (j < s.size() && s[j] != ',' && s[j] != ']') ++j;
    const std::string kv = s.substr(i, j - i);
    const auto eq = kv.find('=');
    if (eq != std::string::npos && eq > 0) props.emplace_back(kv.substr(0, eq), kv.substr(eq + 1));
    i = j < s.size() && s[j] == ',' ? j + 1 : j;
  }
}

// ---------------------------------------------------------------------------------------------------------------
// conversion

struct Builder {
  const Table *t = nullptr;
  Stats *st = nullptr;
  int sx = 0, sy = 0, sz = 0;
  std::vector<int64_t> l0, l1;
  nbt::Tag palette;  // List<Compound> (block_palette)
  std::unordered_map<std::string, int> byKey;  // canonical Java state -> palette index (-1 = structure void)
  std::vector<uint8_t> waterlogged;  // per palette index
  int waterIdx = -1;

  bool init(int64_t x, int64_t y, int64_t z, std::string &err) {
    if (x <= 0 || y <= 0 || z <= 0 || x > 65535 || y > 65535 || z > 65535 || x * y * z > kMaxVolume) {
      err = "invalid or too large (max 16M blocks)";
      return false;
    }
    sx = int(x); sy = int(y); sz = int(z);
    l0.assign(size_t(x * y * z), -1);
    palette.type = nbt::List;
    palette.listType = nbt::Compound;
    return true;
  }
  size_t at(int x, int y, int z) const { return (size_t(x) * sy + y) * sz + z; }

  // Java state -> palette index. -1 = nothing (structure void / unknown legacy id)
  int add(const std::string &javaName, std::vector<std::pair<std::string, std::string>> props) {
    std::sort(props.begin(), props.end());
    std::string key = javaName;
    for (auto &p : props) { key += '\x1f'; key += p.first; key += '='; key += p.second; }
    auto it = byKey.find(key);
    if (it != byKey.end()) return it->second;
    ++st->paletteEntries;
    bool wl = false;
    for (auto &p : props)
      if (p.first == "waterlogged" && p.second == "true") wl = true;
    nbt::Tag entry;
    bool exact = false;
    if (!mapState(javaName, props, entry, exact)) {
      // no Bedrock equivalent known: keep the Java name so it shows up (and is never guessed as another block)
      ++st->unmapped;
      if (st->unmappedNames.size() < 160 && st->unmappedNames.find(javaName) == std::string::npos)
        st->unmappedNames += (st->unmappedNames.empty() ? "" : ",") + javaName;
      entry = nbt::Tag{};
      entry.type = nbt::Compound;
      entry.fields.emplace_back("name", makeString(javaName.find(':') == std::string::npos ? "minecraft:" + javaName
                                                                                           : javaName));
      nbt::Tag states;
      states.type = nbt::Compound;
      entry.fields.emplace_back("states", std::move(states));
    } else if (!exact) {
      ++st->approx;
    }
    const int idx = int(palette.items.size());
    palette.items.push_back(std::move(entry));
    waterlogged.push_back(wl ? 1 : 0);
    byKey.emplace(std::move(key), idx);
    return idx;
  }

  void set(int x, int y, int z, int p) {
    if (p < 0 || x < 0 || y < 0 || z < 0 || x >= sx || y >= sy || z >= sz) return;
    const size_t li = at(x, y, z);
    l0[li] = p;
    if (waterlogged[size_t(p)]) {
      if (l1.empty()) l1.assign(l0.size(), -1);
      if (waterIdx < 0) {
        nbt::Tag w;
        w.type = nbt::Compound;
        w.fields.emplace_back("name", makeString("minecraft:water"));
        nbt::Tag states;
        states.type = nbt::Compound;
        states.fields.emplace_back("liquid_depth", makeInt(0));
        w.fields.emplace_back("states", std::move(states));
        waterIdx = int(palette.items.size());
        palette.items.push_back(std::move(w));
        waterlogged.push_back(0);
      }
      l1[li] = waterIdx;
    }
  }

  void finish(nbt::Tag &out) {
    out = nbt::Tag{};
    out.type = nbt::Compound;
    out.fields.emplace_back("format_version", makeInt(1));
    nbt::Tag size;
    size.type = nbt::List;
    size.listType = nbt::Int;
    size.nums = {sx, sy, sz};
    out.fields.emplace_back("size", std::move(size));
    nbt::Tag structure;
    structure.type = nbt::Compound;
    nbt::Tag bi;
    bi.type = nbt::List;
    bi.listType = nbt::List;
    for (int layer = 0; layer < 2; ++layer) {
      nbt::Tag l;
      l.type = nbt::List;
      l.listType = nbt::Int;
      if (layer == 0) l.nums.swap(l0);
      else if (!l1.empty()) l.nums.swap(l1);
      else l.nums.assign(size_t(sx) * sy * sz, -1);
      bi.items.push_back(std::move(l));
    }
    structure.fields.emplace_back("block_indices", std::move(bi));
    nbt::Tag ents;
    ents.type = nbt::List;
    ents.listType = nbt::Compound;
    structure.fields.emplace_back("entities", std::move(ents));
    nbt::Tag def;
    def.type = nbt::Compound;
    def.fields.emplace_back("block_palette", std::move(palette));
    nbt::Tag pd;
    pd.type = nbt::Compound;
    def.fields.emplace_back("block_position_data", std::move(pd));
    nbt::Tag pal;
    pal.type = nbt::Compound;
    pal.fields.emplace_back("default", std::move(def));
    structure.fields.emplace_back("palette", std::move(pal));
    out.fields.emplace_back("structure", std::move(structure));
  }
};

int64_t intOf(const nbt::Tag *t, int64_t def = 0) {
  if (!t) return def;
  if (t->type == nbt::Byte || t->type == nbt::Short || t->type == nbt::Int || t->type == nbt::Long) return t->i;
  return def;
}
// Sponge / MCEdit store the dimensions as (signed) shorts that are really unsigned
int64_t ushortOf(const nbt::Tag *t) {
  if (!t) return 0;
  return t->type == nbt::Short ? (t->i & 0xFFFF) : intOf(t);
}

// Java palette entry {Name, Properties{...}}
int addEntry(Builder &b, const nbt::Tag &e) {
  const nbt::Tag *nm = e.get("Name");
  if (!nm || nm->type != nbt::String) return -1;
  std::vector<std::pair<std::string, std::string>> props;
  if (const nbt::Tag *pr = e.get("Properties"); pr && pr->type == nbt::Compound)
    for (auto &f : pr->fields)
      if (f.second.type == nbt::String) props.emplace_back(f.first, f.second.s);
  return b.add(nm->s, std::move(props));
}

bool fromJavaNbt(const nbt::Tag &root, nbt::Tag &out, Stats &st, std::string &err) {
  st.format = "java-nbt";
  const nbt::Tag *size = root.get("size");
  if (!size || !size->isIntList() || size->nums.size() != 3) { err = "invalid size"; return false; }
  const nbt::Tag *pal = root.get("palette");
  if ((!pal || pal->type != nbt::List) && root.get("palettes")) {
    const nbt::Tag *ps = root.get("palettes");
    if (ps->type == nbt::List && !ps->items.empty()) pal = &ps->items[0];
  }
  if (!pal || pal->type != nbt::List || (pal->listType != nbt::Compound && !pal->items.empty())) {
    err = "missing palette";
    return false;
  }
  const nbt::Tag *blocks = root.get("blocks");
  if (!blocks || blocks->type != nbt::List) { err = "missing blocks"; return false; }
  Builder b;
  b.t = table();
  b.st = &st;
  if (!b.init(size->nums[0], size->nums[1], size->nums[2], err)) return false;
  std::vector<int> map(pal->items.size(), -1);
  for (size_t k = 0; k < pal->items.size(); ++k) map[k] = addEntry(b, pal->items[k]);
  for (const nbt::Tag &e : blocks->items) {
    const nbt::Tag *pos = e.get("pos");
    const int64_t s = intOf(e.get("state"), -1);
    if (!pos || !pos->isIntList() || pos->nums.size() != 3 || s < 0 || size_t(s) >= map.size()) continue;
    if (e.get("nbt")) ++st.blockEntities;
    b.set(int(pos->nums[0]), int(pos->nums[1]), int(pos->nums[2]), map[size_t(s)]);
  }
  b.finish(out);
  return true;
}

bool fromLitematic(const nbt::Tag &root, nbt::Tag &out, Stats &st, std::string &err) {
  st.format = "litematic";
  st.dataVersion = int(intOf(root.get("MinecraftDataVersion")));
  const nbt::Tag *regions = root.get("Regions");
  if (!regions || regions->type != nbt::Compound || regions->fields.empty()) { err = "no regions"; return false; }
  struct R { const nbt::Tag *t; int64_t lo[3], sz[3]; };
  std::vector<R> rs;
  int64_t mn[3] = {INT64_MAX, INT64_MAX, INT64_MAX}, mx[3] = {INT64_MIN, INT64_MIN, INT64_MIN};
  for (auto &f : regions->fields) {
    const nbt::Tag &r = f.second;
    const nbt::Tag *pos = r.get("Position"), *size = r.get("Size");
    if (r.type != nbt::Compound || !pos || !size) continue;
    R x{&r, {}, {}};
    const char *ax[3] = {"x", "y", "z"};
    bool ok = true;
    for (int a = 0; a < 3; ++a) {
      const int64_t p = intOf(pos->get(ax[a])), s = intOf(size->get(ax[a]));
      if (s == 0 || s < -65535 || s > 65535) ok = false;
      x.lo[a] = s > 0 ? p : p + s + 1;
      x.sz[a] = s > 0 ? s : -s;
    }
    if (!ok) continue;
    for (int a = 0; a < 3; ++a) {
      mn[a] = std::min(mn[a], x.lo[a]);
      mx[a] = std::max(mx[a], x.lo[a] + x.sz[a]);
    }
    rs.push_back(x);
  }
  if (rs.empty()) { err = "no regions"; return false; }
  Builder b;
  b.t = table();
  b.st = &st;
  if (!b.init(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2], err)) return false;
  for (const R &r : rs) {
    const nbt::Tag *pal = r.t->get("BlockStatePalette");
    const nbt::Tag *bs = r.t->get("BlockStates");
    if (!pal || pal->type != nbt::List || pal->items.empty() || !bs || bs->type != nbt::LongArray) continue;
    if (const nbt::Tag *te = r.t->get("TileEntities"); te && te->type == nbt::List) st.blockEntities += te->items.size();
    std::vector<int> map(pal->items.size(), -1);
    for (size_t k = 0; k < pal->items.size(); ++k) map[k] = addEntry(b, pal->items[k]);
    // Litematica packs the palette indices tightly across long boundaries (LitematicaBitArray)
    int bits = 2;
    while ((size_t(1) << bits) < pal->items.size()) ++bits;
    const uint64_t mask = (uint64_t(1) << bits) - 1;
    const size_t vol = size_t(r.sz[0] * r.sz[1] * r.sz[2]);
    const auto &arr = bs->nums;
    if (arr.size() * 64 < uint64_t(vol) * bits) { err = "BlockStates too short"; return false; }
    const int ox = int(r.lo[0] - mn[0]), oy = int(r.lo[1] - mn[1]), oz = int(r.lo[2] - mn[2]);
    const int ax = int(r.sz[0]), az = int(r.sz[2]);
    for (size_t i = 0; i < vol; ++i) {
      const uint64_t start = uint64_t(i) * bits;
      const size_t si = size_t(start >> 6), ei = size_t((start + bits - 1) >> 6);
      const unsigned off = unsigned(start & 63);
      uint64_t v = uint64_t(arr[si]) >> off;
      if (ei != si) v |= uint64_t(arr[ei]) << (64 - off);
      v &= mask;
      if (v >= map.size()) continue;
      const int x = int(i % size_t(ax)), z = int((i / size_t(ax)) % size_t(az)), y = int(i / (size_t(ax) * az));
      b.set(ox + x, oy + y, oz + z, map[size_t(v)]);
    }
  }
  b.finish(out);
  return true;
}

bool fromSponge(const nbt::Tag &root, nbt::Tag &out, Stats &st, std::string &err) {
  const nbt::Tag *s = &root;
  if (const nbt::Tag *inner = root.get("Schematic"); inner && inner->type == nbt::Compound) s = inner;
  const int version = int(intOf(s->get("Version"), 1));
  st.format = "sponge-v" + std::to_string(version);
  st.dataVersion = int(intOf(s->get("DataVersion")));
  const nbt::Tag *pal = s->get("Palette"), *data = s->get("BlockData");
  if (const nbt::Tag *blk = s->get("Blocks"); blk && blk->type == nbt::Compound) {  // v3
    pal = blk->get("Palette");
    data = blk->get("Data");
    if (const nbt::Tag *be = blk->get("BlockEntities"); be && be->type == nbt::List) st.blockEntities += be->items.size();
  } else if (const nbt::Tag *be = s->get("BlockEntities"); be && be->type == nbt::List) {
    st.blockEntities += be->items.size();
  } else if (const nbt::Tag *te = s->get("TileEntities"); te && te->type == nbt::List) {
    st.blockEntities += te->items.size();
  }
  if (!pal || pal->type != nbt::Compound || pal->fields.empty()) { err = "missing palette"; return false; }
  if (!data || data->type != nbt::ByteArray) { err = "missing block data"; return false; }
  const int64_t W = ushortOf(s->get("Width")), H = ushortOf(s->get("Height")), L = ushortOf(s->get("Length"));
  Builder b;
  b.t = table();
  b.st = &st;
  if (!b.init(W, H, L, err)) return false;
  std::vector<int> map;
  for (auto &f : pal->fields) {
    const int64_t id = intOf(&f.second, -1);
    if (id < 0 || id > 1000000) continue;
    if (size_t(id) >= map.size()) map.resize(size_t(id) + 1, -1);
    std::string name;
    std::vector<std::pair<std::string, std::string>> props;
    parseStateString(f.first, name, props);
    map[size_t(id)] = b.add(name, std::move(props));
  }
  // varint palette ids, index = x + z * W + y * W * L
  const auto &bytes = data->nums;
  size_t pos = 0;
  const size_t vol = size_t(W * H * L);
  for (size_t i = 0; i < vol; ++i) {
    uint32_t v = 0;
    int shift = 0;
    for (;;) {
      if (pos >= bytes.size()) { err = "block data too short"; return false; }
      const uint8_t c = uint8_t(bytes[pos++]);
      v |= uint32_t(c & 0x7F) << shift;
      if (!(c & 0x80)) break;
      shift += 7;
      if (shift > 28) { err = "bad block data"; return false; }
    }
    if (v >= map.size()) continue;
    const int x = int(i % size_t(W)), z = int((i / size_t(W)) % size_t(L)), y = int(i / size_t(W * L));
    b.set(x, y, z, map[v]);
  }
  b.finish(out);
  return true;
}

bool fromMcedit(const nbt::Tag &root, nbt::Tag &out, Stats &st, std::string &err) {
  st.format = "mcedit";
  if (const nbt::Tag *m = root.get("Materials"); m && m->type == nbt::String && m->s == "Pocket") st.format = "mcedit-pocket";
  const int64_t W = ushortOf(root.get("Width")), H = ushortOf(root.get("Height")), L = ushortOf(root.get("Length"));
  const nbt::Tag *blocks = root.get("Blocks"), *data = root.get("Data");
  if (!blocks || blocks->type != nbt::ByteArray) { err = "missing Blocks"; return false; }
  Builder b;
  b.t = table();
  b.st = &st;
  if (!b.init(W, H, L, err)) return false;
  const size_t vol = size_t(W * H * L);
  if (blocks->nums.size() < vol) { err = "Blocks too short"; return false; }
  const nbt::Tag *addBlocks = root.get("AddBlocks"), *add = root.get("Add");
  if (addBlocks && addBlocks->type != nbt::ByteArray) addBlocks = nullptr;
  if (add && (add->type != nbt::ByteArray || add->nums.size() < vol)) add = nullptr;
  if (data && (data->type != nbt::ByteArray || data->nums.size() < vol)) data = nullptr;
  if (const nbt::Tag *te = root.get("TileEntities"); te && te->type == nbt::List) st.blockEntities += te->items.size();
  std::unordered_map<uint32_t, int> cache;
  for (size_t i = 0; i < vol; ++i) {
    int id = int(uint8_t(blocks->nums[i]));
    if (addBlocks && (i >> 1) < addBlocks->nums.size()) {
      const int a = int(uint8_t(addBlocks->nums[i >> 1]));
      id |= ((i & 1) == 0 ? (a & 0x0F) : ((a >> 4) & 0x0F)) << 8;
    } else if (add) {
      id |= int(uint8_t(add->nums[i])) << 8;
    }
    const int meta = data ? int(uint8_t(data->nums[i])) & 0x0F : 0;
    const uint32_t key = uint32_t(id) << 8 | uint32_t(meta);
    auto it = cache.find(key);
    if (it == cache.end()) {
      std::string js = legacyState(id, meta);
      if (js.empty()) js = legacyState(id, 0);
      int p = -1;
      if (!js.empty()) {
        std::string name;
        std::vector<std::pair<std::string, std::string>> props;
        parseStateString(js, name, props);
        p = b.add(name, std::move(props));
      } else {
        ++st.unmapped;
        if (st.unmappedNames.size() < 160) st.unmappedNames += (st.unmappedNames.empty() ? "id:" : ",id:") + std::to_string(id);
      }
      it = cache.emplace(key, p).first;
    }
    const int x = int(i % size_t(W)), z = int((i / size_t(W)) % size_t(L)), y = int(i / size_t(W * L));
    b.set(x, y, z, it->second);
  }
  b.finish(out);
  return true;
}

}  // namespace

bool mapState(const std::string &javaName, std::vector<std::pair<std::string, std::string>> props, nbt::Tag &entry,
              bool &exact) {
  exact = false;
  const Table *t = table();
  if (!t) return false;
  if (javaName.find(':') != std::string::npos && javaName.compare(0, 10, "minecraft:") != 0) return false;  // modded
  std::string n = stripNs(javaName);
  const JBlock *blk = findBlock(*t, n);
  if (!blk) {
    auto a = t->alias.find(n);
    if (a != t->alias.end()) blk = findBlock(*t, a->second);
  }
  if (!blk || blk->count == 0) return false;
  // input properties as string ids (unknown key/value strings can't match anything)
  std::vector<std::pair<int, int>> in;
  in.reserve(props.size());
  for (auto &p : props) {
    auto k = t->strId.find(p.first), v = t->strId.find(p.second);
    in.emplace_back(k == t->strId.end() ? -1 : k->second, v == t->strId.end() ? -1 : v->second);
  }
  // closest Java state: most matching properties, fewest conflicting ones; first entry wins ties
  int best = -1, bestScore = INT32_MIN;
  bool bestExact = false;
  for (uint32_t s = blk->first; s < blk->first + blk->count; ++s) {
    const JState &js = t->jst[s];
    int match = 0, conflict = 0;
    for (auto &p : in) {
      if (p.first < 0) continue;
      for (uint32_t k = 0; k < js.n; ++k) {
        const auto &q = t->jprops[js.first + k];
        if (q.first != p.first) continue;
        if (q.second == p.second) ++match; else ++conflict;
        break;
      }
    }
    const int score = match * 4 - conflict * 8;
    if (score > bestScore) {
      bestScore = score;
      best = int(s);
      // properties missing from the file (old versions: no waterlogged, ...) take the table's first entry
      bestExact = conflict == 0 && match == int(in.size());
    }
  }
  if (best < 0) return false;
  bedrockEntry(*t, t->jst[size_t(best)].bed, entry);
  exact = bestExact;
  return true;
}

bool mapStateString(const std::string &javaState, nbt::Tag &entry, bool &exact) {
  std::string name;
  std::vector<std::pair<std::string, std::string>> props;
  parseStateString(javaState, name, props);
  return mapState(name, std::move(props), entry, exact);
}

std::string legacyState(int id, int meta) {
  const Table *t = table();
  if (!t || id < 0 || id > 0xFFFF || meta < 0 || meta > 15) return {};
  auto it = t->legacy.find(uint32_t(id) << 8 | uint32_t(meta));
  return it == t->legacy.end() ? std::string() : t->str[it->second];
}

bool isJavaFormat(const nbt::Tag &root) {
  if (root.type != nbt::Compound) return false;
  if (const nbt::Tag *r = root.get("Regions"); r && r->type == nbt::Compound) return true;
  const nbt::Tag *s = root.get("Schematic");
  if (s && s->type == nbt::Compound) return true;
  if (root.get("Palette") && root.get("BlockData")) return true;
  if (const nbt::Tag *b = root.get("Blocks"); b && (b->type == nbt::ByteArray || b->type == nbt::Compound) && root.get("Width"))
    return true;
  if (root.get("blocks") && (root.get("palette") || root.get("palettes")) && root.get("size") && !root.get("structure"))
    return true;
  return false;
}

bool toBedrock(const nbt::Tag &root, nbt::Tag &out, Stats &st, std::string &err) {
  st = Stats{};
  if (!table()) { err = "Java block table unavailable"; return false; }
  if (root.type != nbt::Compound) { err = "not a structure file"; return false; }
  if (st.dataVersion == 0) st.dataVersion = int(intOf(root.get("DataVersion")));
  if (const nbt::Tag *r = root.get("Regions"); r && r->type == nbt::Compound) return fromLitematic(root, out, st, err);
  const nbt::Tag *s = root.get("Schematic");
  if ((s && s->type == nbt::Compound) || (root.get("Palette") && root.get("BlockData")) ||
      (root.get("Blocks") && root.get("Blocks")->type == nbt::Compound))
    return fromSponge(root, out, st, err);
  if (const nbt::Tag *b = root.get("Blocks"); b && b->type == nbt::ByteArray) return fromMcedit(root, out, st, err);
  if (root.get("blocks") && (root.get("palette") || root.get("palettes"))) return fromJavaNbt(root, out, st, err);
  err = "not a structure file";
  return false;
}

const char *extensionFor(const std::string &f) {
  if (f == "mcstructure") return ".mcstructure";
  if (f == "litematic") return ".litematic";
  if (f.compare(0, 6, "sponge") == 0) return ".schem";
  if (f.compare(0, 6, "mcedit") == 0) return ".schematic";
  if (f == "java-nbt") return ".nbt";
  return "";
}

}  // namespace lm::java
