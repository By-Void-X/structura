#include "Transformed.hpp"

#include <atomic>
#include <mutex>

#include "BlockStates.hpp"

namespace lm::xf {
namespace st = lm::states;
namespace {
std::mutex gMu;
std::shared_ptr<const Table> gCache[2];  // most recent first
std::atomic<uint64_t> gBuilds{0};
Stats gStats;

std::shared_ptr<const Table> findLocked(const Structure *S, int rot, bool mirror) {
  for (const auto &t : gCache)
    if (t && t->keep.get() == S && t->rot == rot && t->mirror == mirror) return t;
  return nullptr;
}

std::shared_ptr<const Table> build(const std::shared_ptr<const Structure> &S, int rot, bool mirror) {
  auto t = std::make_shared<Table>();
  t->keep = S;
  t->rot = rot;
  t->mirror = mirror;
  t->id = gBuilds.fetch_add(1) + 1;
  const Structure &T = *S;
  const size_t n = T.variants.size();
  t->variants = n;
  t->states.resize(n);
  t->unsupported.resize(n);
  t->verified.assign(n, 0);
  t->directional.assign(n, 0);
  for (size_t v = 0; v < n; ++v) {
    const BlockVariant &var = T.variants[v];
    const std::string &name = var.palette < T.palette.size() ? T.palette[var.palette].name : std::string();
    std::vector<BlockStateValue> s = var.states;
    for (const auto &sv : s)
      if (!st::plainType(sv)) {
        ++t->nRaw;
        if (t->unsupported[v].empty())
          t->unsupported[v] = "state " + sv.key + " is raw NBT data (type " + std::to_string(int(sv.type)) +
                              "): not reproducible";
      }
    const st::TransformOutcome o = st::transformBlockState(s, rot, mirror, name);
    if (o.changed) ++t->changed;
    if (!o.unknownDirectional.empty() && t->unsupported[v].empty())
      t->unsupported[v] = "state " + o.unknownDirectional[0] + " has no rotation/mirror rule";
    for (const auto &sv : s) {
      if (!st::plainType(sv)) continue;
      const st::Cls c = st::ruleFor(sv.key, name).cls;
      if (c != st::Cls::Generated) t->verified[v] = 1;
      if (c == st::Cls::Placement) t->directional[v] = 1;
    }
    if (!t->unsupported[v].empty()) ++t->nUnsupported;
    if (t->directional[v]) ++t->nDirectional;
    t->states[v] = std::move(s);
  }
  return t;
}
}  // namespace

std::shared_ptr<const Table> get(const std::shared_ptr<const Structure> &S, int rot, bool mirror) {
  if (!S) return nullptr;
  rot &= 3;
  {
    std::lock_guard<std::mutex> lk(gMu);
    if (auto t = findLocked(S.get(), rot, mirror)) return t;
  }
  auto t = build(S, rot, mirror);  // outside the lock: other threads keep reading the old tables
  std::lock_guard<std::mutex> lk(gMu);
  if (auto other = findLocked(S.get(), rot, mirror)) return other;  // built concurrently: keep one
  gCache[1] = std::move(gCache[0]);
  gCache[0] = t;
  gStats.ready = true;
  gStats.rot = rot;
  gStats.mirror = mirror;
  gStats.builds = gBuilds.load();
  gStats.variants = t->variants;
  gStats.changed = t->changed;
  gStats.unsupported = t->nUnsupported;
  gStats.directional = t->nDirectional;
  gStats.raw = t->nRaw;
  gStats.firstUnsupported.clear();
  for (const auto &u : t->unsupported)
    if (!u.empty()) { gStats.firstUnsupported = u; break; }
  return t;
}

std::shared_ptr<const Table> peek(const Structure *S, int rot, bool mirror) {
  std::unique_lock<std::mutex> lk(gMu, std::try_to_lock);
  if (!lk.owns_lock()) return nullptr;
  return findLocked(S, rot & 3, mirror);
}

void clear() {
  std::lock_guard<std::mutex> lk(gMu);
  gCache[0].reset();
  gCache[1].reset();
  gStats = Stats{};
}

Stats stats() {
  std::lock_guard<std::mutex> lk(gMu);
  return gStats;
}

}  // namespace lm::xf
