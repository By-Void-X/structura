#pragma once
// Recognition of another mod's inline-hook patch at a function entry (pure, host-testable).
//
// Proven forms (from the GlossHook copy shipped in preloader-android, CInlineHook::Set/Redirect and
// Gloss::Inst::jump_inst tables):
//   * B <island>                                   4 bytes  (MakeArm64B, near free memory)
//   * LDR Xn,#8 ; BR Xn ; .quad dest               16 bytes (MakeArm64AbsoluteJump, Gloss uses n = 18)
//   * LDR Xn,#8 ; RET Xn ; .quad dest              16 bytes (MakeArm64AbsoluteJumpRet)
//   * ADRP Xn ; BR Xn                              8 bytes  (jump_inst A64_A2)
//   * STP X1,X0,[SP,#-16] ; LDR X0,#8 ; BR X0 ; .quad ; LDUR X0,[SP,#-8]   24 bytes (A64_A4, "128")
// plus the common forms of other hookers (Dobby/ShadowHook/And64InlineHook):
//   * ADRP Xn ; ADD Xn,Xn,#lo ; BR Xn              12 bytes
//   * ADRP Xn ; LDR Xn,[Xn,#lo] ; BR Xn            12 bytes
// each optionally preceded by one BTI landing pad (+4 bytes).
// The patch length tells how many leading bytes of the original prologue are gone, so the rest of the
// signature can be compared exactly instead of blindly skipping a fixed number of bytes.
#include <cstddef>
#include <cstdint>

namespace lm::hookpatch {

constexpr size_t kMaxPatch = 28;  // largest recognised form (24) + BTI

inline bool isBti(uint32_t i) { return (i & 0xFFFFFF3Fu) == 0xD503241Fu; }
inline bool isB(uint32_t i) { return (i & 0xFC000000u) == 0x14000000u; }
inline bool isAdrp(uint32_t i, unsigned &rd) { rd = i & 31u; return (i & 0x9F000000u) == 0x90000000u; }
inline bool isLdrLit8(uint32_t i, unsigned &rt) { rt = i & 31u; return (i & 0xFFFFFFE0u) == 0x58000040u; }
inline bool isBr(uint32_t i, unsigned rn) { return i == (0xD61F0000u | (rn << 5)); }
inline bool isRet(uint32_t i, unsigned rn) { return i == (0xD65F0000u | (rn << 5)); }
inline bool isAddImmSame(uint32_t i, unsigned r) {  // ADD Xr, Xr, #imm12 (64-bit, no shift or lsl 12)
  return (i & 0xFF800000u) == 0x91000000u && (i & 31u) == r && ((i >> 5) & 31u) == r;
}
inline bool isLdrImmSame(uint32_t i, unsigned r) {  // LDR Xr, [Xr, #imm]
  return (i & 0xFFC00000u) == 0xF9400000u && (i & 31u) == r && ((i >> 5) & 31u) == r;
}

// `w` holds the first (kMaxPatch / 4) instruction words at the function entry. Returns the number of
// prologue bytes overwritten by a recognised hook patch, or 0 when the entry is not a known patch.
inline size_t patchLength(const uint32_t *w, size_t n) {
  if (!w || n < 1) return 0;
  size_t k = 0;
  if (isBti(w[0])) k = 1;
  auto at = [&](size_t j) -> uint32_t { return k + j < n ? w[k + j] : 0u; };
  const size_t pre = k * 4;
  if (isB(at(0))) return pre + 4;
  unsigned r = 0;
  if (isLdrLit8(at(0), r) && r != 31 && (isBr(at(1), r) || isRet(at(1), r))) return pre + 16;
  if (at(0) == 0xA93F03E1u && at(1) == 0x58000040u && at(2) == 0xD61F0000u && at(5) == 0xF85F83E0u)
    return pre + 24;
  if (isAdrp(at(0), r) && r != 31) {
    if (isBr(at(1), r)) return pre + 8;
    if ((isAddImmSame(at(1), r) || isLdrImmSame(at(1), r)) && isBr(at(2), r)) return pre + 12;
  }
  return 0;
}

}  // namespace lm::hookpatch
