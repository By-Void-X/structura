







#include "Hologram.hpp"
#include "Progress.hpp"
#include "EasyPlace.hpp"
#include "Transformed.hpp"
#include "PlayerContext.hpp"
#include "Resolver.hpp"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <memory>
#include <cstdlib>
#include <cstdio>
#include <mutex>
#include <pthread.h>
#include <time.h>
#include <string>
#include <unordered_map>
#include <vector>

#include <pl/memory/Hook.hpp>
#include <pl/memory/Signature.hpp>

#include "BlockNames.hpp"
#include "BlockStates.hpp"
#include "StructuraApi.h"
#include "Nbt.hpp"
#include "Game.hpp"
#include "Resolver.hpp"
#include "State.hpp"
#include "Perf.hpp"
#include "HoloState.hpp"

#include <EGL/egl.h>
#include <new>

namespace lm::holo {
namespace {

using namespace lm::game;

TessBeginFn sBegin = nullptr;
TessColorFn sColor = nullptr;
TessVertexFn sVertex = nullptr;

using RenderMeshFn4 = void (*)(void *screenCtx, void *tess, void *material, char *pad);
using RenderMeshFn5 = void (*)(void *screenCtx, void *tess, void *material, uintptr_t flags, char *pad);
RenderMeshFn4 sRenderMesh4 = nullptr;
RenderMeshFn5 sRenderMesh5 = nullptr;
GetBlockFn sGetBlock = nullptr;
void *gRenderLevelOrig = nullptr;  
uintptr_t sMaterialGroup = 0;
MaterialPtr sLineMat;              
// Material lookups are retried with backoff (frames) instead of once: on slow devices the material
// group can still be empty on the first hologram frame, which used to disable it for the session.
constexpr int kMatMaxAttempts = 8;
struct MatRetry {
  int attempts = 0;
  uint32_t nextFrame = 0;
};
MatRetry sLineRetry;
uint32_t gFrame = 0;
bool matRetryDue(MatRetry &r) { return r.attempts < kMatMaxAttempts && int32_t(gFrame - r.nextFrame) >= 0; }
void matRetryStep(MatRetry &r) {
  ++r.attempts;
  r.nextFrame = gFrame + std::min(30u << std::min(r.attempts, 6), 1800u);
}





using TessInWorldFn = bool (*)(void *bt, void *tess, void *block, const BlockPos &pos, int);
using GetBTFn = void *(*)(void *owner);
using BTResetFn = void (*)(void *bt, const BlockPos &origin);
using BTSetCacheFn = void (*)(void *bt, void *block, const BlockPos &pos);
using BlockFlagFn = uint64_t (*)(void *block);
using RegistryFn = void *(*)();
using LookupFn = void *(*)(void *registry, const HashedString *name, int);
using FindStateFn = void *(*)(void *legacy, const HashedString *name);
using StateFromTagFn = uint64_t (*)(void *state, const void *tag);
TessInWorldFn sTessInWorld = nullptr;
GetBTFn sGetBT = nullptr;
BTResetFn sBTReset = nullptr;
BTSetCacheFn sBTSetCache = nullptr;
BlockFlagFn sBlockFlag = nullptr;
RegistryFn sRegistry = nullptr;
LookupFn sLookup = nullptr;
FindStateFn sFindState = nullptr;
using TessClearFn = void (*)(void *tess);
TessClearFn sTessClear = nullptr;


struct MeshBlob {
  alignas(16) uint8_t b[0x400];
  MeshBlob() {}
  ~MeshBlob() {}
  MeshBlob(const MeshBlob &) = delete;
  MeshBlob &operator=(const MeshBlob &) = delete;
};
struct MatRef {  
  void *stack = nullptr;
  float *m = nullptr;
  MatRef() {}
  ~MatRef() {}
  MatRef(const MatRef &) = delete;
  MatRef &operator=(const MatRef &) = delete;
};
using TessEndFn = MeshBlob (*)(void *tess, int mode, const char *name, size_t len, int flags);
using MeshRenderFn = void (*)(void *mesh, void *ctx, void *mat, const void *tex, int, int, char *pad, void *);
using MeshDestroyFn = void (*)(void *mesh);
using MatPushFn = MatRef (*)(void *stack, int);
using MatPopFn = void (*)(MatRef *ref);
TessEndFn sTessEnd = nullptr;
MeshRenderFn sMeshRender = nullptr;
MeshDestroyFn sMeshDestroy = nullptr;
MatPushFn sMatPush = nullptr;
MatPopFn sMatPop = nullptr;
bool meshReady() { return sTessEnd && sMeshRender && sMeshDestroy && sMatPush && sMatPop; }
uintptr_t sVtByteTag = 0, sVtIntTag = 0, sVtStringTag = 0;


struct BlockLook {
  const char *label;
  const char *mat;
  bool useAlpha;  
  int tint;       
};


const BlockLook kLooks[] = {
    {"Blue translucent", "particles_blend", true, 1},
    {"Blue solid", "particles_alpha", true, 1},
};
constexpr int kLookCount = sizeof(kLooks) / sizeof(kLooks[0]);
MaterialPtr sTexMats[kLookCount];
MatRetry sTexRetry[kLookCount];
pl::log::Logger *gLog = nullptr;
bool texReady() {
  return sTessInWorld && sGetBT && sBTReset && sBTSetCache && sBlockFlag && sRegistry && sLookup && sFindState &&
         sVtByteTag && sVtIntTag && sVtStringTag && sRenderMesh5 && sBegin && sColor && sTessClear && meshReady();
}

struct FaceMat {
  const char *name;
  unsigned lrpOffset;
};
const FaceMat kFaceMats[] = {
    {"selection_overlay", off::LRP_mat_selection_overlay},
    {"selection_overlay_double_sided", off::LRP_mat_selection_overlay_double_sided},
    {"selection_overlay_opaque", off::LRP_mat_selection_overlay_opaque},
    {"cracks_overlay", off::LRP_mat_cracks_overlay},
    {"selection_box", off::LRP_mat_selection_box},
};
constexpr int kFaceMatCount = sizeof(kFaceMats) / sizeof(kFaceMats[0]);


struct Rgba {
  float r, g, b, a;
};
inline Rgba rgba(uint32_t argb, float alpha) {
  return {((argb >> 16) & 0xFF) / 255.f, ((argb >> 8) & 0xFF) / 255.f, (argb & 0xFF) / 255.f, alpha};
}

struct QuadV {
  Vec3 v[4];
  Rgba c;
};
struct LineV {
  Vec3 a, b;
  Rgba c;
};
std::vector<QuadV> gQuads;
std::vector<LineV> gLines;


constexpr size_t kQuadBatch = 512;    
constexpr size_t kLineBatch = 1024;   


void submitMesh(void *ctx, void *tess, void *mat) {
  char pad[0x58]{};
  if (sRenderMesh4) {
    sRenderMesh4(ctx, tess, mat, pad);
  } else if (sRenderMesh5) {
    
    sRenderMesh5(ctx, tess, mat, 0, pad);
  }
}

void flushQuads(void *tess, void *ctx, void *mat, const Vec3 &cam, bool twoSided) {
  if (!mat || gQuads.empty()) return;
  for (size_t from = 0; from < gQuads.size(); from += kQuadBatch) {
    const size_t to = std::min(gQuads.size(), from + kQuadBatch);
    sBegin(tess, nullptr, QuadList, int((to - from) * (twoSided ? 8 : 4)), 0);
    Rgba last{-1, -1, -1, -1};
    for (size_t i = from; i < to; ++i) {
      const QuadV &q = gQuads[i];
      if (std::memcmp(&q.c, &last, sizeof(Rgba)) != 0) { sColor(tess, q.c.r, q.c.g, q.c.b, q.c.a); last = q.c; }
      for (int k = 0; k < 4; ++k) sVertex(tess, q.v[k].x - cam.x, q.v[k].y - cam.y, q.v[k].z - cam.z);
      if (twoSided)
        for (int k = 3; k >= 0; --k) sVertex(tess, q.v[k].x - cam.x, q.v[k].y - cam.y, q.v[k].z - cam.z);
    }
    submitMesh(ctx, tess, mat);
    status().meshCalls.fetch_add(1, std::memory_order_relaxed);
  }
}

void flushLines(void *tess, void *ctx, void *mat, const Vec3 &cam) {
  if (!mat || gLines.empty()) return;
  for (size_t from = 0; from < gLines.size(); from += kLineBatch) {
    const size_t to = std::min(gLines.size(), from + kLineBatch);
    sBegin(tess, nullptr, LineList, int((to - from) * 2), 0);
    Rgba last{-1, -1, -1, -1};
    for (size_t i = from; i < to; ++i) {
      const LineV &l = gLines[i];
      if (std::memcmp(&l.c, &last, sizeof(Rgba)) != 0) { sColor(tess, l.c.r, l.c.g, l.c.b, l.c.a); last = l.c; }
      sVertex(tess, l.a.x - cam.x, l.a.y - cam.y, l.a.z - cam.z);
      sVertex(tess, l.b.x - cam.x, l.b.y - cam.y, l.b.z - cam.z);
    }
    submitMesh(ctx, tess, mat);
    status().meshCalls.fetch_add(1, std::memory_order_relaxed);
  }
}

void boxLines(float x0, float y0, float z0, float x1, float y1, float z1, Rgba c) {
  const Vec3 p[8] = {{x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1},
                     {x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}};
  static constexpr int e[12][2] = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6},
                                   {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
  for (auto &ed : e) gLines.push_back({p[ed[0]], p[ed[1]], c});
}


void faceQuad(int f, float x0, float y0, float z0, float x1, float y1, float z1, Vec3 out[4]) {
  switch (f) {
    case 0: out[0] = {x0, y1, z0}; out[1] = {x0, y1, z1}; out[2] = {x1, y1, z1}; out[3] = {x1, y1, z0}; break;
    case 1: out[0] = {x0, y0, z0}; out[1] = {x1, y0, z0}; out[2] = {x1, y0, z1}; out[3] = {x0, y0, z1}; break;
    case 2: out[0] = {x0, y0, z0}; out[1] = {x0, y1, z0}; out[2] = {x1, y1, z0}; out[3] = {x1, y0, z0}; break;
    case 3: out[0] = {x0, y0, z1}; out[1] = {x1, y0, z1}; out[2] = {x1, y1, z1}; out[3] = {x0, y1, z1}; break;
    case 4: out[0] = {x0, y0, z0}; out[1] = {x0, y0, z1}; out[2] = {x0, y1, z1}; out[3] = {x0, y1, z0}; break;
    default: out[0] = {x1, y0, z0}; out[1] = {x1, y1, z0}; out[2] = {x1, y1, z1}; out[3] = {x1, y0, z1}; break;
  }
}


void *lrpMat(uintptr_t lrp, unsigned offset) {
  auto *mp = reinterpret_cast<MaterialPtr *>(lrp + offset);
  return *mp ? mp : nullptr;
}

void *lineMaterial(uintptr_t lrp) {
  if (!sLineMat && sMaterialGroup && matRetryDue(sLineRetry)) {
    matRetryStep(sLineRetry);
    void **vt = nullptr;
    if (!safeRead(sMaterialGroup, &vt, sizeof(vt)) || !plausiblePtr(reinterpret_cast<uintptr_t>(vt))) vt = nullptr;
    if (vt && vt[off::VT_RenderMaterialGroup_getMaterial]) {
      using GetMat = MaterialPtr (*)(void *, const HashedString *);
      HashedString hs("selection_box");
      sLineMat = reinterpret_cast<GetMat>(vt[off::VT_RenderMaterialGroup_getMaterial])(
          reinterpret_cast<void *>(sMaterialGroup), &hs);
    }
  }
  if (sLineMat) return &sLineMat;
  return lrpMat(lrp, off::LRP_mat_selection_box);
}

uintptr_t resolveAdrpAdd(uintptr_t at) {  
  uint32_t i0, i1;
  std::memcpy(&i0, reinterpret_cast<void *>(at), 4);
  std::memcpy(&i1, reinterpret_cast<void *>(at + 4), 4);
  if ((i0 & 0x9F000000u) != 0x90000000u || (i1 & 0xFF000000u) != 0x91000000u) return 0;
  const int64_t immhi = (i0 >> 5) & 0x7FFFF, immlo = (i0 >> 29) & 3;
  int64_t imm = (immhi << 2) | immlo;
  if (imm & (1LL << 20)) imm -= (1LL << 21);
  const uintptr_t page = (at & ~uintptr_t(0xFFF)) + uintptr_t(imm << 12);
  uint32_t add = (i1 >> 10) & 0xFFF;
  if (i1 & 0x400000) add <<= 12;
  return page + add;
}

uintptr_t blTarget(uintptr_t at) {  
  uint32_t i;
  std::memcpy(&i, reinterpret_cast<void *>(at), 4);
  if ((i & 0xFC000000u) != 0x94000000u) return 0;
  int64_t imm = i & 0x03FFFFFF;
  if (imm & 0x02000000) imm -= 0x04000000;
  return at + uintptr_t(imm * 4);
}


template <class T> bool rd(uintptr_t a, T &out) { return safeRead(a, &out, sizeof(T)); }


struct FakeByteTag {
  uintptr_t vt;
  uint8_t v;
  uint8_t pad[23];
};
struct FakeIntTag {
  uintptr_t vt;
  int32_t v;
  uint8_t pad[20];
};
struct FakeStringTag {
  uintptr_t vt;
  std::string v;
  uint8_t pad[8];
};



uintptr_t lookupLegacy(const std::string &fullName) {
  HashedString hs(fullName.c_str());
  return reinterpret_cast<uintptr_t>(sLookup(sRegistry(), &hs, 1));
}


struct ResolveReport {
  std::string fail;                
  std::vector<std::string> notes;  
  std::vector<std::string> unknownDirectional;  // keys that look directional but have no transform rule
  int applied = 0, aliased = 0;
};

enum class SetRes { Ok, UnknownKey, Rejected, NotInBlock, OutOfRange, NoPermutation, ReadFailed };
const char *setResText(SetRes r) {
  switch (r) {
    case SetRes::Ok: return "ok";
    case SetRes::UnknownKey: return "unknown state key";
    case SetRes::Rejected: return "value rejected by the game";
    case SetRes::NotInBlock: return "state not used by this block";
    case SetRes::OutOfRange: return "value out of range";
    case SetRes::NoPermutation: return "not in the permutation table";
    case SetRes::ReadFailed: return "memory read failed";
  }
  return "?";
}


SetRes applyState(uintptr_t &block, const BlockStateValue &sv) {
  uintptr_t L = 0;
  if (!rd(block + 0x68, L) || !plausiblePtr(L)) return SetRes::ReadFailed;
  HashedString hk(sv.key.c_str());
  const uintptr_t st = reinterpret_cast<uintptr_t>(sFindState(reinterpret_cast<void *>(L), &hk));
  if (!plausiblePtr(st)) return SetRes::UnknownKey;
  uintptr_t vt = 0, fromTag = 0;
  if (!rd(st, vt) || !plausiblePtr(vt) || !rd(vt + 3 * sizeof(void *), fromTag) || !fromTag) return SetRes::ReadFailed;
  uint64_t r = 0;
  const auto fn = reinterpret_cast<StateFromTagFn>(fromTag);
  if (sv.type == nbt::String) {
    FakeStringTag t{sVtStringTag, sv.s, {}};
    r = fn(reinterpret_cast<void *>(st), &t);
  } else {
    const bool intFirst = sv.type == nbt::Int;
    for (int pass = 0; pass < 2 && !(r & 0x100000000ULL); ++pass) {
      if ((pass == 0) == intFirst) {
        FakeIntTag t{sVtIntTag, sv.i, {}};
        r = fn(reinterpret_cast<void *>(st), &t);
      } else {
        FakeByteTag t{sVtByteTag, uint8_t(sv.i), {}};
        r = fn(reinterpret_cast<void *>(st), &t);
      }
    }
  }
  if (!(r & 0x100000000ULL)) return SetRes::Rejected;
  const uint32_t value = uint32_t(r);
  uint64_t id = 0;
  if (!rd(st + 8, id)) return SetRes::ReadFailed;
  
  const uintptr_t endNode = L + 0x1b0;
  uintptr_t n = 0, cand = endNode;
  if (!rd(L + 0x1b0, n)) return SetRes::ReadFailed;
  for (int guard = 0; n && guard < 64; ++guard) {
    uint64_t key = 0;
    if (!rd(n + 0x20, key)) { n = 0; cand = endNode; break; }
    if (key < id) { if (!rd(n + 8, n)) n = 0; }
    else { cand = n; if (!rd(n, n)) n = 0; }
  }
  uint64_t ckey = 0;
  if (cand == endNode || !rd(cand + 0x20, ckey) || id < ckey) return SetRes::NotInBlock;
  
  uint32_t inst[4];
  uint16_t data = 0;
  uintptr_t perm[2];
  if (!rd(cand + 0x28, inst) || !rd(block + 0x128, data) || !rd(L + 0x1e8, perm)) return SetRes::ReadFailed;
  if (inst[0] <= value) return SetRes::OutOfRange;
  const uint32_t shift = (inst[2] - inst[1] + 1) & 31;
  const uint32_t idx = ((uint32_t(data) & ~inst[3]) | (value << shift)) & 0xFFFF;
  if (perm[1] < perm[0] || idx >= (perm[1] - perm[0]) / 8) return SetRes::NoPermutation;
  uintptr_t nb = 0;
  if (!rd(perm[0] + 8 * idx, nb) || !plausiblePtr(nb)) return SetRes::NoPermutation;
  block = nb;
  return SetRes::Ok;
}




uintptr_t resolveTransformed(const BlockVariant &v, const std::string &modernName,
                             const std::vector<BlockStateValue> &st, ResolveReport *rep) {
  std::string full = v.fullName.find(':') == std::string::npos ? "minecraft:" + v.fullName : v.fullName;
  uintptr_t legacy = lookupLegacy(full);
  if (!plausiblePtr(legacy) && !modernName.empty()) legacy = lookupLegacy("minecraft:" + modernName);
  if (!plausiblePtr(legacy)) {
    if (rep) rep->fail = "unknown block name";
    return 0;
  }
  uintptr_t block = 0;
  if (!rd(legacy + 0x200, block) || !plausiblePtr(block)) {
    if (rep) rep->fail = "no default block";
    return 0;
  }
  for (const auto &sv : st) {
    const SetRes r = applyState(block, sv);
    if (r == SetRes::Ok) {
      if (rep) ++rep->applied;
      continue;
    }
    
    bool done = false;
    if (r == SetRes::UnknownKey || r == SetRes::NotInBlock) {
      BlockStateValue alt[2];
      const int na = states::legacyAliases(modernName, sv, alt);
      for (int k = 0; k < na && !done; ++k) {
        if (applyState(block, alt[k]) == SetRes::Ok) {
          done = true;
          if (rep) {
            ++rep->applied;
            ++rep->aliased;
          }
        }
      }
    }
    if (!done && rep) rep->notes.push_back(sv.key + "=" + states::valueText(sv) + ": " + setResText(r));
  }
  return block;
}

// One shared pipeline: palette states -> rotation/mirror (xf::Table, built once per rot/mirror by
// states::transformBlockState) -> game Block* (resolveTransformed). Hologram textures, the comparison,
// Easy Place and the public API all resolve from the same table.

struct TexCache {
  std::shared_ptr<const Structure> keep;
  int rot = -1;
  bool mirror = false;
  uintptr_t world = 0;  
  uint32_t generation = 0;
  std::vector<uintptr_t> blocks;
  std::vector<uint8_t> occludes;  
  std::vector<uint8_t> logged;    
  std::vector<uint8_t> nStates;   
  std::shared_ptr<const xf::Table> xt;  // shared transformed states (same table as Easy Place)
  std::vector<uint8_t> cmpKeys;   // variant has states that are verified (not game-generated)
  uint32_t logLines = 0;
  size_t next = 0, ok = 0, total = 0;  // batched resolution cursor
} gTexCache;

bool occluderName(const std::string &n) {
  static const char *kYes[] = {"grass_block", "packed_ice", "blue_ice", "sea_lantern", "crafting_table",
                               "fletching_table", "smithing_table", "cartography_table", "mushroom_block",
                               "mushroom_stem", "moss_block", "honeycomb_block"};
  for (const char *k : kYes)
    if (n == k || (n.find(k) != std::string::npos && std::strcmp(k, "mushroom_block") == 0)) return true;
  static const char *kNo[] = {"glass", "leaves", "slab", "stairs", "fence", "wall", "door", "pane", "bars",
                              "torch", "flower", "sapling", "carpet", "rail", "button", "lever", "plate",
                              "sign", "ladder", "vine", "water", "lava", "ice", "slime", "honey", "chain",
                              "lantern", "candle", "cake", "bed", "chest", "anvil", "hopper", "grass",
                              "fern", "bush", "mushroom", "head", "skull", "pot", "banner", "coral", "kelp",
                              "sea", "lily", "web", "snow_layer", "frame", "scaffolding", "bamboo", "cactus",
                              "campfire", "bell", "stand", "table", "piston", "repeater", "comparator", "wire",
                              "tripwire", "hook", "end_rod", "lightning", "pointed", "amethyst_cluster", "bud",
                              "azalea", "dripleaf", "roots", "sprouts", "vines", "spore", "moss_carpet",
                              "pickle", "egg", "conduit", "beacon", "barrier", "light_block", "portal",
                              "farmland", "path", "enchant", "grindstone", "lectern", "stonecutter", "daylight"};
  for (const char *k : kNo)
    if (n.find(k) != std::string::npos) return false;
  return true;
}

std::string variantName(const Structure &T, size_t i) {
  const BlockVariant &v = T.variants[i];
  return v.fullName.find(':') == std::string::npos ? "minecraft:" + v.fullName : v.fullName;
}

// Resolves the structure's block variants to game blocks in batches (kTexBatch per frame) so large
// palettes never stall one frame. Returns true when every variant has been processed.
constexpr size_t kTexBatch = 192;
bool updateTexCache(const std::shared_ptr<const Structure> &S, int rot, bool mirror, uintptr_t world) {
  const Structure &T = *S;
  if (!(gTexCache.keep == S && gTexCache.rot == rot && gTexCache.mirror == mirror && gTexCache.world == world)) {
    gTexCache.keep = S;
    gTexCache.rot = rot;
    gTexCache.mirror = mirror;
    gTexCache.world = world;
    ++gTexCache.generation;
    gTexCache.blocks.assign(T.variants.size(), 0);
    gTexCache.occludes.assign(T.variants.size(), 0);
    gTexCache.logged.assign(T.variants.size(), 0);
    gTexCache.nStates.assign(T.variants.size(), 0);
    gTexCache.xt.reset();
    gTexCache.cmpKeys.assign(T.variants.size(), 0);
    gTexCache.logLines = 0;
    gTexCache.next = 0;
    gTexCache.ok = gTexCache.total = 0;
  }
  if (gTexCache.next >= T.variants.size()) return true;
  if (!gTexCache.xt) gTexCache.xt = xf::peek(S.get(), rot, mirror);  // built by app::poll, never here
  if (!gTexCache.xt || gTexCache.xt->states.size() != T.variants.size()) {
    gTexCache.xt.reset();
    return false;
  }
  const xf::Table &X = *gTexCache.xt;
  const size_t end = std::min(T.variants.size(), gTexCache.next + kTexBatch);
  for (size_t i = gTexCache.next; i < end; ++i) {
    const BlockVariant &v = T.variants[i];
    if (v.palette == kVoid || v.palette >= T.palette.size() || T.palette[v.palette].air) continue;
    ++gTexCache.total;
    gTexCache.nStates[i] = uint8_t(std::min<size_t>(255, v.states.size()));
    ResolveReport rep;
    const std::string &pn = T.palette[v.palette].name;
    gTexCache.blocks[i] = resolveTransformed(v, pn, X.states[i], &rep);
    gTexCache.cmpKeys[i] = X.verified[i];
    if (gLog && !X.unsupported[i].empty())
      gLog->warn("variant {}: {} (shown as stored, Easy Place skips it)", variantName(T, i), X.unsupported[i]);
    gTexCache.occludes[i] = occluderName(T.palette[v.palette].name) ? 1 : 0;
    if (gTexCache.blocks[i]) ++gTexCache.ok;
    if (!gLog) continue;
    if (!gTexCache.blocks[i]) {  
      gTexCache.logged[i] = 1;
      gLog->warn("texture variant {} states={} block=FAIL ({}) model=- vertices=0 fallback=YES", variantName(T, i),
                 v.states.size(), rep.fail);
    } else {
      for (const auto &n : rep.notes) gLog->warn("texture variant {}: state {} not applied", variantName(T, i), n);
    }
  }
  gTexCache.next = end;
  hs::rt().texResolved.store(uint32_t(end), std::memory_order_relaxed);
  hs::rt().texTotal.store(uint32_t(T.variants.size()), std::memory_order_relaxed);
  status().texVarOk.store(uint32_t(gTexCache.ok), std::memory_order_relaxed);
  status().texVarTotal.store(uint32_t(gTexCache.total), std::memory_order_relaxed);
  if (end < T.variants.size()) return false;
  if (gLog) gLog->info("textures: {}/{} block variants with game block (rot={} mirror={})", gTexCache.ok, gTexCache.total,
                       rot & 3, mirror);
  return true;
}


void logVariantResult(const Structure &T, uint16_t v, int verts, bool fallback, const char *why) {
  if (!gLog || v >= gTexCache.logged.size() || gTexCache.logged[v]) return;
  gTexCache.logged[v] = 1;
  if (++gTexCache.logLines > 4000) return;
  const char *model = verts > 0 ? "OK" : verts == 0 ? "NONE" : "BROKEN";
  if (fallback)
    gLog->warn("texture variant {} states={} block=OK model={} vertices={} fallback=YES ({})", variantName(T, v),
               gTexCache.nStates[v], model, std::max(verts, 0), why);
  else
    gLog->info("texture variant {} states={} block=OK model=OK vertices={} fallback=NO", variantName(T, v),
               gTexCache.nStates[v], verts);
}



struct DoorCache {
  std::shared_ptr<const Structure> keep;
  int rot = -1;
  bool mirror = false;
  std::vector<int8_t> info;
} gDoorCache;

void updateDoorCache(const std::shared_ptr<const Structure> &S, int rot, bool mirror) {
  if (gDoorCache.keep == S && gDoorCache.rot == rot && gDoorCache.mirror == mirror) return;
  const Structure &T = *S;
  const auto X = xf::peek(S.get(), rot, mirror);  // shared transformed states; retried next frame if not built
  if (!X || X->states.size() != T.variants.size()) return;
  gDoorCache.keep = S;
  gDoorCache.rot = rot;
  gDoorCache.mirror = mirror;
  gDoorCache.info.assign(T.variants.size(), -1);
  for (size_t i = 0; i < T.variants.size(); ++i) {
    const BlockVariant &v = T.variants[i];
    if (v.palette == kVoid || v.palette >= T.palette.size()) continue;
    const std::string &n = T.palette[v.palette].name;
    if (!states::isDoorName(n)) continue;
    gDoorCache.info[i] = int8_t(states::doorInfo(X->states[i]));
  }
}








constexpr int kWin = 20;
std::atomic<bool> gWinOn{false};
pthread_t gWinTid{};
uintptr_t gWinRegion = 0;
int gWinX0 = 0, gWinY0 = 0, gWinZ0 = 0;
uintptr_t gWinBlk[kWin * kWin * kWin];  
void *gGetBlockOrig = nullptr;          
uintptr_t gGetBlockTarget = 0;          
std::atomic<bool> sGetBlockHooked{false};
std::atomic<uint32_t> gWinHits{0};
uintptr_t gLibBase = 0;  

void *getBlockDetour(void *region, const BlockPos &pos) {
  if (gWinOn.load(std::memory_order_relaxed)) [[unlikely]] {
    if (untag(reinterpret_cast<uintptr_t>(region)) == gWinRegion && pthread_equal(pthread_self(), gWinTid)) {
      const unsigned ix = unsigned(pos.x - gWinX0), iy = unsigned(pos.y - gWinY0), iz = unsigned(pos.z - gWinZ0);
      if (ix < unsigned(kWin) && iy < unsigned(kWin) && iz < unsigned(kWin)) {
        const uintptr_t b = gWinBlk[(ix * kWin + iy) * kWin + iz];
        if (b) {
          gWinHits.fetch_add(1, std::memory_order_relaxed);
          return reinterpret_cast<void *>(b);
        }
      }
    }
  }
  void *orig;
  while (!(orig = __atomic_load_n(&gGetBlockOrig, __ATOMIC_ACQUIRE))) {
  }
  return reinterpret_cast<GetBlockFn>(orig)(region, pos);
}


struct WinScope {
  explicit WinScope(bool on) : active(on) {
    if (active) gWinOn.store(true, std::memory_order_release);
  }
  ~WinScope() {
    if (active) gWinOn.store(false, std::memory_order_release);
  }
  bool active;
};


constexpr float kCullBand = 4.f;     
constexpr float kCullRebuild = 2.f;  
struct TexFrame {
  bool ok = false;
  bool begun = false;
  uintptr_t tess = 0, bt = 0;
  uintptr_t region = 0;  
  void *ctx = nullptr;
  void *mat = nullptr;
  alignas(16) uint8_t texVariant[0x28]{};  
  Vec3 cam;
  uint8_t alpha = 0x80;
  int tint = 0;
  uint32_t tintRgb = kDefaultBlockColor[ColMissing];  
  
  
  
  bool cull = false;
  float ccx = 0, ccy = 0, ccz = 0;
  void *lineMat = nullptr;
  int threshold = 2048;
  int blocks = 0;
  uint32_t verts = 0, zero = 0;
  int ox = 0, oy = 0, oz = 0;              
  std::vector<struct MeshBlob *> *out = nullptr;  
};

MaterialPtr *texMaterialFor(int i) {
  if (!sTexMats[i] && sMaterialGroup && matRetryDue(sTexRetry[i])) {
    matRetryStep(sTexRetry[i]);
    hs::rt().matAttempts.store(sTexRetry[i].attempts, std::memory_order_relaxed);
    void **vt = nullptr;
    if (!safeRead(sMaterialGroup, &vt, sizeof(vt)) || !plausiblePtr(reinterpret_cast<uintptr_t>(vt))) vt = nullptr;
    if (vt && vt[off::VT_RenderMaterialGroup_getMaterial]) {
      using GetMat = MaterialPtr (*)(void *, const HashedString *);
      HashedString hs(kLooks[i].mat);
      sTexMats[i] = reinterpret_cast<GetMat>(vt[off::VT_RenderMaterialGroup_getMaterial])(
          reinterpret_cast<void *>(sMaterialGroup), &hs);
      if (gLog) gLog->info("textures: material {} {} (attempt {}/{})", kLooks[i].mat, sTexMats[i] ? "OK" : "unavailable",
                           sTexRetry[i].attempts, kMatMaxAttempts);
    }
  }
  return sTexMats[i] ? &sTexMats[i] : nullptr;
}


int effectiveLook(int want) {
  want = std::clamp(want, 0, kLookCount - 1);
  if (texMaterialFor(want)) return want;
  return 0;
}

void *texMaterial(uintptr_t bt, int look) {
  if (MaterialPtr *m = texMaterialFor(look)) return m;
  if (MaterialPtr *m = texMaterialFor(0)) return m;
  auto *ui = reinterpret_cast<MaterialPtr *>(bt + 0x5e0);  
  return *ui ? ui : nullptr;
}


bool texFrameSetup(TexFrame &f, uintptr_t lrp, uintptr_t tess, void *ctx, const Vec3 &cam, float alpha, int want) {
  f = TexFrame{};
  auto &st = status();
  if (!texReady()) { st.texStage.store(0, std::memory_order_relaxed); return false; }
  uintptr_t owner = 0;
  uintptr_t tex[4]{};
  
  
  if (!rd(lrp + 0x1120, owner) || !plausiblePtr(owner) || !rd(owner + 0x1a8, tex)) {
    st.texStage.store(1, std::memory_order_relaxed);
    return false;
  }
  const uintptr_t bt = reinterpret_cast<uintptr_t>(sGetBT(reinterpret_cast<void *>(owner)));
  uintptr_t region = 0;
  if (!plausiblePtr(bt) || !rd(bt + 8, region) || !plausiblePtr(region)) {
    st.texStage.store(2, std::memory_order_relaxed);
    return false;
  }
  (void)want;
  const int look = effectiveLook(alpha >= 0.99f ? 1 : 0);
  void *mat = texMaterial(bt, look);
  if (!mat) { st.texStage.store(3, std::memory_order_relaxed); return false; }
  st.texStage.store(4, std::memory_order_relaxed);
  int cap = 0;
  rd(tess + 0x294, cap);
  f.threshold = cap > 1536 ? std::min(cap - 1024, 16384) : std::max(256, cap / 2);
  std::memcpy(f.texVariant, tex, sizeof(tex));  
  const uint32_t index = 1;
  std::memcpy(f.texVariant + 0x20, &index, 4);
  f.tess = tess;
  f.bt = bt;
  f.region = untag(region);
  f.ctx = ctx;
  
  static uintptr_t checkedVt = 0;
  uintptr_t vt = 0, slot2 = 0;
  if (gLog && rd(region, vt) && vt != checkedVt && rd(untag(vt) + 2 * sizeof(void *), slot2)) {
    checkedVt = vt;
    if (!sGetBlockHooked.load(std::memory_order_relaxed))
      gLog->warn("textures: hologram window for shape reads unavailable (getBlock hook not installed)");
    else if (untag(slot2) != untag(gGetBlockTarget))
      gLog->warn("textures: region getBlock slot {:#x} is not the hooked function {:#x}; doors may fall back",
                 untag(slot2) - gLibBase, untag(gGetBlockTarget) - gLibBase);
    else
      gLog->info("textures: hologram window active for shape reads (region getBlock = hooked function)");
  }
  f.mat = mat;
  f.cam = cam;
  f.alpha = kLooks[look].useAlpha ? uint8_t(std::lround(std::clamp(alpha, 0.05f, 1.f) * 255.f)) : 0xFF;
  f.tint = kLooks[look].tint;
  f.tintRgb = settings().blockColor[ColMissing].load(std::memory_order_relaxed);
  f.lineMat = lineMaterial(lrp);
  f.ok = true;
  return true;
}

void texSetOffset(uintptr_t tess, float x, float y, float z) {
  float *o = reinterpret_cast<float *>(tess + 0x1cc);
  o[0] = x; o[1] = y; o[2] = z;
}

void texBegin(TexFrame &f) {
  void *t = reinterpret_cast<void *>(f.tess);
  sBegin(t, nullptr, QuadList, 4096, 0);
  texSetOffset(f.tess, -float(f.ox), -float(f.oy), -float(f.oz));  
  sColor(t, 1.f, 1.f, 1.f, f.alpha / 255.f);
  f.begun = true;
}


void texCut(TexFrame &f) {
  if (!f.begun) return;
  int n = 0;
  rd(f.tess + 0x290, n);
  if (n > 0 && f.out) {
    static const char kName[] = "Structura";
    perf::count(perf::MeshRebuild);
    perf::count(perf::Alloc);
    ep::setStep("build: tessellator end mesh");
    auto *m = new MeshBlob(sTessEnd(reinterpret_cast<void *>(f.tess), 0, kName, sizeof(kName) - 1, 0));
    f.out->push_back(m);
  }
  sTessClear(reinterpret_cast<void *>(f.tess));  
  f.begun = false;
}



int texBlock(TexFrame &f, uintptr_t block, int wx, int wy, int wz) {
  if (!f.begun) texBegin(f);
  const uintptr_t t = f.tess;
  uintptr_t pv[2], cv[2];
  if (!rd(t + 0x10, pv) || !rd(t + 0x70, cv)) return -1;
  const size_t pb = (pv[1] - pv[0]) / sizeof(Vec3), cb = (cv[1] - cv[0]) / 4;
  *reinterpret_cast<uint32_t *>(f.bt + 0x78) = uint32_t(sBlockFlag(reinterpret_cast<void *>(block)) & 0xFF);
  const BlockPos pos{wx, wy, wz};
  ep::setStep("build: tessellate in world");
  sTessInWorld(reinterpret_cast<void *>(f.bt), reinterpret_cast<void *>(t), reinterpret_cast<void *>(block), pos, 0);
  if (!rd(t + 0x10, pv) || !rd(t + 0x70, cv)) return -1;
  const size_t pa = (pv[1] - pv[0]) / sizeof(Vec3), ca = (cv[1] - cv[0]) / 4;
  
  
  if (pa > pb) {
    Vec3 *p = reinterpret_cast<Vec3 *>(untag(pv[0]));
    const float bx = float(wx - f.ox), by = float(wy - f.oy), bz = float(wz - f.oz);
    bool bad = false;
    const bool quads = (pa - pb) % 4 == 0;  
    float area = quads ? 0.f : 1.f;
    for (size_t i = pb; i < pa && !bad; ++i) {
      const float rx = p[i].x - bx, ry = p[i].y - by, rz = p[i].z - bz;
      if (!std::isfinite(rx) || !std::isfinite(ry) || !std::isfinite(rz) || rx < -1.f || rx > 2.f || ry < -1.f ||
          ry > 2.f || rz < -1.f || rz > 2.f)
        bad = true;
    }
    for (size_t q = pb; quads && !bad && q + 3 < pa; q += 4) {
      const float ax = p[q + 2].x - p[q].x, ay = p[q + 2].y - p[q].y, az = p[q + 2].z - p[q].z;
      const float cx = p[q + 3].x - p[q + 1].x, cy = p[q + 3].y - p[q + 1].y, cz = p[q + 3].z - p[q + 1].z;
      const float nx = ay * cz - az * cy, ny = az * cx - ax * cz, nz = ax * cy - ay * cx;
      area += 0.5f * std::sqrt(nx * nx + ny * ny + nz * nz);
    }
    if (bad || area < 0.02f) {
      for (size_t i = pb + 1; i < pa; ++i) p[i] = p[pb];
      if (ca > cb) {
        uint32_t *c = reinterpret_cast<uint32_t *>(untag(cv[0]));
        for (size_t i = cb; i < ca; ++i) c[i] &= 0x00FFFFFFu;
      }
      int n = 0;
      rd(t + 0x290, n);
      if (n >= f.threshold) texCut(f);
      return -1;
    }
  }
  
  if (ca > cb) {
    uint32_t *c = reinterpret_cast<uint32_t *>(untag(cv[0]));
    
    if (f.tint == 0) {
      for (size_t i = cb; i < ca; ++i) c[i] = (c[i] & 0x00FFFFFFu) | (uint32_t(f.alpha) << 24);
    } else {
      for (size_t i = cb; i < ca; ++i) {
        uint32_t r = c[i] & 0xFF, g = (c[i] >> 8) & 0xFF, b = (c[i] >> 16) & 0xFF;
        if (f.tint == 1) {  
          
          const uint32_t tr = (f.tintRgb >> 16) & 0xFF, tg = (f.tintRgb >> 8) & 0xFF, tb = f.tintRgb & 0xFF;
          const uint32_t tmax = std::max(tr, std::max(tg, tb));
          const uint32_t l0 = std::max(r, std::max(g, b)), l = l0 + (255 - l0) * 40 / 100;
          r = std::min<uint32_t>(255, (r * 35 + l * 65 * tr / 255) / 100 + (tr == tmax ? 12 : 0));
          g = std::min<uint32_t>(255, (g * 35 + l * 65 * tg / 255) / 100 + (tg == tmax ? 12 : 0));
          b = std::min<uint32_t>(255, (b * 35 + l * 65 * tb / 255) / 100 + (tb == tmax ? 12 : 0));
        } else {  
          r = r * 62 / 100; g = g * 62 / 100; b = b * 62 / 100;
        }
        c[i] = (uint32_t(f.alpha) << 24) | (b << 16) | (g << 8) | r;
      }
    }
  }
  
  if (f.cull && pa > pb && (pb % 4) == 0 && ((pa - pb) % 4) == 0) {
    Vec3 *p = reinterpret_cast<Vec3 *>(untag(pv[0]));
    const float base[3] = {float(wx - f.ox), float(wy - f.oy), float(wz - f.oz)};
    const float cc[3] = {f.ccx, f.ccy, f.ccz};
    for (size_t q = pb; q + 3 < pa; q += 4) {
      for (int a = 0; a < 3; ++a) {
        auto co = [&](size_t i) { return a == 0 ? p[i].x : a == 1 ? p[i].y : p[i].z; };
        const float v = co(q);
        if (std::fabs(co(q + 1) - v) > 1e-3f || std::fabs(co(q + 2) - v) > 1e-3f || std::fabs(co(q + 3) - v) > 1e-3f)
          continue;
        const float t = v - base[a];
        const bool plus = std::fabs(t - 1.f) < 1e-3f, minus = std::fabs(t) < 1e-3f;
        if ((plus && v > cc[a] + kCullBand) || (minus && v < cc[a] - kCullBand))
          p[q + 1] = p[q + 2] = p[q + 3] = p[q];  
        break;
      }
    }
  }
  
  if (pa > pb) {
    Vec3 *p = reinterpret_cast<Vec3 *>(untag(pv[0]));
    const float cx = float(wx - f.ox) + 0.5f, cy = float(wy - f.oy) + 0.5f, cz = float(wz - f.oz) + 0.5f, k = 0.996f;
    for (size_t i = pb; i < pa; ++i) {
      p[i].x = cx + (p[i].x - cx) * k;
      p[i].y = cy + (p[i].y - cy) * k;
      p[i].z = cz + (p[i].z - cz) * k;
    }
  }
  ++f.blocks;
  f.verts += uint32_t(pa - pb);
  int n = 0;
  rd(t + 0x290, n);
  if (n >= f.threshold) texCut(f);
  return int(pa - pb);
}

void texFrameEnd(TexFrame &f) {
  texCut(f);
  texSetOffset(f.tess, 0.f, 0.f, 0.f);
  sBTReset(reinterpret_cast<void *>(f.bt), BlockPos{0, -30000, 0});  
}


void drawMesh(TexFrame &f, uintptr_t stack, MeshBlob *m, float tx, float ty, float tz, void *mat = nullptr,
              bool noTex = false) {
  ep::setStep("draw: matrix push");
  MatRef ref = sMatPush(reinterpret_cast<void *>(stack), 0);
  if (ref.m) {
    *reinterpret_cast<uint8_t *>(stack + 0x40) = 1;  
    float *M = ref.m;
    for (int i = 0; i < 4; ++i) M[12 + i] += M[i] * tx + M[4 + i] * ty + M[8 + i] * tz;
    char pad[0x58]{};
    
    ep::setStep("draw: mesh render");
    sMeshRender(m->b, static_cast<char *>(f.ctx) + 0x10, mat ? mat : f.mat, noTex ? nullptr : f.texVariant, 0, 0, pad,
                nullptr);
    status().meshCalls.fetch_add(1, std::memory_order_relaxed);
  }
  ep::setStep("draw: matrix pop");
  sMatPop(&ref);
}

double nowMs() {
  timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}
std::atomic<int> gApiBox[6];
std::atomic<double> gApiBoxAt{-1e9};


uintptr_t currentRegion() {
  // World reads go through the player only while its context is fresh (a quiet tick source may mean the
  // world is being torn down).
  if (!ctx::fresh(ctx::monoMs())) return 0;
  const uintptr_t player = status().player.load(std::memory_order_relaxed);
  uintptr_t dim, region;
  if (!plausiblePtr(player) || !safeReadPtr(player + off::Actor_mDimension, dim) || !plausiblePtr(dim)) return 0;
  if (!safeReadPtr(dim + off::Dimension_mBlockSource, region) || !plausiblePtr(region)) return 0;
  return region;
}

uintptr_t gAir = 0;
uintptr_t gAirRegion = 0;
int gNameTries = 0;

uintptr_t blockAt(uintptr_t region, int x, int y, int z) {
  return reinterpret_cast<uintptr_t>(sGetBlock(reinterpret_cast<void *>(region), BlockPos{x, y, z}));
}

void ensureAirAndNames(uintptr_t region) {
  if (region != gAirRegion) {
    gAir = blockAt(region, 0, 32767, 0);  
    gAirRegion = region;
  }
  auto &st = status();
  if (names::ready() || st.namesState.load() != 0 || !gAir) return;
  static int frame = 0;
  if (++frame % 30) return;
  
  const int fx = int(std::floor(st.feetX.load())), fy = int(std::floor(st.feetY.load())),
            fz = int(std::floor(st.feetZ.load()));
  std::vector<uintptr_t> others;
  static const int cols[5][2] = {{0, 0}, {3, 0}, {-3, 0}, {0, 3}, {0, -3}};
  for (auto &c : cols)
    for (int dy = 1; dy < 80 && others.size() < 4; ++dy) {
      const uintptr_t b = blockAt(region, fx + c[0], fy - dy, fz + c[1]);
      if (b && b != gAir && std::find(others.begin(), others.end(), b) == others.end()) {
        others.push_back(b);
        break;  
      }
    }
  if (others.empty()) return;
  if (names::discover(gAir, others)) {
    st.namesState.store(1);
    if (gLog) gLog->info("block names: OK ({})", names::describe());  
  } else if (++gNameTries > 20) {
    st.namesState.store(-1);
    if (gLog) gLog->warn("block names: not found (partial compare, capture off)");
  }
}


struct CmpCursor {
  uint64_t gen = 0;
  size_t pos = 0;
} gCmp;





int64_t stateValue(uintptr_t block, const std::string &key);

// Value of one palette state on a game block, trying the legacy aliases of the key (1.20 palettes).
struct CmpCtx {
  uintptr_t blk[2];  // 0 expected, 1 actual
  const std::string *name;
};
int64_t cmpValue(void *ctx, int side, const BlockStateValue &sv) {
  const auto *c = static_cast<const CmpCtx *>(ctx);
  int64_t r = stateValue(c->blk[side & 1], sv.key);
  if (r >= 0) return r;
  BlockStateValue alt[2];
  const int na = states::legacyAliases(*c->name, sv, alt);
  for (int k = 0; k < na; ++k)
    if ((r = stateValue(c->blk[side & 1], alt[k].key)) >= 0) return r;
  return -1;
}

// Same type, different Block*: exact state classification, memoised per (world block, expected block).
struct ClassSlot {
  uintptr_t world = 0, expected = 0;
  uint32_t gen = 0;
  uint8_t res = 0;
};
constexpr size_t kClassSlots = 8192;
ClassSlot gClass[kClassSlots];
uint8_t classifyState(uint16_t v, const std::string &name, uintptr_t world, uintptr_t expected) {
  const size_t h = size_t(((world >> 4) * 0x9E3779B1u) ^ (expected >> 4)) & (kClassSlots - 1);
  ClassSlot &e = gClass[h];
  const uint32_t gen = gTexCache.generation + 1;  // never 0
  if (e.world == world && e.expected == expected && e.gen == gen) return e.res;
  uint8_t res = CmpCorrect;
  if (gTexCache.xt && v < gTexCache.xt->states.size()) {
    CmpCtx ctx{{expected, world}, &name};
    const auto c = states::compareStates(gTexCache.xt->states[v], name, &cmpValue, &ctx);
    res = c.match == states::Match::StateMismatch ? CmpWrongState : CmpCorrect;
  }
  e.world = world;
  e.expected = expected;
  e.gen = gen;
  e.res = res;
  return res;
}

uint8_t compareOne(const Structure &s, uint16_t p, uint16_t v, uintptr_t world, uintptr_t expected) {
  if (p == kVoid) return CmpUnknown;
  const bool worldAir = (world == gAir);
  if (s.palette[p].air) return worldAir ? CmpAirOk : CmpExtra;
  if (worldAir) return CmpMissing;
  if (expected && world == expected) return CmpCorrect;  
  if (!names::ready()) return CmpCorrect;  
  const std::string *n = names::nameOf(world);
  if (!n) return CmpWrong;
  if (!states::sameBlockType(*n, s.palette[p].name)) return CmpWrong;
  return expected ? classifyState(v, s.palette[p].name, world, expected) : CmpCorrect;
}


std::mutex gCapMu;
CaptureResult gCapDone;
bool gCapReady = false;
std::string gCapError;
struct CapJob {
  bool active = false;
  int x0, y0, z0, sx, sy, sz;
  size_t next = 0;
  std::vector<int32_t> idx;
  std::vector<std::string> names;
  std::unordered_map<const std::string *, int32_t> map;
  int32_t airIdx = -1;
} gCap;

void captureStep(uintptr_t region) {
  auto &st = status();
  if (!gCap.active) {
    if (!st.captureRequest.exchange(false)) return;
    auto &m = model();
    std::lock_guard<std::mutex> lk(m.mu);
    if (!m.cornerA || !m.cornerB) return;
    gCap = CapJob{};
    gCap.x0 = std::min(m.ax, m.bx); gCap.y0 = std::min(m.ay, m.by); gCap.z0 = std::min(m.az, m.bz);
    gCap.sx = std::abs(m.ax - m.bx) + 1; gCap.sy = std::abs(m.ay - m.by) + 1; gCap.sz = std::abs(m.az - m.bz) + 1;
    gCap.idx.assign(size_t(gCap.sx) * gCap.sy * gCap.sz, -1);
    gCap.active = true;
    st.captureProgress.store(0);
  }
  if (!names::ready()) {
    gCap.active = false;
    st.captureProgress.store(-1);
    std::lock_guard<std::mutex> lk(gCapMu);
    gCapError = "Not ready, try again";
    return;
  }
  const size_t total = gCap.idx.size();
  const size_t end = std::min(total, gCap.next + 32768);
  for (; gCap.next < end; ++gCap.next) {
    const size_t k = gCap.next;
    const int x = int(k / (size_t(gCap.sy) * gCap.sz)), y = int((k / gCap.sz) % gCap.sy), z = int(k % gCap.sz);
    const uintptr_t b = blockAt(region, gCap.x0 + x, gCap.y0 + y, gCap.z0 + z);
    if (!b || b == gAir) {
      if (gCap.airIdx < 0) {
        gCap.airIdx = int32_t(gCap.names.size());
        gCap.names.push_back("minecraft:air");
      }
      gCap.idx[k] = gCap.airIdx;
      continue;
    }
    const std::string *n = names::nameOf(b);
    if (!n) continue;  
    auto it = gCap.map.find(n);
    if (it == gCap.map.end()) {
      it = gCap.map.emplace(n, int32_t(gCap.names.size())).first;
      gCap.names.push_back("minecraft:" + *n);
    }
    gCap.idx[k] = it->second;
  }
  st.captureProgress.store(int(gCap.next * 100 / std::max<size_t>(1, total)));
  if (gCap.next >= total) {
    std::lock_guard<std::mutex> lk(gCapMu);
    gCapDone = CaptureResult{gCap.sx, gCap.sy, gCap.sz, gCap.x0, gCap.y0, gCap.z0, std::move(gCap.names),
                             std::move(gCap.idx)};
    gCapReady = true;
    gCap = CapJob{};
    st.captureProgress.store(-1);
  }
}


enum Kind : uint8_t { KNone = 0, KNormal, KWrong, KExtra, KCorrect, KWrongState };

inline uint64_t chunkKey(int cx, int cy, int cz) {
  return (uint64_t(uint32_t(cx) & 0x1FFFFF) << 42) | (uint64_t(uint32_t(cy) & 0x1FFFFF) << 21) | (uint32_t(cz) & 0x1FFFFF);
}

struct Flash {
  int x, y, z;
  double at;
};
std::vector<Flash> gFlash;
void pushFlash(int x, int y, int z) {
  if (gFlash.size() >= 256) gFlash.erase(gFlash.begin());
  gFlash.push_back({x, y, z, nowMs()});
}

inline uint64_t posKey(int x, int y, int z) {
  return (uint64_t(uint32_t(x) & 0x3FFFFFF) << 38) | (uint64_t(uint32_t(y) & 0xFFF) << 26) | (uint32_t(z) & 0x3FFFFFF);
}
inline void posFromKey(uint64_t k, int &x, int &y, int &z) {
  x = int(uint32_t(k >> 38) << 6) >> 6;
  y = int(uint32_t((k >> 26) & 0xFFF) << 20) >> 20;
  z = int(uint32_t(k & 0x3FFFFFF) << 6) >> 6;
}


struct ChunkMeshes {
  std::vector<MeshBlob *> meshes;
  bool culled = false;            
  float bcx = 0, bcy = 0, bcz = 0;  
  std::vector<uint64_t> special;  
  bool built = false;             
  bool dirty = true;              
  uint32_t builtFrame = 0, seenFrame = 0;
};
std::unordered_map<uint64_t, ChunkMeshes> gChunks;
uint64_t gChunkSig = 0;
// Mesh budget: hard cap on live hologram meshes (nearest chunks are built first).
constexpr uint32_t kMaxMeshes = 6000;
constexpr int kMaxBuildsPerFrame = 8;
uint32_t gMeshTotal = 0;
// Per-frame results of drawStructure (render thread only).
struct FrameOut {
  bool texOn = false, outOfRange = false, capped = false, texPending = false;
  uint32_t chunksTotal = 0, chunksBuilt = 0, builds = 0, meshesDrawn = 0;
  uint64_t sig = 0;
} gOut;
bool gTexNoPrefill = false;  
int gTexEmptyChunks = 0;


std::vector<std::pair<MeshBlob *, uint32_t>> gGraveyard;
void buryMesh(MeshBlob *m) { gGraveyard.push_back({m, gFrame}); }
void reapMeshes(bool all) {
  size_t k = 0;
  for (auto &e : gGraveyard) {
    // 4 frames was too short: the game's Rendering Pool can still draw a freed mesh a while after it was dropped,
    // and destroying it then touches its mutex ("pthread_mutex_lock called on a destroyed mutex"). Keep it ~1.5 s.
    if (all || gFrame - e.second >= 90) {
      sMeshDestroy(e.first->b);
      delete e.first;
    } else {
      gGraveyard[k++] = e;
    }
  }
  gGraveyard.resize(k);
}
void freeChunk(ChunkMeshes &c) {
  for (MeshBlob *m : c.meshes) buryMesh(m);
  gMeshTotal -= std::min<uint32_t>(gMeshTotal, uint32_t(c.meshes.size()));
  c.meshes.clear();
}
// Render context replaced (EGL context changed): the old meshes belong to a dead context, so they are
// dropped without calling the game's destroy on them (bounded leak instead of touching stale handles).
void abandonAllChunks() {
  for (auto &kv : gChunks) {
    for (MeshBlob *m : kv.second.meshes) delete m;
    kv.second.meshes.clear();
  }
  gChunks.clear();
  for (auto &e : gGraveyard) delete e.first;
  gGraveyard.clear();
  gMeshTotal = 0;
}
void freeAllChunks() {
  for (auto &kv : gChunks) freeChunk(kv.second);
  gChunks.clear();
}

// visible-layer box (world coords, inclusive) shared by the hologram, the overlay and Easy Place
void apiLayerBox(const Structure &T, const Placement &P, int layer, int layer2, int b[6]);

void drawStructure(const Vec3 &cam, uintptr_t region, TexFrame *tf) {
  ep::setStep("hologram: draw");
  auto &s = settings();
  auto &st = status();
  std::shared_ptr<const Structure> S;
  std::shared_ptr<CompareData> C;
  Placement P;
  int layer = 0, layer2 = 0;
  uint64_t gen = 0;
  {
    
    
    struct Snap {
      std::shared_ptr<const Structure> S;
      std::shared_ptr<CompareData> C;
      Placement P;
      int layer = 0, layer2 = 0;
      uint64_t gen = 0;
    };
    static Snap snap;
    auto &m = model();
    std::unique_lock<std::mutex> lk(m.mu, std::try_to_lock);
    if (lk.owns_lock()) {
      if (!m.structure || !m.placed) {
        snap = Snap{};
        lk.unlock();
        if (!gChunks.empty()) freeAllChunks();
        return;
      }
      snap.S = m.structure;
      snap.P = m.placement;
      snap.layer = m.layer;
      snap.layer2 = m.layer2;
      snap.gen = m.gen;
      // The compare buffer is allocated on the UI thread (app::poll); use it only when it matches
      // this generation and this world, otherwise compare is skipped for the frame.
      const uint64_t ep = hs::rt().worldEpoch.load(std::memory_order_relaxed);
      snap.C = (m.compare && m.compare->gen == snap.gen && m.compare->epoch == ep && m.compare->n == snap.S->volume())
                   ? m.compare
                   : nullptr;
    } else {
      perf::count(perf::BlockingWait);
      if (!snap.S) return;
    }
    S = snap.S;
    
    
    static std::shared_ptr<const Structure> keepAlive;
    if (keepAlive != S) keepAlive = S;
    P = snap.P;
    layer = snap.layer;
    layer2 = snap.layer2;
    gen = snap.gen;
    C = snap.C;
  }
  const Structure &T = *S;
  int dx, dz;
  rotatedSize(T, P.rot, dx, dz);
  const LayerMode lm = LayerMode(std::clamp(s.layerMode.load(), 0, 4));
  const int axis = std::clamp(s.layerAxis.load(), 0, 2);

  
  const int bx0 = P.ox, bx1 = P.ox + dx - 1, by0 = P.oy, by1 = P.oy + T.sy - 1, bz0 = P.oz, bz1 = P.oz + dz - 1;
  
  // one implementation of the layer box: what is drawn is exactly what Easy Place may place
  int lb[6];
  apiLayerBox(T, P, layer, layer2, lb);
  (void)axis;
  const int sx0 = lb[0], sx1 = lb[1], sy0 = lb[2], sy1 = lb[3], sz0 = lb[4], sz1 = lb[5];
  
  gApiBox[0].store(sx0, std::memory_order_relaxed); gApiBox[1].store(sx1, std::memory_order_relaxed);
  gApiBox[2].store(sy0, std::memory_order_relaxed); gApiBox[3].store(sy1, std::memory_order_relaxed);
  gApiBox[4].store(sz0, std::memory_order_relaxed); gApiBox[5].store(sz1, std::memory_order_relaxed);
  gApiBoxAt.store(nowMs(), std::memory_order_release);

  
  boxLines(float(bx0), float(by0), float(bz0), float(bx1 + 1), float(by1 + 1), float(bz1 + 1), Rgba{1.f, 0.85f, 0.2f, 1.f});
  if (lm != LayerMode::All)
    boxLines(float(sx0), float(sy0), float(sz0), float(sx1 + 1), float(sy1 + 1), float(sz1 + 1), Rgba{0.2f, 0.9f, 1.f, 1.f});

  const bool hideCorrect = s.hideCorrect.load();
  const int filter = std::clamp(s.holoFilter.load(), 0, 3);
  const float alpha = std::clamp(s.alpha.load(), 0.05f, 1.f);
  const bool texOn = tf && tf->ok && T.vidx.size() == T.volume() && !T.variants.empty();
  if (texOn && !updateTexCache(S, P.rot, P.mirror, untag(region))) {
    // Still resolving block variants: show the outline only, build meshes once every variant is known.
    gOut.texOn = true;
    gOut.texPending = true;
    return;
  }
  gOut.texPending = false;
  const bool hasVariants = T.vidx.size() == T.volume() && !T.variants.empty();
  // Without textures the comparison still needs the transformed states + expected blocks (same cache,
  // resolved in batches of kTexBatch per frame, no meshes).
  bool statesReady = texOn;
  if (!texOn && hasVariants && sLookup && sRegistry && sFindState && sVtByteTag && sVtIntTag &&
      sVtStringTag)
    statesReady = updateTexCache(S, P.rot, P.mirror, untag(region));
  if (hasVariants) updateDoorCache(S, P.rot, P.mirror);

  
  static int pf[6] = {0, 0, 0, 0, 0, 0};
  {
    uint64_t h = 1469598103934665603ull;
    auto mix = [&](uint64_t v) { h = (h ^ v) * 1099511628211ull; };
    mix(reinterpret_cast<uintptr_t>(S.get()));
    mix(uint32_t(P.ox)); mix(uint32_t(P.oy)); mix(uint32_t(P.oz)); mix(uint32_t(P.rot)); mix(P.mirror ? 1 : 0);
    mix(hideCorrect); mix(uint32_t(filter)); mix(gTexNoPrefill); mix(texOn); mix(region);
    mix(hs::rt().worldEpoch.load(std::memory_order_relaxed));
    mix(hs::rt().renderEpoch.load(std::memory_order_relaxed));
    static uint64_t lastAlpha = 0;
    
    const uint64_t a8 = tf ? (uint64_t(tf->alpha) | uint64_t(tf->tint) << 8 | uint64_t(tf->tintRgb & 0xFFFFFF) << 16)
                           : uint64_t(std::lround(alpha * 255.f));
    if (h != gChunkSig) {
      // A preparation still in progress for the old signature is cancelled (its chunks are discarded).
      if (gChunkSig && gOut.chunksTotal > gOut.chunksBuilt) {
        hs::rt().cancelled.fetch_add(1, std::memory_order_relaxed);
        hs::rt().lastCancelWhy.store(int(hs::Why::StructureChanged), std::memory_order_relaxed);
      }
      gChunkSig = h;
      hs::rt().buildGen.fetch_add(1, std::memory_order_relaxed);
      freeAllChunks();
    } else if (a8 != lastAlpha) {
      for (auto &kv : gChunks) kv.second.dirty = true;  
    } else if (pf[0] != sx0 || pf[1] != sx1 || pf[2] != sy0 || pf[3] != sy1 || pf[4] != sz0 || pf[5] != sz1) {
      
      const int nb[6] = {sx0, sx1, sy0, sy1, sz0, sz1};
      for (auto &kv : gChunks) {
        const uint64_t k = kv.first;
        const int qx = int(uint32_t(k >> 42) << 11) >> 11, qy = int(uint32_t((k >> 21) & 0x1FFFFF) << 11) >> 11,
                  qz = int(uint32_t(k & 0x1FFFFF) << 11) >> 11;
        const int q[3] = {qx, qy, qz};
        bool hit = false;
        for (int a = 0; a < 3 && !hit; ++a) {
          for (int e = 0; e < 2 && !hit; ++e) {
            const int o = pf[a * 2 + e], n = nb[a * 2 + e];
            if (o == n) continue;
            const int lo = std::min(o, n) - 1, hi = std::max(o, n) + 1;
            if (q[a] * 16 <= hi && q[a] * 16 + 15 >= lo) hit = true;
          }
        }
        if (hit) kv.second.dirty = true;
      }
    }
    lastAlpha = a8;
    pf[0] = sx0; pf[1] = sx1; pf[2] = sy0; pf[3] = sy1; pf[4] = sz0; pf[5] = sz1;
  }

  const int R = std::clamp(s.radius.load(), 4, 64);
  const int cx = int(std::floor(cam.x)), cy = int(std::floor(cam.y)), cz = int(std::floor(cam.z));
  
  const int vx0 = std::max(bx0, cx - R), vx1 = std::min(bx1, cx + R);
  const int vy0 = std::max(by0, cy - R), vy1 = std::min(by1, cy + R);
  const int vz0 = std::max(bz0, cz - R), vz1 = std::min(bz1, cz + R);
  const int x0 = std::max(sx0, cx - R), x1 = std::min(sx1, cx + R);
  const int y0 = std::max(sy0, cy - R), y1 = std::min(sy1, cy + R);
  const int z0 = std::max(sz0, cz - R), z1 = std::min(sz1, cz + R);

  // Display filter (holoFilter): 0 all, 1 missing only, 2 incorrect only, 3 unverified only. Display only:
  // it never changes what Easy Place places.
  auto kindOf = [&](uint16_t p, uint8_t c, uint8_t ep) -> Kind {
    if (T.palette[p].air) return (c == CmpExtra && filter != 1 && filter != 3) ? KExtra : KNone;
    const bool incorrect = c == CmpWrong || c == CmpWrongState;
    if (filter == 1 && !(c == CmpMissing || (c == CmpUnknown && ep != EpUnsupported))) return KNone;
    if (filter == 2 && !incorrect) return KNone;
    if (filter == 3 && c != CmpUnknown) return KNone;
    if (c == CmpCorrect) return hideCorrect ? KNone : KCorrect;
    if (c == CmpWrong) return KWrong;
    if (c == CmpWrongState) return KWrongState;
    return KNormal;  
  };
  auto kindAt = [&](int wx, int wy, int wz) -> Kind {
    if (wx < sx0 || wx > sx1 || wy < sy0 || wy > sy1 || wz < sz0 || wz > sz1) return KNone;  
    int lx, ly, lz;
    if (!worldToLocal(T, P, wx, wy, wz, lx, ly, lz)) return KNone;
    const size_t li = T.index(lx, ly, lz);
    const uint16_t p = T.idx[li];
    if (p == kVoid) return KNone;
    return kindOf(p, C ? C->cmp(li) : CmpUnknown, C ? C->st[li].load(std::memory_order_relaxed) >> 4 : 0);
  };
  
  auto doorInfoLocal = [&](int lx, int ly, int lz) -> int {
    if (!hasVariants || lx < 0 || ly < 0 || lz < 0 || lx >= T.sx || ly >= T.sy || lz >= T.sz) return -1;
    const uint16_t v = T.vidx[T.index(lx, ly, lz)];
    return (v != kVoid && v < gDoorCache.info.size()) ? gDoorCache.info[v] : -1;
  };
  auto doorShape = [&](int wx, int wy, int wz, float *s0, float *s1) -> bool {
    int lx, ly, lz;
    if (!worldToLocal(T, P, wx, wy, wz, lx, ly, lz)) return false;
    const int me = doorInfoLocal(lx, ly, lz);
    if (me < 0) return false;
    const bool upper = me & 16;
    const int other = doorInfoLocal(lx, upper ? ly - 1 : ly + 1, lz);
    const int lower = (upper && other >= 0 && (other & 32)) ? other : me;
    const int top = (!upper && other >= 0 && (other & 16)) ? other : me;
    const int dir = lower & 3;
    const bool open = lower & 4, hinge = top & 8;
    
    const int side = !open ? dir : hinge ? (dir + 3) & 3 : (dir + 1) & 3;
    constexpr float t = 3.f / 16.f;
    s0[0] = s0[1] = s0[2] = 0.f;
    s1[0] = s1[1] = s1[2] = 1.f;
    switch (side) {
      case 0: s1[0] = t; break;
      case 1: s1[2] = t; break;
      case 2: s0[0] = 1.f - t; break;
      default: s0[2] = 1.f - t; break;
    }
    return true;
  };
  
  auto markDirty = [&](int wx, int wy, int wz) {
    for (int ax = -1; ax <= 1; ++ax)
      for (int ay = -1; ay <= 1; ++ay)
        for (int az = -1; az <= 1; ++az) {
          const int qx = wx + ax, qy = wy + ay, qz = wz + az;
          if ((ax && (qx >> 4) == (wx >> 4)) || (ay && (qy >> 4) == (wy >> 4)) || (az && (qz >> 4) == (wz >> 4)))
            continue;
          auto it = gChunks.find(chunkKey(qx >> 4, qy >> 4, qz >> 4));
          if (it != gChunks.end()) it->second.dirty = true;
        }
  };

  
  if (C && region && sGetBlock && gAir && vx0 <= vx1 && vy0 <= vy1 && vz0 <= vz1) {
    const size_t bx = size_t(vx1 - vx0 + 1), by = size_t(vy1 - vy0 + 1), bz = size_t(vz1 - vz0 + 1), vol = bx * by * bz;
    if (gCmp.gen != gen) { gCmp.gen = gen; gCmp.pos = 0; }
    const bool exact = statesReady && T.vidx.size() == T.volume();

    const int budget = 4000;
    for (int n = 0; n < budget; ++n) {
      const size_t k = (gCmp.pos++) % vol;
      const int wx = vx0 + int(k / (by * bz)), wy = vy0 + int((k / bz) % by), wz = vz0 + int(k % bz);
      int lx, ly, lz;
      if (!worldToLocal(T, P, wx, wy, wz, lx, ly, lz)) continue;
      const size_t li = T.index(lx, ly, lz);
      const uint16_t p = T.idx[li];
      if (p == kVoid) continue;
      uintptr_t expected = 0;
      uint16_t v = kVoid;
      if (exact) {
        v = T.vidx[li];
        if (v != kVoid && v < gTexCache.blocks.size() && v < gTexCache.cmpKeys.size() && gTexCache.cmpKeys[v])
          expected = gTexCache.blocks[v];
      }
      const uint8_t rec = C->st[li].load(std::memory_order_relaxed);
      const uint8_t old = rec & 7;
      const uint8_t now = compareOne(T, p, v, blockAt(region, wx, wy, wz), expected);
      if (now == old) continue;
      progress::setCmp(*C, li, now);  // central progress model (counters, layer slices, stale EP outcome)
      if (kindOf(p, old, rec >> 4) != kindOf(p, now, 0)) markDirty(wx, wy, wz);
      
      if (now == CmpCorrect && (old == CmpMissing || old == CmpWrong || old == CmpWrongState) && !T.palette[p].air)
        pushFlash(wx, wy, wz);
    }
    st.cmpChecks.fetch_add(budget, std::memory_order_relaxed);
  }
  gOut.texOn = texOn;
  if (x0 > x1 || y0 > y1 || z0 > z1) { gOut.outOfRange = true; return; }

  const bool faces = s.showFaces.load();
  static const int d[6][3] = {{0, 1, 0}, {0, -1, 0}, {0, 0, -1}, {0, 0, 1}, {-1, 0, 0}, {1, 0, 0}};
  static const float shade[6] = {1.0f, 0.55f, 0.8f, 0.8f, 0.68f, 0.68f};
  constexpr size_t kMaxQuads = 40000, kMaxLines = 60000;

  
  if (!gFlash.empty()) {
    const uint32_t flashCol = s.blockColor[ColCorrect].load(std::memory_order_relaxed);
    const double now = nowMs();
    size_t keep = 0;
    for (size_t i = 0; i < gFlash.size(); ++i) {
      const Flash &fl = gFlash[i];
      const float t = float((now - fl.at) / 1200.0);
      if (t >= 1.f) continue;
      gFlash[keep++] = fl;
      const float a = 0.75f * (1.f - t), gr = 0.02f + 0.06f * t;
      const float fx0 = fl.x - gr, fy0 = fl.y - gr, fz0 = fl.z - gr, fx1 = fl.x + 1 + gr, fy1 = fl.y + 1 + gr,
                  fz1 = fl.z + 1 + gr;
      for (int f = 0; f < 6; ++f) {
        Vec3 q[4];
        faceQuad(f, fx0, fy0, fz0, fx1, fy1, fz1, q);
        if (gQuads.size() < kMaxQuads) gQuads.push_back({{q[0], q[1], q[2], q[3]}, rgba(flashCol, a)});
        if (gLines.size() + 4 <= kMaxLines)
          for (int e = 0; e < 4; ++e) gLines.push_back({q[e], q[(e + 1) & 3], rgba(flashCol, 1.f - t)});
      }
    }
    gFlash.resize(keep);
  }

  
  
  const float pulse = 0.5f + 0.5f * float(std::sin(std::fmod(nowMs() * 0.0075, 6.283185307)));
  
  
  uint32_t bcol[ColCount];
  for (int i = 0; i < ColCount; ++i) bcol[i] = s.blockColor[i].load(std::memory_order_relaxed);
  auto emitColored = [&](int wx, int wy, int wz, Kind k) {
    uint32_t col;
    float a = alpha, grow;
    bool mark = false;
    switch (k) {
      case KWrong: col = bcol[ColWrong]; a = 0.45f + 0.4f * pulse; grow = 0.03f; mark = true; break;            
      case KWrongState: col = bcol[ColWrongState]; a = 0.45f + 0.4f * pulse; grow = 0.03f; mark = true; break;  
      case KExtra: col = bcol[ColExtra]; a = 0.45f + 0.4f * pulse; grow = 0.03f; mark = true; break;            
      case KCorrect: col = bcol[ColCorrect]; a = 0.32f; grow = 0.01f; mark = true; break;                       
      default: col = bcol[ColMissing]; grow = -0.03f; break;  
    }
    float s0[3] = {0.f, 0.f, 0.f}, s1[3] = {1.f, 1.f, 1.f};
    if (k == KNormal && doorShape(wx, wy, wz, s0, s1)) grow = -0.006f;  
    const float bx0 = wx + s0[0] - grow, by0 = wy + s0[1] - grow, bz0 = wz + s0[2] - grow;
    const float bx1 = wx + s1[0] + grow, by1 = wy + s1[1] + grow, bz1 = wz + s1[2] + grow;
    
    const bool edge[6] = {s1[1] >= 1.f, s0[1] <= 0.f, s0[2] <= 0.f, s1[2] >= 1.f, s0[0] <= 0.f, s1[0] >= 1.f};
    for (int f = 0; f < 6; ++f) {
      if (edge[f] && kindAt(wx + d[f][0], wy + d[f][1], wz + d[f][2]) != KNone) continue;  
      Vec3 q[4];
      faceQuad(f, bx0, by0, bz0, bx1, by1, bz1, q);
      if (faces && gQuads.size() < kMaxQuads) {
        const float sh = shade[f];
        Rgba c = rgba(col, a);
        c.r *= sh; c.g *= sh; c.b *= sh;
        gQuads.push_back({{q[0], q[1], q[2], q[3]}, c});
      }
      if (mark && k != KCorrect && gLines.size() + 6 <= kMaxLines) {  
        const Rgba lc = rgba(col, 1.f);
        for (int e = 0; e < 4; ++e) gLines.push_back({q[e], q[(e + 1) & 3], lc});
        gLines.push_back({q[0], q[2], lc});
        gLines.push_back({q[1], q[3], lc});
      } else if (mark && gLines.size() + 4 <= kMaxLines) {  
        const Rgba lc = rgba(col, 1.f);
        for (int e = 0; e < 4; ++e) gLines.push_back({q[e], q[(e + 1) & 3], lc});
      }
    }
  };

  const int ccx0 = x0 >> 4, ccy0 = y0 >> 4, ccz0 = z0 >> 4, ccx1 = x1 >> 4, ccy1 = y1 >> 4, ccz1 = z1 >> 4;
  
  auto colorChunk = [&](int qx, int qy, int qz) {
    const int bx0 = std::max(qx * 16, x0), bx1 = std::min(qx * 16 + 15, x1);
    const int by0 = std::max(qy * 16, y0), by1 = std::min(qy * 16 + 15, y1);
    const int bz0 = std::max(qz * 16, z0), bz1 = std::min(qz * 16 + 15, z1);
    for (int wx = bx0; wx <= bx1; ++wx)
      for (int wy = by0; wy <= by1; ++wy)
        for (int wz = bz0; wz <= bz1; ++wz) {
          const Kind k = kindAt(wx, wy, wz);
          if (k != KNone) emitColored(wx, wy, wz, k);
        }
  };

  if (!texOn) {
    for (int a = ccx0; a <= ccx1; ++a)
      for (int b = ccy0; b <= ccy1; ++b)
        for (int c = ccz0; c <= ccz1; ++c) colorChunk(a, b, c);
    return;
  }

  
  auto texBlockAt = [&](int wx, int wy, int wz, uint8_t *occ, uint16_t *var) -> uintptr_t {
    if (kindAt(wx, wy, wz) != KNormal) return 0;
    int lx, ly, lz;
    if (!worldToLocal(T, P, wx, wy, wz, lx, ly, lz)) return 0;
    const uint16_t v = T.vidx[T.index(lx, ly, lz)];
    if (var) *var = v;
    if (v == kVoid || v >= gTexCache.blocks.size()) return 0;
    if (occ) *occ = gTexCache.occludes[v];
    return gTexCache.blocks[v];
  };
  
  auto structBlockAt = [&](int wx, int wy, int wz, bool *isDoor, bool *upper) -> uintptr_t {
    int lx, ly, lz;
    if (!worldToLocal(T, P, wx, wy, wz, lx, ly, lz)) return 0;
    const size_t li = T.index(lx, ly, lz);
    const uint16_t p = T.idx[li];
    if (p == kVoid) return 0;
    if (T.palette[p].air) return gAir;
    const uint16_t v = T.vidx[li];
    if (v == kVoid || v >= gTexCache.blocks.size()) return 0;
    if (isDoor && v < gDoorCache.info.size() && gDoorCache.info[v] >= 0) {
      *isDoor = true;
      if (upper) *upper = (gDoorCache.info[v] & 16) != 0;
    }
    return gTexCache.blocks[v];
  };
  auto inFilter = [&](int wx, int wy, int wz) {
    return wx >= sx0 && wx <= sx1 && wy >= sy0 && wy <= sy1 && wz >= sz0 && wz <= sz1;
  };

  
  auto buildChunk = [&](int qx, int qy, int qz, ChunkMeshes &cm) {
    static uintptr_t win[kWin * kWin * kWin];
    static uint8_t winOcc[kWin * kWin * kWin];
    std::vector<MeshBlob *> fresh;
    std::vector<uint64_t> special;
    const int ox = qx * 16, oy = qy * 16, oz = qz * 16;
    tf->ox = ox; tf->oy = oy; tf->oz = oz;
    tf->cull = tf->alpha < 0xFF;
    tf->ccx = cam.x - ox; tf->ccy = cam.y - oy; tf->ccz = cam.z - oz;
    tf->out = &fresh;
    const int blocks0 = tf->blocks;
    const uint32_t verts0 = tf->verts;
    
    
    sBTReset(reinterpret_cast<void *>(tf->bt), BlockPos{ox, oy, oz});
    std::memset(win, 0, sizeof(win));
    std::memset(gWinBlk, 0, sizeof(gWinBlk));
    
    
    const int wx0 = std::max(ox - 2, bx0), wx1 = std::min(ox + 17, bx1);
    const int wy0 = std::max(oy - 2, by0), wy1 = std::min(oy + 17, by1);
    const int wz0 = std::max(oz - 2, bz0), wz1 = std::min(oz + 17, bz1);
    for (int wx = wx0; wx <= wx1; ++wx)
      for (int wy = wy0; wy <= wy1; ++wy)
        for (int wz = wz0; wz <= wz1; ++wz) {
          bool door = false, upper = false;
          uintptr_t sb = structBlockAt(wx, wy, wz, &door, &upper);
          if (!sb) continue;
          if (!inFilter(wx, wy, wz)) {
            
            if (!door || !inFilter(wx, upper ? wy - 1 : wy + 1, wz)) continue;
          }
          const int wi = ((wx - ox + 2) * kWin + (wy - oy + 2)) * kWin + (wz - oz + 2);
          gWinBlk[wi] = sb;
          uint8_t oc = 0;
          if (const uintptr_t b = texBlockAt(wx, wy, wz, &oc, nullptr)) {
            win[wi] = b;
            winOcc[wi] = oc;
          }
          if (!gTexNoPrefill)
            sBTSetCache(reinterpret_cast<void *>(tf->bt), reinterpret_cast<void *>(sb), BlockPos{wx, wy, wz});
        }
    gWinX0 = ox - 2; gWinY0 = oy - 2; gWinZ0 = oz - 2;
    gWinRegion = tf->region;
    gWinTid = pthread_self();
    const WinScope winScope(sGetBlockHooked.load(std::memory_order_acquire) && tf->region != 0);
    const int bx0c = std::max(ox, sx0), bx1c = std::min(ox + 15, sx1);
    const int by0c = std::max(oy, sy0), by1c = std::min(oy + 15, sy1);
    const int bz0c = std::max(oz, sz0), bz1c = std::min(oz + 15, sz1);
    
    const int sxs = cam.x < ox + 8 ? -1 : 1, sys = cam.y < oy + 8 ? -1 : 1, szs = cam.z < oz + 8 ? -1 : 1;
    for (int ix = 0; ix <= bx1c - bx0c; ++ix)
      for (int iy = 0; iy <= by1c - by0c; ++iy)
        for (int iz = 0; iz <= bz1c - bz0c; ++iz) {
          const int wx = sxs < 0 ? bx1c - ix : bx0c + ix, wy = sys < 0 ? by1c - iy : by0c + iy,
                    wz = szs < 0 ? bz1c - iz : bz0c + iz;
          const Kind k = kindAt(wx, wy, wz);
          if (k == KNone) continue;
          const int wi = ((wx - ox + 2) * kWin + (wy - oy + 2)) * kWin + (wz - oz + 2);
          const uintptr_t b = win[wi];
          if (k != KNormal || !b) {  
            special.push_back(posKey(wx, wy, wz));
            continue;
          }
          
          bool exposed = false;
          for (int f = 0; f < 6 && !exposed; ++f) {
            const int ni = wi + (d[f][0] * kWin + d[f][1]) * kWin + d[f][2];
            if (!win[ni] || !winOcc[ni]) exposed = true;
          }
          if (!exposed) continue;
          uint16_t v = kVoid;
          {
            int lx, ly, lz;
            if (worldToLocal(T, P, wx, wy, wz, lx, ly, lz)) v = T.vidx[T.index(lx, ly, lz)];
          }
          const int nv = texBlock(*tf, b, wx, wy, wz);
          if (nv > 0) {
            logVariantResult(T, v, nv, false, nullptr);
            continue;
          }
          
          ++tf->zero;
          special.push_back(posKey(wx, wy, wz));
          const bool door = v < gDoorCache.info.size() && gDoorCache.info[v] >= 0;
          logVariantResult(T, v, nv, true,
                           door ? (nv == 0 ? "door: no geometry from BlockTessellator, thin-panel fallback"
                                           : "door: broken geometry, thin-panel fallback")
                                : (nv == 0 ? "no geometry from BlockTessellator (block entity?)" : "broken geometry"));
        }
    texCut(*tf);
    tf->out = nullptr;
    
    if (tf->blocks > blocks0 && tf->verts == verts0) {
      if (++gTexEmptyChunks >= 6 && !gTexNoPrefill) {
        gTexNoPrefill = true;
        if (gLog) gLog->warn("textures: no geometry from hologram cache; using game mode");
      }
    } else if (tf->verts > verts0) {
      gTexEmptyChunks = 0;
    }
    freeChunk(cm);  
    cm.meshes.swap(fresh);
    gMeshTotal += uint32_t(cm.meshes.size());
    cm.culled = tf->cull;
    cm.bcx = cam.x; cm.bcy = cam.y; cm.bcz = cam.z;
    cm.special.swap(special);
    cm.built = true;
    cm.dirty = false;
    cm.builtFrame = gFrame;
  };

  
  struct ChunkRef {
    int x, y, z;
    float d2;
    ChunkMeshes *cm;
  };
  static std::vector<ChunkRef> chunks;
  chunks.clear();
  for (int a = ccx0; a <= ccx1; ++a)
    for (int b = ccy0; b <= ccy1; ++b)
      for (int c = ccz0; c <= ccz1; ++c) {
        ChunkMeshes &cm = gChunks[chunkKey(a, b, c)];
        cm.seenFrame = gFrame;
        if (cm.built && cm.culled && !cm.dirty) {
          const float cv[3] = {cam.x, cam.y, cam.z}, bv[3] = {cm.bcx, cm.bcy, cm.bcz};
          const int o3[3] = {a * 16, b * 16, c * 16};
          for (int ax = 0; ax < 3; ++ax) {
            if (std::fabs(cv[ax] - bv[ax]) <= kCullRebuild) continue;
            const float lo = std::min(cv[ax], bv[ax]) - kCullBand - 1.f, hi = std::max(cv[ax], bv[ax]) + kCullBand + 1.f;
            if (o3[ax] + 16 >= lo && o3[ax] <= hi) { cm.dirty = true; break; }
          }
        }
        const float ex = a * 16 + 8 - cam.x, ey = b * 16 + 8 - cam.y, ez = c * 16 + 8 - cam.z;
        chunks.push_back({a, b, c, ex * ex + ey * ey + ez * ez, &cm});
      }
  std::sort(chunks.begin(), chunks.end(), [](const ChunkRef &l, const ChunkRef &r) { return l.d2 < r.d2; });

  
  
  static double debtMs = 0;
  const double t0 = nowMs();
  bool any = false;
  if (debtMs > 0) {
    debtMs = std::max(0.0, debtMs - 2.5);
  } else {
    int builds = 0;
    for (ChunkRef &c : chunks) {
      if (!c.cm->dirty) continue;
      
      if (c.cm->built && gFrame - c.cm->builtFrame < 20) continue;
      if (any && nowMs() - t0 > 2.5) break;
      if (builds >= kMaxBuildsPerFrame) break;
      if (!c.cm->built && gMeshTotal >= kMaxMeshes) { gOut.capped = true; break; }
      buildChunk(c.x, c.y, c.z, *c.cm);
      any = true;
      ++builds;
    }
    gOut.builds += uint32_t(builds);
    debtMs = std::min(10.0, std::max(0.0, nowMs() - t0 - 2.5));
  }
  
  if (!any && debtMs <= 0 && (gFrame % 30) == 0) {
    ChunkRef *old = nullptr;
    for (ChunkRef &c : chunks)
      if (c.cm->built && gFrame - c.cm->builtFrame > 600 && (!old || c.cm->builtFrame < old->cm->builtFrame)) old = &c;
    if (old) {
      buildChunk(old->x, old->y, old->z, *old->cm);
      any = true;
    }
  }
  
  
  if (any || tf->begun) texFrameEnd(*tf);

  
  uintptr_t stack = 0, camObj = 0;
  if (rd(reinterpret_cast<uintptr_t>(tf->ctx) + 0x18, camObj) && plausiblePtr(camObj)) stack = camObj + 0x48;
  uint32_t ready = 0, pending = 0, nMeshes = 0;
  for (auto itc = chunks.rbegin(); itc != chunks.rend(); ++itc) {  
    ChunkRef &c = *itc;
    ChunkMeshes &cm = *c.cm;
    if (!stack) {  
      ++pending;
      colorChunk(c.x, c.y, c.z);
      continue;
    }
    if (!cm.built) {  
      ++pending;
      continue;
    }
    ++ready;
    const float tx = float(c.x * 16 - cam.x), ty = float(c.y * 16 - cam.y), tz = float(c.z * 16 - cam.z);
    for (MeshBlob *m : cm.meshes) {
      drawMesh(*tf, stack, m, tx, ty, tz);
      ++nMeshes;
    }

    for (uint64_t key : cm.special) {
      if (gQuads.size() >= kMaxQuads && gLines.size() + 6 > kMaxLines) break;  
      int wx, wy, wz;
      posFromKey(key, wx, wy, wz);
      if (wx < x0 || wx > x1 || wy < y0 || wy > y1 || wz < z0 || wz > z1) continue;
      const Kind k = kindAt(wx, wy, wz);
      if (k != KNone) emitColored(wx, wy, wz, k);
    }
  }
  
  for (auto it = gChunks.begin(); it != gChunks.end();) {
    if (gFrame - it->second.seenFrame > 120) {
      freeChunk(it->second);
      it = gChunks.erase(it);
    } else {
      ++it;
    }
  }
  gOut.chunksTotal = uint32_t(chunks.size());
  gOut.chunksBuilt = 0;
  for (const ChunkRef &c : chunks)
    if (c.cm->built) ++gOut.chunksBuilt;
  gOut.meshesDrawn = nMeshes;
  st.texChunks.store(ready, std::memory_order_relaxed);
  st.texBlocks.store(pending, std::memory_order_relaxed);
  st.texZero.store(tf->zero, std::memory_order_relaxed);
  st.texVerts.store(nMeshes, std::memory_order_relaxed);
}


void drawTestBox(const Vec3 &cam) {
  auto &st = status();
  const float fx = std::floor(st.feetX.load()), fy = std::floor(st.feetY.load() + 0.01f), fz = std::floor(st.feetZ.load());
  const bool hasPlayer = st.player.load() != 0;
  const float bx = hasPlayer ? fx : std::floor(cam.x), by = hasPlayer ? fy : std::floor(cam.y) - 2, bz = hasPlayer ? fz : std::floor(cam.z);
  boxLines(bx - 1, by, bz - 1, bx + 2, by + 3, bz + 2, Rgba{1.f, 0.f, 1.f, 1.f});
  boxLines(bx - 1.02f, by - 0.02f, bz - 1.02f, bx + 2.02f, by + 3.02f, bz + 2.02f, Rgba{1.f, 1.f, 0.f, 1.f});
  const float yaw = st.yaw.load() * 3.14159265f / 180.f;
  const float px = std::floor(bx + 0.5f - std::sin(yaw) * 4.f), pz = std::floor(bz + 0.5f + std::cos(yaw) * 4.f);
  boxLines(px, by, pz, px + 1, by + 12, pz + 1, Rgba{0.f, 1.f, 1.f, 1.f});
  for (int k = 1; k < 12; ++k)
    gLines.push_back({Vec3{px, by + k, pz}, Vec3{px + 1, by + k, pz + 1}, Rgba{0.f, 1.f, 1.f, 1.f}});
  if (gQuads.size() < 39000) {  
    Vec3 q[4];
    faceQuad(0, bx - 1, by, bz - 1, bx + 2, by + 3, bz + 2, q);
    gQuads.push_back({{q[0], q[1], q[2], q[3]}, Rgba{1.f, 0.f, 1.f, 0.5f}});
  }
}

void drawCaptureBox() {
  
  struct Corners {
    bool a = false, b = false;
    int ax = 0, ay = 0, az = 0, bx = 0, by = 0, bz = 0;
  };
  static Corners c;
  if (!model().corners.load(std::memory_order_acquire)) {
    c = Corners{};
    return;
  }
  {
    auto &m = model();
    std::unique_lock<std::mutex> lk(m.mu, std::try_to_lock);
    if (lk.owns_lock()) c = Corners{m.cornerA, m.cornerB, m.ax, m.ay, m.az, m.bx, m.by, m.bz};
    else perf::count(perf::BlockingWait);
  }
  const Rgba g{0.3f, 1.f, 0.3f, 1.f};
  if (c.a) boxLines(c.ax - 0.02f, c.ay - 0.02f, c.az - 0.02f, c.ax + 1.02f, c.ay + 1.02f, c.az + 1.02f, g);
  if (c.b) boxLines(c.bx - 0.02f, c.by - 0.02f, c.bz - 0.02f, c.bx + 1.02f, c.by + 1.02f, c.bz + 1.02f, g);
  if (c.a && c.b)
    boxLines(float(std::min(c.ax, c.bx)), float(std::min(c.ay, c.by)), float(std::min(c.az, c.bz)),
             float(std::max(c.ax, c.bx) + 1), float(std::max(c.ay, c.by) + 1), float(std::max(c.az, c.bz) + 1),
             Rgba{0.3f, 1.f, 0.3f, 1.f});
}

bool gIdleWasDrawing = true;

// ---- Hologram lifecycle (render thread only; publishes atomics, never locks or allocates) ----
constexpr int64_t kResumeGapMs = 1500;     // no renderLevel for this long = paused/background/menu
constexpr int kStableFrames = 10;          // world identity must hold this many frames before preparing
constexpr int64_t kStallMs = 20000;        // preparation without progress for this long = failed
constexpr int64_t kMatFailMs = 15000;      // no usable material for this long = failed (keeps checking)
struct Life {
  uintptr_t lr = 0, lrp = 0, player = 0, dim = 0, region = 0;
  ctx::RenderMemo ctxMemo;  // render context that last saw the player context fresh
  EGLContext egl = EGL_NO_CONTEXT;
  bool primed = false;
  bool failed = false;
  hs::Why failWhy = hs::Why::None;
  int64_t noMatSince = 0;
  uint32_t lastDone = 0;
  int64_t lastProgressMs = 0;
  uint64_t lastSig = 0;
  int stable = 0;
  bool wasPreparing = false;
  uint64_t readySig = 0;  // signature whose first full build finished (later builds are progressive)
} gLife;

void resetMaterialsRetry(bool dropMaterials) {
  sLineRetry = MatRetry{};
  for (auto &r : sTexRetry) r = MatRetry{};
  if (dropMaterials) {
    // MaterialPtr has no destructor here: dropping only forgets the reference (no free on a live material).
    new (&sLineMat) MaterialPtr();
    for (auto &m : sTexMats) new (&m) MaterialPtr();
  }
}

void invalidateHologram(hs::Why why, bool renderSide, bool abandon) {
  auto &R = hs::rt();
  if (gLife.wasPreparing) {
    R.cancelled.fetch_add(1, std::memory_order_relaxed);
    R.lastCancelWhy.store(int(why), std::memory_order_relaxed);
  }
  if (abandon) {
    abandonAllChunks();
    R.eglAbandoned.store(true, std::memory_order_relaxed);
  } else {
    freeAllChunks();  // deferred: meshes go to the graveyard and are destroyed >= 90 frames later
  }
  gChunkSig = 0;
  gTexNoPrefill = false;
  gTexEmptyChunks = 0;
  gTexCache.keep.reset();
  gTexCache.world = 0;
  gCmp = CmpCursor{};
  gAirRegion = 0;
  gAir = 0;
  gFlash.clear();
  resetMaterialsRetry(renderSide);
  if (renderSide) R.renderEpoch.fetch_add(1, std::memory_order_relaxed);
  gLife.failed = false;
  gLife.failWhy = hs::Why::None;
  gLife.noMatSince = 0;
  gLife.lastProgressMs = 0;
  gLife.lastDone = 0;
  gLife.wasPreparing = false;
  gLife.readySig = 0;
  gOut = FrameOut{};
  R.invalidations.fetch_add(1, std::memory_order_relaxed);
  R.lastInvalidateWhy.store(int(why), std::memory_order_relaxed);
  R.lastInvalidateMs.store(hs::monoMs(), std::memory_order_relaxed);
  hs::resetRenderStages();
  if (gLog) gLog->info("hologram: invalidated ({}){}", hs::whyName(why), abandon ? " - old meshes dropped" : "");
}

// Returns true when the world/player context is valid and stable for drawing.
bool validateWorld(uintptr_t me, uintptr_t lrp, uintptr_t &regionOut, hs::Why &why) {
  auto &R = hs::rt();
  const int64_t now = hs::monoMs();
  const int64_t prev = R.lastFrameMs.exchange(now, std::memory_order_relaxed);
  // render context identity
  hs::Why inval = hs::Why::None;
  bool renderSide = false, abandon = false;
  if (gLife.primed && prev && now - prev > kResumeGapMs) { inval = hs::Why::Resumed; renderSide = true; }
  const EGLContext ec = eglGetCurrentContext();
  if (ec != EGL_NO_CONTEXT) {
    if (gLife.egl != EGL_NO_CONTEXT && ec != gLife.egl) { inval = hs::Why::RenderContextChanged; renderSide = abandon = true; }
    gLife.egl = ec;
  }
  if (gLife.primed && (me != gLife.lr || lrp != gLife.lrp)) { inval = hs::Why::RenderContextChanged; renderSide = true; }
  gLife.lr = me;
  gLife.lrp = lrp;
  // world identity from the player context (ClientInstance::update or a validated fallback tick)
  const bool anyCtx = ctx::anySource();
  const ctx::View cv = ctx::view(ctx::monoMs());
  // A quiet source (singleplayer pause, loading screen, world left) keeps its last context only inside the
  // render context that saw it fresh; the player is never dereferenced meanwhile.
  const ctx::RenderUse use = ctx::renderUse(cv, anyCtx, me, lrp, gLife.ctxMemo);
  if (use == ctx::RenderUse::Drop) ctx::dropStale(cv.player, "render context changed while the player context was stale");
  const bool stale = use == ctx::RenderUse::Stale;
  const uintptr_t player = use == ctx::RenderUse::Fresh || stale ? cv.player : 0;
  R.ctxStale.store(stale, std::memory_order_relaxed);
  uintptr_t dim = 0, region = 0;
  if (stale) {
    dim = gLife.dim;  // identity only: no reads through a quiet context
    region = gLife.region;
  } else {
    if (plausiblePtr(player) && (!safeReadPtr(player + off::Actor_mDimension, dim) || !plausiblePtr(dim))) dim = 0;
    region = sGetBlock ? currentRegion() : 0;
  }
  if (gLife.primed && (player != gLife.player || dim != gLife.dim || region != gLife.region)) {
    const bool dimChange = player && player == gLife.player && dim && gLife.dim && dim != gLife.dim;
    R.worldEpoch.fetch_add(1, std::memory_order_relaxed);
    if (dimChange) R.dimEpoch.fetch_add(1, std::memory_order_relaxed);
    names::invalidate();  // Block* -> name cache is per world
    if (inval == hs::Why::None) inval = dimChange ? hs::Why::DimensionChanged : hs::Why::WorldChanged;
    gLife.stable = 0;
  }
  gLife.player = player;
  gLife.dim = dim;
  gLife.region = region;
  if (!gLife.primed) {
    gLife.primed = true;
    hs::resetRenderStages();
  }
  // Automatic recovery: if the hologram sits in HologramFailed for more than 3 s, retry it (at most 5 times in a row).
  // The manual "Retry hologram" button does the same thing; this just saves the tap for the usual transient failures
  // (world reload, chunk churn, layer change). The counter resets as soon as the hologram is healthy again.
  static int64_t sFailSince = 0;
  static int sAutoRetries = 0;
  bool autoRetry = false;
  {
    // Log every change of render state / reason, so a failure can be read from the log afterwards.
    static int sLoggedState = -1, sLoggedWhy = -1;
    const int rsNow = R.renderState.load(std::memory_order_relaxed);
    const int whyNow = R.why.load(std::memory_order_relaxed);
    if (rsNow != sLoggedState || whyNow != sLoggedWhy) {
      ep::logf("hologram: state=%s why=%s retries=%d", hs::stateName(hs::HState(rsNow)),
               hs::whyName(hs::Why(whyNow)), sAutoRetries);
      sLoggedState = rsNow;
      sLoggedWhy = whyNow;
    }
  }
  if (R.renderState.load(std::memory_order_relaxed) == int(hs::HState::HologramFailed)) {
    const int64_t now = hs::monoMs();
    if (!sFailSince) sFailSince = now;
    if (now - sFailSince > 3000 && sAutoRetries < 5) {
      ++sAutoRetries;
      sFailSince = 0;
      autoRetry = true;
      ep::logf("hologram: automatic retry %d/5", sAutoRetries);
    }
  } else {
    sFailSince = 0;
    sAutoRetries = 0;
  }
  if (R.retryRequest.exchange(false, std::memory_order_relaxed) || autoRetry) {
    R.failures.store(0, std::memory_order_relaxed);
    if (inval == hs::Why::None) invalidateHologram(hs::Why::None, true, false);  // retry (manual or automatic)
  }
  if (inval != hs::Why::None) invalidateHologram(inval, renderSide, abandon);
  const bool playerOk = anyCtx && plausiblePtr(player);
  // The local player only exists inside a world, so it is the validity signal. Dimension/region are used
  // to detect changes (and for block checks) but are not required: a build where they cannot be read
  // keeps the hologram working with block checks off. Without any validated player context source the
  // hologram waits (no camera-only guessing of the world).
  const bool worldOk = playerOk;
  R.playerValid.store(playerOk && !stale, std::memory_order_relaxed);
  R.dimValid.store(dim != 0, std::memory_order_relaxed);
  R.worldValid.store(worldOk, std::memory_order_relaxed);
  if (worldOk) gLife.stable = std::min(gLife.stable + 1, 1 << 20);
  else gLife.stable = 0;
  R.stableFrames.store(gLife.stable, std::memory_order_relaxed);
  regionOut = stale ? 0 : region;  // verification pauses while the context is quiet
  if (!anyCtx) { why = hs::Why::NoContextSource; return false; }
  if (!playerOk) { why = hs::Why::NoPlayer; return false; }
  if (!worldOk) { why = hs::Why::NoWorld; return false; }
  if (gLife.stable < kStableFrames) {
    why = inval == hs::Why::None ? hs::Why::Settling : inval;
    return false;
  }
  return true;
}

void renderLevelDetour(void *self, void *screenCtx, void *fro) {
  void *orig;
  while (!(orig = __atomic_load_n(&gRenderLevelOrig, __ATOMIC_ACQUIRE))) {  
  }
  // The hologram builds its meshes on the game's shared tessellator (ScreenContext::mTessellator) and changes its
  // offset and color. Those changes are only undone at the end of a hologram frame, so when the hologram stops drawing
  // (out of range, world change) they can stay behind and skew the entities that the game draws next (mobs). Put the
  // shared tessellator back to neutral before the game renders this frame.
  // Only on the build where the tessellator layout (offset 0x1cc) was verified. On any other build this write could
  // land in a different field of the shared tessellator, which is what made items and icons disappear and crash.
  static const bool sResetAllowed = rsv::game().buildId == "56de9eed077631e03a31f4f58eb2f0e00071d335";
  if (sResetAllowed && screenCtx && plausiblePtr(reinterpret_cast<uintptr_t>(screenCtx))) {
    const uintptr_t tessNow = *reinterpret_cast<uintptr_t *>(reinterpret_cast<uintptr_t>(screenCtx) + off::ScreenContext_mTessellator);
    if (plausiblePtr(tessNow)) {
      texSetOffset(tessNow, 0.f, 0.f, 0.f);
      if (sColor) sColor(reinterpret_cast<void *>(tessNow), 1.f, 1.f, 1.f, 1.f);
    }
  }
  reinterpret_cast<RenderLevelFn>(orig)(self, screenCtx, fro);  

  auto &st = status();
  auto &s = settings();
  auto &R = hs::rt();
  R.lastHookMs.store(hs::monoMs(), std::memory_order_relaxed);
  st.renderCalls.fetch_add(1, std::memory_order_relaxed);
  perf::count(perf::RenderHook);
  st.renderStage.store(1, std::memory_order_relaxed);  
  const uintptr_t sc = reinterpret_cast<uintptr_t>(screenCtx), me = reinterpret_cast<uintptr_t>(self);
  auto badRender = [&] {
    R.renderValid.store(false, std::memory_order_relaxed);
    hs::setStage(hs::Stage::RenderData, hs::SSt::Running);
    hs::setRenderState(hs::HState::WaitingForRender, hs::Why::RenderDataInvalid);
  };
  if (!plausiblePtr(sc) || !plausiblePtr(me)) { badRender(); return; }
  const uintptr_t tess = *reinterpret_cast<uintptr_t *>(sc + off::ScreenContext_mTessellator);
  const uintptr_t lrp = *reinterpret_cast<uintptr_t *>(me + off::LevelRenderer_mLevelRendererPlayer);
  if (!plausiblePtr(tess) || !plausiblePtr(lrp)) { badRender(); return; }
  st.renderStage.store(2, std::memory_order_relaxed);  
  const float *camPtr = reinterpret_cast<const float *>(lrp + off::LevelRendererPlayer_mCamPos);
  const Vec3 cam{camPtr[0], camPtr[1], camPtr[2]};
  if (!std::isfinite(cam.x) || !std::isfinite(cam.y) || !std::isfinite(cam.z)) { badRender(); return; }
  R.renderValid.store(true, std::memory_order_relaxed);
  st.camX.store(cam.x, std::memory_order_relaxed);
  st.camY.store(cam.y, std::memory_order_relaxed);
  st.camZ.store(cam.z, std::memory_order_relaxed);
  st.renderStage.store(3, std::memory_order_relaxed);  

  uintptr_t vregion = 0;
  hs::Why worldWhy = hs::Why::None;
  const bool worldReady = validateWorld(me, lrp, vregion, worldWhy);
  hs::setStage(hs::Stage::WaitWorld, worldReady ? hs::SSt::Ok : hs::SSt::Running);
  hs::setStage(hs::Stage::RenderData, hs::SSt::Ok);

  const bool holoWanted = model().live.load(std::memory_order_acquire) && s.hologram.load(std::memory_order_relaxed);
  if (!holoWanted && gLife.wasPreparing) {
    R.cancelled.fetch_add(1, std::memory_order_relaxed);
    R.lastCancelWhy.store(int(hs::Why::Cancelled), std::memory_order_relaxed);
    hs::setRenderState(hs::HState::HologramCancelled, hs::Why::Cancelled);
    gLife.wasPreparing = false;
  }
  {
    const bool work = (holoWanted && worldReady) ||
                      model().corners.load(std::memory_order_acquire) || gCap.active ||
                      st.captureRequest.load(std::memory_order_relaxed) || s.testDraw.load(std::memory_order_relaxed) ||
                      !gChunks.empty() || !gGraveyard.empty();
    if (!work) {
      if (holoWanted) hs::setRenderState(worldWhy == hs::Why::NoPlayer || worldWhy == hs::Why::NoContextSource
                                             ? hs::HState::WaitingForPlayer
                                             : hs::HState::WaitingForWorld, worldWhy);
      if (sGetBlock && !names::ready() && st.namesState.load(std::memory_order_relaxed) == 0 && worldReady) {
        perf::count(perf::WorldQuery);
        if (vregion) ensureAirAndNames(vregion);
      }
      if (gIdleWasDrawing) {
        gIdleWasDrawing = false;
        st.drawnQuads.store(0, std::memory_order_relaxed);
        st.drawnLines.store(0, std::memory_order_relaxed);
      }
      return;
    }
    gIdleWasDrawing = true;
  }

  perf::count(perf::WorldQuery);
  const uintptr_t region = worldReady ? vregion : 0;
  if (region) {
    ensureAirAndNames(region);
    captureStep(region);
  }

  gQuads.clear();
  gLines.clear();
  ++gFrame;
  reapMeshes(false);
  
  
  struct TessOffsetGuard {
    float *o;
    float v[3];
    explicit TessOffsetGuard(uintptr_t t) : o(reinterpret_cast<float *>(t + 0x1cc)) { std::memcpy(v, o, sizeof(v)); }
    ~TessOffsetGuard() { std::memcpy(o, v, sizeof(v)); }
  } tessGuard(tess);
  
  float *colorHolder = nullptr;
  const uintptr_t ch = *reinterpret_cast<uintptr_t *>(sc + off::ScreenContext_mColorHolder);
  if (plausiblePtr(ch)) colorHolder = reinterpret_cast<float *>(ch);
  float saved[4]{};
  if (colorHolder) {
    std::memcpy(saved, colorHolder, sizeof(saved));
    colorHolder[0] = colorHolder[1] = colorHolder[2] = colorHolder[3] = 1.f;
  }
  // Materials are resolved (with retry) before the hologram decides whether it can draw.
  void *lineMat = lineMaterial(lrp);
  const int fm = std::clamp(s.faceMaterial.load(), 0, kFaceMatCount - 1);
  void *faceMat = lrpMat(lrp, kFaceMats[fm].lrpOffset);
  R.matLine.store(lineMat ? 1 : (sLineRetry.attempts < kMatMaxAttempts ? 2 : 3), std::memory_order_relaxed);
  R.matFace.store(faceMat ? 1 : 2, std::memory_order_relaxed);

  const bool holoOn = holoWanted && worldReady;
  if (!holoOn && !gChunks.empty()) freeAllChunks();
  if (holoWanted && !worldReady)
    hs::setRenderState(worldWhy == hs::Why::NoPlayer || worldWhy == hs::Why::NoContextSource
                           ? hs::HState::WaitingForPlayer
                           : hs::HState::WaitingForWorld,
                       worldWhy);
  const size_t q0 = gQuads.size(), l0 = gLines.size();
  bool holoDrawn = false;
  if (holoOn && !gLife.failed) {
    static TexFrame tf;
    const bool texOk = texFrameSetup(tf, lrp, tess, screenCtx, cam, s.alpha.load(), s.blockLook.load());
    const bool texPossible = texReady();
    R.matTex.store(texOk ? 1
                   : !texPossible ? 3
                   : (st.texStage.load(std::memory_order_relaxed) == 3 && sTexRetry[0].attempts < kMatMaxAttempts) ? 2
                                                                                                                : 3,
                   std::memory_order_relaxed);
    const int64_t now = hs::monoMs();
    if (!texOk && !lineMat && !faceMat) {
      // Nothing can be drawn yet: wait for materials (cheap pointer checks), fail after a while.
      if (!gLife.noMatSince) gLife.noMatSince = now;
      hs::setStage(hs::Stage::Materials, hs::SSt::Running);
      if (now - gLife.noMatSince > kMatFailMs) {
        gLife.failed = true;
        gLife.failWhy = hs::Why::MaterialsMissing;
        R.failures.fetch_add(1, std::memory_order_relaxed);
        if (gLog) gLog->warn("hologram: no usable material after {} ms", now - gLife.noMatSince);
      } else {
        hs::setRenderState(hs::HState::WaitingForRender, hs::Why::MaterialsMissing);
      }
    } else {
      gLife.noMatSince = 0;
      hs::setStage(hs::Stage::Materials, texOk || !texPossible ? hs::SSt::Ok : hs::SSt::Warning);
      gOut.outOfRange = false;
      gOut.capped = false;
      const uint32_t builds0 = gOut.builds;
      drawStructure(cam, region, texOk ? &tf : nullptr);
      if (gOut.builds != builds0) R.prepBatches.fetch_add(gOut.builds - builds0, std::memory_order_relaxed);
      R.prepPerFrame.store(gOut.builds - builds0, std::memory_order_relaxed);
      R.meshCount.store(gMeshTotal, std::memory_order_relaxed);
      R.meshCapped.store(gOut.capped, std::memory_order_relaxed);
      const uint32_t total = gOut.texOn ? gOut.chunksTotal : 0, done = gOut.texOn ? gOut.chunksBuilt : 0;
      R.prepTotal.store(total, std::memory_order_relaxed);
      R.prepDone.store(done, std::memory_order_relaxed);
      if (gChunkSig != gLife.lastSig) {
        gLife.lastSig = gChunkSig;
        gLife.lastDone = 0;
        gLife.lastProgressMs = now;
        R.prepBatches.store(0, std::memory_order_relaxed);
      }
      const uint32_t progressKey = done + R.texResolved.load(std::memory_order_relaxed);
      if (progressKey != gLife.lastDone || !gLife.lastProgressMs) { gLife.lastDone = progressKey; gLife.lastProgressMs = now; }
      // First build of a signature = Preparing; afterwards chunks entering the radius build progressively
      // while the hologram stays Visible.
      const bool building = gOut.texPending || (total > done && !gOut.capped);
      const bool preparing = gOut.texPending || (building && gLife.readySig != gChunkSig);
      if (!building) gLife.readySig = gChunkSig;
      gLife.wasPreparing = preparing;
      hs::setStage(hs::Stage::RenderCache, building ? hs::SSt::Running : gOut.capped ? hs::SSt::Warning : hs::SSt::Ok);
      const bool lines = gLines.size() > l0 && lineMat, quads = gQuads.size() > q0 && faceMat;
      holoDrawn = gOut.meshesDrawn > 0 || lines || quads;
      if (building && now - gLife.lastProgressMs > kStallMs) {
        gLife.failed = true;
        gLife.failWhy = hs::Why::BuildStalled;
        R.failures.fetch_add(1, std::memory_order_relaxed);
        if (gLog) gLog->warn("hologram: preparation stalled at {}/{} chunks", done, total);
      } else if (preparing) {
        hs::setRenderState(hs::HState::PreparingHologram, hs::Why::None);
      } else if (holoDrawn) {
        hs::setRenderState(hs::HState::HologramVisible, gOut.capped        ? hs::Why::MemoryLimit
                                                        : gOut.outOfRange  ? hs::Why::OutOfRange
                                                        : !texOk && texPossible ? hs::Why::TexturesUnavailable
                                                                                : hs::Why::None);
      } else {
        hs::setRenderState(hs::HState::HologramReady, gOut.outOfRange ? hs::Why::OutOfRange : hs::Why::None);
      }
      hs::setStage(hs::Stage::Visible, holoDrawn ? hs::SSt::Ok : hs::SSt::Pending);
      if (holoDrawn) R.lastVisibleMs.store(now, std::memory_order_relaxed);
    }
  }
  if (holoOn && gLife.failed) {
    // Failed: draw nothing for the hologram, keep everything else, wait for a retry request.
    if (!gChunks.empty()) freeAllChunks();
    hs::setStage(gLife.failWhy == hs::Why::BuildStalled ? hs::Stage::RenderCache : hs::Stage::Materials, hs::SSt::Failed);
    hs::setRenderState(hs::HState::HologramFailed, gLife.failWhy);
    // Recover by itself when a material shows up (pointer check only, no lookups).
    if (gLife.failWhy == hs::Why::MaterialsMissing && (lineMat || faceMat)) {
      gLife.failed = false;
      gLife.noMatSince = 0;
    }
  }
  hs::setStage(hs::Stage::Done, holoDrawn ? hs::SSt::Ok : hs::SSt::Pending);
  drawCaptureBox();
  if (s.testDraw.load()) drawTestBox(cam);
  if (gQuads.empty() && gLines.empty()) {
    st.drawnQuads.store(0, std::memory_order_relaxed);
    st.drawnLines.store(0, std::memory_order_relaxed);
    if (colorHolder) std::memcpy(colorHolder, saved, sizeof(saved));
    return;
  }

  st.renderStage.store(4, std::memory_order_relaxed);  
  void *t = reinterpret_cast<void *>(tess);
  int mask = 0;
  for (int i = 0; i < kFaceMatCount; ++i)
    if (lrpMat(lrp, kFaceMats[i].lrpOffset)) mask |= 1 << i;
  st.faceMatMask.store(mask, std::memory_order_relaxed);
  
  st.hasLineMat.store(lineMat != nullptr, std::memory_order_relaxed);
  flushLines(t, screenCtx, lineMat, cam);
  flushQuads(t, screenCtx, faceMat, cam, s.twoSided.load());
  st.drawnQuads.store(gQuads.size(), std::memory_order_relaxed);
  st.drawnLines.store(gLines.size(), std::memory_order_relaxed);
  if (colorHolder) std::memcpy(colorHolder, saved, sizeof(saved));
  st.renderStage.store(5, std::memory_order_relaxed);  
}

}  

int faceMaterialCount() { return kFaceMatCount; }
int blockLookCount() { return kLookCount; }
const char *blockLookName(int i) { return (i >= 0 && i < kLookCount) ? kLooks[i].label : "?"; }
bool blockLookUsesAlpha(int) { return true; }
const char *faceMaterialName(int i) { return (i >= 0 && i < kFaceMatCount) ? kFaceMats[i].name : "?"; }

bool takeCapture(CaptureResult &out) {
  std::lock_guard<std::mutex> lk(gCapMu);
  if (!gCapReady) return false;
  out = std::move(gCapDone);
  gCapReady = false;
  return true;
}
std::string captureError() {
  std::lock_guard<std::mutex> lk(gCapMu);
  std::string e;
  e.swap(gCapError);
  return e;
}

namespace {
std::atomic_bool sRenderHooked{false};  
}  

InstallResult install(pl::log::Logger &log) {
  gLog = &log;
  auto &st = status();
  if (sRenderHooked.load(std::memory_order_acquire)) return InstallResult::Ok;  
  
  auto res = [&](const char *name, const char *pat) {
    const rsv::Hit h = rsv::find(name, pat);
    if (h) log.info("[sig] {}: FOUND (+{:#x}, {})", name, h.addr - rsv::game().base, rsv::viaText(h.via));
    else log.warn("[sig] {}: NOT FOUND (optional)", name);
    return h.addr;
  };
  auto ess = [&](const char *name, const char *pat) { return rsv::find(name, pat).addr; };
  const uintptr_t rl = ess("RenderLevel", sig::RenderLevel);
  sBegin = reinterpret_cast<TessBeginFn>(ess("TessellatorBegin", sig::TessellatorBegin));
  sColor = reinterpret_cast<TessColorFn>(ess("TessellatorColor", sig::TessellatorColor));
  sVertex = reinterpret_cast<TessVertexFn>(ess("TessellatorVertex", sig::TessellatorVertex));
  const uintptr_t rm4 = ess("RenderMeshImmediately2", sig::RenderMeshImmediately2);
  if (rm4) sRenderMesh4 = reinterpret_cast<RenderMeshFn4>(rm4);
  
  if (const uintptr_t rm5 = ess("RenderMeshImmediately", sig::RenderMeshImmediately))
    sRenderMesh5 = reinterpret_cast<RenderMeshFn5>(rm5);
  st.renderMeshAbi.store(sRenderMesh4 ? 4 : sRenderMesh5 ? 5 : 0, std::memory_order_relaxed);
  
  sTessInWorld = reinterpret_cast<TessInWorldFn>(res("TessellateInWorld", sig::TessellateInWorld));
  sGetBT = reinterpret_cast<GetBTFn>(res("GetBlockTessellator", sig::GetBlockTessellator));
  sBTReset = reinterpret_cast<BTResetFn>(res("BTResetCache", sig::BTResetCache));
  sBTSetCache = reinterpret_cast<BTSetCacheFn>(res("BTSetBlockInCache", sig::BTSetBlockInCache));
  sBlockFlag = reinterpret_cast<BlockFlagFn>(res("BlockRenderFlag", sig::BlockRenderFlag));
  if (const uintptr_t g = res("BlockRegistryGetter", sig::BlockRegistryGetter)) sRegistry = reinterpret_cast<RegistryFn>(g);
  sLookup = reinterpret_cast<LookupFn>(res("BlockLookupByName", sig::BlockLookupByName));
  sFindState = reinterpret_cast<FindStateFn>(res("FindBlockState", sig::FindBlockState));
  if (const uintptr_t a = res("ByteTagVtable", sig::ByteTagVtable)) sVtByteTag = resolveAdrpAdd(a);
  if (const uintptr_t a = res("IntTagVtable", sig::IntTagVtable)) sVtIntTag = resolveAdrpAdd(a);
  if (const uintptr_t a = res("StringTagVtable", sig::StringTagVtable)) sVtStringTag = resolveAdrpAdd(a);
  sTessClear = reinterpret_cast<TessClearFn>(res("TessellatorClear", sig::TessellatorClear));
  sTessEnd = reinterpret_cast<TessEndFn>(res("TessellatorEndMesh", sig::TessellatorEndMesh));
  sMeshRender = reinterpret_cast<MeshRenderFn>(res("MeshRender", sig::MeshRender));
  sMeshDestroy = reinterpret_cast<MeshDestroyFn>(res("MeshDestroy", sig::MeshDestroy));
  sMatPush = reinterpret_cast<MatPushFn>(res("MatrixStackPush", sig::MatrixStackPush));
  sMatPop = reinterpret_cast<MatPopFn>(res("MatrixRefPop", sig::MatrixRefPop));
  {
    int miss = 0;
    for (const void *p : {(const void *)sTessInWorld, (const void *)sGetBT, (const void *)sBTReset,
                          (const void *)sBTSetCache, (const void *)sBlockFlag, (const void *)sRegistry,
                          (const void *)sLookup, (const void *)sFindState, (const void *)sVtByteTag,
                          (const void *)sVtIntTag, (const void *)sVtStringTag, (const void *)sTessClear,
                          (const void *)sRenderMesh5, (const void *)sTessEnd, (const void *)sMeshRender,
                          (const void *)sMeshDestroy, (const void *)sMatPush, (const void *)sMatPop})
      if (!p) ++miss;
    st.texSigMissing.store(miss);
  }
  log.info("block textures: {}", texReady() ? "ready" : "unavailable (solid color)");
  sGetBlock = reinterpret_cast<GetBlockFn>(ess("BlockSourceGetBlock", sig::BlockSourceGetBlock));
  st.hasGetBlock.store(sGetBlock != nullptr);
  if (const uintptr_t g = res("RenderMaterialGroupCommon", sig::RenderMaterialGroupCommon)) {
    const uintptr_t grp = resolveAdrpAdd(g);
    if (grp) sMaterialGroup = grp + off::MaterialGroup_mRenderMaterialGroup;
  }
  if (!rl || !sBegin || !sColor || !sVertex || (!sRenderMesh4 && !sRenderMesh5)) {
    log.error("render functions missing: hologram off");
    return InstallResult::SignatureMissing;
  }
  gQuads.reserve(16384);
  gLines.reserve(32768);
  const int rc = pl::memory::hook(reinterpret_cast<void *>(rl), reinterpret_cast<void *>(&renderLevelDetour),
                                  &gRenderLevelOrig, pl::memory::HookPriority::Normal);
  rsv::markHook("RenderLevel", rc == 0 && gRenderLevelOrig);
  if (rc != 0 || !gRenderLevelOrig) {
    log.error("hook renderLevel failed rc={}", rc);
    return InstallResult::HookFailed;
  }
  sRenderHooked.store(true, std::memory_order_release);
  st.hkRender.store(true);
  log.info("hologram: renderLevel hook OK; RenderMesh ABI={} args",
           sRenderMesh4 ? 4 : 5);
  
  
  
  gLibBase = rsv::game().base;
  if (sGetBlock && !sGetBlockHooked.load(std::memory_order_acquire)) {
    gGetBlockTarget = reinterpret_cast<uintptr_t>(sGetBlock);
    void *target = reinterpret_cast<void *>(sGetBlock);
    const int grc = pl::memory::hook(target, reinterpret_cast<void *>(&getBlockDetour), &gGetBlockOrig,
                                     pl::memory::HookPriority::Normal);
    rsv::markHook("BlockSourceGetBlock", grc == 0 && gGetBlockOrig);
    if (grc == 0 && gGetBlockOrig) {
      sGetBlock = reinterpret_cast<GetBlockFn>(gGetBlockOrig);  
      sGetBlockHooked.store(true, std::memory_order_release);
      log.info("hologram: getBlock window hook OK (+{:#x})", gGetBlockTarget - gLibBase);
    } else {
      log.warn("hologram: getBlock window hook failed rc={} (doors may use the logged fallback)", grc);
    }
  }
  return InstallResult::Ok;
}


namespace {
std::mutex gApiMu;
struct ApiCache {
  std::shared_ptr<const Structure> keep;
  uint64_t epoch = ~0ull;
  int rot = -1;
  bool mirror = false;
  std::vector<uintptr_t> blocks;
  std::vector<uint8_t> done;
  std::vector<double> tryAt;
  std::vector<uint8_t> stDone;                    // transformed states computed
  std::vector<std::vector<BlockStateValue>> st;   // transformed states (shared pipeline)
  std::vector<std::string> unsupported;           // non-empty: this variant can't be transformed exactly
  std::shared_ptr<const xf::Table> xt;            // shared transformed states
} gApiCache;

struct ApiCtx {
  std::shared_ptr<const Structure> S;
  Placement P;
  int box[6]{};
};


void apiLayerBox(const Structure &T, const Placement &P, int layer, int layer2, int b[6]) {
  int dx, dz;
  rotatedSize(T, P.rot, dx, dz);
  b[0] = P.ox; b[1] = P.ox + dx - 1; b[2] = P.oy; b[3] = P.oy + T.sy - 1; b[4] = P.oz; b[5] = P.oz + dz - 1;
  auto &s = settings();
  const LayerMode lm = LayerMode(std::clamp(s.layerMode.load(), 0, 4));
  const int axis = std::clamp(s.layerAxis.load(), 0, 2);
  const int size = axis == 0 ? dx : axis == 1 ? T.sy : dz;
  if (size <= 0) return;
  const int base = axis == 0 ? P.ox : axis == 1 ? P.oy : P.oz;
  const int L = std::clamp(layer, 0, size - 1), L2 = std::clamp(layer2, 0, size - 1);
  int lo = 0, hi = size - 1;
  switch (lm) {
    case LayerMode::Only: lo = hi = L; break;
    case LayerMode::UpTo: hi = L; break;
    case LayerMode::Above: lo = L; break;
    case LayerMode::Range: lo = std::min(L, L2); hi = std::max(L, L2); break;
    default: break;
  }
  b[axis * 2] = base + lo;
  b[axis * 2 + 1] = base + hi;
}
bool apiSnapshot(ApiCtx &c) {
  if (!ctx::fresh(ctx::monoMs()) || !plausiblePtr(status().player.load(std::memory_order_relaxed))) return false;
  auto &m = model();
  std::lock_guard<std::mutex> lk(m.mu);
  if (!m.structure || !m.placed) return false;
  c.S = m.structure;
  c.P = m.placement;
  apiLayerBox(*c.S, c.P, m.layer, m.layer2, c.box);
  if (!settings().epLayerOnly.load(std::memory_order_relaxed)) {
    // layer-limited placement off: Easy Place / verification see the whole structure (display unchanged)
    int dx, dz;
    rotatedSize(*c.S, c.P.rot, dx, dz);
    c.box[0] = c.P.ox; c.box[1] = c.P.ox + dx - 1; c.box[2] = c.P.oy; c.box[3] = c.P.oy + c.S->sy - 1;
    c.box[4] = c.P.oz; c.box[5] = c.P.oz + dz - 1;
  }
  return true;
}

uint16_t apiVariant(const ApiCtx &c, int x, int y, int z) {
  if (x < c.box[0] || x > c.box[1] || y < c.box[2] || y > c.box[3] || z < c.box[4] || z > c.box[5]) return kVoid;
  const Structure &T = *c.S;
  int lx, ly, lz;
  if (!worldToLocal(T, c.P, x, y, z, lx, ly, lz)) return kVoid;
  const size_t li = T.index(lx, ly, lz);
  if (li >= T.idx.size() || T.vidx.size() != T.idx.size()) return kVoid;
  const uint16_t p = T.idx[li];
  if (p == kVoid || p >= T.palette.size() || T.palette[p].air) return kVoid;
  const uint16_t v = T.vidx[li];
  return v < T.variants.size() ? v : kVoid;
}
uintptr_t apiBlockOf(const ApiCtx &c, uint16_t v) {
  if (!sLookup || !sRegistry || !sFindState || v == kVoid || v >= c.S->variants.size()) return 0;
  std::lock_guard<std::mutex> lk(gApiMu);
  const uint64_t ep = hs::rt().worldEpoch.load(std::memory_order_relaxed);
  if (gApiCache.keep != c.S || gApiCache.rot != c.P.rot || gApiCache.mirror != c.P.mirror || gApiCache.epoch != ep) {
    gApiCache.keep = c.S;
    gApiCache.epoch = ep;
    gApiCache.rot = c.P.rot;
    gApiCache.mirror = c.P.mirror;
    gApiCache.blocks.assign(c.S->variants.size(), 0);
    gApiCache.done.assign(c.S->variants.size(), 0);
    gApiCache.tryAt.assign(c.S->variants.size(), -1e9);
    gApiCache.stDone.assign(c.S->variants.size(), 0);
    gApiCache.st.assign(c.S->variants.size(), {});
    gApiCache.unsupported.assign(c.S->variants.size(), {});
    gApiCache.xt = xf::get(c.S, c.P.rot & 3, c.P.mirror);  // game thread: builds the shared table if needed
  }
  
  
  if (!gApiCache.done[v] && nowMs() - gApiCache.tryAt[v] >= 1000.0) {
    const BlockVariant &var = c.S->variants[v];
    const std::string &nm = var.palette < c.S->palette.size() ? c.S->palette[var.palette].name : std::string();
    ResolveReport rep;
    const xf::Table *X = gApiCache.xt && v < gApiCache.xt->states.size() ? gApiCache.xt.get() : nullptr;
    if (!X) return 0;
    gApiCache.blocks[v] = resolveTransformed(var, nm, X->states[v], &rep);
    gApiCache.tryAt[v] = nowMs();
    if (gApiCache.blocks[v]) gApiCache.done[v] = 1;
    if (!gApiCache.stDone[v]) {
      gApiCache.st[v] = X->states[v];
      gApiCache.unsupported[v] = X->unsupported[v];
      gApiCache.stDone[v] = 1;
    }
  }
  return gApiCache.blocks[v];
}
// Transformed states of a variant (cached together with the game block). Empty when not resolved yet.
std::vector<BlockStateValue> apiStates(const ApiCtx &c, uint16_t v, std::string *unsupported = nullptr) {
  (void)apiBlockOf(c, v);
  std::lock_guard<std::mutex> lk(gApiMu);
  if (gApiCache.keep != c.S || v >= gApiCache.stDone.size() || !gApiCache.stDone[v]) {
    const auto X = xf::get(c.S, c.P.rot & 3, c.P.mirror);  // same shared table
    if (!X || v >= X->states.size()) return {};
    if (unsupported) *unsupported = X->unsupported[v];
    return X->states[v];
  }
  if (unsupported) *unsupported = gApiCache.unsupported[v];
  return gApiCache.st[v];
}
const BlockStateValue *findState(const std::vector<BlockStateValue> &st, const char *key) {
  for (const auto &sv : st)
    if (sv.key == key) return &sv;
  return nullptr;
}

int64_t stateValue(uintptr_t block, const std::string &key) {
  if (!sFindState) return -1;
  uintptr_t L = 0;
  if (!plausiblePtr(block) || !rd(block + 0x68, L) || !plausiblePtr(L)) return -1;
  HashedString hk(key.c_str());
  const uintptr_t st = reinterpret_cast<uintptr_t>(sFindState(reinterpret_cast<void *>(L), &hk));
  if (!plausiblePtr(st)) return -1;
  uint64_t id = 0;
  if (!rd(st + 8, id)) return -1;
  const uintptr_t endNode = L + 0x1b0;
  uintptr_t n = 0, cand = endNode;
  if (!rd(L + 0x1b0, n)) return -1;
  for (int guard = 0; n && guard < 64; ++guard) {
    uint64_t k = 0;
    if (!rd(n + 0x20, k)) { cand = endNode; break; }
    if (k < id) { if (!rd(n + 8, n)) n = 0; }
    else { cand = n; if (!rd(n, n)) n = 0; }
  }
  uint64_t ckey = 0;
  if (cand == endNode || !rd(cand + 0x20, ckey) || id < ckey) return -1;
  uint32_t inst[4];
  uint16_t data = 0;
  if (!rd(cand + 0x28, inst) || !rd(block + 0x128, data)) return -1;
  const uint32_t shift = (inst[2] - inst[1] + 1) & 31;
  return int64_t((uint32_t(data) & inst[3]) >> shift);
}
void copyOut(const std::string &s, char *buf, int len) {
  if (!buf || len <= 0) return;
  const size_t n = std::min(s.size(), size_t(len - 1));
  std::memcpy(buf, s.data(), n);
  buf[n] = 0;
}

int apiExpectedAt(int x, int y, int z, uintptr_t *outBlock) {
  if (outBlock) *outBlock = 0;
  ApiCtx c;
  if (!apiSnapshot(c)) return 0;
  const uint16_t v = apiVariant(c, x, y, z);
  if (v == kVoid) return 0;
  if (outBlock) *outBlock = apiBlockOf(c, v);
  return 1;
}
int apiPlaceTarget(int *x, int *y, int *z) {
  if (!x || !y || !z) return 0;
  ApiCtx c;
  if (!apiSnapshot(c)) return 0;
  const uint16_t v = apiVariant(c, *x, *y, *z);
  if (v == kVoid) return 0;
  const auto st = apiStates(c, v);
  const uint16_t pal = c.S->variants[v].palette;
  
  if (const auto *u = findState(st, "upper_block_bit"); u && u->i == 1) {
    const uint16_t b = apiVariant(c, *x, *y - 1, *z);
    if (b != kVoid && c.S->variants[b].palette == pal) {
      *y -= 1;
      return 1;
    }
    return 0;
  }
  
  if (const auto *h = findState(st, "head_piece_bit"); h && h->i == 1) {
    const auto *d = findState(st, "direction");
    if (!d || d->i < 0 || d->i > 3) return 0;
    static const int kdx[4] = {0, -1, 0, 1}, kdz[4] = {1, 0, -1, 0};
    const int fx = *x - kdx[d->i], fz = *z - kdz[d->i];
    const uint16_t b = apiVariant(c, fx, *y, fz);
    if (b != kVoid && c.S->variants[b].palette == pal) {
      *x = fx;
      *z = fz;
      return 1;
    }
  }
  return 0;
}
int apiOrientMatch(int x, int y, int z, uintptr_t cand) {
  ApiCtx c;
  if (!apiSnapshot(c) || !plausiblePtr(cand)) return -1;
  const uint16_t v = apiVariant(c, x, y, z);
  if (v == kVoid) return -1;
  const uintptr_t exp = apiBlockOf(c, v);
  if (!plausiblePtr(exp)) return -1;
  if (exp == cand) return 1;
  uintptr_t le = 0, lc = 0;
  if (!rd(exp + 0x68, le) || !rd(cand + 0x68, lc)) return -1;
  if (le != lc) return 0;
  const BlockVariant &var = c.S->variants[v];
  const std::string &nm = var.palette < c.S->palette.size() ? c.S->palette[var.palette].name : std::string();
  CmpCtx ctx{{exp, cand}, &nm};
  const auto r = states::compareStates(apiStates(c, v), nm, &cmpValue, &ctx);
  // orientation match: only states the game decides or that are changed later may differ
  return states::planScore(r) >= 2 ? 1 : 0;
}
uintptr_t apiWorldBlock(int x, int y, int z) {
  if (!sGetBlock) return 0;
  const uintptr_t region = currentRegion();
  if (!region) return 0;
  return blockAt(region, x, y, z);
}
int apiBlockName(uintptr_t block, char *buf, int len) {
  if (!plausiblePtr(block)) return 0;
  if (gAir && block == gAir) { copyOut("air", buf, len); return 1; }
  if (!names::ready()) return 0;
  const std::string *n = names::nameOf(block);
  if (!n) return 0;
  copyOut(*n, buf, len);
  return 1;
}
int apiExpectedName(int x, int y, int z, char *buf, int len) {
  ApiCtx c;
  if (!apiSnapshot(c)) return 0;
  const uint16_t v = apiVariant(c, x, y, z);
  if (v == kVoid) return 0;
  const uint16_t p = c.S->variants[v].palette;
  if (p >= c.S->palette.size()) return 0;
  const auto &e = c.S->palette[p];
  copyOut(e.label.empty() ? e.name : e.label, buf, len);
  return 1;
}
int64_t apiStateValue(uintptr_t block, const char *key) {
  if (!key || !sFindState) return -1;
  return stateValue(block, std::string(key));
}
const StructuraApiV1 kApi = {STRUCTURA_API_VERSION, uint32_t(sizeof(StructuraApiV1)), &apiExpectedAt,
                              &apiPlaceTarget, &apiOrientMatch, &apiWorldBlock, &apiBlockName, &apiExpectedName,
                              &apiStateValue};
}  

const StructuraApiV1 *api() { return &kApi; }

namespace {
// string value index -> name, by asking the game's own state parser (diagnostics only)
std::string stateValueText(uintptr_t block, const BlockStateValue &sv, int64_t idx, const std::string &name) {
  if (idx < 0) return "-";
  if (sv.type != nbt::String) return std::to_string(idx);
  static const char *const kVocab[] = {"north", "east", "south", "west", "up", "down", "top", "bottom", "unknown",
                                       "x", "y", "z", "standing", "hanging", "side", "multiple", "floor", "ceiling",
                                       "single_wall", "double_wall", "down_east_west", "up_north_south",
                                       "up_east_west", "down_north_south", "down_east", "down_north", "down_south",
                                       "down_west", "up_east", "up_north", "up_south", "up_west", "west_up",
                                       "east_up", "north_up", "south_up"};
  for (const char *w : kVocab) {
    BlockStateValue t;
    t.key = sv.key;
    t.type = nbt::String;
    t.s = w;
    uintptr_t b = block;
    if (applyState(b, t) == SetRes::Ok && stateValue(b, sv.key) == idx) return w;
  }
  (void)name;
  return "#" + std::to_string(idx);
}
}  // namespace

int layerGate(int x, int y, int z) {
  ApiCtx c;
  if (!apiSnapshot(c)) return 0;
  int dx, dz;
  rotatedSize(*c.S, c.P.rot, dx, dz);
  if (x < c.P.ox || x >= c.P.ox + dx || y < c.P.oy || y >= c.P.oy + c.S->sy || z < c.P.oz || z >= c.P.oz + dz)
    return 0;
  return (x >= c.box[0] && x <= c.box[1] && y >= c.box[2] && y <= c.box[3] && z >= c.box[4] && z <= c.box[5]) ? 1 : 2;
}

bool expectAt(int x, int y, int z, Expect &out) {
  out = Expect{};
  ApiCtx c;
  if (!apiSnapshot(c)) return false;
  const uint16_t v = apiVariant(c, x, y, z);
  if (v == kVoid) return false;
  const BlockVariant &var = c.S->variants[v];
  out.ok = true;
  out.variant = v;
  out.x = x;
  out.y = y;
  out.z = z;
  (void)worldToLocal(*c.S, c.P, x, y, z, out.lx, out.ly, out.lz);
  out.name = var.palette < c.S->palette.size() ? c.S->palette[var.palette].name : std::string();
  out.block = apiBlockOf(c, v);
  out.states = apiStates(c, v, &out.unsupported);
  out.original = var.states;
  for (const auto &sv : out.states) {
    const auto cl = states::ruleFor(sv.key, out.name).cls;
    if (cl == states::Cls::Placement || cl == states::Cls::Part) out.directional = true;
  }
  const auto comp = states::companionOf(out.states, out.name);
  if (comp.has) {
    out.companion = true;
    out.cx = x + comp.dx;
    out.cy = y + comp.dy;
    out.cz = z + comp.dz;
    out.companionWhat = comp.what;
    const uint16_t cv = apiVariant(c, out.cx, out.cy, out.cz);
    out.companionInStructure = cv != kVoid && c.S->variants[cv].palette == var.palette;
    if (out.companionInStructure) out.companionBlock = apiBlockOf(c, cv);
  }
  return true;
}

states::Compared compareWorld(const Expect &e, uintptr_t world) {
  states::Compared r;
  if (!plausiblePtr(world) || (gAir && world == gAir)) {
    r.match = states::Match::Missing;
    return r;
  }
  if (e.block && world == e.block) {
    r.match = states::Match::Exact;
    return r;
  }
  bool same = false;
  uintptr_t le = 0, lw = 0;
  if (plausiblePtr(e.block) && rd(e.block + 0x68, le) && rd(world + 0x68, lw) && le && le == lw) {
    same = true;
  } else if (names::ready()) {
    const std::string *n = names::nameOf(world);
    same = n && states::sameBlockType(*n, e.name);
  }
  if (!same || !plausiblePtr(e.block)) {
    r.match = states::Match::WrongBlock;
    return r;
  }
  CmpCtx ctx{{e.block, world}, &e.name};
  return states::compareStates(e.states, e.name, &cmpValue, &ctx);
}

std::string describeWorld(const Expect &e, uintptr_t world, bool expectedSide) {
  if (!plausiblePtr(world)) return "-";
  std::string out;
  CmpCtx ctx{{e.block, world}, &e.name};
  for (const auto &sv : e.states) {
    if (states::ruleFor(sv.key, e.name).cls == states::Cls::Generated) continue;
    const int64_t idx = cmpValue(&ctx, expectedSide ? 0 : 1, sv);
    if (!out.empty()) out += ' ';
    out += sv.key.rfind("minecraft:", 0) == 0 ? sv.key.substr(10) : sv.key;
    out += '=';
    out += stateValueText(expectedSide ? e.block : world, sv, idx, e.name);
  }
  return out.empty() ? std::string("(no states)") : out;
}

int64_t blockStateValue(uintptr_t block, const Expect &e, const BlockStateValue &sv) {
  CmpCtx ctx{{block, block}, &e.name};
  return cmpValue(&ctx, 0, sv);
}

}  
