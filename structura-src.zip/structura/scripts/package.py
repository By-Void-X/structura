"""Packs manifest.json + .so into a .levipack and checks the result (skill rule 9)."""
import json, struct, subprocess, sys, zipfile
from pathlib import Path

so, manifest, out = map(Path, sys.argv[1:4])
m = json.loads(manifest.read_text())
data = so.read_bytes()
assert data[:4] == b"\x7fELF", "not ELF"
assert struct.unpack_from("<H", data, 18)[0] == 0xB7, "not AArch64"
assert m["type"] == "preload-native" and m["entry"] == so.name, "manifest/entry mismatch"
syms = subprocess.run(["readelf", "--dyn-syms", "-W", str(so)], capture_output=True, text=True).stdout
assert "PLGetModRegistration" in syms, "PLGetModRegistration not exported!"
out.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.writestr("manifest.json", json.dumps(m, indent=2, ensure_ascii=False) + "\n")
    z.write(so, so.name)
with zipfile.ZipFile(out) as z:
    names = z.namelist()
    assert sorted(names) == sorted(["manifest.json", so.name]), names
    assert z.getinfo(so.name).file_size == len(data)
print(f"OK: {out} ({out.stat().st_size} bytes) -> {names}")
