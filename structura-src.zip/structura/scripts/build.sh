set -euo pipefail
cd "$(dirname "$0")/.."
NDK="${NDK:-${ANDROID_NDK_HOME:-$HOME/.cache/ndk/android-ndk-r28c}}"
if [ ! -d "$NDK" ]; then echo "NDK not found at $NDK"; exit 1; fi
SAMPLES_VERSION=1.26.50.4
mkdir -p build
SAMPLES="${BEDROCK_SAMPLES:-build/bedrock-samples-$SAMPLES_VERSION.zip}"
if [ ! -e "$SAMPLES" ]; then
  curl -fsSL -o "$SAMPLES.part" "https://github.com/Mojang/bedrock-samples/archive/refs/tags/v$SAMPLES_VERSION.zip"
  mv "$SAMPLES.part" "$SAMPLES"
fi
python3 tools/gen_block_pack.py "$SAMPLES" build/block_pack.zip
# Java Edition -> Bedrock block table (for .nbt/.litematic/.schem/.schematic), PrismarineJS/minecraft-data (MIT)
MCDATA_REV=201ca802a1b2c968b02e7fa5b31dd74e8bff3d8b
MCDATA="https://raw.githubusercontent.com/PrismarineJS/minecraft-data/$MCDATA_REV/data"
for f in "bedrock/1.26.30/blocksJ2B.json:build/blocksJ2B.json" "pc/common/legacy.json:build/legacy.json"; do
  if [ ! -s "${f#*:}" ]; then
    curl -fsSL -o "${f#*:}.part" "$MCDATA/${f%%:*}"
    mv "${f#*:}.part" "${f#*:}"
  fi
done
python3 tools/gen_java_map.py build/blocksJ2B.json build/legacy.json "$SAMPLES" build/java_map.bin
cmake -S . -B build -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-28 -DCMAKE_BUILD_TYPE=Release
cmake --build build -j"$(nproc)" --target Structura
python3 scripts/package.py build/libStructura.so manifest.json release/Structura.levipack
